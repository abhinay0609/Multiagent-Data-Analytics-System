"""Statistical outlier detection using interpretable MVP methods."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import numpy as np
import pandas as pd

from schemas.analysis_schema import AnomalyResult, FindingImportance


def detect_anomalies(
    values: Sequence[float] | pd.Series,
    *,
    entities: Sequence[Any] | None = None,
    entity_column: str | None = None,
    metric_name: str = "value",
    methods: Sequence[str] = ("iqr", "z_score", "rolling_mean"),
    z_score_threshold: float = 3.0,
    rolling_window: int = 3,
    rolling_deviation_threshold_percent: float = 50.0,
) -> list[AnomalyResult]:
    """Flag outliers using IQR, absolute z-score, and prior rolling mean.

    Rolling-mean deviation compares each observation with preceding values
    only, avoiding the observed value contaminating its own expected baseline.
    """
    if not np.isfinite(z_score_threshold) or z_score_threshold <= 0:
        raise ValueError("z_score_threshold must be a positive finite number.")
    if (
        isinstance(rolling_window, bool)
        or not isinstance(rolling_window, int)
        or rolling_window < 1
    ):
        raise ValueError("rolling_window must be a positive integer.")
    if (
        not np.isfinite(rolling_deviation_threshold_percent)
        or rolling_deviation_threshold_percent < 0
    ):
        raise ValueError(
            "rolling_deviation_threshold_percent must be finite and non-negative."
        )
    selected_methods = tuple(method.casefold() for method in methods)
    allowed_methods = {"iqr", "z_score", "rolling_mean"}
    unknown_methods = set(selected_methods) - allowed_methods
    if unknown_methods:
        raise ValueError(
            "Unsupported anomaly methods: " + ", ".join(sorted(unknown_methods))
        )

    series = pd.to_numeric(pd.Series(values), errors="coerce")
    raw = series.to_numpy(dtype=float, na_value=np.nan)
    valid_offsets = np.flatnonzero(np.isfinite(raw))
    clean_values = raw[valid_offsets]
    if entities is not None and len(entities) != len(series):
        raise ValueError("entities must have the same length as values.")
    labels = (
        [str(entities[offset]) for offset in valid_offsets]
        if entities is not None
        else [str(offset) for offset in valid_offsets]
    )
    if clean_values.size < 4:
        return []

    signals: list[tuple[int, float, float, str, str]] = []
    if "iqr" in selected_methods:
        q1, q3 = np.percentile(clean_values, [25, 75])
        spread = float(q3 - q1)
        lower, upper = float(q1 - 1.5 * spread), float(q3 + 1.5 * spread)
        for offset in np.flatnonzero((clean_values < lower) | (clean_values > upper)):
            expected = float(np.median(clean_values))
            signals.append(
                (
                    int(offset),
                    expected,
                    float(clean_values[offset] - expected),
                    "iqr",
                    f"The value is outside the IQR fences [{lower:g}, {upper:g}].",
                )
            )

    if "z_score" in selected_methods:
        mean = float(np.mean(clean_values))
        standard_deviation = float(np.std(clean_values))
        if standard_deviation > 0:
            z_scores = np.abs((clean_values - mean) / standard_deviation)
            for offset in np.flatnonzero(z_scores > z_score_threshold):
                signals.append(
                    (
                        int(offset),
                        mean,
                        float(clean_values[offset] - mean),
                        "z_score",
                        f"The absolute z-score exceeds {z_score_threshold:g}.",
                    )
                )

    if "rolling_mean" in selected_methods:
        for offset in range(rolling_window, clean_values.size):
            prior = clean_values[offset - rolling_window:offset]
            expected = float(np.mean(prior))
            if expected == 0:
                continue
            deviation_percent = abs(
                float((clean_values[offset] - expected) / expected * 100.0)
            )
            if deviation_percent > rolling_deviation_threshold_percent:
                signals.append(
                    (
                        offset,
                        expected,
                        float(clean_values[offset] - expected),
                        "rolling_mean",
                        "The value deviates from its prior rolling mean by "
                        f"{deviation_percent:.2f}%, exceeding the configured "
                        f"{rolling_deviation_threshold_percent:g}% threshold.",
                    )
                )

    by_offset: dict[int, list[tuple[float, float, str, str]]] = {}
    for offset, expected, deviation, method, evidence in signals:
        by_offset.setdefault(offset, []).append(
            (expected, deviation, method, evidence)
        )

    results: list[AnomalyResult] = []
    for offset, matches in sorted(by_offset.items()):
        observed = float(clean_values[offset])
        methods_found = list(dict.fromkeys(match[2] for match in matches))
        expected = matches[0][0]
        deviation = observed - expected
        method_label = ", ".join(methods_found)
        evidence = " ".join(match[3] for match in matches)
        severity = (
            FindingImportance.HIGH
            if any(method in {"iqr", "z_score"} for method in methods_found)
            else FindingImportance.MEDIUM
        )
        results.append(
            AnomalyResult(
                entity=labels[offset],
                entity_column=entity_column,
                metric_name=metric_name,
                observed_value=observed,
                expected_value=expected,
                deviation=deviation,
                method=method_label,
                source_columns=(
                    [entity_column, metric_name]
                    if entity_column is not None
                    else [metric_name]
                ),
                severity=severity,
                evidence=evidence,
            )
        )
    return results