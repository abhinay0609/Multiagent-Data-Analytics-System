"""Create deterministic, evidence-linked insights from calculated outputs."""

from __future__ import annotations

from collections.abc import Sequence

from schemas.analysis_schema import (
    AnalyticalFinding,
    AnomalyResult,
    ComparisonResult,
    ContributionResult,
    EvidenceReference,
    FindingImportance,
    FindingType,
    TrendResult,
)


def generate_insights(
    *,
    comparisons: Sequence[ComparisonResult] = (),
    trends: Sequence[TrendResult] = (),
    anomalies: Sequence[AnomalyResult] = (),
    contributions: Sequence[ContributionResult] = (),
    referenced_tables: Sequence[str] = (),
) -> list[AnalyticalFinding]:
    """Turn deterministic results into qualified findings with evidence."""
    findings: list[AnalyticalFinding] = []
    for comparison in comparisons:
        findings.append(
            AnalyticalFinding(
                title=f"{comparison.name} comparison",
                finding_type=FindingType.COMPARISON,
                importance=FindingImportance.MEDIUM,
                description=comparison.interpretation,
                evidence=[
                    EvidenceReference(
                        description="Comparison calculated from returned rows.",
                        table_names=list(referenced_tables),
                        columns=(
                            comparison.source_columns
                            or [comparison.name]
                        ),
                        values={
                            "baseline": comparison.baseline_value,
                            "target": comparison.target_value,
                            "absolute_change": comparison.absolute_change,
                        },
                    )
                ],
                confidence=1.0,
            )
        )
    for trend in trends:
        findings.append(
            AnalyticalFinding(
                title=f"{trend.metric_name} trend",
                finding_type=FindingType.TREND,
                importance=FindingImportance.MEDIUM,
                description=trend.interpretation,
                evidence=[
                    EvidenceReference(
                        description=(
                            "Trend calculated from ordered, returned rows."
                        ),
                        table_names=list(referenced_tables),
                        columns=(
                            trend.source_columns or [trend.metric_name]
                        ),
                        values={
                            "start_value": trend.start_value,
                            "end_value": trend.end_value,
                            "absolute_change": trend.absolute_change,
                            "periods": trend.periods,
                        },
                    )
                ],
                confidence=1.0,
            )
        )
    for anomaly in anomalies:
        findings.append(
            AnalyticalFinding(
                title=f"Unusual {anomaly.metric_name} value",
                finding_type=FindingType.ANOMALY,
                importance=anomaly.severity,
                description=(
                    f"{anomaly.entity} has an unusual {anomaly.metric_name} "
                    f"value under the {anomaly.method} method."
                ),
                evidence=[
                    EvidenceReference(
                        description=anomaly.evidence,
                        table_names=list(referenced_tables),
                        columns=anomaly.source_columns or [anomaly.metric_name],
                        values={
                            "entity": anomaly.entity,
                            "observed_value": anomaly.observed_value,
                            "expected_value": anomaly.expected_value,
                        },
                    )
                ],
                confidence=1.0,
            )
        )
    for contribution in contributions:
        findings.append(
            AnalyticalFinding(
                title=f"Observed contribution from {contribution.segment}",
                finding_type=FindingType.CONTRIBUTION,
                importance=FindingImportance.MEDIUM,
                description=(
                    f"{contribution.segment} is an observed contributing "
                    f"factor at the {contribution.dimension} level."
                ),
                evidence=[
                    EvidenceReference(
                        description=contribution.evidence,
                        table_names=list(referenced_tables),
                        columns=contribution.source_columns,
                        values={
                            "segment": contribution.segment,
                            "baseline_value": contribution.baseline_value,
                            "target_value": contribution.target_value,
                            "absolute_change": contribution.absolute_change,
                            "contribution_percentage": (
                                contribution.contribution_percentage
                            ),
                            "share_percentage": contribution.share_percentage,
                        },
                    )
                ],
                confidence=1.0,
                caveat=(
                    "This is an evidence-based contribution, not proof of "
                    "causality."
                ),
            )
        )
    return findings