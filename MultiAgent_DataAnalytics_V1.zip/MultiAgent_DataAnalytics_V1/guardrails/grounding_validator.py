"""Check whether an answer is supported by executed query results."""

from __future__ import annotations

from html import escape as html_escape
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping, Sequence


@dataclass(frozen=True)
class GroundingIssue:
    """One unsupported or insufficiently qualified answer claim."""

    code: str
    message: str


@dataclass(frozen=True)
class GroundingResult:
    """Result of validating answer claims against query evidence."""

    grounded: bool
    issues: tuple[GroundingIssue, ...]


class GroundingValidator:
    """Validate numbers, metrics, entities, and causal language in answers."""

    _BUSINESS_ENTITY_TABLE_NAMES = frozenset(
        {"category", "customer", "employee", "product", "supplier"}
    )
    _NUMBER_PATTERN = re.compile(
        r"(?<![\w.])[-+]?"
        r"(?:\d{1,3}(?:,\d{3})+|\d+)"
        r"(?:\.\d+)?%?"
        r"(?!\w)"
    )
    _METRIC_PATTERNS = {
        "sales": re.compile(r"\bsales?\b", re.IGNORECASE),
        "revenue": re.compile(r"\brevenue\b", re.IGNORECASE),
        "profit": re.compile(r"\bprofits?\b", re.IGNORECASE),
        "margin": re.compile(r"\bmargins?\b", re.IGNORECASE),
        "quantity": re.compile(r"\bquantit(?:y|ies)\b", re.IGNORECASE),
        "units sold": re.compile(r"\bunits?\s+sold\b", re.IGNORECASE),
        "order count": re.compile(
            r"\b(?:number|count)\s+of\s+orders?\b|\border\s+count\b",
            re.IGNORECASE,
        ),
        "growth": re.compile(r"\bgrowth\b", re.IGNORECASE),
        "percentage": re.compile(
            r"\bpercent(?:age)?\b|\brate\b",
            re.IGNORECASE,
        ),
    }
    _RECOMMENDATION_PATTERN = re.compile(
        r"\b(?:recommend(?:ation)?|should|must|need\s+to|"
        r"suggest(?:s|ed)?|consider)\b",
        re.IGNORECASE,
    )
    _CAUSAL_PATTERN = re.compile(
        r"\b(?:caused?\s+by|because\s+of|due\s+to|"
        r"resulted?\s+from|driven\s+by|leads?\s+to)\b",
        re.IGNORECASE,
    )
    _CAUSAL_QUALIFIER_PATTERN = re.compile(
        r"\b(?:may|might|could|possibly|potentially|"
        r"suggests?|appears?|associated|correlated|"
        r"correlates|not\s+enough\s+evidence)\b",
        re.IGNORECASE,
    )
    _INSUFFICIENT_DATA_PATTERN = re.compile(
        r"\b(?:no\s+(?:matching\s+)?(?:query\s+)?results?|"
        r"no\s+data|no\s+records?|insufficient\s+data|"
        r"not\s+enough\s+data|could\s+not\s+determine|"
        r"cannot\s+determine|can't\s+determine|"
        r"unable\s+to\s+determine|data\s+is\s+unavailable)\b",
        re.IGNORECASE,
    )

    def validate(
        self,
        answer: str,
        query_results: Sequence[Mapping[str, Any]],
        *,
        result_columns: Sequence[str] | None = None,
        referenced_tables: Sequence[str] = (),
        known_tables: Sequence[str] = (),
        known_columns: Sequence[str] = (),
        user_query: str | None = None,
        data_sufficient: bool | None = None,
        result_count: int | None = None,
    ) -> GroundingResult:
        """Validate an answer against rows, columns, and schema metadata.

        ``known_tables`` and ``known_columns`` are optional schema names;
        supplying them lets this validator detect answer references that
        were not part of the executed query.
        """
        if not isinstance(answer, str):
            raise TypeError("answer must be a string.")
        if not isinstance(query_results, Sequence) or isinstance(
            query_results,
            (str, bytes),
        ):
            raise TypeError("query_results must be a sequence of mappings.")
        if any(not isinstance(row, Mapping) for row in query_results):
            raise TypeError("Every query result must be a mapping.")

        clean_answer = answer.strip()
        issues: list[GroundingIssue] = []
        rows = list(query_results)
        columns = self._normalize_names(
            result_columns
            if result_columns is not None
            else tuple(
                dict.fromkeys(
                    key
                    for row in rows
                    for key in row
                )
            ),
            "result_columns",
        )
        referenced = self._normalize_names(
            referenced_tables,
            "referenced_tables",
        )
        known_table_names = self._normalize_names(
            known_tables,
            "known_tables",
        )
        known_column_names = self._normalize_names(
            known_columns,
            "known_columns",
        )

        if data_sufficient is not None and not isinstance(
            data_sufficient,
            bool,
        ):
            raise TypeError("data_sufficient must be a boolean or None.")
        if result_count is not None and (
            isinstance(result_count, bool)
            or not isinstance(result_count, int)
            or result_count < 0
        ):
            raise ValueError("result_count must be a non-negative integer.")

        sufficient = bool(rows) if data_sufficient is None else data_sufficient

        if not clean_answer:
            issues.append(
                GroundingIssue(
                    "EMPTY_ANSWER",
                    "The answer is empty.",
                )
            )

        available_numbers = self._collect_numbers(rows)
        text_evidence_values = [
            str(value)
            for row in rows
            for value in row.values()
            if isinstance(value, str) and value
        ]
        if user_query:
            available_numbers.update(
                self._extract_requested_limits(user_query)
            )
        available_numbers.add(
            Decimal(len(rows) if result_count is None else result_count)
        )

        for match in self._NUMBER_PATTERN.finditer(clean_answer):
            token = match.group()
            if self._is_list_marker(clean_answer, match.start(), match.end()):
                continue
            if self._is_calendar_year(token):
                continue
            number = self._parse_number(token)
            if number is not None and not self._number_is_grounded(
                number,
                available_numbers,
                is_percentage=token.endswith("%"),
            ) and not self._number_is_in_text_evidence(
                clean_answer,
                match.start(),
                match.end(),
                text_evidence_values,
            ):
                issues.append(
                    GroundingIssue(
                        "UNSUPPORTED_NUMBER",
                        f"Number '{token}' does not appear in the query "
                        "results or request.",
                    )
                )

        result_column_set = {
            column.casefold()
            for column in columns
        }
        observed_columns = {
            str(key).casefold()
            for row in rows
            for key in row
        }
        if (
            result_columns is not None
            and rows
            and observed_columns != result_column_set
        ):
            issues.append(
                GroundingIssue(
                    "RESULT_COLUMNS_MISMATCH",
                    "Declared result columns do not match the query "
                    "result records.",
                )
            )

        for metric, pattern in self._METRIC_PATTERNS.items():
            if pattern.search(clean_answer) and not any(
                self._contains_words(
                    self._normalize_text(column),
                    metric,
                )
                for column in result_column_set
            ):
                issues.append(
                    GroundingIssue(
                        "UNSUPPORTED_METRIC",
                        f"Metric '{metric}' is not represented in the "
                        "query result columns.",
                    )
                )

        if known_table_names:
            referenced_set = {
                table.casefold()
                for table in referenced
            }
            known_table_set = {
                table.casefold()
                for table in known_table_names
            }
            for table in referenced_set - known_table_set:
                issues.append(
                    GroundingIssue(
                        "UNKNOWN_REFERENCED_TABLE",
                        f"Referenced table '{table}' is not in the "
                        "known schema.",
                    )
                )
            for table in known_table_names:
                if (
                    self._contains_table_reference(clean_answer, table)
                    and table.casefold() not in referenced_set
                ):
                    issues.append(
                        GroundingIssue(
                            "UNQUERIED_TABLE",
                            f"Table '{table}' was mentioned but was not "
                            "referenced by the executed query.",
                        )
                    )

        if known_column_names:
            for column in known_column_names:
                if (
                    self._contains_identifier(clean_answer, column)
                    and column.casefold() not in result_column_set
                ):
                    issues.append(
                        GroundingIssue(
                            "UNQUERIED_COLUMN",
                            f"Column '{column}' was mentioned but was not "
                            "returned by the executed query.",
                        )
                    )

        if self._RECOMMENDATION_PATTERN.search(clean_answer):
            has_evidence_reference = (
                bool(rows)
                and (
                    any(
                        self._contains_identifier(clean_answer, column)
                        for column in columns
                    )
                    or any(
                        self._parse_number(token) in available_numbers
                        for token in self._NUMBER_PATTERN.findall(
                            clean_answer
                        )
                        if self._parse_number(token) is not None
                    )
                )
            )
            if not has_evidence_reference:
                issues.append(
                    GroundingIssue(
                        "UNSUPPORTED_RECOMMENDATION",
                        "Recommendations must cite available query "
                        "evidence.",
                    )
                )

        for sentence in re.split(r"(?<=[.!?])\s+", clean_answer):
            if (
                self._CAUSAL_PATTERN.search(sentence)
                and not self._CAUSAL_QUALIFIER_PATTERN.search(sentence)
            ):
                issues.append(
                    GroundingIssue(
                        "UNQUALIFIED_CAUSAL_CLAIM",
                        "Causal claims must be qualified because query "
                        "results alone do not establish causation.",
                    )
                )

        if (
            not sufficient
            and not self._INSUFFICIENT_DATA_PATTERN.search(clean_answer)
        ):
            issues.append(
                GroundingIssue(
                    "INSUFFICIENT_DATA_NOT_DISCLOSED",
                    "The answer must disclose that the available data is "
                    "insufficient.",
                )
            )

        unique_issues = tuple(
            dict.fromkeys(issues)
        )
        return GroundingResult(
            grounded=not unique_issues,
            issues=unique_issues,
        )

    @staticmethod
    def _normalize_names(
        values: Sequence[str],
        label: str,
    ) -> tuple[str, ...]:
        if isinstance(values, (str, bytes)):
            raise TypeError(f"{label} must be a sequence of strings.")
        normalized: list[str] = []
        for value in values:
            if not isinstance(value, str):
                raise TypeError(f"{label} must contain only strings.")
            clean_value = value.strip()
            if clean_value:
                normalized.append(clean_value)
        return tuple(normalized)

    @classmethod
    def _collect_numbers(
        cls,
        rows: Sequence[Mapping[str, Any]],
    ) -> set[Decimal]:
        numbers: set[Decimal] = set()
        for row in rows:
            for value in row.values():
                if isinstance(value, bool):
                    continue
                if isinstance(value, (int, float, Decimal)):
                    parsed = cls._parse_number(str(value))
                    if parsed is not None:
                        numbers.add(parsed)
        return numbers

    @classmethod
    def _extract_requested_limits(cls, text: str) -> set[Decimal]:
        return {
            number
            for token in re.findall(
                r"\b(?:top|bottom|first|last)\s+"
                r"(\d+)\b",
                text,
                re.IGNORECASE,
            )
            if (number := cls._parse_number(token)) is not None
        }

    @staticmethod
    def _parse_number(token: str) -> Decimal | None:
        try:
            return Decimal(token.replace(",", "").removesuffix("%"))
        except InvalidOperation:
            return None

    @staticmethod
    def _number_is_grounded(
        number: Decimal,
        available_numbers: set[Decimal],
        is_percentage: bool = False,
    ) -> bool:
        if number in available_numbers:
            return True
        return is_percentage and number / 100 in available_numbers

    @staticmethod
    def _number_is_in_text_evidence(
        answer: str,
        start: int,
        end: int,
        evidence_values: Sequence[str],
    ) -> bool:
        """Accept digits only when they are inside a returned text value."""
        for value in evidence_values:
            escaped_value = (
                html_escape(value)
                .replace("|", r"\|")
                .replace("\r", " ")
                .replace("\n", " ")
            )
            for candidate in {value, escaped_value}:
                offset = answer.find(candidate)
                while offset >= 0:
                    if offset <= start and end <= offset + len(candidate):
                        return True
                    offset = answer.find(candidate, offset + 1)
        return False

    @staticmethod
    def _is_list_marker(
        text: str,
        start: int,
        end: int,
    ) -> bool:
        line_start = text.rfind("\n", 0, start) + 1
        line_prefix = text[line_start:start]
        following_text = text[end:]
        return (
            not line_prefix.strip()
            and bool(re.match(r"^[.)]\s", following_text))
        )

    @staticmethod
    def _is_calendar_year(token: str) -> bool:
        parsed = GroundingValidator._parse_number(token)
        return (
            parsed is not None
            and parsed == parsed.to_integral_value()
            and 1900 <= parsed <= 2100
        )

    @staticmethod
    def _normalize_text(value: str) -> str:
        spaced_value = re.sub(
            r"(?<=[a-z0-9])(?=[A-Z])",
            " ",
            value,
        )
        return re.sub(
            r"[^a-z0-9]+",
            " ",
            spaced_value.casefold(),
        ).strip()

    @classmethod
    def _contains_words(
        cls,
        normalized_column: str,
        phrase: str,
    ) -> bool:
        normalized_phrase = cls._normalize_text(phrase)
        return (
            f" {normalized_phrase} "
            in f" {normalized_column} "
        )

    @staticmethod
    def _contains_identifier(text: str, identifier: str) -> bool:
        return bool(
            re.search(
                rf"(?<![A-Za-z0-9_]){re.escape(identifier)}"
                rf"(?![A-Za-z0-9_])",
                text,
                re.IGNORECASE,
            )
        )

    @classmethod
    def _contains_table_reference(cls, text: str, table: str) -> bool:
        identifier = re.escape(table)
        explicit_reference = re.search(
            rf"(?:`{identifier}`|\b(?:table|from|join)\s+{identifier}\b|"
            rf"\b{identifier}\s+table\b|\b[A-Za-z_]\w*\.{identifier}\b)",
            text,
            re.IGNORECASE,
        )
        if explicit_reference:
            return True
        if table.casefold() in cls._BUSINESS_ENTITY_TABLE_NAMES:
            return False
        return cls._contains_identifier(text, table)


grounding_validator = GroundingValidator()