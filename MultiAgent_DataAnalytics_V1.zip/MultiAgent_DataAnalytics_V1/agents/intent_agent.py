"""Understand and structure a business analytics request."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Mapping, Sequence

from guardrails import (
    InputGuardrail,
    InputGuardrailResult,
    RequestCategory,
    input_guardrail,
)
from schemas.intent_schema import (
    ComparisonRequirement,
    ComparisonType,
    IntentResult,
    QueryIntent,
)
from schemas.user_schema import UserRole

from agents._common import (
    AgentLLM,
    call_model_json,
    get_default_llm,
    render_prompt,
)


class AgentRequestBlockedError(ValueError):
    """Raised when deterministic input policy blocks agent processing."""

    def __init__(self, result: InputGuardrailResult) -> None:
        self.guardrail_result = result
        super().__init__(result.reason)


class IntentAgent:
    """Convert an approved natural-language question into a typed intent."""

    def __init__(
        self,
        llm: AgentLLM | None = None,
        input_guardrail_instance: InputGuardrail | None = None,
    ) -> None:
        self._llm = llm if llm is not None else get_default_llm()
        self._input_guardrail = (
            input_guardrail_instance
            if input_guardrail_instance is not None
            else input_guardrail
        )

    def run(
        self,
        user_question: str,
        user_role: UserRole | str,
        available_databases: Sequence[Mapping[str, Any] | Any],
        *,
        database_name: str = "northwind",
        conversation_context: str = "",
        defer_human_approval: bool = False,
    ) -> IntentResult:
        """Classify a user request after deterministic input guardrails."""
        if not isinstance(user_question, str):
            raise TypeError("user_question must be a string.")
        if not isinstance(database_name, str) or not database_name.strip():
            raise ValueError("database_name must be a non-empty string.")
        if not isinstance(defer_human_approval, bool):
            raise TypeError("defer_human_approval must be a boolean.")
        role_name = _role_name(user_role)
        database_descriptions = _public_database_descriptions(
            available_databases
        )
        if not database_descriptions:
            raise ValueError("At least one available database is required.")

        guardrail = self._input_guardrail.validate(
            user_question,
            database_name=database_name,
        )
        if not guardrail.accepted or (
            guardrail.requires_human_approval
            and not defer_human_approval
        ):
            raise AgentRequestBlockedError(guardrail)

        clean_question = guardrail.normalized_input
        if clean_question is None:
            raise ValueError("Input guardrail returned no normalized request.")

        if guardrail.requires_clarification:
            comparison = ComparisonRequirement()
            intent = QueryIntent.UNKNOWN
            if guardrail.category == RequestCategory.CLARIFICATION_REQUIRED:
                intent = QueryIntent.COMPARISON
                comparison = ComparisonRequirement(
                    required=True,
                    comparison_type=ComparisonType.PERIOD_OVER_PERIOD,
                )
            return IntentResult(
                original_question=clean_question,
                normalized_question=clean_question,
                intent=intent,
                comparison=comparison,
                requires_clarification=True,
                clarification_question=(
                    guardrail.clarification_question
                    or "Please clarify the request."
                ),
                missing_information=[guardrail.reason],
                confidence=1.0,
            )

        prompt = render_prompt(
            "intent_prompt.txt",
            {
                "USER_QUESTION": clean_question,
                "USER_ROLE": role_name,
                "SCOPE_DECISION": _scope_context(guardrail),
                "AVAILABLE_DATABASES": database_descriptions,
                "SCHEMA_CONTEXT": {},
                "CONVERSATION_CONTEXT": conversation_context,
            },
        )
        result = call_model_json(self._llm, prompt, IntentResult)
        if result.original_question != clean_question:
            raise ValueError(
                "Intent Agent changed the original user question."
            )
        result = normalize_intent_from_question(result, clean_question)
        return result


def _role_name(user_role: UserRole | str) -> str:
    if isinstance(user_role, UserRole):
        return user_role.value
    if isinstance(user_role, str):
        try:
            return UserRole(user_role).value
        except ValueError as exc:
            raise ValueError(f"Unsupported user role: {user_role!r}.") from exc
    raise TypeError("user_role must be a UserRole or role string.")


def _public_database_descriptions(
    databases: Sequence[Mapping[str, Any] | Any],
) -> list[dict[str, Any]]:
    if isinstance(databases, (str, bytes)):
        raise TypeError("available_databases must be a sequence.")

    public_fields = {
        "name",
        "database_name",
        "backend",
        "driver",
        "host",
        "port",
        "description",
        "read_only",
        "is_default",
    }
    results: list[dict[str, Any]] = []
    for database in databases:
        if isinstance(database, Mapping):
            values = database
        elif is_dataclass(database) and not isinstance(database, type):
            values = asdict(database)
        else:
            raise TypeError(
                "Each database description must be a mapping or dataclass."
            )
        results.append(
            {
                key: value
                for key, value in values.items()
                if key in public_fields
            }
        )
    return results


def _scope_context(result: InputGuardrailResult) -> dict[str, Any]:
    scope_result = result.scope_result
    return {
        "accepted": result.accepted,
        "category": (
            result.category.value
            if result.category is not None
            else None
        ),
        "reason": result.reason,
        "requires_clarification": result.requires_clarification,
        "requires_human_approval": result.requires_human_approval,
        "scope_supported": (
            scope_result.supported if scope_result is not None else None
        ),
    }


def normalize_intent_from_question(result: IntentResult, question: str) -> IntentResult:
    """Deterministically preserve common Northwind analytics semantics.

    The LLM remains responsible for complex/ambiguous requests. Explicit
    count, ranking, listing and anti-join wording is normalized here so an
    LLM's generic_question/default-direction guess cannot bypass SQL work.
    """
    import re
    from schemas.intent_schema import (
        AggregationType, AnalysisType, DimensionDefinition, FilterCondition,
        FilterOperator, MetricDefinition, RankingRequirement, SortDirection,
        TimeGranularity, TimePeriod,
    )

    text = re.sub(r"\s+", " ", question.casefold()).strip()
    updates: dict[str, Any] = {}

    ascending = bool(re.search(
        r"\b(lowest|bottom|least|smallest|minimum|fewest)\b", text
    ))
    descending = bool(re.search(
        r"\b(highest|top|most|largest|greatest|maximum)\b", text
    ))
    ranking_requested = ascending or descending

    # Determine the requested business entity. More specific entities first.
    dimension = None
    if re.search(r"\bproduct\s+categories?\b|\bcategories\b|\bcategory\b", text):
        dimension = "category"
    elif re.search(r"\bproducts?\b", text):
        dimension = "product"
    elif re.search(r"\bcustomers?\b", text):
        dimension = "customer"
    elif re.search(r"\bcountr(?:y|ies)\b", text):
        dimension = "country"
    elif re.search(r"\bemployees?\b", text):
        dimension = "employee"
    elif re.search(r"\bsuppliers?\b", text):
        dimension = "supplier"
    elif re.search(r"\borders?\b", text):
        dimension = "order"

    # A common scalar COUNT request must not become a grouped customer list.
    count_requested = bool(re.search(
        r"\b(count|number of|how many)\b", text
    ))
    count_entity = dimension or "record"
    if count_requested:
        metric_name = f"{count_entity}_count" if count_entity != "record" else "record_count"
        updates.update(
            intent=QueryIntent.AGGREGATION,
            metrics=[MetricDefinition(
                name=metric_name,
                aggregation=AggregationType.COUNT,
                alias=metric_name,
            )],
            dimensions=(
                [DimensionDefinition(name="country")]
                if re.search(r"\bby country\b|\bcountries have\b", text)
                else []
            ),
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.AGGREGATION],
        )
        # Count-by-country or other grouped counts are rankings only when the
        # question explicitly asks for highest/lowest/most/fewest.
        if ranking_requested and updates["dimensions"]:
            updates["intent"] = QueryIntent.RANKING
            updates["ranking"] = RankingRequirement(
                required=True,
                limit=_extract_limit(text) or 5,
                sort_direction=(SortDirection.ASCENDING if ascending else SortDirection.DESCENDING),
                rank_by=metric_name,
            )
            updates["analysis_types"] = [AnalysisType.RANKING]

    monthly_revenue_trend = (
        re.search(r"\b(monthly|by month|each month|per month)\b", text)
        and re.search(r"\b(revenue|sales)\b", text)
    )
    if monthly_revenue_trend:
        analysis_types = [
            AnalysisType.AGGREGATION,
            AnalysisType.TREND,
        ]
        if re.search(r"\b(unusual|anomal(?:y|ies)|outlier)\b", text):
            analysis_types.append(AnalysisType.ANOMALY)
        updates.update(
            intent=QueryIntent.TREND_ANALYSIS,
            metrics=[MetricDefinition(
                name="total_sales",
                aggregation=AggregationType.SUM,
                alias="total_sales",
            )],
            dimensions=[],
            time_period=TimePeriod(granularity=TimeGranularity.MONTH),
            ranking=RankingRequirement(required=False),
            analysis_types=analysis_types,
        )

    # Ranking of customer/product sales. The direction is always derived from
    # the current question; never inherit the model's default DESC value.
    if ranking_requested and dimension and re.search(r"\b(sales|revenue|value)\b", text):
        metric_name = "total_sales"
        updates.update(
            intent=QueryIntent.RANKING,
            metrics=[MetricDefinition(
                name=metric_name,
                aggregation=AggregationType.SUM,
                alias=metric_name,
            )],
            dimensions=[DimensionDefinition(name=dimension)],
            ranking=RankingRequirement(
                required=True,
                limit=_extract_limit(text) or 5,
                sort_direction=(SortDirection.ASCENDING if ascending else SortDirection.DESCENDING),
                rank_by=metric_name,
            ),
            analysis_types=[AnalysisType.RANKING, AnalysisType.AGGREGATION],
        )

    if (
        ranking_requested
        and dimension == "employee"
        and re.search(r"\borders?\b", text)
        and re.search(r"\b(count|number of|many)\b", text)
    ):
        updates.update(
            intent=QueryIntent.RANKING,
            metrics=[MetricDefinition(
                name="order_count",
                aggregation=AggregationType.COUNT,
                alias="order_count",
            )],
            dimensions=[DimensionDefinition(name="employee")],
            ranking=RankingRequirement(
                required=True,
                limit=_extract_limit(text) or 5,
                sort_direction=(
                    SortDirection.ASCENDING if ascending
                    else SortDirection.DESCENDING
                ),
                rank_by="order_count",
            ),
            analysis_types=[AnalysisType.RANKING, AnalysisType.AGGREGATION],
        )

    if (
        re.search(r"\b(average|avg|mean)\b", text)
        and re.search(r"\bunit\s+price\b", text)
        and re.search(r"\bproducts?\b", text)
    ):
        updates.update(
            intent=QueryIntent.AGGREGATION,
            metrics=[MetricDefinition(
                name="average_unit_price",
                aggregation=AggregationType.AVERAGE,
                alias="average_unit_price",
            )],
            dimensions=[],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.AGGREGATION],
        )

    # Scalar average sales value per order.
    if re.search(r"\b(average|mean)\b", text) and re.search(r"\b(per|each)\s+order\b", text):
        updates.update(
            intent=QueryIntent.AGGREGATION,
            metrics=[MetricDefinition(
                name="average_sales_per_order",
                aggregation=AggregationType.AVERAGE,
                alias="average_sales_per_order",
            )],
            dimensions=[],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.AGGREGATION],
        )

    # Explicit projection/listing joins: product name + supplier name.
    if re.search(r"\bproduct\s+names?\b", text) and re.search(r"\bsupplier\s+names?\b", text):
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            metrics=[],
            dimensions=[
                DimensionDefinition(name="product_name"),
                DimensionDefinition(name="supplier_name"),
            ],
            filters=[],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    if (
        re.search(r"\bproduct\s+names?\b", text)
        and re.search(r"\bcategory\s+names?\b", text)
    ):
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            metrics=[],
            dimensions=[
                DimensionDefinition(name="product_name"),
                DimensionDefinition(name="category_name"),
            ],
            filters=[],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    if (
        re.search(r"\bcustomer\s+names?\b", text)
        and re.search(r"\border\s+(?:ids?|numbers?)\b", text)
    ):
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            metrics=[],
            dimensions=[
                DimensionDefinition(name="customer_name"),
                DimensionDefinition(name="order_id"),
            ],
            filters=[],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    if (
        re.search(r"\bemployee\s+names?\b", text)
        and re.search(r"\borders?\b", text)
    ):
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            metrics=[],
            dimensions=[
                DimensionDefinition(name="employee_name"),
                DimensionDefinition(name="order_id"),
            ],
            filters=[],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    if (
        re.search(r"\btotal\s+(?:sales|revenue)\b", text)
        and re.search(r"\bby\s+country\b", text)
    ):
        updates.update(
            intent=QueryIntent.AGGREGATION,
            metrics=[MetricDefinition(
                name="total_sales",
                aggregation=AggregationType.SUM,
                alias="total_sales",
            )],
            dimensions=[DimensionDefinition(name="country")],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.AGGREGATION],
        )

    # Anti-join request. IS NULL is a semantic instruction for the SQL agent;
    # the SQL prompt explicitly requires NOT EXISTS/LEFT JOIN ... IS NULL.
    if re.search(r"\bcustomers?\b", text) and re.search(
        r"\bnever\s+(?:placed|made|submitted)\s+(?:an?\s+)?orders?\b|\bwithout\s+orders?\b|\bno\s+orders?\b", text
    ):
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            metrics=[],
            dimensions=[DimensionDefinition(name="customer")],
            filters=[FilterCondition(
                field="salesorder.orderId",
                operator=FilterOperator.IS_NULL,
            )],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    if re.search(r"\bproducts?\b", text) and re.search(
        r"\bnever\s+(?:been\s+)?ordered\b|\bwithout\s+orders?\b|\bno\s+orders?\b",
        text,
    ):
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            metrics=[],
            dimensions=[DimensionDefinition(name="product")],
            filters=[FilterCondition(
                field="orderdetail.orderId",
                operator=FilterOperator.IS_NULL,
            )],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    # Plain entity listings are data queries, not unsupported general chat.
    if not updates and re.search(r"\b(show|list|display|give me)\b", text) and dimension:
        updates.update(
            intent=QueryIntent.DATA_QUERY,
            dimensions=[DimensionDefinition(name=dimension)],
            ranking=RankingRequirement(required=False),
            analysis_types=[AnalysisType.SUMMARY],
        )

    if updates:
        # Explicitly clear stale LLM clarification/default classifications for
        # these unambiguous supported patterns.
        updates.setdefault("requires_clarification", False)
        updates.setdefault("clarification_question", None)
        result = result.model_copy(update=updates)
    return result


def _extract_limit(question: str) -> int | None:
    """Extract numeric or word-form N from common top/bottom/list requests."""
    import re
    text = question.casefold()
    match = re.search(r"\b(?:top|bottom|highest|lowest)\s+(\d+)\b", text)
    if match:
        return max(1, min(int(match.group(1)), 1000))
    words = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    }
    word_pattern = "|".join(words)
    match = re.search(r"\b(?:top|bottom|highest|lowest)\s+(" + word_pattern + r")\b", text)
    if match:
        return words[match.group(1)]
    # e.g. "Which five customers generated the lowest sales?"
    match = re.search(r"\b(" + word_pattern + r")\s+(?:customers?|products?|employees?|suppliers?|countries?)\b", text)
    if match:
        return words[match.group(1)]
    return None
