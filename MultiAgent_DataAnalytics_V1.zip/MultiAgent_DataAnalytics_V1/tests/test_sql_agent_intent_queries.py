from agents.intent_agent import normalize_intent_from_question
from agents.sql_agent import SQLAgent
from schemas.intent_schema import IntentResult
from schemas.plan_schema import (
    AnalysisPlan,
    AnalyticalTask,
    DataRequirement,
    TaskType,
)
from schemas.sql_schema import SQLValidationStatus
from sql_security.sql_validator import SQLValidator


class UnexpectedLLM:
    def generate(self, prompt, system_prompt=None):
        raise AssertionError(
            "Unexpected model call for deterministic request: "
            f"{prompt} / {system_prompt}"
        )


def _plan():
    return AnalysisPlan(
        objective="Answer the current analytics request.",
        strategy_summary="Generate and validate the read-only query.",
        data_requirements=DataRequirement(
            database_name="northwind",
            requires_schema_discovery=False,
        ),
        tasks=[
            AnalyticalTask(
                task_id="sql",
                sequence=1,
                task_type=TaskType.SQL_GENERATION,
                assigned_agent="sql_agent",
                title="Generate SQL",
                description="Generate the requested read-only query.",
                expected_output="One SQL query.",
            )
        ],
    )


def _schema_context():
    return {
        "tables": {
            "customer": ["custId", "companyName", "country"],
            "product": [
                "productId", "productName", "supplierId", "categoryId",
                "unitPrice",
            ],
            "supplier": ["supplierId", "companyName"],
            "category": ["categoryId", "categoryName"],
            "salesorder": [
                "orderId", "custId", "employeeId", "orderDate",
            ],
            "orderdetail": [
                "orderId", "productId", "unitPrice", "quantity", "discount",
            ],
            "employee": ["employeeId", "firstname", "lastname"],
        },
        "relationships": [
            {
                "source_table": "salesorder",
                "source_columns": ["custId"],
                "target_table": "customer",
                "target_columns": ["custId"],
            },
            {
                "source_table": "salesorder",
                "source_columns": ["employeeId"],
                "target_table": "employee",
                "target_columns": ["employeeId"],
            },
            {
                "source_table": "orderdetail",
                "source_columns": ["orderId"],
                "target_table": "salesorder",
                "target_columns": ["orderId"],
            },
            {
                "source_table": "orderdetail",
                "source_columns": ["productId"],
                "target_table": "product",
                "target_columns": ["productId"],
            },
            {
                "source_table": "product",
                "source_columns": ["supplierId"],
                "target_table": "supplier",
                "target_columns": ["supplierId"],
            },
            {
                "source_table": "product",
                "source_columns": ["categoryId"],
                "target_table": "category",
                "target_columns": ["categoryId"],
            },
        ],
    }


def _generate(question):
    intent = normalize_intent_from_question(
        IntentResult(
            original_question=question,
            normalized_question=question,
        ),
        question,
    )
    return SQLAgent(llm=UnexpectedLLM()).run(
        _plan(),
        _schema_context(),
        user_question=question,
        intent_result=intent.model_dump(mode="json"),
    )


def test_customer_and_product_counts_use_their_own_table_and_scalar_shape():
    customer_query = _generate("How many customers are there?")
    product_query = _generate("How many products are there?")
    available_products_query = _generate("How many products are available?")

    assert "COUNT(*) AS `customer_count`" in customer_query.sql_query
    assert "FROM `customer`" in customer_query.sql_query
    assert "GROUP BY" not in customer_query.sql_query.upper()
    assert "FROM `product`" in product_query.sql_query
    assert "customer" not in product_query.sql_query.casefold()
    assert "GROUP BY" not in product_query.sql_query.upper()
    assert "FROM `product`" in available_products_query.sql_query


def test_monthly_revenue_query_groups_sales_by_month():
    result = _generate(
        "Show the monthly revenue trend and highlight unusual months"
    )

    assert "DATE_FORMAT(o.`orderDate`, '%Y-%m-01')" in result.sql_query
    assert (
        "SUM(od.`unitPrice` * od.`quantity` * (1 - od.`discount`))"
        in result.sql_query
    )
    assert "FROM `salesorder` AS o" in result.sql_query
    assert "JOIN `orderdetail` AS od" in result.sql_query
    assert "GROUP BY DATE_FORMAT" in result.sql_query
    assert "customer" not in result.sql_query.casefold()


def test_requested_northwind_queries_generate_matching_sql():
    cases = [
        ("How many customers are there?", {"customer"}, "COUNT(*)"),
        ("How many products are available?", {"product"}, "COUNT(*)"),
        ("What is the average unit price of all products?", {"product"}, "AVG("),
        ("What is the total number of orders?", {"salesorder"}, "COUNT(*)"),
        (
            "Show the top 5 customers by total sales.",
            {"customer", "salesorder", "orderdetail"},
            "ORDER BY `total_sales` DESC LIMIT 5",
        ),
        (
            "Which five customers generated the lowest total sales?",
            {"customer", "salesorder", "orderdetail"},
            "ORDER BY `total_sales` ASC LIMIT 5",
        ),
        (
            "Which products generated the highest total sales?",
            {"product", "orderdetail"},
            "ORDER BY `total_sales` DESC",
        ),
        (
            "Which five products generated the lowest total sales?",
            {"product", "orderdetail"},
            "ORDER BY `total_sales` ASC LIMIT 5",
        ),
        (
            "Which countries have the highest number of customers?",
            {"customer"},
            "COUNT(DISTINCT c.`custId`)",
        ),
        (
            "Show product names with supplier names.",
            {"product", "supplier"},
            "supplierName",
        ),
        (
            "Show customer names along with their order IDs.",
            {"customer", "salesorder"},
            "orderId",
        ),
        (
            "Show employee names and the orders they handled.",
            {"employee", "salesorder"},
            "employeeName",
        ),
        (
            "Show product names along with their category names.",
            {"product", "category"},
            "categoryName",
        ),
        (
            "Which customers have never placed an order?",
            {"customer", "salesorder"},
            "NOT EXISTS",
        ),
        (
            "Which products have never been ordered?",
            {"product", "orderdetail"},
            "NOT EXISTS",
        ),
        (
            "What is the average sales value per order?",
            {"orderdetail"},
            "AVG(order_total)",
        ),
        (
            "Show total sales by country.",
            {"customer", "salesorder", "orderdetail"},
            "GROUP BY c.`country`",
        ),
        (
            "What is the monthly sales revenue?",
            {"salesorder", "orderdetail"},
            "DATE_FORMAT",
        ),
        (
            "Which employees handled the highest number of orders?",
            {"employee", "salesorder"},
            "COUNT(DISTINCT so.`orderId`)",
        ),
        (
            "Which product categories contribute the most to total sales?",
            {"category", "product", "orderdetail"},
            "ORDER BY `total_sales` DESC",
        ),
    ]

    validator = SQLValidator()

    for question, expected_tables, expected_sql in cases:
        result = _generate(question)
        assert set(result.referenced_tables) == expected_tables, question
        assert expected_sql in result.sql_query, question
        validation = validator.validate(result.sql_query)
        assert validation.status == SQLValidationStatus.VALID.value, (
            question,
            validation.issues,
        )
        assert set(validation.referenced_tables) == expected_tables, question
