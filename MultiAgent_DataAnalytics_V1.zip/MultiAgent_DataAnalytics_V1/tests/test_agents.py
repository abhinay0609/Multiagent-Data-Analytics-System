"""Offline tests for the five specialized analytics agents.

Run from the project root with:

    python -m tests.test_agents
"""

from typing import Any

from agents import (
    AgentRequestBlockedError,
    AnalysisAgent,
    IntentAgent,
    PlanningAgent,
    ReportingAgent,
    SQLAgent,
)
from guardrails import GroundingResult
from reporting import create_figure
from schemas.intent_schema import (
    AggregationType,
    AnalysisType,
    ComparisonRequirement,
    ComparisonType,
    DimensionDefinition,
    IntentResult,
    MetricDefinition,
    QueryIntent,
    RankingRequirement,
    TimePeriod,
)
from schemas.sql_schema import (
    QueryExecutionMetadata,
    QueryExecutionResult,
)
from schemas.plan_schema import AnalysisPlan
from schemas.user_schema import UserRole


class FakeLLM:
    """Return queued outputs while retaining prompt inputs for assertions."""

    def __init__(
        self,
        *,
        json_outputs: list[dict[str, Any]] | None = None,
        text_outputs: list[str] | None = None,
    ) -> None:
        self.json_outputs = list(json_outputs or [])
        self.text_outputs = list(text_outputs or [])
        self.system_prompts: list[str] = []
        self.user_prompts: list[str] = []
        self.output_schemas: list[dict[str, Any] | None] = []
        self.calls = 0

    def generate_json(
        self,
        prompt: str,
        system_prompt: str | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self.calls += 1
        self.user_prompts.append(prompt)
        self.system_prompts.append(system_prompt or "")
        self.output_schemas.append(output_schema)
        return self.json_outputs.pop(0)

    def generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
    ) -> str:
        self.calls += 1
        self.user_prompts.append(prompt)
        self.system_prompts.append(system_prompt or "")
        return self.text_outputs.pop(0)


class FailingLLM:
    def generate_json(
        self,
        prompt: str,
        system_prompt: str | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        raise RuntimeError("Ollama is unavailable.")


def _intent_output(question: str) -> dict[str, Any]:
    return {
        "original_question": question,
        "normalized_question": "Rank customers by total sales.",
        "intent": "ranking",
        "metrics": [{"name": "total_sales", "aggregation": "sum"}],
        "dimensions": [{"name": "customer"}],
        "ranking": {
            "required": True,
            "limit": 5,
            "sort_direction": "descending",
            "rank_by": "total_sales",
        },
        "requires_clarification": False,
        "missing_information": [],
        "confidence": 0.9,
    }


def _plan_output() -> dict[str, Any]:
    return {
        "objective": "Rank customers by total sales.",
        "strategy_summary": (
            "Aggregate sales by customer and rank the returned rows."
        ),
        "data_requirements": {
            "database_name": "northwind",
            "required_tables": ["customer", "salesorder", "orderdetail"],
            "required_metrics": ["total_sales"],
            "required_dimensions": ["customer"],
            "requires_schema_discovery": True,
        },
        "tasks": [
            {
                "task_id": "sql",
                "sequence": 1,
                "task_type": "sql_generation",
                "assigned_agent": "sql_agent",
                "title": "Generate customer ranking query",
                "description": "Rank customers by total sales.",
                "depends_on": ["schema"],
                "expected_output": "A candidate read-only MySQL query.",
            }
        ],
        "analysis_methods": ["aggregation", "ranking"],
        "controls": {
            "max_sql_retries": 2,
            "max_result_rows": 1000,
            "query_timeout_seconds": 30,
            "read_only_required": True,
            "human_approval_required": False,
            "approval_reason": None,
        },
        "requires_clarification": False,
        "confidence": 0.9,
    }


def _intent() -> IntentResult:
    return IntentResult(
        original_question="Show the top five customers by total sales.",
        normalized_question="Rank customers by total sales.",
        intent=QueryIntent.RANKING,
        metrics=[
            MetricDefinition(
                name="total_sales",
                aggregation=AggregationType.SUM,
            )
        ],
        dimensions=[DimensionDefinition(name="customer")],
        ranking=RankingRequirement(
            required=True,
            limit=5,
            rank_by="total_sales",
        ),
        confidence=0.9,
    )


def _execution() -> QueryExecutionResult:
    records = [
        {"customer": "Acme", "total_sales": 150.0},
        {"customer": "Beta", "total_sales": 100.0},
    ]
    return QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="query-1",
            database_name="northwind",
            row_count=len(records),
            columns=["customer", "total_sales"],
        ),
        records=records,
    )


def main() -> None:
    print("=" * 60)
    print("Testing the five specialized agents")
    print("=" * 60)

    question = "Show the top five customers by total sales."
    intent_llm = FakeLLM(json_outputs=[_intent_output(question)])
    intent_agent = IntentAgent(llm=intent_llm)
    intent = intent_agent.run(
        question,
        UserRole.BUSINESS_MANAGER,
        [
            {
                "name": "northwind",
                "description": "Northwind sales database.",
                "password": "must-not-reach-the-prompt",
            }
        ],
    )
    assert intent.intent == "ranking"
    assert "must-not-reach-the-prompt" not in intent_llm.system_prompts[0]
    blocked_llm = FakeLLM()
    try:
        IntentAgent(llm=blocked_llm).run(
            "SELECT * FROM customer",
            UserRole.BUSINESS_MANAGER,
            [{"name": "northwind"}],
        )
    except AgentRequestBlockedError:
        pass
    else:
        raise AssertionError("Unsafe user SQL was not blocked.")
    assert blocked_llm.calls == 0
    clarified = IntentAgent(llm=blocked_llm).run(
        "Compare sales",
        UserRole.BUSINESS_MANAGER,
        [{"name": "northwind"}],
    )
    assert clarified.requires_clarification is True
    assert blocked_llm.calls == 0
    print("Intent classification and input guardrails passed.")

    incomplete_plan = _plan_output()
    incomplete_plan["tasks"][0].pop("expected_output")
    plan_llm = FakeLLM(
        json_outputs=[incomplete_plan, _plan_output()]
    )
    planner = PlanningAgent(llm=plan_llm)
    plan = planner.run(
        intent,
        {
            "allowed": True,
            "reason": "Authorized for Northwind.",
            "password_hash": "must-not-reach-the-planner",
        },
        [{"name": "northwind", "database_name": "northwind_db"}],
        "northwind",
        schema_context={"tables": ["customer", "salesorder", "orderdetail"]},
        execution_policy={
            "max_sql_retries": 2,
            "max_result_rows": 1000,
            "query_timeout_seconds": 30,
        },
    )
    assert plan.data_requirements.database_name == "northwind"
    assert plan.controls.read_only_required is True
    assert plan_llm.calls == 2
    assert plan_llm.output_schemas[0] is not None
    assert plan.tasks[0].task_type == "schema_discovery"
    assert plan.tasks[1].sequence == 2
    assert "schema" in plan.tasks[1].depends_on
    assert "must-not-reach-the-planner" not in plan_llm.system_prompts[0]

    schema_alias_plan = _plan_output()
    schema_alias_plan["tasks"][0]["task_id"] = "generate_query"
    schema_alias_plan["tasks"][0]["sequence"] = 2
    schema_alias_plan["tasks"].insert(
        0,
        {
            "task_id": "schema_lookup",
            "sequence": 1,
            "task_type": "schema_discovery",
            "assigned_agent": "sql_agent",
            "title": "Discover relevant schema",
            "description": "Retrieve the schema required by this plan.",
            "expected_output": "Relevant schema metadata",
        },
    )
    schema_alias_plan["tasks"].append(
        {
            "task_id": "validation_step",
            "sequence": 3,
            "task_type": "sql_validation",
            "assigned_agent": "system",
            "title": "Validate query",
            "description": "Check the generated query.",
            "depends_on": ["sql"],
            "expected_output": "Validation result",
        }
    )
    schema_alias_plan["tasks"].append(
        {
            "task_id": "execution_step",
            "sequence": 4,
            "task_type": "query_execution",
            "assigned_agent": "system",
            "title": "Execute query",
            "description": "Run the approved query.",
            "depends_on": ["validate"],
            "expected_output": "Query results",
        }
    )
    normalized_alias_plan = AnalysisPlan.model_validate(schema_alias_plan)
    assert normalized_alias_plan.tasks[1].depends_on == ["schema_lookup"]
    assert normalized_alias_plan.tasks[2].depends_on == ["generate_query"]
    assert normalized_alias_plan.tasks[3].depends_on == ["validation_step"]
    invalid_dependency_plan = _plan_output()
    invalid_dependency_plan["tasks"][0]["depends_on"] = ["missing_task"]
    try:
        AnalysisPlan.model_validate(invalid_dependency_plan)
    except ValueError:
        pass
    else:
        raise AssertionError("Unknown task dependencies were accepted.")

    try:
        PlanningAgent(llm=FakeLLM()).run(
            intent,
            {"allowed": False, "reason": "Denied."},
            [{"name": "northwind"}],
            "northwind",
        )
    except PermissionError:
        pass
    else:
        raise AssertionError("Planner accepted denied permission context.")
    approval_plan_data = _plan_output()
    approval_plan_data["controls"].update(
        {
            "human_approval_required": True,
            "approval_reason": "Sensitive data requires review.",
        }
    )
    approval_plan = PlanningAgent(
        llm=FakeLLM(json_outputs=[approval_plan_data])
    ).run(
        intent,
        {"allowed": True, "reason": "Authorized for Northwind."},
        [{"name": "northwind"}],
        "northwind",
        execution_policy={
            "max_sql_retries": 2,
            "max_result_rows": 1000,
            "query_timeout_seconds": 30,
        },
        human_approval_required=True,
        approval_reason="Sensitive data requires review.",
    )
    assert approval_plan.controls.human_approval_required is True
    assert (
        approval_plan.controls.approval_reason
        == "Sensitive data requires review."
    )
    print("Plan generation, policy preservation, and permission gating passed.")

    sql_llm = FakeLLM(
        text_outputs=[
            "```sql\nSELECT c.companyName, "
            "SUM(od.unitPrice * od.quantity) AS total_sales "
            "FROM customer AS c "
            "JOIN salesorder AS so ON so.custId = c.custId "
            "JOIN orderdetail AS od ON od.orderId = so.orderId "
            "GROUP BY c.custId, c.companyName "
            "ORDER BY total_sales DESC LIMIT 5\n```"
        ]
    )
    generated = SQLAgent(llm=sql_llm).run(
        plan,
        {
            "customer": ["custId", "companyName"],
            "salesorder": ["orderId", "custId"],
            "orderdetail": ["orderId", "unitPrice", "quantity"],
        },
        previous_validation_errors=["Unknown column from prior attempt."],
    )
    assert generated.statement_type == "select"
    assert generated.retry_attempt == 1
    assert set(generated.referenced_tables) == {
        "customer",
        "salesorder",
        "orderdetail",
    }
    assert "total_sales" in generated.expected_columns
    assert "must not execute" in sql_llm.system_prompts[0]
    assert "Unknown column from prior attempt." in sql_llm.system_prompts[0]
    assert "Output exactly one MySQL SELECT" in sql_llm.system_prompts[0]
    try:
        SQLAgent(
            llm=FakeLLM(
                text_outputs=[
                    "SELECT 1; DELETE FROM customer"
                ]
            )
        ).run(plan, {"customer": ["custId"]})
    except ValueError as exc:
        assert "exactly one SQL statement" in str(exc)
    else:
        raise AssertionError("SQL Agent accepted multiple statements.")
    print("SQL generation and metadata extraction passed.")

    execution = _execution()
    analysis_llm = FakeLLM(
        json_outputs=[
            {
                "analysis_summary": (
                    "Customer ranking follows the total_sales values "
                    "in the returned rows."
                ),
                "assumptions": [],
                "limitations": [],
                "warnings": [],
            }
        ]
    )
    analysis = AnalysisAgent(llm=analysis_llm).run(
        execution,
        _intent(),
        plan,
        referenced_tables=["customer", "salesorder", "orderdetail"],
    )
    sum_metric = next(
        metric
        for metric in analysis.metrics
        if metric.name == "sum_of_total_sales"
    )
    assert sum_metric.value == 250
    assert analysis.findings[0].finding_type == "ranking"
    assert "Acme" in analysis.findings[0].description
    assert "Pandas and NumPy" in analysis_llm.system_prompts[0]

    contradictory_analysis = AnalysisAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "analysis_summary": (
                        "No findings can be reported because query "
                        "execution failed and returned no rows."
                    ),
                    "assumptions": [],
                    "limitations": [
                        "The query returned no usable records."
                    ],
                    "warnings": [],
                }
            ]
        )
    ).run(execution, _intent(), plan)
    assert "query execution failed" not in (
        contradictory_analysis.analysis_summary.casefold()
    )
    assert contradictory_analysis.sufficient_data is True
    assert all(
        "no usable records" not in limitation.casefold()
        for limitation in contradictory_analysis.limitations
    )

    five_rows = [
        {
            "customer": f"Customer {chr(64 + index)}",
            "total_sales": 600.0 - index * 100,
        }
        for index in range(1, 6)
    ]
    five_row_execution = QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="five-row-query",
            database_name="northwind",
            row_count=len(five_rows),
            columns=["customer", "total_sales"],
        ),
        records=five_rows,
    )
    deterministic_analysis = AnalysisAgent(llm=FailingLLM()).run(
        five_row_execution,
        _intent(),
        plan,
        referenced_tables=["customer"],
    )
    assert deterministic_analysis.analyzed_row_count == 5
    assert deterministic_analysis.sufficient_data is True
    assert deterministic_analysis.findings[0].description.startswith(
        "Customer A ranks first"
    )
    assert any(
        "could not provide a validated explanation" in warning
        for warning in deterministic_analysis.warnings
    )
    deterministic_report = ReportingAgent(llm=FailingLLM()).run(
        _intent(),
        five_row_execution,
        deterministic_analysis,
        GroundingResult(grounded=True, issues=()),
        sql_validation_result={"referenced_tables": ["customer"]},
    )
    assert deterministic_report.grounded is True
    assert deterministic_report.key_findings
    assert any(
        "could not provide a validated report" in warning
        for warning in deterministic_report.warnings
    )

    grounding_failure_report = ReportingAgent(
        llm=FakeLLM()
    ).run(
        _intent(),
        execution,
        analysis,
        {
            "grounded": False,
            "issues": ["UNSUPPORTED_NUMBER: An analysis claim was unsupported."],
        },
    )
    assert grounding_failure_report.grounded is False
    assert grounding_failure_report.key_findings == []
    assert "returned 2 rows" in grounding_failure_report.executive_summary
    assert "execution failed" not in (
        grounding_failure_report.executive_summary.casefold()
    )
    assert "no rows" not in grounding_failure_report.executive_summary.casefold()

    contradictory_report_llm = FakeLLM(
        json_outputs=[
            {
                "report_title": "Analysis unavailable",
                "executive_summary": (
                    "No findings are available because the query returned "
                    "no usable records."
                ),
                "key_findings": [],
                "charts": [],
                "recommendations": [],
                "limitations": ["The query execution failed."],
                "grounded": True,
                "confidence": 0.9,
            }
        ]
    )
    contradictory_report = ReportingAgent(
        llm=contradictory_report_llm
    ).run(
        _intent(),
        execution,
        analysis,
        {"grounded": True, "issues": []},
    )
    assert contradictory_report.grounded is True
    assert contradictory_report.key_findings
    assert contradictory_report.executive_summary
    assert "execution failed" not in (
        contradictory_report.executive_summary.casefold()
    )
    assert "no usable records" not in (
        contradictory_report.executive_summary.casefold()
    )

    empty_execution = QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="empty-query",
            database_name="northwind",
            row_count=0,
            columns=["total_sales"],
        ),
        records=[],
    )
    empty_analysis = AnalysisAgent(llm=FakeLLM()).run(
        empty_execution,
        _intent(),
        plan,
    )
    assert empty_analysis.sufficient_data is False
    assert "completed successfully" in empty_analysis.analysis_summary
    assert "execution failed" not in empty_analysis.analysis_summary

    failed_execution = QueryExecutionResult(
        success=False,
        metadata=QueryExecutionMetadata(
            query_id="failed-query",
            database_name="northwind",
        ),
        error_message="Connection unavailable.",
    )
    failed_analysis = AnalysisAgent(llm=FakeLLM()).run(
        failed_execution,
        _intent(),
        plan,
    )
    assert failed_analysis.sufficient_data is False
    assert "execution failed" in failed_analysis.analysis_summary

    fabricated_llm = FakeLLM(
        json_outputs=[
            {
                "analysis_summary": "Sales increased by 900 percent.",
                "assumptions": [],
                "limitations": [],
                "warnings": [],
            },
            {
                "analysis_summary": "Sales increased by 900 percent.",
                "assumptions": [],
                "limitations": [],
                "warnings": [],
            },
        ]
    )
    fabricated_fallback = AnalysisAgent(
        llm=fabricated_llm
    ).run(execution, _intent(), plan)
    assert fabricated_fallback.sufficient_data is True
    assert "900" not in fabricated_fallback.analysis_summary
    assert any(
        "could not provide a validated explanation" in warning
        for warning in fabricated_fallback.warnings
    )
    print("Pandas/NumPy calculations and qualitative analysis passed.")

    comparison_intent = IntentResult(
        original_question="Compare sales between the two periods.",
        normalized_question="Compare sales between 2024 and 2025.",
        intent=QueryIntent.COMPARISON,
        metrics=[MetricDefinition(name="sales", aggregation="sum")],
        dimensions=[DimensionDefinition(name="period")],
        comparison=ComparisonRequirement(
            required=True,
            comparison_type=ComparisonType.CATEGORY_COMPARISON,
            baseline="2024",
            target="2025",
            comparison_dimension="period",
        ),
    )
    comparison_execution = QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="comparison-1",
            database_name="northwind",
            row_count=2,
            columns=["period", "sales"],
        ),
        records=[
            {"period": "2024", "sales": 100.0},
            {"period": "2025", "sales": 150.0},
        ],
    )
    comparison_result = AnalysisAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "analysis_summary": (
                        "The returned periods support a sales comparison."
                    ),
                    "assumptions": [],
                    "limitations": [],
                    "warnings": [],
                }
            ]
        )
    ).run(comparison_execution, comparison_intent, plan)
    assert comparison_result.comparisons[0].absolute_change == 50
    assert comparison_result.comparisons[0].percentage_change == 50

    trend_intent = IntentResult(
        original_question="Show the sales trend over time.",
        normalized_question="Show sales over time.",
        intent=QueryIntent.TREND_ANALYSIS,
        metrics=[MetricDefinition(name="sales", aggregation="sum")],
        time_period=TimePeriod(time_column_hint="orderDate"),
        analysis_types=[AnalysisType.TREND],
    )
    trend_execution = QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="trend-1",
            database_name="northwind",
            row_count=3,
            columns=["orderDate", "sales"],
        ),
        records=[
            {"orderDate": "2025-01-01", "sales": 10.0},
            {"orderDate": "2025-02-01", "sales": 15.0},
            {"orderDate": "2025-03-01", "sales": 20.0},
        ],
    )
    trend_result = AnalysisAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "analysis_summary": (
                        "The observed time points show an increasing sales pattern."
                    ),
                    "assumptions": [],
                    "limitations": [],
                    "warnings": [],
                }
            ]
        )
    ).run(trend_execution, trend_intent, plan)
    assert trend_result.trends[0].direction == "increasing"
    assert trend_result.trends[0].absolute_change == 10

    anomaly_intent = IntentResult(
        original_question="Find unusual sales values by customer.",
        normalized_question="Detect sales anomalies by customer.",
        intent=QueryIntent.ANOMALY_DETECTION,
        metrics=[MetricDefinition(name="sales", aggregation="sum")],
        dimensions=[DimensionDefinition(name="customer")],
        analysis_types=[AnalysisType.ANOMALY],
    )
    anomaly_values = [10.0] * 11 + [1000.0]
    anomaly_records = [
        {"customer": f"C{index}", "sales": value}
        for index, value in enumerate(anomaly_values)
    ]
    anomaly_execution = QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="anomaly-1",
            database_name="northwind",
            row_count=len(anomaly_records),
            columns=["customer", "sales"],
        ),
        records=anomaly_records,
    )
    anomaly_result = AnalysisAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "analysis_summary": (
                        "A returned customer has an unusual sales value."
                    ),
                    "assumptions": [],
                    "limitations": [],
                    "warnings": [],
                }
            ]
        )
    ).run(anomaly_execution, anomaly_intent, plan)
    assert len(anomaly_result.anomalies) == 1
    assert anomaly_result.anomalies[0].entity == "C11"

    contribution_result = AnalysisAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "analysis_summary": (
                        "The largest observed group is identified in the returned rows."
                    ),
                    "assumptions": [],
                    "limitations": [],
                    "warnings": [],
                }
            ]
        )
    ).run(
        execution,
        _intent(),
        plan.model_copy(update={"analysis_methods": ["contribution"]}),
    )
    assert contribution_result.contributing_factors
    assert "Acme" in contribution_result.contributing_factors[0]
    print("Comparison, trend, anomaly, and contribution calculations passed.")

    report_llm = FakeLLM(
        json_outputs=[
            {
                "report_title": "Customer Sales Ranking",
                "executive_summary": (
                    "Acme ranked first by total sales in the returned rows."
                ),
                "key_findings": [
                    {
                        "title": "Acme ranked first",
                        "description": (
                            "Acme has the highest total_sales value in the "
                            "returned rows."
                        ),
                        "supporting_metric": "total_sales",
                        "supporting_value": "150.0",
                        "evidence_reference": "Returned query rows.",
                    }
                ],
                "charts": [
                    {
                        "chart_id": "customer-sales",
                        "chart_type": "bar",
                        "title": "Sales by customer",
                        "x_column": "customer",
                        "y_columns": ["total_sales"],
                        "data": [],
                        "rationale": (
                            "A bar chart compares the returned customers."
                        ),
                    }
                ],
                "recommendations": [],
                "grounded": True,
                "grounding_notes": [],
                "confidence": 0.9,
            }
        ]
    )
    report = ReportingAgent(llm=report_llm).run(
        _intent(),
        execution,
        analysis,
        GroundingResult(grounded=True, issues=()),
        [{"chart_type": "bar", "reason": "Compare customers."}],
        sql_validation_result={
            "referenced_tables": [
                "customer",
                "salesorder",
                "orderdetail",
            ]
        },
    )
    assert report.grounded is True
    assert report.charts[0].data == execution.records

    report_without_chart = ReportingAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "report_title": "Customer Sales Ranking",
                    "executive_summary": (
                        "Acme ranked first by total sales in the returned rows."
                    ),
                    "charts": [],
                    "grounded": True,
                    "grounding_notes": [],
                    "confidence": 0.9,
                }
            ]
        )
    ).run(
        _intent(),
        execution,
        analysis,
        GroundingResult(grounded=True, issues=()),
        sql_validation_result={
            "referenced_tables": [
                "customer",
                "salesorder",
                "orderdetail",
            ]
        },
    )
    assert report_without_chart.grounded is True
    assert len(report_without_chart.charts) == 1
    fallback_chart = report_without_chart.charts[0]
    assert fallback_chart.chart_type == "bar"
    assert fallback_chart.x_column == "customer"
    assert fallback_chart.y_columns == ["total_sales"]
    assert fallback_chart.data == execution.records
    fallback_figure = create_figure(fallback_chart)
    assert fallback_figure is not None
    assert fallback_figure.data[0].type == "bar"
    print("Report grounding and chart-data enforcement passed.")

    ungrounded_report = ReportingAgent(
        llm=FakeLLM(
            json_outputs=[
                {
                    "report_title": "Sales report",
                    "executive_summary": "Sales increased by 999.",
                    "key_findings": [
                        {
                            "title": "Unsupported increase",
                            "description": "Sales increased by 999.",
                        }
                    ],
                    "grounded": True,
                    "confidence": 0.9,
                }
            ]
        )
    ).run(
        _intent(),
        execution,
        analysis,
        GroundingResult(grounded=True, issues=()),
        sql_validation_result={
            "referenced_tables": [
                "customer",
                "salesorder",
                "orderdetail",
            ]
        },
    )
    assert ungrounded_report.grounded is True
    assert ungrounded_report.executive_summary
    assert "999" not in str(ungrounded_report.model_dump(mode="json"))
    assert [
        finding.title for finding in ungrounded_report.key_findings
    ] == [finding.title for finding in analysis.findings]
    print("Ungrounded LLM reports fall back to validated query results.")

    print("\nAll five agents tested successfully.")


if __name__ == "__main__":
    main()