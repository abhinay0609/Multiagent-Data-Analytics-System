"""LangGraph node implementations and dependency injection."""

from __future__ import annotations

from dataclasses import dataclass
from html import escape as html_escape
from typing import Any, Mapping, Protocol, Sequence

from agents.analysis_agent import AnalysisAgent
from agents.intent_agent import AgentRequestBlockedError, IntentAgent
from agents.planning_agent import PlanningAgent
from agents.reporting_agent import ReportingAgent
from agents.sql_agent import SQLAgent
from auth.authentication import (
    AuthenticationService,
    authentication_service,
)
from loguru import logger
from auth.authorization import AuthorizationService, authorization_service
from config.settings import settings
from guardrails import (
    GroundingValidator,
    InputGuardrail,
    OutputGuardrail,
    grounding_validator,
    input_guardrail,
    output_guardrail,
)
from reporting.report_generator import serialize_chart_specifications
from schemas.analysis_schema import AnalysisResult
from schemas.intent_schema import IntentResult, QueryIntent
from schemas.plan_schema import AnalysisPlan
from schemas.report_schema import ReportResult
from schemas.sql_schema import (
    QueryExecutionResult,
    SQLGenerationResult,
    SQLValidationResult,
    SQLValidationStatus,
)
from schemas.user_schema import (
    Permission,
    UserIdentity,
)
from sql_security.retry_handler import SQLRetryHandler

from graph.state import (
    AgentName,
    AnalyticsState,
    ErrorCategory,
    WorkflowError,
    state_update,
)


class AgentRunner(Protocol):
    """Small structural boundary for injected agent implementations."""

    def run(self, *args: Any, **kwargs: Any) -> Any: ...


class RegistryProvider(Protocol):
    def contains(self, name: str) -> bool: ...

    def list_databases(self) -> list[dict[str, Any]]: ...


class SchemaProvider(Protocol):
    def get_database_schema(
        self,
        database_name: str | None = None,
    ) -> dict[str, Any]: ...

    def build_schema_context(
        self,
        database_name: str | None = None,
        **kwargs: Any,
    ) -> str: ...


class SQLValidatorProvider(Protocol):
    def validate(
        self,
        sql: str,
        query_id: str | None = None,
    ) -> SQLValidationResult: ...


class QueryExecutorProvider(Protocol):
    def execute(
        self,
        validation_result: SQLValidationResult,
        user: UserIdentity,
        database_name: str | None = None,
        parameters: Mapping[str, Any] | None = None,
        max_rows: int | None = None,
    ) -> QueryExecutionResult: ...


class SchemaServiceProvider(Protocol):
    def get_schema(
        self,
        username: str,
        database_name: str,
    ) -> dict[str, Any]: ...

    def build_schema_context(
        self,
        username: str,
        database_name: str,
        **kwargs: Any,
    ) -> str: ...


@dataclass(frozen=True)
class WorkflowDependencies:
    """Trusted services and agents kept outside the serializable state."""

    authentication: AuthenticationService
    authorization: AuthorizationService
    registry: RegistryProvider
    schema_manager: SchemaProvider
    sql_validator: SQLValidatorProvider
    query_executor: QueryExecutorProvider
    intent_agent: AgentRunner
    planning_agent: AgentRunner
    sql_agent: AgentRunner
    analysis_agent: AgentRunner
    reporting_agent: AgentRunner
    input_guardrail: InputGuardrail
    grounding_validator: GroundingValidator
    output_guardrail: OutputGuardrail
    retry_handler: SQLRetryHandler
    schema_service: SchemaServiceProvider | None = None
    database_name: str = "northwind"


def create_default_dependencies(
    database_name: str = "northwind",
    *,
    authentication: AuthenticationService | None = None,
    authorization: AuthorizationService | None = None,
) -> WorkflowDependencies:
    """Construct production components using the approved registry."""
    from database.database_registry import initialize_database_registry
    from database.query_executor import QueryExecutor
    from database.schema_manager import SchemaManager
    from sql_security.sql_validator import SQLValidator

    registry = initialize_database_registry()
    schema = SchemaManager(registry)
    selected_authentication = (
        authentication
        if authentication is not None
        else authentication_service
    )
    selected_authorization = (
        authorization
        if authorization is not None
        else authorization_service
    )
    from services.schema_service import SchemaService

    return WorkflowDependencies(
        authentication=selected_authentication,
        authorization=selected_authorization,
        registry=registry,
        schema_manager=schema,
        sql_validator=SQLValidator(
            database_name=database_name,
            manager=schema,
        ),
        query_executor=QueryExecutor(
            registry=registry,
            default_database_name=database_name,
        ),
        intent_agent=IntentAgent(),
        planning_agent=PlanningAgent(),
        sql_agent=SQLAgent(),
        analysis_agent=AnalysisAgent(),
        reporting_agent=ReportingAgent(),
        input_guardrail=input_guardrail,
        grounding_validator=grounding_validator,
        output_guardrail=output_guardrail,
        retry_handler=SQLRetryHandler(),
        schema_service=SchemaService(
            registry=registry,
            schema_manager=schema,
            authentication=selected_authentication,
            authorization=selected_authorization,
        ),
        database_name=database_name,
    )


class WorkflowNodes:
    """Wrap agents and backend controls as deterministic graph nodes."""

    def __init__(self, dependencies: WorkflowDependencies) -> None:
        self.dependencies = dependencies

    def input_guardrail(self, state: AnalyticsState) -> AnalyticsState:
        result = self.dependencies.input_guardrail.validate(
            state.get("user_query", ""),
            database_name=state.get(
                "database_name",
                self.dependencies.database_name,
            ),
        )
        category = (
            result.category.value
            if result.category is not None
            else None
        )
        changes: dict[str, Any] = {
            "normalized_query": (
                result.normalized_input or state.get("user_query", "")
            ),
            "scope_category": category,
            "scope_reason": result.reason,
            "requires_human_approval": (
                state.get("requires_human_approval", False)
                or result.requires_human_approval
            ),
            "clarification_question": result.clarification_question,
            "current_agent": "input_guardrail",
        }

        if result.requires_clarification:
            changes.update(
                status="requires_clarification",
                next_node="clarification",
            )
        elif not result.accepted:
            changes.update(
                status="failed",
                next_node="reporting_agent",
                safe_response=result.reason,
                terminal_error=True,
                errors=[
                    _error(
                        ErrorCategory.VALIDATION,
                        result.reason,
                        AgentName.SYSTEM,
                        recoverable=False,
                        technical_details=result.issue_code,
                    )
                ],
            )
        else:
            changes.update(
                status="planning",
                next_node="authorization",
            )
        return _updated(changes, "input_guardrail", "Request checked.")

    def authorization(self, state: AnalyticsState) -> AnalyticsState:
        user_id = state.get("user_id")
        identity = (
            self.dependencies.authentication.get_user_by_id(user_id)
            if user_id
            else None
        )
        if identity is None:
            return _failed(
                ErrorCategory.AUTHORIZATION,
                "An authenticated user is required to access analytics.",
                AgentName.SYSTEM,
            )

        database_name = state.get(
            "database_name",
            self.dependencies.database_name,
        )
        if not self.dependencies.registry.contains(database_name):
            return _failed(
                ErrorCategory.DATABASE,
                f"Database '{database_name}' is not registered.",
                AgentName.SYSTEM,
            )

        read_access = self.dependencies.authorization.authorize(
            identity,
            Permission.NORTHWIND_READ,
            database_name,
        )
        schema_access = self.dependencies.authorization.authorize(
            identity,
            Permission.SCHEMA_READ,
            database_name,
        )
        allowed = read_access.allowed and schema_access.allowed
        reason = (
            " ".join(
                item.reason
                for item in (read_access, schema_access)
            )
            if allowed
            else (
                read_access.reason
                if not read_access.allowed
                else schema_access.reason
            )
        )
        context = {
            "allowed": allowed,
            "reason": reason,
            "database_name": database_name,
            "role": _enum_value(identity.role),
            "permissions": [
                _enum_value(permission)
                for permission in identity.permissions
            ],
            "allowed_databases": identity.allowed_databases,
        }
        if not allowed:
            return _updated(
                {
                    "permission_context": context,
                    "status": "failed",
                    "next_node": "reporting_agent",
                    "safe_response": reason,
                    "terminal_error": True,
                    "current_agent": "authorization",
                    "errors": [
                        _error(
                            ErrorCategory.AUTHORIZATION,
                            reason,
                            AgentName.SYSTEM,
                            recoverable=False,
                        )
                    ],
                },
                "authorization",
                "Access denied.",
                failed=True,
            )

        if (
            state.get("status") == "requires_approval"
            and state.get("sql_is_safe") is True
            and state.get("human_approved") is not True
        ):
            next_node = "reporting_agent"
        elif (
            state.get("sql_is_safe") is True
            and state.get("human_approved") is True
        ):
            next_node = "query_executor"
        else:
            next_node = "intent_agent"
        return _updated(
            {
                "permission_context": context,
                "status": "planning",
                "next_node": next_node,
                "current_agent": "authorization",
            },
            "authorization",
            "Backend permissions verified.",
        )

    def intent(self, state: AnalyticsState) -> AnalyticsState:
        identity = self._identity(state)
        if identity is None:
            return _failed(
                ErrorCategory.AUTHORIZATION,
                "The authenticated user could not be resolved.",
                AgentName.INTENT_AGENT,
            )
        try:
            result = self.dependencies.intent_agent.run(
                state.get("normalized_query", state.get("user_query", "")),
                identity.role,
                self.dependencies.registry.list_databases(),
                database_name=state.get(
                    "database_name",
                    self.dependencies.database_name,
                ),
                defer_human_approval=True,
            )
            intent = IntentResult.model_validate(result)
        except AgentRequestBlockedError as exc:
            return _failed(
                ErrorCategory.VALIDATION,
                "The request was blocked by the input guardrail.",
                AgentName.INTENT_AGENT,
                technical_details=str(exc),
            )
        except (RuntimeError, ValueError, TypeError) as exc:
            return _failed(
                ErrorCategory.LLM,
                "The request could not be classified safely.",
                AgentName.INTENT_AGENT,
                technical_details=str(exc),
            )

        intent_value = _enum_value(intent.intent)
        if intent.requires_clarification:
            next_node = "clarification"
            status = "requires_clarification"
        elif intent_value == QueryIntent.SCHEMA_QUESTION.value:
            next_node = "schema_retrieval"
            status = "schema_discovery"
        elif intent_value in {
            QueryIntent.GENERAL_QUESTION.value,
            QueryIntent.UNKNOWN.value,
        }:
            next_node = "reporting_agent"
            status = "response_generation"
        else:
            next_node = "planning_agent"
            status = "planning"

        safe_response = None
        if next_node == "reporting_agent":
            safe_response = (
                "This request could not be mapped to a supported "
                "business analytics task."
            )
        return _updated(
            {
                "intent_result": intent.model_dump(mode="json"),
                "intent": intent_value,
                "intent_confidence": intent.confidence,
                "entities": {
                    "metrics": [
                        metric.model_dump(mode="json")
                        for metric in intent.metrics
                    ],
                    "dimensions": [
                        dimension.model_dump(mode="json")
                        for dimension in intent.dimensions
                    ],
                    "filters": [
                        item.model_dump(mode="json")
                        for item in intent.filters
                    ],
                },
                "clarification_question": intent.clarification_question,
                "safe_response": safe_response,
                "status": status,
                "next_node": next_node,
                "current_agent": AgentName.INTENT_AGENT.value,
            },
            AgentName.INTENT_AGENT.value,
            f"Classified request as {intent_value}.",
        )

    def planning(self, state: AnalyticsState) -> AnalyticsState:
        approval_required = state.get(
            "requires_human_approval",
            False,
        )
        approval_reason = (
            state.get("scope_reason")
            or "This request requires human approval."
            if approval_required
            else None
        )
        try:
            intent = IntentResult.model_validate(state["intent_result"])
            plan = self.dependencies.planning_agent.run(
                intent,
                state.get("permission_context", {}),
                self.dependencies.registry.list_databases(),
                state.get("database_name", self.dependencies.database_name),
                execution_policy={
                    "max_sql_retries": min(
                        state.get("max_retries", 2),
                        5,
                    ),
                    "max_result_rows": settings.MAX_QUERY_ROWS,
                    "query_timeout_seconds": settings.QUERY_TIMEOUT,
                    "read_only_required": True,
                    "human_approval_required": approval_required,
                    "approval_reason": approval_reason,
                },
                human_approval_required=approval_required,
                approval_reason=approval_reason,
            )
            plan = AnalysisPlan.model_validate(plan)
        except (RuntimeError, ValueError, TypeError, PermissionError) as exc:
            return _failed(
                ErrorCategory.LLM,
                "A safe execution plan could not be created.",
                AgentName.PLANNING_AGENT,
                technical_details=str(exc),
            )

        requires_clarification = (
            intent.requires_clarification or plan.requires_clarification
        )
        next_node = "clarification" if requires_clarification else (
            "schema_retrieval"
        )
        return _updated(
            {
                "plan_result": plan.model_dump(mode="json"),
                "execution_plan": [
                    task.model_dump(mode="json")
                    for task in plan.tasks
                ],
                "requires_human_approval": (
                    state.get("requires_human_approval", False)
                    or plan.controls.human_approval_required
                ),
                "max_retries": min(
                    state.get("max_retries", 2),
                    plan.controls.max_sql_retries,
                ),
                "clarification_question": (
                    plan.clarification_question
                    or state.get("clarification_question")
                ),
                "status": (
                    "requires_clarification"
                    if requires_clarification
                    else "schema_discovery"
                ),
                "next_node": next_node,
                "current_agent": AgentName.PLANNING_AGENT.value,
            },
            AgentName.PLANNING_AGENT.value,
            "Execution plan created.",
        )

    def schema_retrieval(self, state: AnalyticsState) -> AnalyticsState:
        database_name = state.get(
            "database_name",
            self.dependencies.database_name,
        )
        try:
            identity = self._identity(state)
            if identity is None:
                return _failed(
                    ErrorCategory.AUTHORIZATION,
                    "The authenticated user could not be resolved.",
                    AgentName.SYSTEM,
                )
            schema_service = self.dependencies.schema_service
            if schema_service is None:
                schema = self.dependencies.schema_manager.get_database_schema(
                    database_name=database_name,
                )
                schema_context = (
                    self.dependencies.schema_manager.build_schema_context(
                        database_name=database_name,
                        max_tables=25,
                        max_characters=12000,
                    )
                )
            else:
                schema = schema_service.get_schema(
                    username=identity.username,
                    database_name=database_name,
                )
                schema_context = schema_service.build_schema_context(
                    username=identity.username,
                    database_name=database_name,
                    max_tables=25,
                    max_characters=12000,
                )
        except (RuntimeError, ValueError, TypeError) as exc:
            return _failed(
                ErrorCategory.SCHEMA,
                "Database schema information could not be retrieved.",
                AgentName.SYSTEM,
                technical_details=str(exc),
            )

        if _enum_value(
            state.get("intent_result", {}).get("intent", "")
        ) == QueryIntent.SCHEMA_QUESTION.value:
            table_names = schema.get("table_names", [])
            table_names = [
                str(name)
                for name in table_names
                if isinstance(name, str)
            ]
            response = (
                "Available tables: " + ", ".join(table_names)
                if table_names
                else "No database tables are available."
            )
            return _updated(
                {
                    "schema_metadata": schema,
                    "schema_context": schema_context,
                    "selected_tables": table_names,
                    "safe_response": response,
                    "status": "response_generation",
                    "next_node": "reporting_agent",
                    "current_agent": AgentName.SYSTEM.value,
                },
                AgentName.SYSTEM.value,
                "Schema question answered from registry metadata.",
            )

        required_tables = (
            state.get("plan_result", {})
            .get("data_requirements", {})
            .get("required_tables", [])
        )
        schema_tables = schema.get("table_names", [])
        selected_tables = (
            [
                table
                for table in required_tables
                if isinstance(table, str) and table in schema_tables
            ]
            if isinstance(required_tables, list)
            else []
        )
        return _updated(
            {
                "schema_metadata": schema,
                "schema_context": schema_context,
                "selected_tables": selected_tables or list(schema_tables),
                "selected_columns": {
                    table_name: [
                        column["name"]
                        for column in table.get("columns", [])
                        if isinstance(column, Mapping)
                        and isinstance(column.get("name"), str)
                    ]
                    for table_name, table in schema.get(
                        "tables",
                        {},
                    ).items()
                    if isinstance(table, Mapping)
                },
                "status": "sql_generation",
                "next_node": "sql_agent",
                "current_agent": AgentName.SYSTEM.value,
            },
            AgentName.SYSTEM.value,
            "Schema retrieved from the registered database.",
        )

    def sql_generation(self, state: AnalyticsState) -> AnalyticsState:
        try:
            plan = AnalysisPlan.model_validate(state["plan_result"])
            result = self.dependencies.sql_agent.run(
                plan,
                state.get("schema_context", ""),
                previous_validation_errors=state.get(
                    "sql_validation_errors",
                    [],
                ),
                max_result_rows=plan.controls.max_result_rows,
            )
            generated = SQLGenerationResult.model_validate(result)
        except (RuntimeError, ValueError, TypeError) as exc:
            return _failed(
                ErrorCategory.SQL_GENERATION,
                "A read-only SQL candidate could not be generated.",
                AgentName.SQL_AGENT,
                technical_details=str(exc),
            )

        return _updated(
            {
                "sql_generation_result": generated.model_dump(mode="json"),
                "generated_sql": generated.sql_query,
                "validated_sql": None,
                "sql_parameters": generated.parameters,
                "sql_explanation": generated.explanation,
                "sql_is_safe": False,
                "sql_validation_result": {},
                "status": "sql_validation",
                "next_node": "sql_validation",
                "current_agent": AgentName.SQL_AGENT.value,
            },
            AgentName.SQL_AGENT.value,
            "SQL candidate generated; validation is required.",
        )

    def sql_validation(self, state: AnalyticsState) -> AnalyticsState:
        generated = SQLGenerationResult.model_validate(
            state.get("sql_generation_result", {})
        )
        validation = self.dependencies.sql_validator.validate(
            generated.sql_query,
            query_id=generated.query_id,
        )
        validation = SQLValidationResult.model_validate(validation)
        retry = self.dependencies.retry_handler.evaluate(
            validation,
            current_retry_count=state.get("retry_count", 0),
            max_retries=state.get("max_retries", 0),
        )
        logger.info(
            "SQL validation decision: {}",
            {
                "request_id": state.get("request_id"),
                "status": validation.status,
                "syntax_valid": validation.syntax_valid,
                "schema_valid": validation.schema_valid,
                "security_valid": validation.security_valid,
                "read_only": validation.read_only,
                "issue_codes": [issue.code for issue in validation.issues],
                "retry_decision": retry.decision.value,
                "retry_count": retry.next_retry_count,
                "max_retries": retry.max_retries,
            },
        )
        is_safe = (
            validation.status == SQLValidationStatus.VALID.value
            and validation.syntax_valid
            and validation.schema_valid
            and validation.security_valid
            and validation.read_only
            and bool(validation.executable_sql)
        )
        validation_dump = validation.model_dump(mode="json")
        base = {
            "sql_validation_result": validation_dump,
            "validated_sql": validation.executable_sql if is_safe else None,
            "sql_is_safe": is_safe,
            "status": "sql_execution" if is_safe else "sql_validation",
            "current_agent": AgentName.SQL_VALIDATOR.value,
        }

        if is_safe:
            if (
                state.get("requires_human_approval") is True
                and state.get("human_approved") is not True
            ):
                base.update(
                    status="requires_approval",
                    next_node="human_approval",
                )
            else:
                base.update(next_node="query_executor")
            base["sql_validation_errors"] = []
            return _updated(
                base,
                AgentName.SQL_VALIDATOR.value,
                "SQL passed deterministic validation.",
            )

        feedback = (
            retry.correction_feedback
            or "; ".join(
                f"{issue.code}: {issue.message}"
                for issue in validation.issues
            )
            or retry.reason
        )
        retry_allowed = retry.should_retry and not retry.terminal
        base.update(
            {
                "sql_validation_errors": [feedback],
                "retry_count": retry.next_retry_count,
                "errors": [
                    _error(
                        ErrorCategory.SQL_VALIDATION,
                        retry.reason,
                        AgentName.SQL_VALIDATOR,
                        recoverable=retry_allowed,
                        technical_details=feedback,
                    )
                ],
            }
        )
        if retry_allowed:
            base.update(
                status="sql_generation",
                next_node="sql_agent",
            )
        else:
            base.update(
                status="failed",
                next_node="reporting_agent",
                safe_response=(
                    "The generated query did not pass safety validation "
                    "and was not executed."
                ),
                terminal_error=True,
            )
        return _updated(
            base,
            AgentName.SQL_VALIDATOR.value,
            retry.reason,
            failed=not retry_allowed,
        )

    def human_approval(self, state: AnalyticsState) -> AnalyticsState:
        if state.get("human_approved") is True:
            return _updated(
                {
                    "status": "sql_execution",
                    "next_node": "query_executor",
                    "safe_response": None,
                    "current_agent": AgentName.SYSTEM.value,
                },
                AgentName.SYSTEM.value,
                "Human approval recorded.",
            )
        return _updated(
            {
                "status": "requires_approval",
                "next_node": "reporting_agent",
                "safe_response": (
                    "Human approval is required before the validated "
                    "query can be executed."
                ),
                "current_agent": AgentName.SYSTEM.value,
            },
            AgentName.SYSTEM.value,
            "Query execution paused for human approval.",
        )

    def query_execution(self, state: AnalyticsState) -> AnalyticsState:
        validation = SQLValidationResult.model_validate(
            state.get("sql_validation_result", {})
        )
        if (
            state.get("sql_is_safe") is not True
            or validation.status != SQLValidationStatus.VALID.value
        ):
            return _failed(
                ErrorCategory.SQL_VALIDATION,
                "The query execution boundary rejected an unvalidated query.",
                AgentName.QUERY_EXECUTOR,
            )
        identity = self._identity(state)
        if identity is None:
            return _failed(
                ErrorCategory.AUTHORIZATION,
                "The authenticated user could not be resolved.",
                AgentName.QUERY_EXECUTOR,
            )
        plan = AnalysisPlan.model_validate(state.get("plan_result", {}))
        try:
            result = self.dependencies.query_executor.execute(
                validation,
                identity,
                database_name=state.get(
                    "database_name",
                    self.dependencies.database_name,
                ),
                parameters=state.get("sql_parameters", {}),
                max_rows=plan.controls.max_result_rows,
            )
            execution = QueryExecutionResult.model_validate(result)
        except RuntimeError as exc:
            return _failed(
                ErrorCategory.SQL_EXECUTION,
                "The database execution service could not complete the query.",
                AgentName.QUERY_EXECUTOR,
                technical_details=str(exc),
            )

        execution_dump = execution.model_dump(mode="json")
        if execution.success:
            return _updated(
                {
                    "execution_result": execution_dump,
                    "status": "analysis",
                    "next_node": "analysis_agent",
                    "current_agent": AgentName.QUERY_EXECUTOR.value,
                },
                AgentName.QUERY_EXECUTOR.value,
                "Read-only query executed.",
            )

        retry_allowed = (
            execution.retryable
            and state.get("retry_count", 0)
            < state.get("max_retries", 0)
        )
        reason = execution.error_message or "Database query failed."
        changes: dict[str, Any] = {
            "execution_result": execution_dump,
            "sql_is_safe": True,
            "sql_validation_errors": [reason],
            "errors": [
                _error(
                    ErrorCategory.SQL_EXECUTION,
                    "Database query execution failed.",
                    AgentName.QUERY_EXECUTOR,
                    recoverable=retry_allowed,
                    technical_details=reason,
                )
            ],
            "current_agent": AgentName.QUERY_EXECUTOR.value,
        }
        if retry_allowed:
            changes.update(
                retry_count=state.get("retry_count", 0) + 1,
                status="sql_generation",
                next_node="sql_agent",
            )
        else:
            fallback_response = (
                (
                    "Query execution failed after returning partial results; "
                    "the partial rows were not analyzed."
                )
                if execution.records
                else (
                    "No query data is available because execution failed; "
                    "no findings can be supported."
                )
            )
            changes.update(
                status="failed",
                next_node="reporting_agent",
                safe_response=fallback_response,
                terminal_error=True,
            )
        return _updated(
            changes,
            AgentName.QUERY_EXECUTOR.value,
            "Database query execution failed.",
            failed=not retry_allowed,
        )

    def analysis(self, state: AnalyticsState) -> AnalyticsState:
        try:
            execution = QueryExecutionResult.model_validate(
                state["execution_result"]
            )
            intent = IntentResult.model_validate(state["intent_result"])
            plan = AnalysisPlan.model_validate(state["plan_result"])
            result = self.dependencies.analysis_agent.run(
                execution,
                intent,
                plan,
                referenced_tables=state.get(
                    "sql_validation_result",
                    {},
                ).get("referenced_tables", []),
            )
            analysis = AnalysisResult.model_validate(result)
        except (RuntimeError, ValueError, TypeError) as exc:
            return _failed(
                ErrorCategory.ANALYSIS,
                "The executed data could not be analyzed safely.",
                AgentName.ANALYSIS_AGENT,
                technical_details=str(exc),
            )

        return _updated(
            {
                "analysis_result": analysis.model_dump(mode="json"),
                "analysis_summary": analysis.analysis_summary,
                "insights": [
                    finding.description
                    for finding in analysis.findings
                ],
                "metrics": {
                    metric.name: metric.model_dump(mode="json")
                    for metric in analysis.metrics
                },
                "assumptions": analysis.assumptions,
                "warnings": analysis.warnings,
                "status": "analysis",
                "next_node": "grounding_validator",
                "current_agent": AgentName.ANALYSIS_AGENT.value,
            },
            AgentName.ANALYSIS_AGENT.value,
            "Deterministic analysis completed.",
        )

    def grounding(self, state: AnalyticsState) -> AnalyticsState:
        analysis = AnalysisResult.model_validate(state["analysis_result"])
        execution = QueryExecutionResult.model_validate(
            state["execution_result"]
        )
        validation = SQLValidationResult.model_validate(
            state["sql_validation_result"]
        )
        schema = state.get("schema_metadata", {})
        schema_tables = schema.get("table_names", [])
        result = self.dependencies.grounding_validator.validate(
            answer=analysis.analysis_summary,
            query_results=execution.records,
            result_columns=execution.metadata.columns,
            referenced_tables=validation.referenced_tables,
            known_tables=schema_tables,
            known_columns=execution.metadata.columns,
            user_query=state.get("normalized_query", state["user_query"]),
            data_sufficient=analysis.sufficient_data,
        )
        issue_values = [
            {"code": issue.code, "message": issue.message}
            for issue in result.issues
        ]
        analysis_values = analysis.model_dump(mode="json")
        if not result.grounded:
            limitation = (
                "The analysis summary did not pass grounding validation."
            )
            analysis_values["limitations"] = list(
                dict.fromkeys([*analysis.limitations, limitation])
            )
        return _updated(
            {
                "analysis_result": analysis_values,
                "grounding_result": {
                    "grounded": result.grounded,
                    "issues": issue_values,
                },
                "status": "response_generation",
                "next_node": "reporting_agent",
                "current_agent": AgentName.GROUNDING_VALIDATOR.value,
            },
            AgentName.GROUNDING_VALIDATOR.value,
            (
                "Grounding checks passed."
                if result.grounded
                else "Grounding limitations added to the report."
            ),
        )

    def reporting(self, state: AnalyticsState) -> AnalyticsState:
        execution_values = state.get("execution_result", {})
        analysis_values = state.get("analysis_result", {})
        if not execution_values or not analysis_values:
            response = state.get("safe_response") or (
                "The request could not be completed safely."
            )
            return _updated(
                {
                    "final_answer": response,
                    "status": state.get("status", "response_generation"),
                    "next_node": "output_guardrail",
                    "current_agent": AgentName.REPORTING_AGENT.value,
                },
                AgentName.REPORTING_AGENT.value,
                "Returned a deterministic response for a non-query path.",
                failed=state.get("terminal_error") is True,
            )

        try:
            intent = IntentResult.model_validate(state["intent_result"])
            execution = QueryExecutionResult.model_validate(execution_values)
            analysis = AnalysisResult.model_validate(analysis_values)
            report = self.dependencies.reporting_agent.run(
                intent,
                execution,
                analysis,
                state.get(
                    "grounding_result",
                    {"grounded": False, "issues": []},
                ),
                state.get("plan_result", {}).get(
                    "recommended_visualizations",
                    [],
                ),
                sql_validation_result=state.get(
                    "sql_validation_result"
                ),
                validated_sql=(
                    state.get("validated_sql")
                    if state.get("sql_is_safe") is True
                    else None
                ),
                audience_context={
                    "role": state.get(
                        "permission_context",
                        {},
                    ).get("role")
                },
            )
            report = ReportResult.model_validate(report)
        except (RuntimeError, ValueError, TypeError) as exc:
            return _failed(
                ErrorCategory.LLM,
                "A validated report could not be generated.",
                AgentName.REPORTING_AGENT,
                technical_details=str(exc),
            )

        report_text = _format_report(report)
        if execution.success and execution.records:
            result_table = _format_result_table(execution.records)
            if result_table:
                report_text = (
                    f"{report_text}\n\nReturned query results:\n"
                    f"{result_table}"
                )
        report_values = report.model_dump(mode="json")
        for chart in report_values.get("charts", []):
            if isinstance(chart, dict):
                chart.pop("data", None)
        chart_specs = serialize_chart_specifications(report.charts)
        return _updated(
            {
                "report_result": report_values,
                "chart_specifications": chart_specs,
                "visualization_required": bool(chart_specs),
                "visualization_data": (
                    execution.model_dump(mode="json")["records"]
                    if chart_specs
                    else []
                ),
                "final_answer": report_text,
                "status": "response_generation",
                "next_node": "output_guardrail",
                "current_agent": AgentName.REPORTING_AGENT.value,
            },
            AgentName.REPORTING_AGENT.value,
            "Report assembled; output validation is required.",
        )

    def clarification(self, state: AnalyticsState) -> AnalyticsState:
        response = (
            state.get("clarification_question")
            or "Please clarify the request so it can be analyzed safely."
        )
        return _updated(
            {
                "final_answer": response,
                "status": "requires_clarification",
                "next_node": "output_guardrail",
                "current_agent": AgentName.SYSTEM.value,
            },
            AgentName.SYSTEM.value,
            "Requested clarification.",
        )

    def output_guardrail(self, state: AnalyticsState) -> AnalyticsState:
        answer = state.get("final_answer") or state.get("safe_response") or ""
        rows: list[Mapping[str, Any]] = []
        result_columns: Sequence[str] | None = None
        referenced_tables: Sequence[str] = ()
        known_tables: Sequence[str] = ()
        known_columns: Sequence[str] = ()
        result_count: int | None = None
        data_sufficient = True
        execution_values = state.get("execution_result", {})
        analysis_values = state.get("analysis_result", {})

        if execution_values:
            execution = (
                QueryExecutionResult.model_validate(execution_values)
                if execution_values
                else None
            )
            rows.extend(execution.records)
            result_count = len(execution.records)
            if analysis_values:
                rows.extend(_analysis_evidence_rows(analysis_values))
                analysis = AnalysisResult.model_validate(analysis_values)
                data_sufficient = analysis.sufficient_data
            validation_values = state.get("sql_validation_result", {})
            if validation_values:
                validation = SQLValidationResult.model_validate(
                    validation_values
                )
                referenced_tables = validation.referenced_tables
                known_tables = state.get(
                    "schema_metadata",
                    {},
                ).get("table_names", [])
                known_columns = execution.metadata.columns
        elif (
            state.get("scope_category") == "schema_question"
            or state.get("intent") == QueryIntent.SCHEMA_QUESTION.value
        ):
            result_columns = state.get("selected_tables", [])

        result = self.dependencies.output_guardrail.validate(
            answer,
            rows,
            result_columns=result_columns,
            referenced_tables=referenced_tables,
            known_tables=known_tables,
            known_columns=known_columns,
            user_query=state.get("normalized_query", state["user_query"]),
            data_sufficient=data_sufficient,
            result_count=result_count,
        )
        guardrail_values = {
            "approved": result.approved,
            "issues": list(result.issues),
            "grounded": result.grounding_result.grounded,
            "grounding_issues": [
                {"code": issue.code, "message": issue.message}
                for issue in result.grounding_result.issues
            ],
        }
        if not result.approved or result.output is None:
            message = (
                "The response did not pass final safety validation."
            )
            return _updated(
                {
                    "final_answer": None,
                    "status": "failed",
                    "next_node": "end",
                    "terminal_error": True,
                    "output_guardrail_result": guardrail_values,
                    "errors": [
                        _error(
                            ErrorCategory.VALIDATION,
                            message,
                            AgentName.OUTPUT_GUARDRAIL,
                            recoverable=False,
                            technical_details="; ".join(result.issues),
                        )
                    ],
                    "current_agent": AgentName.OUTPUT_GUARDRAIL.value,
                },
                AgentName.OUTPUT_GUARDRAIL.value,
                message,
                failed=True,
            )

        if state.get("requires_human_approval") is True and (
            state.get("human_approved") is not True
        ):
            status = "requires_approval"
        elif state.get("status") == "requires_clarification":
            status = "requires_clarification"
        else:
            status = state.get("status", "completed")
            if status not in {"failed"}:
                status = "completed"
        execution = (
            QueryExecutionResult.model_validate(execution_values)
            if execution_values
            else None
        )
        report_values = state.get("report_result", {})
        report_grounded = (
            report_values.get("grounded")
            if isinstance(report_values, Mapping)
            else None
        )
        final_grounded = result.grounding_result.grounded
        if isinstance(report_grounded, bool):
            final_grounded = final_grounded and report_grounded
        execution_error = (
            (
                execution.success is False
                or bool(execution.error_message)
            )
            if execution is not None
            else any(
                isinstance(error, Mapping)
                and error.get("category") == "sql_execution"
                for error in state.get("errors", [])
            )
        )
        analysis = (
            AnalysisResult.model_validate(analysis_values)
            if analysis_values
            else None
        )
        return _updated(
            {
                "final_answer": result.output,
                "status": status,
                "next_node": "end",
                "output_guardrail_result": guardrail_values,
                "response_metadata": {
                    "grounded": final_grounded,
                    "query_executed": (
                        execution is not None or execution_error
                    ),
                    "row_count": (
                        execution.metadata.row_count
                        if execution is not None
                        else 0
                    ),
                    "result_rows": (
                        len(execution.records)
                        if execution is not None
                        else 0
                    ),
                    "execution_error": execution_error,
                    "sufficient_data": (
                        analysis.sufficient_data
                        if analysis is not None
                        else None
                    ),
                    "chart_count": len(
                        state.get("chart_specifications", [])
                    ),
                    "requires_human_approval": (
                        state.get("requires_human_approval", False)
                        and state.get("human_approved") is not True
                    ),
                },
                "current_agent": AgentName.OUTPUT_GUARDRAIL.value,
            },
            AgentName.OUTPUT_GUARDRAIL.value,
            "Final response passed safety validation.",
        )

    def _identity(self, state: AnalyticsState) -> UserIdentity | None:
        user_id = state.get("user_id")
        return (
            self.dependencies.authentication.get_user_by_id(user_id)
            if user_id
            else None
        )


def build_nodes(dependencies: WorkflowDependencies) -> WorkflowNodes:
    """Create node callables sharing one injected dependency set."""
    return WorkflowNodes(dependencies)


def _format_result_table(
    records: Sequence[Mapping[str, Any]],
) -> str:
    """Render returned records as escaped Markdown for the final answer."""
    if not records:
        return ""
    columns = list(records[0].keys())
    if not columns:
        return ""

    def format_cell(value: Any) -> str:
        if value is None:
            return "NULL"
        return (
            html_escape(str(value))
            .replace("|", r"\|")
            .replace("\r", " ")
            .replace("\n", " ")
        )

    header = "| " + " | ".join(format_cell(item) for item in columns) + " |"
    separator = "| " + " | ".join("---" for _ in columns) + " |"
    rows = [
        "| "
        + " | ".join(format_cell(record.get(column)) for column in columns)
        + " |"
        for record in records
    ]
    return "\n".join([header, separator, *rows])


def _enum_value(value: Any) -> str:
    return str(getattr(value, "value", value))


def _error(
    category: ErrorCategory,
    message: str,
    agent: AgentName,
    *,
    recoverable: bool,
    technical_details: str | None = None,
) -> dict[str, Any]:
    return WorkflowError(
        category=category,
        message=message,
        agent=agent,
        recoverable=recoverable,
        technical_details=technical_details,
    ).model_dump(mode="json")


def _failed(
    category: ErrorCategory,
    message: str,
    agent: AgentName,
    *,
    technical_details: str | None = None,
) -> AnalyticsState:
    return _updated(
        {
            "status": "failed",
            "next_node": "reporting_agent",
            "safe_response": message,
            "terminal_error": True,
            "errors": [
                _error(
                    category,
                    message,
                    agent,
                    recoverable=False,
                    technical_details=technical_details,
                )
            ],
        },
        agent.value,
        message,
        failed=True,
    )


def _updated(
    changes: Mapping[str, Any],
    agent: str,
    details: str,
    *,
    failed: bool = False,
) -> AnalyticsState:
    update = dict(changes)
    update.update(
        state_update(
            agent_trace=[
                {
                    "agent": agent,
                    "action": "execute workflow node",
                    "status": "failed" if failed else "completed",
                    "details": details,
                }
            ]
        )
    )
    return update  # type: ignore[return-value]


def _format_report(report: ReportResult) -> str:
    sections = [
        report.report_title,
        report.executive_summary,
    ]
    if report.key_findings:
        sections.extend(
            [
                "Key findings:",
                *[
                    f"- {finding.title}: {finding.description}"
                    for finding in report.key_findings
                ],
            ]
        )
    if report.recommendations:
        sections.extend(
            [
                "Recommendations:",
                *[
                    f"- {item.title}: {item.recommendation}"
                    for item in report.recommendations
                ],
            ]
        )
    if report.limitations:
        sections.extend(
            ["Limitations:", *[f"- {item}" for item in report.limitations]]
        )
    if report.assumptions:
        sections.extend(
            ["Assumptions:", *[f"- {item}" for item in report.assumptions]]
        )
    return "\n\n".join(sections)


def _analysis_evidence_rows(
    values: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Flatten deterministic analysis evidence for final grounding checks.

    Finding evidence can contain calculated numbers under
    ``findings[*].evidence[*].values``. Those values were previously omitted,
    causing false UNSUPPORTED_NUMBER failures at the final output guardrail.
    """
    rows: list[dict[str, Any]] = []
    for collection in (
        "metrics", "comparisons", "trends", "anomalies",
        "contribution_details",
    ):
        items = values.get(collection, [])
        if isinstance(items, list):
            rows.extend(dict(item) for item in items if isinstance(item, Mapping))

    findings = values.get("findings", [])
    if isinstance(findings, list):
        for finding in findings:
            if not isinstance(finding, Mapping):
                continue
            evidence_items = finding.get("evidence", [])
            if not isinstance(evidence_items, list):
                continue
            for evidence in evidence_items:
                if not isinstance(evidence, Mapping):
                    continue
                evidence_values = evidence.get("values", {})
                if isinstance(evidence_values, Mapping) and evidence_values:
                    rows.append(dict(evidence_values))
                identifiers = evidence.get("record_identifiers", [])
                if isinstance(identifiers, list) and identifiers:
                    rows.append({"record_identifiers": " ".join(map(str, identifiers))})
    return rows

