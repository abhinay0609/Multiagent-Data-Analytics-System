"""FastAPI application factory and process lifecycle."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from loguru import logger

from api.analytics_routes import router as analytics_router
from api.auth_routes import router as auth_router
from api.report_routes import router as report_router
from app.dependencies import (
    AppDependencies,
    create_app_dependencies,
)
from app.startup import (
    check_database_health,
    check_llm_health,
    initialize_application,
)
from config.settings import settings
from database.database_registry import DatabaseRegistryError


def create_app(
    dependencies: AppDependencies | None = None,
) -> FastAPI:
    """Create the API app with injectable backend services."""
    app_dependencies = (
        dependencies
        if dependencies is not None
        else create_app_dependencies()
    )
    owns_registry = app_dependencies.registry is None

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncGenerator[None, None]:
        initialize_application(app_dependencies)
        logger.info("Application startup completed.")
        try:
            yield
        finally:
            if owns_registry and app_dependencies.registry is not None:
                app_dependencies.registry.dispose()
                logger.info("Application database pools disposed.")

    application = FastAPI(
        title=settings.APP_NAME,
        version="1.0.0",
        lifespan=lifespan,
    )
    application.state.dependencies = app_dependencies
    application.include_router(auth_router)
    application.include_router(analytics_router)
    application.include_router(report_router)

    @application.get("/health", tags=["health"])
    def health() -> dict[str, str]:
        return {"status": "healthy"}

    @application.get("/health/database", tags=["health"])
    def database_health():
        if app_dependencies.registry is None:
            return JSONResponse(
                status_code=503,
                content={"status": "unhealthy", "databases": {}},
            )
        try:
            result = check_database_health(app_dependencies.registry)
        except DatabaseRegistryError as exc:
            logger.warning("Database health check failed: {}", exc)
            return JSONResponse(
                status_code=503,
                content={"status": "unhealthy", "databases": {}},
            )
        return JSONResponse(
            status_code=200 if result["status"] == "healthy" else 503,
            content=result,
        )

    @application.get("/health/llm", tags=["health"])
    def llm_health():
        result = check_llm_health(app_dependencies.llm)
        return JSONResponse(
            status_code=200 if result["status"] == "healthy" else 503,
            content=result,
        )

    return application


app = create_app()