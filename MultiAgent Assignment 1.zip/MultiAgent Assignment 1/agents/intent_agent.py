"""Understand and structure a business analytics request."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Mapping, Sequence

from guardrails import (
    InputGuardrail,
    InputGuardrailResult,
    RequestCategory,
    input_guardrail,
)
from schemas.intent_schema import (
    ComparisonRequirement,
    ComparisonType,
    IntentResult,
    QueryIntent,
)
from schemas.user_schema import UserRole

from agents._common import (
    AgentLLM,
    call_model_json,
    get_default_llm,
    render_prompt,
)


class AgentRequestBlockedError(ValueError):
    """Raised when deterministic input policy blocks agent processing."""

    def __init__(self, result: InputGuardrailResult) -> None:
        self.guardrail_result = result
        super().__init__(result.reason)


class IntentAgent:
    """Convert an approved natural-language question into a typed intent."""

    def __init__(
        self,
        llm: AgentLLM | None = None,
        input_guardrail_instance: InputGuardrail | None = None,
    ) -> None:
        self._llm = llm if llm is not None else get_default_llm()
        self._input_guardrail = (
            input_guardrail_instance
            if input_guardrail_instance is not None
            else input_guardrail
        )

    def run(
        self,
        user_question: str,
        user_role: UserRole | str,
        available_databases: Sequence[Mapping[str, Any] | Any],
        *,
        database_name: str = "northwind",
        conversation_context: str = "",
        defer_human_approval: bool = False,
    ) -> IntentResult:
        """Classify a user request after deterministic input guardrails."""
        if not isinstance(user_question, str):
            raise TypeError("user_question must be a string.")
        if not isinstance(database_name, str) or not database_name.strip():
            raise ValueError("database_name must be a non-empty string.")
        if not isinstance(defer_human_approval, bool):
            raise TypeError("defer_human_approval must be a boolean.")
        role_name = _role_name(user_role)
        database_descriptions = _public_database_descriptions(
            available_databases
        )
        if not database_descriptions:
            raise ValueError("At least one available database is required.")

        guardrail = self._input_guardrail.validate(
            user_question,
            database_name=database_name,
        )
        if not guardrail.accepted or (
            guardrail.requires_human_approval
            and not defer_human_approval
        ):
            raise AgentRequestBlockedError(guardrail)

        clean_question = guardrail.normalized_input
        if clean_question is None:
            raise ValueError("Input guardrail returned no normalized request.")

        if guardrail.requires_clarification:
            comparison = ComparisonRequirement()
            intent = QueryIntent.UNKNOWN
            if guardrail.category == RequestCategory.CLARIFICATION_REQUIRED:
                intent = QueryIntent.COMPARISON
                comparison = ComparisonRequirement(
                    required=True,
                    comparison_type=ComparisonType.PERIOD_OVER_PERIOD,
                )
            return IntentResult(
                original_question=clean_question,
                normalized_question=clean_question,
                intent=intent,
                comparison=comparison,
                requires_clarification=True,
                clarification_question=(
                    guardrail.clarification_question
                    or "Please clarify the request."
                ),
                missing_information=[guardrail.reason],
                confidence=1.0,
            )

        prompt = render_prompt(
            "intent_prompt.txt",
            {
                "USER_QUESTION": clean_question,
                "USER_ROLE": role_name,
                "SCOPE_DECISION": _scope_context(guardrail),
                "AVAILABLE_DATABASES": database_descriptions,
                "SCHEMA_CONTEXT": {},
                "CONVERSATION_CONTEXT": conversation_context,
            },
        )
        result = call_model_json(self._llm, prompt, IntentResult)
        if result.original_question != clean_question:
            raise ValueError(
                "Intent Agent changed the original user question."
            )
        return result


def _role_name(user_role: UserRole | str) -> str:
    if isinstance(user_role, UserRole):
        return user_role.value
    if isinstance(user_role, str):
        try:
            return UserRole(user_role).value
        except ValueError as exc:
            raise ValueError(f"Unsupported user role: {user_role!r}.") from exc
    raise TypeError("user_role must be a UserRole or role string.")


def _public_database_descriptions(
    databases: Sequence[Mapping[str, Any] | Any],
) -> list[dict[str, Any]]:
    if isinstance(databases, (str, bytes)):
        raise TypeError("available_databases must be a sequence.")

    public_fields = {
        "name",
        "database_name",
        "backend",
        "driver",
        "host",
        "port",
        "description",
        "read_only",
        "is_default",
    }
    results: list[dict[str, Any]] = []
    for database in databases:
        if isinstance(database, Mapping):
            values = database
        elif is_dataclass(database) and not isinstance(database, type):
            values = asdict(database)
        else:
            raise TypeError(
                "Each database description must be a mapping or dataclass."
            )
        results.append(
            {
                key: value
                for key, value in values.items()
                if key in public_fields
            }
        )
    return results


def _scope_context(result: InputGuardrailResult) -> dict[str, Any]:
    scope_result = result.scope_result
    return {
        "accepted": result.accepted,
        "category": (
            result.category.value
            if result.category is not None
            else None
        ),
        "reason": result.reason,
        "requires_clarification": result.requires_clarification,
        "requires_human_approval": result.requires_human_approval,
        "scope_supported": (
            scope_result.supported if scope_result is not None else None
        ),
    }