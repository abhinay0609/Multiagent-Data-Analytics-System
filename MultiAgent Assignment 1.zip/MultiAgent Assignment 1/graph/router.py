"""Deterministic conditional routing for the analytics workflow."""

from __future__ import annotations

from typing import Any, Mapping

from sql_security.retry_handler import SQLRetryHandler


_TERMINAL_SECURITY_CODES = SQLRetryHandler.TERMINAL_SECURITY_CODES


def route_after_input(state: Mapping[str, Any]) -> str:
    """Route guardrail decisions without asking an agent to choose a path."""
    return _next_or(state, {"authorization", "clarification", "reporting_agent"})


def route_after_authorization(state: Mapping[str, Any]) -> str:
    """Continue only when backend authorization has allowed the request."""
    permission_context = state.get("permission_context", {})
    if not isinstance(permission_context, Mapping) or not permission_context.get(
        "allowed", False
    ):
        return "reporting_agent"

    if (
        state.get("sql_is_safe") is True
        and state.get("human_approved") is True
        and _validation_is_valid(state)
    ):
        return "query_executor"

    if (
        state.get("status") == "requires_approval"
        and state.get("sql_is_safe") is True
        and state.get("human_approved") is not True
    ):
        return "reporting_agent"

    return "intent_agent"


def route_after_intent(state: Mapping[str, Any]) -> str:
    """Choose planning, schema response, clarification, or rejection."""
    return _next_or(
        state,
        {
            "planning_agent",
            "schema_retrieval",
            "clarification",
            "reporting_agent",
        },
    )


def route_after_planning(state: Mapping[str, Any]) -> str:
    """Retrieve schema only for a plan that does not need clarification."""
    if state.get("next_node") == "clarification":
        return "clarification"
    if state.get("status") == "failed" or state.get("terminal_error") is True:
        return "reporting_agent"
    return _next_or(state, {"schema_retrieval", "reporting_agent"})


def route_after_schema(state: Mapping[str, Any]) -> str:
    """Continue to SQL only when schema retrieval produced usable context."""
    if state.get("next_node") == "reporting_agent":
        return "reporting_agent"
    if state.get("schema_context"):
        return "sql_agent"
    return "reporting_agent"


def route_after_sql_generation(state: Mapping[str, Any]) -> str:
    """Every candidate query must pass deterministic validation."""
    if state.get("terminal_error") is True:
        return "reporting_agent"
    if state.get("generated_sql"):
        return "sql_validation"
    return "reporting_agent"


def route_after_sql_validation(state: Mapping[str, Any]) -> str:
    """Gate query execution on validator output and approval state."""
    if (
        state.get("sql_is_safe") is True
        and _validation_is_valid(state)
    ):
        if (
            state.get("requires_human_approval") is True
            and state.get("human_approved") is not True
        ):
            return "human_approval"
        return "query_executor"

    if _has_terminal_sql_error(state):
        return "reporting_agent"
    if (
        state.get("next_node") == "sql_agent"
        and _retry_available(state)
    ):
        return "sql_agent"
    return "reporting_agent"


def route_after_human_approval(state: Mapping[str, Any]) -> str:
    """Require explicit human approval before any query execution."""
    if (
        state.get("human_approved") is True
        and state.get("sql_is_safe") is True
        and _validation_is_valid(state)
    ):
        return "query_executor"
    return "reporting_agent"


def route_after_execution(state: Mapping[str, Any]) -> str:
    """Analyze successful results or allow a bounded execution retry."""
    execution_result = state.get("execution_result", {})
    if (
        isinstance(execution_result, Mapping)
        and execution_result.get("success") is True
    ):
        return "analysis_agent"
    if (
        state.get("next_node") == "sql_agent"
        and state.get("sql_is_safe") is True
        and _retry_available(state)
        and _latest_error_recoverable(state)
    ):
        return "sql_agent"
    return "reporting_agent"


def route_after_analysis(state: Mapping[str, Any]) -> str:
    """Always ground analysis before report generation."""
    if state.get("analysis_result"):
        return "grounding_validator"
    return "reporting_agent"


def route_after_grounding(_state: Mapping[str, Any]) -> str:
    """Grounding failure limits the report; it never reopens SQL execution."""
    return _next_or(_state, {"reporting_agent"})


def _next_or(
    state: Mapping[str, Any],
    allowed: set[str],
) -> str:
    selected = state.get("next_node")
    return selected if isinstance(selected, str) and selected in allowed else (
        "reporting_agent"
    )


def _validation_is_valid(state: Mapping[str, Any]) -> bool:
    result = state.get("sql_validation_result", {})
    return (
        isinstance(result, Mapping)
        and result.get("status") == "valid"
        and result.get("syntax_valid") is True
        and result.get("schema_valid") is True
        and result.get("security_valid") is True
        and result.get("read_only") is True
        and isinstance(result.get("executable_sql"), str)
        and bool(result.get("executable_sql"))
    )


def _has_terminal_sql_error(state: Mapping[str, Any]) -> bool:
    result = state.get("sql_validation_result", {})
    if isinstance(result, Mapping):
        issues = result.get("issues", [])
        if isinstance(issues, list):
            for issue in issues:
                if not isinstance(issue, Mapping):
                    continue
                if (
                    issue.get("severity") == "critical"
                    or issue.get("code") in _TERMINAL_SECURITY_CODES
                ):
                    return True

    errors = state.get("errors", [])
    if isinstance(errors, list) and errors:
        latest = errors[-1]
        if (
            isinstance(latest, Mapping)
            and latest.get("category") == "sql_validation"
            and latest.get("recoverable") is False
        ):
            return True
    return False


def _retry_available(state: Mapping[str, Any]) -> bool:
    retry_count = state.get("retry_count", 0)
    max_retries = state.get("max_retries", 0)
    return (
        isinstance(retry_count, int)
        and not isinstance(retry_count, bool)
        and isinstance(max_retries, int)
        and not isinstance(max_retries, bool)
        and 0 <= retry_count < max_retries
    )


def _latest_error_recoverable(state: Mapping[str, Any]) -> bool:
    errors = state.get("errors", [])
    if not isinstance(errors, list) or not errors:
        return False
    latest = errors[-1]
    return isinstance(latest, Mapping) and latest.get("recoverable") is True