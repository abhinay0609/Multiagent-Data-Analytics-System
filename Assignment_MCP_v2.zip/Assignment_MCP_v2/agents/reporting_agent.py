"""Build evidence-based report content and chart specifications."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import math
import re
from typing import Any

from pydantic import BaseModel

from loguru import logger

from agents._common import (
    AgentLLM,
    call_narrative_json,
    contains_no_result_claim,
    get_narrative_fallback_llm,
    get_narrative_llm,
    render_prompt,
)
from reporting import assemble_report, generate_recommendations
from guardrails import (
    GroundingResult,
    OutputGuardrail,
    output_guardrail,
)
from schemas.analysis_schema import AnalysisResult
from schemas.intent_schema import IntentResult
from schemas.report_schema import (
    ChartSpecification,
    ChartType,
    KeyFinding,
    ReportResult,
)
from schemas.sql_schema import QueryExecutionResult, SQLValidationResult


_BLOCKING_OUTPUT_CODES = {
    "EMPTY_OUTPUT",
    "SECRET_LEAK",
    "INTERNAL_PROMPT_LEAK",
    "STACK_TRACE",
    "DESTRUCTIVE_RECOMMENDATION",
}
class ReportingAgent:
    """Create a schema-validated report and fail closed on unsafe content."""

    def __init__(
        self,
        llm: AgentLLM | None = None,
        output_guardrail_instance: OutputGuardrail | None = None,
    ) -> None:
        self._llm = llm if llm is not None else get_narrative_llm()
        self._fallback_llm = (
            get_narrative_fallback_llm() if llm is None else None
        )
        self._output_guardrail = (
            output_guardrail_instance
            if output_guardrail_instance is not None
            else output_guardrail
        )

    def run(
        self,
        intent: IntentResult | Mapping[str, Any],
        query_execution_result: QueryExecutionResult | Mapping[str, Any],
        analysis_output: AnalysisResult | Mapping[str, Any],
        grounding_validation: GroundingResult | Mapping[str, Any],
        chart_recommendations: Sequence[Mapping[str, Any] | str] = (),
        *,
        sql_validation_result: SQLValidationResult | Mapping[str, Any] | None = None,
        validated_sql: str | None = None,
        audience_context: Mapping[str, Any] | str | None = None,
    ) -> ReportResult:
        """Create a report grounded in analysis and controlled query results."""
        request = IntentResult.model_validate(intent)
        execution = QueryExecutionResult.model_validate(
            query_execution_result
        )
        analysis = AnalysisResult.model_validate(analysis_output)
        grounding = _grounding_context(grounding_validation)
        if isinstance(chart_recommendations, (str, bytes)):
            raise TypeError("chart_recommendations must be a sequence.")
        if any(
            not isinstance(item, (Mapping, str))
            for item in chart_recommendations
        ):
            raise TypeError(
                "Each chart recommendation must be a mapping or string."
            )
        if validated_sql is not None and not isinstance(validated_sql, str):
            raise TypeError("validated_sql must be a string or None.")
        if validated_sql is not None:
            _require_validated_sql(
                sql_validation_result,
                validated_sql,
            )
        if not execution.success:
            report = _execution_failure_report(execution)
        elif not execution.records:
            report = _empty_result_report(analysis)
        elif not grounding["grounded"]:
            report = _grounding_failure_report(
                execution,
                analysis,
                "The analysis did not pass grounding validation.",
            )
        else:
            prompt = render_prompt(
                "reporting_prompt.txt",
                {
                    "INTENT_RESULT": request,
                    "ANALYSIS_RESULT": analysis,
                    "QUERY_EXECUTION_RESULT": execution,
                    "SQL_VALIDATION_RESULT": sql_validation_result or {},
                    "GROUNDING_VALIDATION": grounding,
                    "CHART_RECOMMENDATIONS": list(chart_recommendations),
                    "AUDIENCE_CONTEXT": audience_context or {},
                },
            )
            try:
                report = call_narrative_json(
                    self._llm,
                    prompt,
                    ReportResult,
                    fallback_llm=self._fallback_llm,
                )
            except Exception as exc:
                logger.warning(
                    "Report generation unavailable; using deterministic "
                    "report content. error_type={}",
                    type(exc).__name__,
                )
                report = _deterministic_report(analysis)
            else:
                if validated_sql is not None:
                    if report.generated_sql not in (None, validated_sql):
                        raise ValueError(
                            "Reporting Agent changed the validated SQL text."
                        )
                    report.generated_sql = validated_sql
                elif report.generated_sql is not None:
                    raise ValueError(
                        "Reporting Agent included SQL that was not approved "
                        "for display."
                    )

                report = assemble_report(report, analysis)
                if contains_no_result_claim(_report_text(report)):
                    report = _grounding_failure_report(
                        execution,
                        analysis,
                        "The generated report contradicted the successful "
                        "non-empty query result.",
                    )

        _limit_report_detail(report)
        # Descriptive retrievals still benefit from a tabular report view.
        # The chart/table data comes only from the successful query result.
        if request.intent == "data_query" and execution.success and execution.records and not report.charts:
            report.charts.append(
                ChartSpecification(
                    chart_id="query_results_table",
                    chart_type=ChartType.TABLE,
                    title="Returned query results",
                    data=[dict(row) for row in execution.records],
                    rationale=(
                        "A table is the appropriate view for descriptive "
                        "records without a requested numeric comparison."
                    ),
                )
            )

        _ensure_visualization(report, execution)
        _validate_recommendations(report, analysis)

        tables = _referenced_tables(sql_validation_result)
        evidence_rows = _grounding_rows(execution, analysis)
        report_text = _report_text(report)
        output_check = self._output_guardrail.validate(
            answer=report_text,
            query_results=evidence_rows,
            referenced_tables=tables,
            known_tables=tables,
            known_columns=execution.metadata.columns,
            user_query=request.original_question,
            data_sufficient=(
                analysis.sufficient_data if execution.success else None
            ),
            result_count=len(execution.records),
        )
        blocking_issues = [
            issue
            for issue in output_check.issues
            if issue.split(":", 1)[0] in _BLOCKING_OUTPUT_CODES
        ]
        if blocking_issues:
            raise ValueError(
                "Report failed output safety checks: "
                + "; ".join(blocking_issues)
            )

        if (
            execution.success
            and execution.records
            and grounding["grounded"]
            and (
                not report.grounded
                or not output_check.grounding_result.grounded
            )
        ):
            issue_codes = sorted(
                {
                    issue.code
                    for issue in output_check.grounding_result.issues
                }
            )
            logger.warning(
                "Generated report failed grounding; replacing unsupported "
                "claims. issue_codes={}",
                issue_codes,
            )
            report = _report_grounding_fallback(analysis)
            _ensure_visualization(report, execution)
            report_text = _report_text(report)
            output_check = self._output_guardrail.validate(
                answer=report_text,
                query_results=evidence_rows,
                referenced_tables=tables,
                known_tables=tables,
                known_columns=execution.metadata.columns,
                user_query=request.original_question,
                data_sufficient=analysis.sufficient_data,
                result_count=len(execution.records),
            )

        blocking_issues = [
            issue
            for issue in output_check.issues
            if issue.split(":", 1)[0] in _BLOCKING_OUTPUT_CODES
        ]
        if blocking_issues:
            raise ValueError(
                "Report failed output safety checks: "
                + "; ".join(blocking_issues)
            )

        grounding_notes = list(report.grounding_notes)
        if not grounding.get("grounded", False):
            grounding_notes.extend(
                str(issue) for issue in grounding.get("issues", [])
            )
        if not output_check.grounding_result.grounded:
            grounding_notes.extend(
                f"{issue.code}: {issue.message}"
                for issue in output_check.grounding_result.issues
            )
        grounded = (
            report.grounded
            and bool(grounding.get("grounded", False))
            and output_check.grounding_result.grounded
        )
        if not grounded and not grounding_notes:
            grounding_notes.append(
                "Report claims did not pass all grounding checks."
            )
        report.grounding_notes = list(dict.fromkeys(grounding_notes))
        report.grounded = grounded
        return report


def _ensure_visualization(
    report: ReportResult,
    execution: QueryExecutionResult,
) -> None:
    """Keep valid model charts or build a chart from returned result rows."""
    if not execution.success or not execution.records:
        return

    report.charts = [
        chart
        for chart in report.charts
        if chart.chart_type != ChartType.NONE
    ]
    try:
        _validate_chart_data(report, execution)
    except ValueError as exc:
        logger.warning(
            "Report chart could not use returned columns; generating a "
            "deterministic chart. error_type={}",
            type(exc).__name__,
        )
        report.charts = []

    if not report.charts:
        fallback_chart = _build_fallback_chart(execution.records)
        if fallback_chart is not None:
            report.charts.append(fallback_chart)
            _validate_chart_data(report, execution)


def _build_fallback_chart(
    records: Sequence[Mapping[str, Any]],
) -> ChartSpecification | None:
    """Choose a chart from the shape of validated query result records."""
    if not records:
        return None

    columns = list(records[0])
    numeric_columns = [
        column
        for column in columns
        if _is_numeric_column(records, column)
    ]
    dimension_columns = [
        column
        for column in columns
        if (
            len(
                {
                    str(record[column])
                    for record in records
                    if record.get(column) is not None
                }
            )
            > 1
            and column not in numeric_columns
        )
    ]

    date_columns = [
        column
        for column in columns
        if (
            re.search(r"(?:date|time|month|period)", column, re.IGNORECASE)
            and any(record.get(column) is not None for record in records)
        )
    ]

    if date_columns and numeric_columns:
        time_column = date_columns[0]
        category_columns = [
            column
            for column in dimension_columns
            if column != time_column
            and len(
                {
                    str(record[column])
                    for record in records
                    if record.get(column) is not None
                }
            ) > 1
        ]
        category_column = (
            category_columns[0] if category_columns else None
        )
        return ChartSpecification(
            chart_id="results-over-time",
            chart_type=ChartType.LINE,
            title=(
                f"{numeric_columns[0]} over {time_column}"
                + (
                    f" by {category_column}"
                    if category_column
                    else ""
                )
            ),
            x_column=time_column,
            y_columns=[numeric_columns[0]],
            color_column=category_column,
            rationale=(
                "Show the returned metric over time"
                + (
                    f", segmented by {category_column}."
                    if category_column
                    else "."
                )
            ),
        )

    if dimension_columns and numeric_columns:
        dimension = dimension_columns[0]
        metric = numeric_columns[0]
        return ChartSpecification(
            chart_id="results-by-category",
            chart_type=ChartType.BAR,
            title=f"{metric} by {dimension}",
            x_column=dimension,
            y_columns=[metric],
            orientation="horizontal",
            rationale=(
                f"Compare returned {metric} values across {dimension}."
            ),
        )

    if len(numeric_columns) >= 2:
        x_column, y_column = numeric_columns[:2]
        return ChartSpecification(
            chart_id="numeric-results",
            chart_type=ChartType.SCATTER,
            title=f"{y_column} by {x_column}",
            x_column=x_column,
            y_columns=[y_column],
            rationale=(
                f"Show the relationship between returned "
                f"{x_column} and {y_column} values."
            ),
        )

    if numeric_columns:
        metric = numeric_columns[0]
        return ChartSpecification(
            chart_id="query-result-kpi",
            chart_type=ChartType.KPI,
            title=metric,
            y_columns=[metric],
            aggregation="first",
            rationale=f"Show the returned {metric} value.",
        )

    return None


def _is_numeric_column(
    records: Sequence[Mapping[str, Any]],
    column: str,
) -> bool:
    values = [
        record.get(column)
        for record in records
        if record.get(column) is not None
    ]
    if not values:
        return False

    for value in values:
        if isinstance(value, bool):
            return False
        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            return False
        if not math.isfinite(numeric_value):
            return False
    return True


def _execution_failure_report(
    execution: QueryExecutionResult,
) -> ReportResult:
    """Describe execution failure without misrepresenting partial rows."""
    row_count = len(execution.records)
    if row_count:
        summary = (
            "Query execution failed after returning partial results. "
            f"The {row_count} partial rows were not analyzed."
        )
        limitations = [
            "Execution failed; partial results are not suitable for findings."
        ]
    else:
        summary = (
            "Query execution failed and returned no rows. "
            "No findings were generated."
        )
        limitations = ["The query execution failed before returning rows."]
    return ReportResult(
        report_title="Query execution failed",
        executive_summary=summary,
        limitations=limitations,
        grounded=False,
        grounding_notes=["Query execution did not complete successfully."],
        confidence=0.0,
    )


def _deterministic_report(analysis: AnalysisResult) -> ReportResult:
    """Build a report from validated deterministic findings when Ollama fails."""
    findings = [
        KeyFinding(
            title=finding.title,
            description=finding.description,
            evidence_reference="; ".join(
                table
                for evidence in finding.evidence
                for table in evidence.table_names
            )
            or finding.evidence[0].description,
        )
        for finding in _prioritize_analysis_findings(analysis)[:5]
    ]
    report = ReportResult(
        report_title="Analytics results",
        executive_summary=analysis.analysis_summary,
        key_findings=findings,
        warnings=[
            "The configured language model could not provide a validated "
            "report; "
            "deterministic report content is shown."
        ],
        grounded=True,
        confidence=analysis.confidence,
    )
    return assemble_report(report, analysis)


def _report_grounding_fallback(
    analysis: AnalysisResult,
) -> ReportResult:
    """Keep only validated deterministic findings after report grounding fails."""
    selected_findings = _prioritize_analysis_findings(analysis)[:5]
    findings = [
        KeyFinding(
            title=finding.title,
            description=finding.description,
            evidence_reference="; ".join(
                table
                for evidence in finding.evidence
                for table in evidence.table_names
            )
            or finding.evidence[0].description,
        )
        for finding in selected_findings
    ]
    finding_titles = {finding.title for finding in selected_findings}
    recommendations = [
        recommendation
        for recommendation in generate_recommendations(analysis)
        if set(recommendation.supporting_findings).issubset(finding_titles)
    ][:3]
    return ReportResult(
        report_title="Verified analytics report",
        executive_summary=analysis.analysis_summary,
        key_findings=findings,
        warnings=[
            "The generated report contained unsupported claims; only "
            "validated analysis findings are shown."
        ],
        recommendations=recommendations,
        limitations=list(analysis.limitations),
        grounded=True,
        confidence=analysis.confidence,
    )


def _prioritize_analysis_findings(
    analysis: AnalysisResult,
) -> list[Any]:
    priorities = {
        "ranking": 0,
        "anomaly": 1,
        "trend": 2,
        "comparison": 3,
        "contribution": 4,
        "root_cause": 5,
    }
    return sorted(
        analysis.findings,
        key=lambda finding: priorities.get(
            str(getattr(finding.finding_type, "value", finding.finding_type)),
            6,
        ),
    )


def _limit_report_detail(report: ReportResult) -> None:
    report.key_findings = report.key_findings[:5]
    visible_titles = {
        finding.title for finding in report.key_findings
    }
    report.recommendations = [
        recommendation
        for recommendation in report.recommendations
        if set(recommendation.supporting_findings).issubset(visible_titles)
    ][:3]


def _empty_result_report(analysis: AnalysisResult) -> ReportResult:
    """Distinguish a successful zero-row query from execution failure."""
    limitations = [
        "The query completed successfully but returned zero rows.",
        *analysis.limitations,
    ]
    return ReportResult(
        report_title="No matching results",
        executive_summary=(
            "Query execution succeeded and returned zero rows. "
            "There is insufficient data to produce findings."
        ),
        limitations=list(dict.fromkeys(limitations)),
        grounded=True,
        confidence=1.0,
    )


def _grounding_failure_report(
    execution: QueryExecutionResult,
    analysis: AnalysisResult,
    reason: str,
) -> ReportResult:
    """Withhold ungrounded claims while preserving successful row counts."""
    row_count = len(execution.records)
    summary = (
        f"Query execution succeeded and returned {row_count} rows, but "
        "the analysis did not pass grounding validation. "
        "Findings and recommendations are withheld."
    )
    limitations = [
        reason,
        *analysis.limitations,
    ]
    if not analysis.sufficient_data:
        limitations.append(
            "There is insufficient data for a complete analysis."
        )
        summary += " There is insufficient data for a complete analysis."
    return ReportResult(
        report_title="Analysis withheld pending validation",
        executive_summary=summary,
        limitations=list(dict.fromkeys(limitations)),
        grounded=False,
        grounding_notes=[reason],
        confidence=0.0,
    )


def _grounding_context(
    value: GroundingResult | Mapping[str, Any],
) -> dict[str, Any]:
    if isinstance(value, GroundingResult):
        return {
            "grounded": value.grounded,
            "issues": [
                f"{issue.code}: {issue.message}"
                for issue in value.issues
            ],
        }
    if isinstance(value, Mapping):
        grounded = value.get("grounded")
        if not isinstance(grounded, bool):
            raise ValueError(
                "grounding_validation must include a boolean 'grounded' field."
            )
        issues = value.get("issues", [])
        if not isinstance(issues, Sequence) or isinstance(
            issues,
            (str, bytes),
        ):
            raise TypeError("Grounding issues must be a sequence.")
        return {
            "grounded": grounded,
            "issues": [
                (
                    f"{issue.get('code', 'GROUNDING')}: "
                    f"{issue.get('message', 'Unsupported claim.')}"
                )
                if isinstance(issue, Mapping)
                else str(issue)
                for issue in issues
            ],
        }
    raise TypeError("grounding_validation must be a GroundingResult or mapping.")


def _validate_chart_data(
    report: ReportResult,
    execution: QueryExecutionResult,
) -> None:
    columns = set(execution.metadata.columns)
    if not columns and execution.records:
        columns = {
            str(column)
            for record in execution.records
            for column in record
        }
    if report.charts and not execution.records:
        raise ValueError("Charts cannot be produced without query records.")
    for chart in report.charts:
        axis_columns = [
            column
            for column in [chart.x_column, chart.color_column, *chart.y_columns]
            if column is not None
        ]
        missing_columns = [
            column for column in axis_columns if column not in columns
        ]
        if missing_columns:
            raise ValueError(
                "Chart references columns absent from query results: "
                + ", ".join(missing_columns)
            )
        chart.data = [dict(record) for record in execution.records]


def _validate_recommendations(
    report: ReportResult,
    analysis: AnalysisResult,
) -> None:
    finding_titles = {finding.title for finding in analysis.findings}
    for recommendation in report.recommendations:
        unsupported = [
            title
            for title in recommendation.supporting_findings
            if title not in finding_titles
        ]
        if unsupported:
            raise ValueError(
                "Recommendation cites findings absent from analysis: "
                + ", ".join(unsupported)
            )


def _referenced_tables(
    validation: SQLValidationResult | Mapping[str, Any] | None,
) -> list[str]:
    if validation is None:
        return []
    if isinstance(validation, BaseModel):
        value = validation.model_dump(mode="json")
    elif isinstance(validation, Mapping):
        value = validation
    else:
        raise TypeError(
            "sql_validation_result must be a model, mapping, or None."
        )
    tables = value.get("referenced_tables", [])
    if not isinstance(tables, Sequence) or isinstance(tables, (str, bytes)):
        raise TypeError("SQL referenced_tables must be a sequence.")
    return [str(table) for table in tables]


def _require_validated_sql(
    validation: SQLValidationResult | Mapping[str, Any] | None,
    validated_sql: str,
) -> None:
    if isinstance(validation, BaseModel):
        values = validation.model_dump(mode="json")
    elif isinstance(validation, Mapping):
        values = validation
    else:
        raise ValueError(
            "Displaying SQL requires a deterministic SQL validation result."
        )
    status = values.get("status")
    if getattr(status, "value", status) != "valid":
        raise ValueError(
            "Only SQL with a valid deterministic validation result may be displayed."
        )
    if values.get("executable_sql") != validated_sql:
        raise ValueError(
            "validated_sql must exactly match the validator's executable SQL."
        )


def _grounding_rows(
    execution: QueryExecutionResult,
    analysis: AnalysisResult,
) -> list[dict[str, Any]]:
    """Return raw SQL rows and all structured deterministic analysis evidence."""
    rows = [dict(record) for record in execution.records]
    rows.append({
        "analyzed_row_count": analysis.analyzed_row_count,
        "confidence": analysis.confidence,
    })
    for metric in analysis.metrics:
        rows.append({metric.name: metric.value})
        if metric.formatted_value:
            rows.append({metric.name: metric.formatted_value})
        if metric.record_count is not None:
            rows.append({"record_count": metric.record_count})
    for comparison in analysis.comparisons:
        rows.append({
            comparison.name: comparison.target_value,
            "baseline_value": comparison.baseline_value,
            "absolute_change": comparison.absolute_change,
            "percentage_change": comparison.percentage_change,
        })
    for trend in analysis.trends:
        rows.append({
            "dimension": trend.dimension,
            "segment": trend.segment,
            "start_value": trend.start_value,
            trend.metric_name: trend.end_value,
            "end_value": trend.end_value,
            "absolute_change": trend.absolute_change,
            "percentage_change": trend.percentage_change,
            "period_count": trend.period_count,
            "periods": trend.periods,
            "values": trend.values,
            "period_growth_percentages": trend.period_growth_percentages,
            "month_over_month_growth": trend.month_over_month_growth,
            "quarter_over_quarter_growth": trend.quarter_over_quarter_growth,
            "rolling_average": trend.rolling_average,
            "rolling_window": trend.rolling_window,
        })
    for anomaly in analysis.anomalies:
        rows.append({
            anomaly.metric_name: anomaly.observed_value,
            "expected_value": anomaly.expected_value,
            "deviation": anomaly.deviation,
        })
    for finding in analysis.findings:
        for evidence in finding.evidence:
            if evidence.values:
                rows.append(dict(evidence.values))
            if evidence.record_identifiers:
                rows.append({"record_identifiers": " ".join(evidence.record_identifiers)})
    for contribution in analysis.contribution_details:
        rows.append({
            "dimension": contribution.dimension,
            "segment": contribution.segment,
            "baseline_value": contribution.baseline_value,
            "target_value": contribution.target_value,
            "absolute_change": contribution.absolute_change,
            "contribution_percentage": contribution.contribution_percentage,
            "share_percentage": contribution.share_percentage,
        })
    return rows

def _report_text(report: ReportResult) -> str:
    statements = [
        report.report_title,
        report.executive_summary,
    ]
    statements.extend(
        f"{finding.title}. {finding.description} "
        f"{finding.supporting_metric or ''} "
        f"{finding.supporting_value or ''}"
        for finding in report.key_findings
    )
    statements.extend(
        f"{recommendation.title}. {recommendation.recommendation} "
        f"{recommendation.rationale}"
        for recommendation in report.recommendations
    )
    statements.extend(
        f"{chart.title}. {chart.rationale}"
        for chart in report.charts
    )
    if report.methodology_summary:
        statements.append(report.methodology_summary)
    statements.extend(report.assumptions)
    statements.extend(report.limitations)
    statements.extend(report.warnings)
    statements.extend(report.grounding_notes)
    return "\n".join(statement for statement in statements if statement)