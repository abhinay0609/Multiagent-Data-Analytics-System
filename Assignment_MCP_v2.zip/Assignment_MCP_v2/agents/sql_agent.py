"""Generate SQL candidates without accessing database connections."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError

from agents._common import AgentLLM, call_text, get_default_llm, render_prompt
from schemas.intent_schema import (
    AggregationType,
    AnalysisType,
    FilterOperator,
    IntentResult,
    QueryIntent,
)
from schemas.plan_schema import AnalysisPlan, TaskType
from schemas.sql_schema import (
    SQLGenerationResult,
    SQLStatementType,
)


class SQLAgent:
    """Generate a MySQL candidate query and extract its declared metadata."""

    def __init__(self, llm: AgentLLM | None = None) -> None:
        self._llm = llm if llm is not None else get_default_llm()

    def run(
        self,
        plan: AnalysisPlan | Mapping[str, Any],
        schema_context: Mapping[str, Any] | str,
        *,
        previous_validation_errors: Sequence[str] = (),
        task_id: str | None = None,
        max_result_rows: int | None = None,
        user_question: str | None = None,
        intent_result: Mapping[str, Any] | None = None,
    ) -> SQLGenerationResult:
        """Generate one SQL query; validation and execution stay external."""
        analysis_plan = AnalysisPlan.model_validate(plan)
        if not analysis_plan.controls.read_only_required:
            raise ValueError("SQL Agent requires a read-only execution plan.")
        if not isinstance(schema_context, (Mapping, str)):
            raise TypeError("schema_context must be a mapping or string.")
        if not schema_context or (
            isinstance(schema_context, str) and not schema_context.strip()
        ):
            raise ValueError("schema_context cannot be empty.")
        if isinstance(previous_validation_errors, (str, bytes)):
            raise TypeError("previous_validation_errors must be a sequence.")
        if any(
            not isinstance(error, str) or not error.strip()
            for error in previous_validation_errors
        ):
            raise ValueError(
                "Validation feedback must contain non-empty strings."
            )
        if len(previous_validation_errors) > 5:
            raise ValueError("SQL correction attempts cannot exceed five.")

        sql_tasks = [
            task
            for task in analysis_plan.tasks
            if task.task_type == TaskType.SQL_GENERATION
        ]
        if task_id is not None:
            sql_tasks = [
                task for task in sql_tasks if task.task_id == task_id
            ]
        if len(sql_tasks) != 1:
            raise ValueError(
                "The plan must identify exactly one matching SQL-generation "
                "task."
            )
        task = sql_tasks[0]

        row_limit = (
            analysis_plan.controls.max_result_rows
            if max_result_rows is None
            else max_result_rows
        )
        if (
            isinstance(row_limit, bool)
            or not isinstance(row_limit, int)
            or not 1 <= row_limit <= analysis_plan.controls.max_result_rows
        ):
            raise ValueError(
                "max_result_rows must be within the plan's result-row limit."
            )

        if intent_result is not None:
            intent = IntentResult.model_validate(intent_result)
            deterministic_sql = _generate_supported_query(
                intent,
                schema_context,
                row_limit,
            )
            if deterministic_sql is not None:
                statement, statement_type, tables, columns, expected = (
                    _extract_query_metadata(deterministic_sql)
                )
                return SQLGenerationResult(
                    database_name=analysis_plan.data_requirements.database_name,
                    sql_query=statement.sql(dialect="mysql"),
                    statement_type=statement_type,
                    referenced_tables=tables,
                    referenced_columns=columns,
                    expected_columns=expected,
                    explanation=(
                        "Candidate query generated from the validated "
                        "intent and registered schema."
                    ),
                    is_read_only=True,
                    retry_attempt=len(previous_validation_errors),
                    confidence=1.0,
                )

        intent_context = {
            "objective": analysis_plan.objective,
            "required_tables": task.required_tables,
            "required_columns": task.required_columns,
            "data_requirements": (
                analysis_plan.data_requirements.model_dump(mode="json")
            ),
        }
        prompt = render_prompt(
            "sql_prompt.txt",
            {
                "LOGICAL_DATABASE_NAME": (
                    analysis_plan.data_requirements.database_name
                ),
                "USER_QUESTION": user_question or analysis_plan.objective,
                "INTENT_RESULT": (
                    dict(intent_result) if intent_result is not None
                    else intent_context
                ),
                "PLAN_TASK": task.model_dump(mode="json"),
                "SCHEMA_CONTEXT": schema_context,
                "MAX_RESULT_ROWS": row_limit,
                "FILTER_VALUES": [],
                "PREVIOUS_VALIDATION_ERRORS": list(
                    previous_validation_errors
                ),
            },
        )
        sql_query = _strip_sql_code_fence(call_text(self._llm, prompt))
        if not sql_query:
            raise ValueError(
                "SQL Agent returned no query; generation must stop."
            )

        statement, statement_type, tables, columns, expected = (
            _extract_query_metadata(sql_query)
        )
        retry_attempt = len(previous_validation_errors)
        explanation = (
            "Candidate query generated for the planned task: "
            f"{task.description}"
        )
        return SQLGenerationResult(
            database_name=analysis_plan.data_requirements.database_name,
            sql_query=statement.sql(dialect="mysql"),
            statement_type=statement_type,
            referenced_tables=tables,
            referenced_columns=columns,
            expected_columns=expected,
            explanation=explanation,
            is_read_only=True,
            retry_attempt=retry_attempt,
            confidence=0.0,
        )


def _extract_query_metadata(
    sql_query: str,
) -> tuple[
    exp.Expression,
    SQLStatementType,
    list[str],
    dict[str, list[str]],
    list[str],
]:
    try:
        statements = [
            statement
            for statement in sqlglot.parse(sql_query, read="mysql")
            if statement is not None
        ]
    except ParseError as exc:
        raise ValueError("SQL Agent returned unparsable MySQL.") from exc

    if len(statements) != 1:
        raise ValueError("SQL Agent must return exactly one SQL statement.")

    statement = statements[0]
    if not isinstance(statement, (exp.Select, exp.Union, exp.Intersect, exp.Except)):
        raise ValueError(
            "SQL Agent output must be a SELECT or read-only query."
        )

    statement_type = (
        SQLStatementType.WITH
        if any(statement.find_all(exp.With))
        else SQLStatementType.SELECT
    )
    cte_names = {
        cte.alias_or_name.casefold()
        for cte in statement.find_all(exp.CTE)
    }

    table_aliases: dict[str, str] = {}
    referenced_tables: list[str] = []
    for table in statement.find_all(exp.Table):
        table_name = table.name
        if not table_name or table_name.casefold() in cte_names:
            continue
        table_aliases[table.alias_or_name.casefold()] = table_name
        if table_name not in referenced_tables:
            referenced_tables.append(table_name)

    referenced_columns: dict[str, list[str]] = {
        table_name: []
        for table_name in referenced_tables
    }
    for column in statement.find_all(exp.Column):
        if not column.name or column.name == "*":
            continue
        table_name = table_aliases.get(column.table.casefold())
        if table_name is None and not column.table and len(referenced_tables) == 1:
            table_name = referenced_tables[0]
        if table_name is not None:
            names = referenced_columns[table_name]
            if column.name not in names:
                names.append(column.name)

    projections = (
        statement.expressions
        if isinstance(statement, exp.Select)
        else []
    )
    expected_columns = list(
        dict.fromkeys(
            projection.alias_or_name
            for projection in projections
            if projection.alias_or_name
            and projection.alias_or_name != "*"
        )
    )
    return (
        statement,
        statement_type,
        referenced_tables,
        referenced_columns,
        expected_columns,
    )


def _generate_supported_query(
    intent: IntentResult,
    schema_context: Mapping[str, Any] | str,
    row_limit: int,
) -> str | None:
    """Generate common Northwind analytics queries from validated intent."""
    tables, relationships = _parse_schema_context(schema_context)
    if not tables:
        return None

    if intent.intent == QueryIntent.DATA_QUERY:
        if any(item.operator == FilterOperator.IS_NULL for item in intent.filters):
            anti_join = _generate_anti_join_query(
                intent, tables, relationships, row_limit
            )
            if anti_join is not None:
                return anti_join
        projection = _generate_projection_query(
            intent, tables, relationships, row_limit
        )
        if projection is not None:
            return projection

    if (
        intent.intent == QueryIntent.AGGREGATION
        and len(intent.metrics) == 1
        and intent.metrics[0].aggregation == AggregationType.COUNT
        and not intent.dimensions
    ):
        metric = intent.metrics[0]
        entity = metric.name.casefold()
        if entity.endswith("_count"):
            entity = entity[:-6]
        table_name = _find_entity_table(tables, entity)
        alias = metric.alias or metric.name
        if table_name is None or not _is_identifier(alias):
            raise ValueError(
                "The registered schema does not support the requested "
                "scalar count."
            )
        return (
            f"SELECT COUNT(*) AS `{alias}` FROM `{table_name}` LIMIT 1"
        )

    if (
        intent.intent == QueryIntent.AGGREGATION
        and len(intent.metrics) == 1
        and intent.metrics[0].aggregation == AggregationType.AVERAGE
        and not intent.dimensions
    ):
        metric = intent.metrics[0]
        if metric.name == "average_unit_price":
            product_table = _find_entity_table(tables, "product")
            price_column = _find_column(
                tables, product_table, ("unitPrice", "price")
            )
            if product_table is None or price_column is None:
                raise ValueError(
                    "The registered schema does not support average "
                    "product unit price."
                )
            alias = metric.alias or metric.name
            return (
                f"SELECT AVG(p.`{price_column}`) AS `{alias}` "
                f"FROM `{product_table}` AS p LIMIT 1"
            )
        if metric.name == "average_sales_per_order":
            detail_table = _find_entity_table(tables, "orderdetail")
            order_id = _find_column(tables, detail_table, ("orderId",))
            line_value = _line_value_expression(tables, detail_table, "od")
            if detail_table is None or order_id is None or line_value is None:
                raise ValueError(
                    "The registered schema does not support average sales "
                    "value per order."
                )
            alias = metric.alias or metric.name
            return (
                f"SELECT AVG(order_total) AS `{alias}` "
                f"FROM (SELECT od.`{order_id}` AS order_id, "
                f"SUM({line_value}) AS order_total "
                f"FROM `{detail_table}` AS od "
                f"GROUP BY od.`{order_id}`) AS order_totals LIMIT 1"
            )

    if (
        intent.intent == QueryIntent.RANKING
        and len(intent.metrics) == 1
        and intent.metrics[0].aggregation == AggregationType.COUNT
        and intent.metrics[0].name == "order_count"
        and _has_dimension(intent, "employee")
    ):
        return _employee_order_count_query(
            intent, tables, relationships, row_limit
        )

    if (
        intent.intent in {QueryIntent.AGGREGATION, QueryIntent.RANKING}
        and len(intent.metrics) == 1
        and intent.metrics[0].aggregation == AggregationType.COUNT
        and _has_dimension(intent, "country")
    ):
        return _customer_count_by_country_query(
            intent, tables, row_limit
        )

    wants_trend = (
        intent.intent == QueryIntent.TREND_ANALYSIS
        or AnalysisType.TREND in intent.analysis_types
    )
    monthly = (
        intent.time_period is not None
        and intent.time_period.granularity.value == "month"
    )
    sales_metric = any(
        metric.aggregation == AggregationType.SUM
        and re.search(
            r"\b(sales|revenue)\b",
            metric.name.replace("_", " "),
            re.IGNORECASE,
        )
        for metric in intent.metrics
    )
    if wants_trend and monthly and sales_metric:
        return _monthly_revenue_query(
            tables,
            relationships,
            intent,
            row_limit,
        )

    if (
        intent.intent in {QueryIntent.AGGREGATION, QueryIntent.RANKING}
        and len(intent.metrics) == 1
        and intent.metrics[0].aggregation == AggregationType.SUM
        and re.search(
            r"\b(sales|revenue)\b",
            intent.metrics[0].name.replace("_", " "),
            re.IGNORECASE,
        )
        and intent.dimensions
    ):
        dimension = intent.dimensions[0].name.casefold()
        if dimension in {"customer", "product", "category", "country"}:
            return _sales_by_dimension_query(
                intent,
                tables,
                relationships,
                row_limit,
                dimension,
            )
    return None


def _generate_anti_join_query(
    intent: IntentResult,
    tables: Mapping[str, set[str]],
    relationships: Sequence[tuple[str, str, str, str]],
    row_limit: int,
) -> str | None:
    if _has_dimension(intent, "customer"):
        parent = _find_entity_table(tables, "customer")
        child = _find_entity_table(tables, "order")
        parent_key, child_key = _relationship_columns(
            relationships, parent, child, tables
        )
        name_column = _find_column(
            tables, parent, ("companyName", "customerName")
        )
        if not all((parent, child, parent_key, child_key, name_column)):
            raise ValueError(
                "The registered schema does not support finding customers "
                "without orders."
            )
        return (
            f"SELECT c.`{name_column}` AS customerName "
            f"FROM `{parent}` AS c WHERE NOT EXISTS ("
            f"SELECT 1 FROM `{child}` AS so "
            f"WHERE so.`{child_key}` = c.`{parent_key}`) "
            f"LIMIT {row_limit}"
        )
    if _has_dimension(intent, "product"):
        parent = _find_entity_table(tables, "product")
        child = _find_entity_table(tables, "orderdetail")
        parent_key, child_key = _relationship_columns(
            relationships, parent, child, tables
        )
        name_column = _find_column(
            tables, parent, ("productName", "name")
        )
        if not all((parent, child, parent_key, child_key, name_column)):
            raise ValueError(
                "The registered schema does not support finding products "
                "without orders."
            )
        return (
            f"SELECT p.`{name_column}` AS productName "
            f"FROM `{parent}` AS p WHERE NOT EXISTS ("
            f"SELECT 1 FROM `{child}` AS od "
            f"WHERE od.`{child_key}` = p.`{parent_key}`) "
            f"LIMIT {row_limit}"
        )
    return None


def _generate_projection_query(
    intent: IntentResult,
    tables: Mapping[str, set[str]],
    relationships: Sequence[tuple[str, str, str, str]],
    row_limit: int,
) -> str | None:
    column_specs = {
        "customer_name": ("customer", ("companyName", "customerName"), "customerName"),
        "customer": ("customer", ("companyName", "customerName"), "customerName"),
        "product_name": ("product", ("productName", "name"), "productName"),
        "product": ("product", ("productName", "name"), "productName"),
        "supplier_name": ("supplier", ("companyName", "supplierName"), "supplierName"),
        "category_name": ("category", ("categoryName", "name"), "categoryName"),
        "category": ("category", ("categoryName", "name"), "categoryName"),
        "order_id": ("order", ("orderId",), "orderId"),
        "employee_name": ("employee", ("firstname",), "employeeName"),
        "employee": ("employee", ("firstname",), "employeeName"),
    }
    dimensions = [item.name.casefold() for item in intent.dimensions]
    if not dimensions or not all(item in column_specs for item in dimensions):
        return None

    resolved: list[tuple[str, str, str, str]] = []
    for dimension in dimensions:
        entity, candidates, output_name = column_specs[dimension]
        table_name = _find_entity_table(tables, entity)
        column_name = _find_column(tables, table_name, candidates)
        if table_name is None or column_name is None:
            raise ValueError(
                f"The registered schema does not support the "
                f"'{dimension}' projection."
            )
        resolved.append((dimension, table_name, column_name, output_name))

    base_table = resolved[0][1]
    target_tables = list(dict.fromkeys(item[1] for item in resolved[1:]))
    aliases = _table_aliases(tables)
    joins = _join_fragments(
        base_table, target_tables, relationships, aliases, tables
    )
    projections: list[str] = []
    for dimension, table_name, column_name, output_name in resolved:
        alias = aliases[table_name]
        if dimension in {"employee", "employee_name"}:
            lastname = _find_column(tables, table_name, ("lastname", "lastName"))
            if lastname is None:
                raise ValueError(
                    "The registered schema has no employee surname column."
                )
            expression = (
                f"CONCAT({alias}.`{column_name}`, ' ', "
                f"{alias}.`{lastname}`)"
            )
        else:
            expression = f"{alias}.`{column_name}`"
        projections.append(f"{expression} AS `{output_name}`")

    return (
        f"SELECT {', '.join(projections)} "
        f"FROM `{base_table}` AS {aliases[base_table]} "
        f"{joins}LIMIT {row_limit}"
    )


def _customer_count_by_country_query(
    intent: IntentResult,
    tables: Mapping[str, set[str]],
    row_limit: int,
) -> str:
    customer_table = _find_entity_table(tables, "customer")
    customer_id = _find_column(tables, customer_table, ("custId", "customerId"))
    country = _find_column(tables, customer_table, ("country",))
    metric = intent.metrics[0]
    if not all((customer_table, customer_id, country)):
        raise ValueError(
            "The registered schema does not support customer counts by country."
        )
    direction = _sort_direction(intent)
    limit = _ranking_limit(intent, row_limit)
    return (
        f"SELECT c.`{country}` AS country, "
        f"COUNT(DISTINCT c.`{customer_id}`) AS `{metric.alias or metric.name}` "
        f"FROM `{customer_table}` AS c GROUP BY c.`{country}` "
        f"ORDER BY `{metric.alias or metric.name}` {direction} LIMIT {limit}"
    )


def _employee_order_count_query(
    intent: IntentResult,
    tables: Mapping[str, set[str]],
    relationships: Sequence[tuple[str, str, str, str]],
    row_limit: int,
) -> str:
    order_table = _find_entity_table(tables, "order")
    employee_table = _find_entity_table(tables, "employee")
    order_id = _find_column(tables, order_table, ("orderId",))
    employee_id = _find_column(tables, employee_table, ("employeeId",))
    first_name = _find_column(tables, employee_table, ("firstname", "firstName"))
    last_name = _find_column(tables, employee_table, ("lastname", "lastName"))
    order_employee_id, employee_key = _relationship_columns(
        relationships, order_table, employee_table, tables
    )
    if not all(
        (
            order_table, employee_table, order_id, employee_id, first_name,
            last_name, order_employee_id, employee_key,
        )
    ):
        raise ValueError(
            "The registered schema does not support ranking employees by "
            "order count."
        )
    metric = intent.metrics[0]
    alias = metric.alias or metric.name
    direction = _sort_direction(intent)
    limit = _ranking_limit(intent, row_limit)
    return (
        f"SELECT CONCAT(e.`{first_name}`, ' ', e.`{last_name}`) "
        f"AS employeeName, COUNT(DISTINCT so.`{order_id}`) AS `{alias}` "
        f"FROM `{order_table}` AS so JOIN `{employee_table}` AS e "
        f"ON so.`{order_employee_id}` = e.`{employee_key}` "
        f"GROUP BY e.`{employee_id}`, e.`{first_name}`, e.`{last_name}` "
        f"ORDER BY `{alias}` {direction} LIMIT {limit}"
    )


def _sales_by_dimension_query(
    intent: IntentResult,
    tables: Mapping[str, set[str]],
    relationships: Sequence[tuple[str, str, str, str]],
    row_limit: int,
    dimension: str,
) -> str:
    entity_by_dimension = {
        "customer": "customer",
        "product": "product",
        "category": "category",
        "country": "customer",
    }
    dimension_table = _find_entity_table(
        tables, entity_by_dimension[dimension]
    )
    detail_table = _find_entity_table(tables, "orderdetail")
    order_table = _find_entity_table(tables, "order")
    dimension_column = _find_column(
        tables,
        dimension_table,
        {
            "customer": ("companyName", "customerName"),
            "product": ("productName", "name"),
            "category": ("categoryName", "name"),
            "country": ("country",),
        }[dimension],
    )
    if not all((detail_table, order_table, dimension_table, dimension_column)):
        raise ValueError(
            f"The registered schema does not support sales by {dimension}."
        )
    metric = intent.metrics[0]
    alias = metric.alias or metric.name
    aliases = _table_aliases(tables)
    targets = (
        [order_table, dimension_table]
        if dimension in {"customer", "country"}
        else [dimension_table]
    )
    joins = _join_fragments(
        detail_table, targets, relationships, aliases, tables
    )
    dimension_alias = {
        "customer": "customerName",
        "product": "productName",
        "category": "categoryName",
        "country": "country",
    }[dimension]
    group_expression = f"{aliases[dimension_table]}.`{dimension_column}`"
    line_total = _line_value_expression(tables, detail_table, aliases[detail_table])
    if line_total is None:
        raise ValueError("The schema has no unit-price and quantity fields.")
    ranking = intent.intent == QueryIntent.RANKING
    order_by = (
        f" ORDER BY `{alias}` {_sort_direction(intent)}"
        if ranking else ""
    )
    limit = _ranking_limit(intent, row_limit) if ranking else row_limit
    return (
        f"SELECT {group_expression} AS `{dimension_alias}`, "
        f"SUM({line_total}) AS `{alias}` "
        f"FROM `{detail_table}` AS {aliases[detail_table]} "
        f"{joins}GROUP BY {group_expression}{order_by} LIMIT {limit}"
    )


def _table_aliases(tables: Mapping[str, set[str]]) -> dict[str, str]:
    standard = {
        "customer": "c",
        "salesorder": "so",
        "orderdetail": "od",
        "product": "p",
        "supplier": "s",
        "category": "cat",
        "employee": "e",
    }
    aliases: dict[str, str] = {}
    for index, name in enumerate(tables):
        aliases[name] = standard.get(name.casefold(), f"t{index}")
    return aliases


def _join_fragments(
    base_table: str,
    target_tables: Sequence[str],
    relationships: Sequence[tuple[str, str, str, str]],
    aliases: Mapping[str, str],
    tables: Mapping[str, set[str]],
) -> str:
    connected = {base_table.casefold()}
    joins: list[str] = []
    for target in target_tables:
        if target.casefold() in connected:
            continue
        path = _relationship_path(
            connected, target, relationships
        )
        if path is None:
            for source_table in tables:
                if source_table.casefold() not in connected:
                    continue
                source_column, target_column = _relationship_columns(
                    relationships, source_table, target, tables
                )
                if source_column is not None and target_column is not None:
                    path = [
                        (source_table, source_column, target, target_column)
                    ]
                    break
        if path is None:
            raise ValueError(
                f"The schema has no relationship path from '{base_table}' "
                f"to '{target}'."
            )
        for source, source_column, destination, destination_column in path:
            if destination.casefold() in connected:
                source, destination = destination, source
                source_column, destination_column = (
                    destination_column,
                    source_column,
                )
            joins.append(
                f"JOIN `{destination}` AS {aliases[destination]} "
                f"ON {aliases[source]}.`{source_column}` = "
                f"{aliases[destination]}.`{destination_column}` "
            )
            connected.add(destination.casefold())
    return "".join(joins)


def _relationship_path(
    connected: set[str],
    target: str,
    relationships: Sequence[tuple[str, str, str, str]],
) -> list[tuple[str, str, str, str]] | None:
    from collections import deque

    queue = deque(
        (name, []) for name in connected
    )
    visited = set(connected)
    while queue:
        current, path = queue.popleft()
        if current == target.casefold():
            return path
        for source, source_column, destination, destination_column in relationships:
            if source.casefold() == current:
                neighbor = destination.casefold()
                edge = (source, source_column, destination, destination_column)
            elif destination.casefold() == current:
                neighbor = source.casefold()
                edge = (destination, destination_column, source, source_column)
            else:
                continue
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, [*path, edge]))
    return None


def _relationship_columns(
    relationships: Sequence[tuple[str, str, str, str]],
    left_table: str | None,
    right_table: str | None,
    tables: Mapping[str, set[str]] | None = None,
) -> tuple[str | None, str | None]:
    if left_table is None or right_table is None:
        return None, None
    for source, source_column, target, target_column in relationships:
        if source.casefold() == left_table.casefold() and target.casefold() == right_table.casefold():
            return source_column, target_column
        if source.casefold() == right_table.casefold() and target.casefold() == left_table.casefold():
            return target_column, source_column
    if tables is not None:
        left_columns = tables.get(left_table, set())
        right_columns = tables.get(right_table, set())
        right_by_casefold = {
            column.casefold(): column for column in right_columns
        }
        shared_key_columns = [
            column
            for column in left_columns
            if column.casefold().endswith(("id", "key"))
            and column.casefold() in right_by_casefold
        ]
        if len(shared_key_columns) == 1:
            return (
                shared_key_columns[0],
                right_by_casefold[shared_key_columns[0].casefold()],
            )
    return None, None


def _find_column(
    tables: Mapping[str, set[str]],
    table_name: str | None,
    candidates: Sequence[str],
) -> str | None:
    if table_name is None:
        return None
    columns = tables.get(table_name, set())
    by_casefold = {column.casefold(): column for column in columns}
    return next(
        (by_casefold[name.casefold()] for name in candidates if name.casefold() in by_casefold),
        None,
    )


def _line_value_expression(
    tables: Mapping[str, set[str]],
    table_name: str | None,
    alias: str,
) -> str | None:
    price = _find_column(tables, table_name, ("unitPrice", "price"))
    quantity = _find_column(tables, table_name, ("quantity", "qty"))
    if price is None or quantity is None:
        return None
    expression = f"{alias}.`{price}` * {alias}.`{quantity}`"
    discount = _find_column(tables, table_name, ("discount",))
    if discount is not None:
        expression += f" * (1 - {alias}.`{discount}`)"
    return expression


def _has_dimension(intent: IntentResult, dimension: str) -> bool:
    return any(item.name.casefold() == dimension for item in intent.dimensions)


def _sort_direction(intent: IntentResult) -> str:
    return (
        "ASC"
        if intent.ranking.sort_direction.value == "ascending"
        else "DESC"
    )


def _ranking_limit(intent: IntentResult, row_limit: int) -> int:
    return min(intent.ranking.limit or row_limit, row_limit)


def _parse_schema_context(
    schema_context: Mapping[str, Any] | str,
) -> tuple[dict[str, set[str]], list[tuple[str, str, str, str]]]:
    tables: dict[str, set[str]] = {}
    relationships: list[tuple[str, str, str, str]] = []
    if isinstance(schema_context, str):
        current_table: str | None = None
        for line in schema_context.splitlines():
            table_match = re.match(r"\s*TABLE\s+([A-Za-z_]\w*)\s*$", line)
            if table_match:
                current_table = table_match.group(1)
                tables.setdefault(current_table, set())
                continue
            column_match = re.match(r"\s*-\s+([A-Za-z_]\w*)\s*:", line)
            if current_table is not None and column_match:
                tables[current_table].add(column_match.group(1))
            relationship_match = re.match(
                r"\s*-\s+([A-Za-z_]\w*)\.\(([A-Za-z_]\w*)\)\s*->\s*"
                r"([A-Za-z_]\w*)\.\(([A-Za-z_]\w*)\)\s*$",
                line,
            )
            if relationship_match:
                relationships.append(relationship_match.groups())
        return tables, relationships

    raw_tables = schema_context.get("tables", schema_context)
    if not isinstance(raw_tables, Mapping):
        return tables, relationships
    for table_name, table_data in raw_tables.items():
        if not isinstance(table_name, str):
            continue
        columns: set[str] = set()
        raw_columns = (
            table_data.get("columns", [])
            if isinstance(table_data, Mapping)
            else table_data
        )
        if isinstance(raw_columns, Mapping):
            columns.update(
                name for name in raw_columns if isinstance(name, str)
            )
        elif isinstance(raw_columns, Sequence) and not isinstance(
            raw_columns, (str, bytes)
        ):
            for column in raw_columns:
                if isinstance(column, str):
                    columns.add(column)
                elif isinstance(column, Mapping) and isinstance(
                    column.get("name"), str
                ):
                    columns.add(column["name"])
        tables[table_name] = columns

    raw_relationships = schema_context.get("relationships", [])
    if isinstance(raw_relationships, Sequence) and not isinstance(
        raw_relationships, (str, bytes)
    ):
        for relationship in raw_relationships:
            if not isinstance(relationship, Mapping):
                continue
            source_columns = relationship.get("source_columns", [])
            target_columns = relationship.get("target_columns", [])
            if (
                isinstance(relationship.get("source_table"), str)
                and isinstance(relationship.get("target_table"), str)
                and isinstance(source_columns, Sequence)
                and not isinstance(source_columns, (str, bytes))
                and len(source_columns) == 1
                and isinstance(target_columns, Sequence)
                and not isinstance(target_columns, (str, bytes))
                and len(target_columns) == 1
                and isinstance(source_columns[0], str)
                and isinstance(target_columns[0], str)
            ):
                relationships.append(
                    (
                        relationship["source_table"],
                        source_columns[0],
                        relationship["target_table"],
                        target_columns[0],
                    )
                )
    return tables, relationships


def _find_entity_table(
    tables: Mapping[str, set[str]],
    entity: str,
) -> str | None:
    entity = entity.casefold().rstrip("s")
    if entity == "order":
        return next(
            (
                name for name in tables
                if "order" in name.casefold()
                and not re.search(r"(detail|line|item)", name, re.IGNORECASE)
            ),
            None,
        )
    if entity == "orderdetail":
        return next(
            (
                name for name in tables
                if re.search(r"(detail|line|item)", name, re.IGNORECASE)
            ),
            None,
        )
    for table_name in tables:
        normalized = re.sub(r"[^a-z0-9]", "", table_name.casefold())
        if normalized.rstrip("s") == entity:
            return table_name
    return None


def _monthly_revenue_query(
    tables: Mapping[str, set[str]],
    relationships: Sequence[tuple[str, str, str, str]],
    intent: IntentResult,
    row_limit: int,
) -> str:
    order_table = next(
        (
            name for name in tables
            if "order" in name.casefold()
            and not re.search(r"(detail|line|item)", name, re.IGNORECASE)
        ),
        None,
    )
    detail_table = next(
        (
            name for name in tables
            if re.search(r"(detail|line|item)", name, re.IGNORECASE)
        ),
        None,
    )
    if order_table is None or detail_table is None:
        raise ValueError(
            "The registered schema does not support monthly revenue analysis."
        )

    relation = next(
        (
            (source_column, target_column)
            if source.casefold() == order_table.casefold()
            else (target_column, source_column)
            for source, source_column, target, target_column in relationships
            if {
                source.casefold(),
                target.casefold(),
            } == {
                order_table.casefold(),
                detail_table.casefold(),
            }
        ),
        None,
    )
    if relation is None:
        raise ValueError(
            "The registered schema has no documented order-detail "
            "relationship for monthly revenue analysis."
        )

    date_column = next(
        (
            column for column in tables[order_table]
            if column.casefold() == "orderdate"
        ),
        None,
    )
    if date_column is None:
        date_column = next(
            (
                column for column in tables[order_table]
                if "date" in column.casefold()
                or "time" in column.casefold()
            ),
            None,
        )
    price_column = next(
        (
            column for column in tables[detail_table]
            if column.casefold() in {"unitprice", "price"}
        ),
        None,
    )
    quantity_column = next(
        (
            column for column in tables[detail_table]
            if column.casefold() in {"quantity", "qty"}
        ),
        None,
    )
    if not date_column or not price_column or not quantity_column:
        raise ValueError(
            "The registered schema is missing a date, price, or quantity "
            "column required for monthly revenue analysis."
        )

    metric = next(
        (
            item for item in intent.metrics
            if item.aggregation == AggregationType.SUM
            and re.search(
                r"\b(sales|revenue)\b",
                item.name.replace("_", " "),
                re.IGNORECASE,
            )
        ),
        None,
    )
    if metric is None:
        raise ValueError("A summed sales or revenue metric is required.")
    metric_alias = metric.alias or metric.name
    if not all(
        _is_identifier(item)
        for item in (
            order_table,
            detail_table,
            date_column,
            price_column,
            quantity_column,
            metric_alias,
            *relation,
        )
    ):
        raise ValueError("The schema contains an unsupported SQL identifier.")

    discount_column = next(
        (
            column for column in tables[detail_table]
            if column.casefold() == "discount"
        ),
        None,
    )
    if intent.dimensions:
        dimension = intent.dimensions[0].name.casefold()
        dimension_details = {
            "category": (
                "category",
                ("categoryName", "name"),
                "categoryName",
            ),
            "product": (
                "product",
                ("productName", "name"),
                "productName",
            ),
            "customer": (
                "customer",
                ("companyName", "customerName"),
                "customerName",
            ),
            "country": ("customer", ("country",), "country"),
        }.get(dimension)
        if dimension_details is None:
            raise ValueError(
                "The registered schema does not support monthly sales "
                f"trends by '{dimension}'."
            )
        entity, column_candidates, output_name = dimension_details
        dimension_table = _find_entity_table(tables, entity)
        dimension_column = _find_column(
            tables,
            dimension_table,
            column_candidates,
        )
        if dimension_table is None or dimension_column is None:
            raise ValueError(
                "The registered schema is missing the requested trend "
                f"dimension '{dimension}'."
            )
        aliases = _table_aliases(tables)
        joins = _join_fragments(
            detail_table,
            [order_table, dimension_table],
            relationships,
            aliases,
            tables,
        )
        date_expression = (
            f"DATE_FORMAT({aliases[order_table]}.`{date_column}`, "
            "'%Y-%m-01')"
        )
        dimension_expression = (
            f"{aliases[dimension_table]}.`{dimension_column}`"
        )
        date_filter = (
            f"{aliases[order_table]}.`{date_column}` IS NOT NULL"
        )
        line_total = f"od.`{price_column}` * od.`{quantity_column}`"
        if discount_column is not None:
            line_total += f" * (1 - od.`{discount_column}`)"
        return (
            f"SELECT {date_expression} AS `{date_column}`, "
            f"{dimension_expression} AS `{output_name}`, "
            f"SUM({line_total}) AS `{metric_alias}` "
            f"FROM `{detail_table}` AS od "
            f"{joins}WHERE {date_filter} GROUP BY {date_expression}, "
            f"{dimension_expression} "
            f"ORDER BY {date_expression} ASC, "
            f"{dimension_expression} ASC LIMIT {row_limit}"
        )

    line_total = (
        f"od.`{price_column}` * od.`{quantity_column}`"
    )
    if discount_column is not None:
        line_total += f" * (1 - od.`{discount_column}`)"
    date_expression = f"DATE_FORMAT(o.`{date_column}`, '%Y-%m-01')"
    date_filter = f"o.`{date_column}` IS NOT NULL"
    order_key, detail_key = relation
    return (
        f"SELECT {date_expression} AS `{date_column}`, "
        f"SUM({line_total}) AS `{metric_alias}` "
        f"FROM `{order_table}` AS o "
        f"JOIN `{detail_table}` AS od "
        f"ON o.`{order_key}` = od.`{detail_key}` "
        f"WHERE {date_filter} "
        f"GROUP BY {date_expression} "
        f"ORDER BY `{date_column}` ASC LIMIT {row_limit}"
    )


def _is_identifier(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value))


def _strip_sql_code_fence(sql_query: str) -> str:
    """Remove a single enclosing Markdown fence without accepting prose."""
    match = re.fullmatch(
        r"\s*```(?:sql)?\s*(.*?)\s*```\s*",
        sql_query,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return match.group(1).strip() if match is not None else sql_query.strip()