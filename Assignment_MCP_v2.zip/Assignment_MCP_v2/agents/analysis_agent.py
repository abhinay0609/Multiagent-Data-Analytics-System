"""Calculate analytics deterministically and use an LLM for interpretation."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np
import pandas as pd
from loguru import logger
from pydantic import BaseModel, ConfigDict, Field, field_validator

from agents._common import (
    AgentLLM,
    call_narrative_json,
    contains_no_result_claim,
    get_narrative_fallback_llm,
    get_narrative_llm,
    render_prompt,
)
from analytics import (
    analyze_contributions,
    analyze_trend,
    compare_groups,
    detect_anomalies,
    generate_insights,
)
from guardrails import GroundingValidator, grounding_validator
from schemas.analysis_schema import (
    AnalysisResult,
    AnalyticalFinding,
    AnomalyResult,
    ComparisonResult,
    ContributionResult,
    EvidenceReference,
    FindingImportance,
    FindingType,
    MetricResult,
    TrendDirection,
    TrendResult,
)
from schemas.intent_schema import IntentResult
from schemas.plan_schema import AnalysisPlan
from schemas.sql_schema import QueryExecutionResult


_NUMBER_PATTERN = re.compile(r"(?<![A-Za-z])[-+]?\d+(?:[.,]\d+)*%?")
_NUMBER_WORD_PATTERN = re.compile(
    r"\b(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|"
    r"eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|"
    r"eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|"
    r"eighty|ninety|hundred|thousand|million|billion|percent(?:age)?)\b",
    re.IGNORECASE,
)
class _AnalysisExplanation(BaseModel):
    """Qualitative-only Ollama response; numeric fields remain deterministic."""

    model_config = ConfigDict(extra="forbid")

    analysis_summary: str = Field(min_length=1)
    assumptions: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)

    @field_validator("analysis_summary")
    @classmethod
    def reject_numeric_summary(cls, value: str) -> str:
        clean_value = value.strip()
        if not clean_value:
            raise ValueError("analysis_summary cannot be empty.")
        if _contains_number(clean_value):
            raise ValueError(
                "Analysis explanation must not contain calculated numbers."
            )
        return clean_value

    @field_validator("assumptions", "limitations", "warnings")
    @classmethod
    def reject_numeric_list_items(cls, values: list[str]) -> list[str]:
        clean_values = [value.strip() for value in values]
        if any(not value for value in clean_values):
            raise ValueError("Explanation lists cannot contain blank items.")
        if any(_contains_number(value) for value in clean_values):
            raise ValueError(
                "Analysis explanation must not contain calculated numbers."
            )
        return clean_values


class AnalysisAgent:
    """Analyze executed rows with Pandas/NumPy; LLM output is qualitative."""

    def __init__(
        self,
        llm: AgentLLM | None = None,
        grounding_validator_instance: GroundingValidator | None = None,
    ) -> None:
        self._llm = llm if llm is not None else get_narrative_llm()
        self._fallback_llm = (
            get_narrative_fallback_llm() if llm is None else None
        )
        self._grounding_validator = (
            grounding_validator_instance
            if grounding_validator_instance is not None
            else grounding_validator
        )

    def run(
        self,
        query_execution_result: QueryExecutionResult | Mapping[str, Any],
        intent: IntentResult | Mapping[str, Any],
        plan: AnalysisPlan | Mapping[str, Any],
        *,
        referenced_tables: Sequence[str] = (),
        sufficient_data_context: str | Mapping[str, Any] | None = None,
    ) -> AnalysisResult:
        """Return deterministic metrics and evidence with qualitative LLM text."""
        execution = QueryExecutionResult.model_validate(
            query_execution_result
        )
        request = IntentResult.model_validate(intent)
        analysis_plan = AnalysisPlan.model_validate(plan)
        if isinstance(referenced_tables, (str, bytes)):
            raise TypeError("referenced_tables must be a sequence.")
        if any(not isinstance(table, str) for table in referenced_tables):
            raise TypeError("referenced_tables must contain strings.")

        if not execution.success:
            return self._insufficient_result(
                "The query execution failed; available results were not analyzed.",
                analyzed_row_count=len(execution.records),
                source_columns=execution.metadata.columns,
            )
        if not execution.records:
            return self._insufficient_result(
                "The query completed successfully but returned zero rows to analyze.",
                analyzed_row_count=0,
                source_columns=execution.metadata.columns,
            )

        records = execution.records
        frame = pd.DataFrame.from_records(records)
        source_columns = list(execution.metadata.columns or frame.columns)
        numeric_columns = _numeric_columns(frame)
        requested_metric_columns: list[str] = []
        for metric in request.metrics:
            column = _choose_metric_column(
                list(numeric_columns),
                metric.alias,
                [metric],
            )
            if column is not None and column not in requested_metric_columns:
                requested_metric_columns.append(column)
        metrics = _calculate_metrics(
            numeric_columns,
            requested_metric_columns,
        )
        limitations: list[str] = []
        deterministic_warnings: list[str] = []
        is_sufficient = sufficient_data_context is not False
        if request.metrics and not requested_metric_columns:
            limitations.append(
                "Requested metrics could not be matched to numeric result "
                "columns."
            )
            is_sufficient = False
        if execution.metadata.truncated:
            is_sufficient = False
            limitations.append(
                "The query result was truncated; findings apply only to "
                "the returned rows."
            )
        if sufficient_data_context is False:
            is_sufficient = False
            limitations.append(
                "The caller marked the available data as insufficient."
            )
        if isinstance(sufficient_data_context, Mapping):
            if sufficient_data_context.get("sufficient") is False:
                is_sufficient = False
            context_limitations = sufficient_data_context.get("limitations", [])
            if isinstance(context_limitations, Sequence) and not isinstance(
                context_limitations,
                (str, bytes),
            ):
                limitations.extend(
                    str(item)
                    for item in context_limitations
                    if isinstance(item, str) and item.strip()
                )
        elif (
            sufficient_data_context is not None
            and not isinstance(sufficient_data_context, (str, bool))
        ):
            raise TypeError(
                "sufficient_data_context must be text, a mapping, bool, or None."
            )

        comparisons, comparison_limits = _calculate_comparisons(
            frame,
            numeric_columns,
            request,
        )
        trends, trend_limits = _calculate_trends(
            frame,
            numeric_columns,
            request,
        )
        anomalies = _calculate_anomalies(
            frame,
            numeric_columns,
            request,
        )
        ranking_findings = _calculate_ranking(
            frame,
            numeric_columns,
            request,
            referenced_tables,
        )
        ranking_findings.extend(
            _calculate_trend_ranking(
                trends,
                request,
                referenced_tables,
            )
        )
        contributing_factors, contribution_metrics, contribution_details = (
            _calculate_contributions(
                frame,
                numeric_columns,
                request,
                analysis_plan,
            )
        )
        metrics.extend(contribution_metrics)
        if request.ranking.required and not ranking_findings:
            limitations.append(
                "The requested ranking could not be calculated from the "
                "returned columns."
            )
            is_sufficient = False
        anomaly_requested = (
            request.intent == "anomaly_detection"
            or any(
                _enum_value(item) == "anomaly"
                for item in request.analysis_types
            )
        )
        if anomaly_requested and not anomalies:
            anomaly_metric = _choose_metric_column(
                list(numeric_columns),
                None,
                request.metrics,
            )
            if (
                anomaly_metric is None
                or numeric_columns[anomaly_metric].size < 4
            ):
                limitations.append(
                    "Anomaly analysis requires a numeric metric with at "
                    "least four returned values."
                )
                is_sufficient = False
            else:
                deterministic_warnings.append(
                    "No returned values met the anomaly detection threshold."
                )
        contribution_requested = (
            any(
                _enum_value(item) in {"contribution", "root_cause"}
                for item in request.analysis_types
            )
            or request.intent == "root_cause_analysis"
            or any(
                str(method).casefold() in {"contribution", "root_cause"}
                for method in analysis_plan.analysis_methods
            )
        )
        if contribution_requested and not contributing_factors:
            limitations.append(
                "A contributing group could not be calculated from the "
                "returned columns."
            )
            is_sufficient = False
        findings = (
            generate_insights(
                comparisons=comparisons,
                trends=trends,
                anomalies=anomalies,
                contributions=contribution_details,
                referenced_tables=referenced_tables,
            )
            + ranking_findings
        )
        # A successful descriptive DATA_QUERY may have no numeric metric,
        # trend, or ranking. Still provide a factual, row-count-based finding
        # so the report is useful without inventing business interpretation.
        if records and not findings:
            if metrics:
                metric = metrics[0]
                finding_title = f"Verified {metric.name} result"
                finding_description = (
                    f"The returned {metric.name.replace('_', ' ')} is "
                    f"{metric.formatted_value or metric.value}."
                )
                evidence_values = {metric.name: metric.value}
                evidence_columns = metric.source_columns or source_columns
            else:
                finding_title = "Matching records retrieved"
                finding_description = (
                    f"The query returned {len(records)} matching records "
                    "for the requested data fields."
                )
                evidence_values = {"returned_rows": len(records)}
                evidence_columns = source_columns
            findings.append(
                AnalyticalFinding(
                    title=finding_title,
                    finding_type=FindingType.SUMMARY,
                    importance=FindingImportance.MEDIUM,
                    description=finding_description,
                    evidence=[
                        EvidenceReference(
                            description=(
                                "Evidence comes from the successful query "
                                "result and deterministic calculation."
                            ),
                            table_names=list(referenced_tables),
                            columns=list(evidence_columns),
                            values=evidence_values,
                        )
                    ],
                    confidence=1.0,
                    caveat=(
                        "This finding describes returned query evidence; it "
                        "does not infer business causality."
                    ),
                )
            )
        for limitation in comparison_limits + trend_limits:
            limitations.append(limitation)
            is_sufficient = False
        if not is_sufficient and not limitations:
            limitations.append(
                "The available result data is insufficient for a complete analysis."
            )

        calculated_results = {
            "row_count": len(records),
            "truncated": execution.metadata.truncated,
            "numeric_metrics": [
                metric.model_dump(mode="json")
                for metric in metrics
            ],
            "comparisons": [
                comparison.model_dump(mode="json")
                for comparison in comparisons
            ],
            "trends": [trend.model_dump(mode="json") for trend in trends],
            "anomalies": [
                anomaly.model_dump(mode="json")
                for anomaly in anomalies
            ],
            "deterministic_findings": [
                finding.model_dump(mode="json")
                for finding in findings
            ],
            "contributing_factors": contributing_factors,
            "contribution_details": [
                item.model_dump(mode="json")
                for item in contribution_details
            ],
        }
        prompt = render_prompt(
            "analysis_prompt.txt",
            {
                "INTENT_RESULT": request,
                "ANALYSIS_PLAN": analysis_plan,
                "QUERY_EXECUTION_RESULT": execution,
                "SQL_VALIDATION_RESULT": {
                    "referenced_tables": list(referenced_tables),
                    "referenced_columns": source_columns,
                },
                "CALCULATED_RESULTS": calculated_results,
                "SUFFICIENT_DATA_CONTEXT": {
                    "sufficient": is_sufficient,
                    "limitations": limitations,
                    "context": sufficient_data_context,
                },
            },
        )
        try:
            explanation_model = call_narrative_json(
                self._llm,
                prompt,
                _AnalysisExplanation,
                fallback_llm=self._fallback_llm,
            )
            explanation = explanation_model.model_dump(mode="json")
            summary = explanation["analysis_summary"]
            explanation_lists = (
                explanation["assumptions"]
                + explanation["limitations"]
                + explanation["warnings"]
            )
            if execution.success and records and (
                contains_no_result_claim(summary)
                or any(
                    contains_no_result_claim(item)
                    for item in explanation_lists
                )
            ):
                summary = (
                    "Analysis was performed using the returned query results."
                )
                explanation["assumptions"] = [
                    item
                    for item in explanation["assumptions"]
                    if not contains_no_result_claim(item)
                ]
                explanation["limitations"] = [
                    item
                    for item in explanation["limitations"]
                    if not contains_no_result_claim(item)
                ]
                explanation["warnings"] = [
                    item
                    for item in explanation["warnings"]
                    if not contains_no_result_claim(item)
                ]
                explanation["warnings"].append(
                    "A contradictory no-results statement from the analysis "
                    "model was replaced."
                )
            grounding = self._grounding_validator.validate(
                answer=summary,
                query_results=records,
                result_columns=source_columns,
                referenced_tables=referenced_tables,
                user_query=request.original_question,
                data_sufficient=is_sufficient,
            )
            if not grounding.grounded:
                raise ValueError(
                    "Analysis explanation failed grounding checks: "
                    + "; ".join(
                        issue.message for issue in grounding.issues
                    )
                )
        except Exception as exc:
            logger.warning(
                "Analysis interpretation unavailable; using deterministic "
                "results. error_type={}",
                type(exc).__name__,
            )
            summary = _deterministic_summary(
                trends,
                sufficient=is_sufficient,
            )
            explanation = {
                "assumptions": [],
                "limitations": [],
                "warnings": [
                    "The configured language model could not provide a "
                    "validated explanation; deterministic results are shown."
                ],
            }
            grounding = self._grounding_validator.validate(
                answer=summary,
                query_results=records,
                result_columns=source_columns,
                referenced_tables=referenced_tables,
                user_query=request.original_question,
                data_sufficient=is_sufficient,
            )
            if not grounding.grounded:
                raise ValueError(
                    "Deterministic analysis summary failed grounding checks: "
                    + "; ".join(
                        issue.message for issue in grounding.issues
                    )
                ) from exc

        limitations.extend(explanation.get("limitations", []))
        return AnalysisResult(
            analysis_summary=summary,
            metrics=metrics,
            comparisons=comparisons,
            trends=trends,
            anomalies=anomalies,
            findings=findings,
            contributing_factors=contributing_factors,
            contribution_details=contribution_details,
            assumptions=explanation.get("assumptions", []),
            limitations=list(dict.fromkeys(limitations)),
            warnings=(
                deterministic_warnings
                + explanation.get("warnings", [])
            ),
            analyzed_row_count=len(records),
            source_columns=source_columns,
            sufficient_data=is_sufficient,
            confidence=0.8 if is_sufficient else 0.4,
        )

    @staticmethod
    def _insufficient_result(
        message: str,
        *,
        analyzed_row_count: int,
        source_columns: Sequence[str],
    ) -> AnalysisResult:
        return AnalysisResult(
            analysis_summary=message,
            limitations=[message],
            analyzed_row_count=analyzed_row_count,
            source_columns=list(source_columns),
            sufficient_data=False,
            confidence=0.0,
        )


def _numeric_columns(frame: pd.DataFrame) -> dict[str, pd.Series]:
    numeric_columns: dict[str, pd.Series] = {}
    for column in frame.columns:
        values = frame[column]
        if pd.api.types.is_bool_dtype(values.dtype):
            continue
        numeric = pd.to_numeric(values, errors="coerce")
        finite_mask = np.isfinite(numeric.to_numpy(dtype=float, na_value=np.nan))
        clean_values = numeric.loc[finite_mask].astype(float)
        if not clean_values.empty:
            numeric_columns[str(column)] = clean_values
    return numeric_columns


def _calculate_metrics(
    numeric_columns: Mapping[str, pd.Series],
    selected_columns: Sequence[str],
) -> list[MetricResult]:
    results: list[MetricResult] = []
    for column in selected_columns:
        values = numeric_columns[column]
        array = values.to_numpy(dtype=float)
        calculations = (
            ("sum", np.sum(array)),
            ("average", np.mean(array)),
            ("minimum", np.min(array)),
            ("maximum", np.max(array)),
        )
        for aggregation, value in calculations:
            results.append(
                MetricResult(
                    name=f"{aggregation}_of_{column}",
                    value=_native_number(float(value)),
                    aggregation=aggregation,
                    source_columns=[column],
                    record_count=int(array.size),
                )
            )
    return results


def _calculate_ranking(
    frame: pd.DataFrame,
    numeric_columns: Mapping[str, pd.Series],
    intent: IntentResult,
    referenced_tables: Sequence[str],
) -> list[AnalyticalFinding]:
    if not intent.ranking.required or not numeric_columns:
        return []
    metric_column = _choose_metric_column(
        list(numeric_columns),
        intent.ranking.rank_by,
        intent.metrics,
    )
    if metric_column is None:
        return []
    dimension_column = _choose_dimension_column(
        frame,
        intent.dimensions,
        numeric_columns,
    )
    if dimension_column is None:
        return []
    ranked = frame.copy()
    ranked[metric_column] = pd.to_numeric(
        ranked[metric_column],
        errors="coerce",
    )
    ranked = ranked.dropna(subset=[metric_column]).sort_values(
        metric_column,
        ascending=intent.ranking.sort_direction == "ascending",
    )
    if ranked.empty:
        return []
    top_row = ranked.iloc[0]
    entity = str(top_row[dimension_column])
    metric_value = _native_number(float(top_row[metric_column]))
    return [
        AnalyticalFinding(
            title=f"Leading {dimension_column} in returned rows",
            finding_type=FindingType.RANKING,
            importance=FindingImportance.MEDIUM,
            description=(
                f"{entity} ranks first among the returned rows for "
                f"{metric_column}."
            ),
            evidence=[
                EvidenceReference(
                    description=(
                        "Value taken from the leading returned row."
                    ),
                    table_names=list(referenced_tables),
                    columns=[dimension_column, metric_column],
                    values={
                        dimension_column: entity,
                        metric_column: metric_value,
                    },
                )
            ],
            confidence=1.0,
            caveat=(
                "Ranking applies only to the rows returned by the query."
            ),
        )
    ]


def _calculate_contributions(
    frame: pd.DataFrame,
    numeric_columns: Mapping[str, pd.Series],
    intent: IntentResult,
    plan: AnalysisPlan,
) -> tuple[list[str], list[MetricResult], list[ContributionResult]]:
    requested = (
        any(
            _enum_value(item) in {"contribution", "root_cause"}
            for item in intent.analysis_types
        )
        or intent.intent == "root_cause_analysis"
        or any(
            str(method).casefold() in {"contribution", "root_cause"}
            for method in plan.analysis_methods
        )
    )
    if not requested:
        return [], [], []
    metric_column = _choose_metric_column(
        list(numeric_columns),
        None,
        intent.metrics,
    )
    dimension_columns = [
        match
        for dimension in intent.dimensions
        if (
            match := _match_column(
                [str(column) for column in frame.columns],
                dimension.name,
            )
        ) is not None
    ]
    if not dimension_columns:
        fallback_dimension = _choose_dimension_column(
            frame,
            intent.dimensions,
            numeric_columns,
        )
        if fallback_dimension is not None:
            dimension_columns = [fallback_dimension]
    if metric_column is None or not dimension_columns:
        return [], [], []
    comparison = intent.comparison
    period_column = (
        _match_column(
            list(frame.columns),
            comparison.comparison_dimension,
        )
        if comparison.required
        else None
    )
    details = analyze_contributions(
        frame,
        metric_column,
        dimension_columns,
        period_column=period_column,
        baseline=comparison.baseline if period_column else None,
        target=comparison.target if period_column else None,
    )
    if not details:
        return [], [], []
    factors = [
        f"{item.segment} is an observed contributing factor at the "
        f"{item.dimension} level; this is descriptive, not causal."
        for item in details
    ]
    contribution_metrics: list[MetricResult] = []
    for item in details:
        value = (
            item.absolute_change
            if item.absolute_change is not None
            else item.target_value
        )
        if value is None:
            continue
        contribution_metrics.append(
            MetricResult(
                name=f"{metric_column}_for_{item.segment}",
                value=_native_number(float(value)),
                aggregation=(
                    "change_by_group"
                    if item.absolute_change is not None
                    else "sum_by_group"
                ),
                source_columns=dimension_columns + [metric_column],
                record_count=len(frame),
            )
        )
    return factors, contribution_metrics, details


def _calculate_comparisons(
    frame: pd.DataFrame,
    numeric_columns: Mapping[str, pd.Series],
    intent: IntentResult,
) -> tuple[list[ComparisonResult], list[str]]:
    comparison = intent.comparison
    if not comparison.required:
        return [], []
    metric_column = _choose_metric_column(
        list(numeric_columns),
        None,
        intent.metrics,
    )
    dimension = _match_column(
        list(frame.columns),
        comparison.comparison_dimension,
    )
    if metric_column is None or dimension is None:
        return [], [
            "Comparison could not be calculated from the returned columns."
        ]
    labels = [comparison.baseline, comparison.target]
    if not all(labels):
        return [], [
            "Comparison requires explicit baseline and target values."
        ]
    result = compare_groups(
        frame,
        metric_column,
        dimension,
        labels[0],
        labels[1],
    )
    if result is None:
        return [], [
            "Comparison baseline or target was not present in the returned rows."
        ]
    return [result], []


def _calculate_trends(
    frame: pd.DataFrame,
    numeric_columns: Mapping[str, pd.Series],
    intent: IntentResult,
) -> tuple[list[TrendResult], list[str]]:
    requested = (
        intent.intent == "trend_analysis"
        or any(_enum_value(item) == "trend" for item in intent.analysis_types)
    )
    if not requested:
        return [], []
    metric_column = _choose_metric_column(
        list(numeric_columns),
        None,
        intent.metrics,
    )
    time_hint = (
        intent.time_period.time_column_hint
        if intent.time_period is not None
        else None
    )
    time_column = _match_column(list(frame.columns), time_hint)
    if time_column is None:
        candidates = [
            str(column)
            for column in frame.columns
            if "date" in str(column).casefold()
            or "time" in str(column).casefold()
        ]
        time_column = candidates[0] if candidates else None
    if metric_column is None or time_column is None:
        return [], [
            "Trend could not be calculated because a metric or time column "
            "was unavailable."
        ]
    granularity = (
        _enum_value(intent.time_period.granularity)
        if intent.time_period is not None
        else "month"
    )
    dimension_column = _match_column(
        list(frame.columns),
        intent.dimensions[0].name if intent.dimensions else None,
    )
    if dimension_column is None and intent.dimensions:
        dimension_column = _match_dimension_column(
            list(frame.columns),
            intent.dimensions[0].name,
        )
    if dimension_column is None:
        result = analyze_trend(
            frame,
            time_column,
            metric_column,
            granularity=granularity,
        )
        if result is None:
            return [], [
                "Trend requires at least two valid time points."
            ]
        return [result], []

    results: list[TrendResult] = []
    limitations: list[str] = []
    for segment, segment_frame in frame.groupby(
        dimension_column,
        sort=False,
        dropna=False,
    ):
        if pd.isna(segment):
            limitations.append(
                f"Trend data with a missing {dimension_column} value was excluded."
            )
            continue
        result = analyze_trend(
            segment_frame,
            time_column,
            metric_column,
            granularity=granularity,
        )
        if result is None:
            limitations.append(
                f"{segment} has fewer than two valid time periods for "
                "trend analysis."
            )
            continue
        segment_name = str(segment)
        direction_text = {
            TrendDirection.INCREASING: "increased",
            TrendDirection.DECREASING: "decreased",
            TrendDirection.STABLE: "remained stable",
            TrendDirection.VOLATILE: "varied",
        }[TrendDirection(result.direction)]
        change_text = (
            f" by {result.percentage_change:.2f}%"
            if result.percentage_change is not None
            else "; percentage change is unavailable because the starting "
            "value is zero"
        )
        detailed_interpretation = (
            f"{segment_name} {metric_column} {direction_text} from "
            f"{result.start_value:g} to {result.end_value:g}{change_text} "
            f"across the observed {result.granularity} periods."
        )
        results.append(
            result.model_copy(
                update={
                    "dimension": intent.dimensions[0].name,
                    "segment": segment_name,
                    "source_columns": [
                        dimension_column,
                        time_column,
                        metric_column,
                    ],
                    "interpretation": detailed_interpretation,
                }
            )
        )
    results.sort(
        key=lambda item: (
            item.percentage_change is None,
            -(item.percentage_change or 0.0),
        )
    )
    if not results:
        limitations.append(
            "Trend requires at least two valid time points per segment."
        )
    return results, limitations


def _calculate_anomalies(
    frame: pd.DataFrame,
    numeric_columns: Mapping[str, pd.Series],
    intent: IntentResult,
) -> list[AnomalyResult]:
    requested = (
        intent.intent == "anomaly_detection"
        or any(_enum_value(item) == "anomaly" for item in intent.analysis_types)
        or intent.intent == "trend_analysis"
    )
    if not requested:
        return []
    metric_column = _choose_metric_column(
        list(numeric_columns),
        None,
        intent.metrics,
    )
    if metric_column is None:
        return []
    values = numeric_columns[metric_column]
    dimension_column = _choose_dimension_column(
        frame,
        intent.dimensions,
        numeric_columns,
    )
    if intent.intent == "trend_analysis" and dimension_column is not None:
        time_hint = (
            intent.time_period.time_column_hint
            if intent.time_period is not None
            else None
        )
        time_column = _match_column(list(frame.columns), time_hint)
        if time_column is None:
            time_column = next(
                (
                    str(column)
                    for column in frame.columns
                    if "date" in str(column).casefold()
                    or "time" in str(column).casefold()
                ),
                None,
            )
        if time_column is not None:
            anomalies: list[AnomalyResult] = []
            for segment, segment_frame in frame.groupby(
                dimension_column,
                sort=False,
                dropna=True,
            ):
                ordered = segment_frame.sort_values(time_column)
                segment_values = pd.to_numeric(
                    ordered[metric_column],
                    errors="coerce",
                )
                periods = ordered[time_column].astype(str)
                detected = detect_anomalies(
                    segment_values,
                    entities=[
                        f"{segment} at {period}"
                        for period in periods
                    ],
                    entity_column=dimension_column,
                    metric_name=metric_column,
                )
                anomalies.extend(
                    anomaly.model_copy(
                        update={
                            "source_columns": [
                                dimension_column,
                                time_column,
                                metric_column,
                            ]
                        }
                    )
                    for anomaly in detected
                )
            return anomalies

    entities = (
        frame.loc[values.index, dimension_column].tolist()
        if dimension_column is not None
        else values.index.tolist()
    )
    return detect_anomalies(
        values,
        entities=entities,
        entity_column=dimension_column,
        metric_name=metric_column,
    )


def _calculate_trend_ranking(
    trends: Sequence[TrendResult],
    intent: IntentResult,
    referenced_tables: Sequence[str],
) -> list[AnalyticalFinding]:
    if not trends or not intent.dimensions:
        return []
    eligible = [
        trend
        for trend in trends
        if trend.segment is not None
        and trend.percentage_change is not None
        and trend.percentage_change > 0
    ]
    if not eligible:
        return []
    fastest = max(eligible, key=lambda trend: trend.percentage_change or 0.0)
    if (
        fastest.segment is None
        or fastest.dimension is None
        or fastest.percentage_change is None
    ):
        return []
    return [
        AnalyticalFinding(
            title=f"Fastest-growing {fastest.dimension}",
            finding_type=FindingType.RANKING,
            importance=FindingImportance.HIGH,
            description=(
                f"{fastest.segment} had the largest observed percentage "
                f"increase in {fastest.metric_name} "
                f"({fastest.percentage_change:.2f}%) across the returned "
                "periods."
            ),
            evidence=[
                EvidenceReference(
                    description=(
                        "Category growth ranked by calculated start-to-end "
                        "percentage change."
                    ),
                    table_names=list(referenced_tables),
                    columns=fastest.source_columns,
                    values={
                        fastest.dimension: fastest.segment,
                        "start_value": fastest.start_value,
                        "end_value": fastest.end_value,
                        "percentage_change": fastest.percentage_change,
                    },
                )
            ],
            confidence=1.0,
            caveat=(
                "Ranking applies only to segments with enough returned "
                "time periods to calculate a trend."
            ),
        )
    ]


def _deterministic_summary(
    trends: Sequence[TrendResult],
    *,
    sufficient: bool,
) -> str:
    segmented_trends = [
        trend
        for trend in trends
        if trend.segment is not None and trend.percentage_change is not None
    ]
    increasing = [
        trend
        for trend in segmented_trends
        if trend.percentage_change is not None
        and trend.percentage_change > 0
    ]
    if increasing:
        fastest = max(
            increasing,
            key=lambda trend: trend.percentage_change or 0.0,
        )
        dimension_label = fastest.dimension or "segment"
        if dimension_label.endswith("y"):
            dimension_label = f"{dimension_label[:-1]}ies"
        elif not dimension_label.endswith("s"):
            dimension_label = f"{dimension_label}s"
        summary = (
            f"Among the returned "
            f"{dimension_label}, "
            f"{fastest.segment} had the strongest increase in "
            f"{fastest.metric_name} across the observed periods."
        )
    elif trends:
        summary = (
            "The returned time series show no segment with a positive "
            "start-to-end increase."
        )
    elif sufficient:
        return "Analysis was performed using the returned query results."
    else:
        summary = (
            "The query returned rows, but there is insufficient data for a "
            "complete analysis."
        )
    if not sufficient:
        summary += " The available data is insufficient for a complete analysis."
    return summary


def _choose_metric_column(
    columns: Sequence[str],
    preferred: str | None,
    metrics: Sequence[Any],
) -> str | None:
    candidates = [preferred] if preferred else []
    for metric in metrics:
        candidates.extend(
            [
                getattr(metric, "alias", None),
                getattr(metric, "name", None),
            ]
        )
    for candidate in candidates:
        match = _match_column(columns, candidate)
        if match is not None:
            return match
    for candidate in candidates:
        if not candidate:
            continue
        normalized_candidate = _normalize(candidate)
        partial_matches = [
            column
            for column in columns
            if (
                normalized_candidate in _normalize(column)
                or _normalize(column) in normalized_candidate
            )
        ]
        if len(partial_matches) == 1:
            return partial_matches[0]
    non_identifier_columns = [
        column for column in columns if not _is_identifier_column(column)
    ]
    return (
        non_identifier_columns[0]
        if len(non_identifier_columns) == 1
        else None
    )


def _choose_dimension_column(
    frame: pd.DataFrame,
    dimensions: Sequence[Any],
    numeric_columns: Mapping[str, pd.Series],
) -> str | None:
    columns = [str(column) for column in frame.columns]
    for dimension in dimensions:
        dimension_name = getattr(dimension, "name", None)
        match = _match_column(columns, dimension_name)
        if match is None:
            match = _match_dimension_column(columns, dimension_name)
        if match is not None:
            return match
    non_numeric = [
        column for column in columns if column not in numeric_columns
    ]
    return non_numeric[0] if len(non_numeric) == 1 else None


def _match_column(
    columns: Sequence[str],
    candidate: str | None,
) -> str | None:
    if not candidate:
        return None
    normalized = _normalize(candidate)
    for column in columns:
        if _normalize(column) == normalized:
            return column
    return None


def _match_dimension_column(
    columns: Sequence[str],
    candidate: str | None,
) -> str | None:
    if not candidate:
        return None
    aliases = {
        "category": ("categoryName", "category_name"),
        "product": ("productName", "product_name"),
        "customer": ("customerName", "companyName", "customer_name"),
        "employee": ("employeeName", "employee_name"),
        "supplier": ("supplierName", "companyName", "supplier_name"),
    }
    for alias in aliases.get(candidate.casefold(), ()):
        match = _match_column(columns, alias)
        if match is not None:
            return match
    return None


def _normalize(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.casefold())


def _is_identifier_column(column: str) -> bool:
    separated = re.sub(
        r"(?<=[a-z0-9])(?=[A-Z])",
        "_",
        column,
    )
    return separated.casefold().split("_")[-1] in {"id", "key"}


def _native_number(value: float) -> int | float:
    if not np.isfinite(value):
        raise ValueError("A calculated metric is not finite.")
    if value.is_integer():
        return int(value)
    return value


def _enum_value(value: Any) -> str:
    return str(getattr(value, "value", value))


def _contains_number(value: str) -> bool:
    return bool(
        _NUMBER_PATTERN.search(value)
        or _NUMBER_WORD_PATTERN.search(value)
    )