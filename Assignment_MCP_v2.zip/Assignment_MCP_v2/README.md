# Multi-Agent Data Analytics System — FastAPI + Streamlit

A five-agent analytics workflow using FastAPI, LangGraph, Ollama, MySQL and deterministic SQL/data validation.

## Current scope

This package includes a FastAPI backend and a Streamlit frontend. Streamlit authenticates through the API and submits analytics requests; it does not generate SQL or bypass backend authorization.

Workflow:
1. Input guardrail and backend authorization
2. Intent Understanding Agent
3. Planning Agent
4. Schema retrieval from the registered MySQL database
5. SQL Generation Agent
6. Deterministic SQL validation and bounded correction retries
7. Read-only query execution
8. Analysis Agent (Pandas/NumPy calculations + LLM interpretation)
9. Grounding validation
10. Reporting Agent and final output guardrail

Ollama handles intent, planning, and SQL generation. When GEMINI_API_KEY is
configured, Gemini handles the analysis and reporting narratives; otherwise
those agents use Ollama. Both agents retain deterministic fallbacks. Backend
permissions, SQL safety, database execution and numeric calculations remain
deterministic.

## Requirements

- Windows 10/11 or Linux
- Python 3.12 recommended for the pinned dependency set
- MySQL Server with the Northwind schema imported as `northwind_db`
- Ollama installed and running
- A MySQL account with SELECT-only permissions on `northwind_db`

Do not use the MySQL root account for normal analytics execution. The DB account used by the application should be read-only.

## Setup (Windows PowerShell)

Run these commands from the project root (the folder containing `run_api.py`):

```powershell
# 1. Create and activate a virtual environment
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1

# 2. Upgrade pip and install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 3. Create your local environment file
Copy-Item .env.example .env
# Edit .env and enter your own MySQL credentials, JWT secret, and bootstrap admin password.
# Add a Google AI Studio API key as GEMINI_API_KEY to enable Gemini for analysis/report narratives.

# 4. Check that Ollama is available and download the configured model
# Gemini is a hosted API model; install the google-genai package via requirements
# and configure GEMINI_API_KEY in .env (there is no local Gemini model to pull).
ollama serve
# In a second PowerShell window:
ollama pull llama3.2
ollama list

# 5. Start the API
python run_api.py
```

If PowerShell blocks activation, run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

If Python 3.12 is not installed, use an installed supported Python version and create a fresh virtual environment. Do not reuse a virtual environment created by another Python version.

## Run the Streamlit frontend

Start the API in one terminal:

```powershell
python run_api.py
```

Start Streamlit in a second terminal:

```powershell
python -m streamlit run streamlit_app.py
# or
python run_streamlit.py
```

Open the local Streamlit URL shown in the terminal (normally
`http://localhost:8501`). Sign in using the bootstrap administrator or another
account provisioned by your application. Set `ANALYTICS_API_URL` if the API is
not running at `http://127.0.0.1:8000`. Analytics requests wait up to 900
seconds by default; set `ANALYTICS_REQUEST_TIMEOUT_SECONDS` to adjust this for
your environment.

## Logging

Loguru writes concise console logs and rotating daily files under `logs/`.
Every workflow stage includes the request ID and stage name. Logs include
state-transition summaries, selected tables, SQL-presence/validation metadata,
result columns/counts and safe report diagnostics. Do not log secrets or full
customer result sets. Files rotate at 10 MB and are retained for 14 days.

## Verify the backend

Open:
- `http://127.0.0.1:8000/health`
- `http://127.0.0.1:8000/health/database`
- `http://127.0.0.1:8000/health/llm`
- `http://127.0.0.1:8000/docs`

Log in through the authentication endpoint in Swagger (`POST /api/auth/login`) using the bootstrap admin credentials configured in `.env`. Copy the returned access token.

Then call `POST /api/analytics/query` with a Bearer token and a JSON body such as:

```json
{
  "question": "Show top 5 customers by total sales",
  "database_name": "northwind",
  "max_retries": 2
}
```

Second test:
```json
{
  "question": "Which employees handled the highest value orders?",
  "database_name": "northwind",
  "max_retries": 2
}
```

The second question is interpreted as employee-level ranking by aggregated order-line value when the schema exposes the Employees → Orders → Order Details relationships. The SQL agent must use the exact table and column names retrieved from your live schema. If you mean individual highest-value orders rather than employees ranked by total value, ask: "Show the 10 highest-value individual orders with the employee who handled each order."

## What to expect in the API response

For a successful request, the response model includes:
- `status`
- `final_answer` (executive summary and returned result table)
- `report` (structured executive summary, findings, charts, recommendations, assumptions and limitations)
- `chart_specifications`
- `visualization_data`
- `query_executed`, `row_count`, `result_rows`
- `grounded`, `sufficient_data`
- `errors` and `retry_count`

A failed request returns HTTP 502 with a safe `detail` object containing a user-facing `final_answer`, `request_id`, retry count and normalized error information. SQL candidates and database credentials are not returned.

## Run tests

```powershell
python -m pytest -q
```

Some tests require the local MySQL database or Ollama service. Run the full suite with those dependencies available. If a test is environment-dependent, inspect its fixture/marker before treating a local integration failure as a code regression.

## Security and housekeeping

- `.env` is local-only and must never be committed or shared.
- `.env.example` contains placeholders only.
- Rotate database and bootstrap credentials if a real `.env` was shared outside your machine.
- Do not put passwords, JWT secrets, raw SQL with sensitive literals, or full customer records in logs.
- The API's database user should have SELECT-only grants.
- Keep `.venv`, `__pycache__`, `.pytest_cache`, generated logs and local secrets out of source-control archives.

## Known next phase

Once API responses are stable, build the Streamlit UI to consume the API. Add request-correlated UI/backend logging and a report visualization layer; do not duplicate SQL generation, authorization or workflow logic in Streamlit.


## Final output-grounding fix (20 Nov 2026)

The Reporting Agent and final Output Guardrail now include structured values
from `AnalysisResult.findings[*].evidence[*].values` and record identifiers,
in addition to raw SQL rows and calculated metrics/comparisons/trends/anomalies.
This fixes false `UNSUPPORTED_NUMBER` failures when a report accurately repeats
a calculated number retained in finding evidence but absent from top-level
metric collections. Numeric grounding and all safety checks remain enabled;
this change does not bypass the guardrail.

After replacing the project folder, run `python -m compileall .`, restart the
API, and retest. If it still fails, capture the full
`output_guardrail_result.issues` list rather than disabling final validation.
