"""Generate cautious recommendations linked to deterministic findings."""

from __future__ import annotations

from schemas.analysis_schema import (
    AnalysisResult,
    FindingType,
    TrendDirection,
)
from schemas.report_schema import (
    BusinessRecommendation,
    RecommendationPriority,
    RecommendationTimeframe,
)


def generate_recommendations(
    analysis: AnalysisResult,
) -> list[BusinessRecommendation]:
    """Recommend evidence review, never unsupported actions or causal claims."""
    if not analysis.sufficient_data:
        return []

    findings_by_type: dict[str, set[str]] = {}
    for finding in analysis.findings:
        findings_by_type.setdefault(
            str(getattr(finding.finding_type, "value", finding.finding_type)),
            set(),
        ).add(finding.title)

    recommendations: list[BusinessRecommendation] = []
    for trend in analysis.trends:
        finding_title = (
            f"{trend.metric_name} trend for {trend.segment}"
            if trend.segment is not None
            else f"{trend.metric_name} trend"
        )
        if finding_title not in findings_by_type.get(FindingType.TREND.value, set()):
            continue
        segment_label = trend.segment or trend.metric_name
        if trend.direction == TrendDirection.INCREASING:
            title = f"Monitor the increase in {segment_label}"
            recommendation = (
                f"Track whether the observed increase in {segment_label} "
                "continues in subsequent periods before adjusting plans."
            )
        elif trend.direction == TrendDirection.DECREASING:
            title = f"Review the declining {segment_label} trend"
            recommendation = (
                f"Review the observed decline in {segment_label} and "
                "validate relevant business factors before taking action."
            )
        elif trend.direction == TrendDirection.VOLATILE:
            title = f"Investigate variability in {segment_label}"
            recommendation = (
                f"Review the periods behind the variation in {segment_label} "
                "and confirm the pattern before acting."
            )
        else:
            title = f"Continue monitoring {segment_label}"
            recommendation = (
                f"Continue tracking {segment_label} to confirm that the "
                "observed stable pattern persists."
            )
        recommendations.append(
            BusinessRecommendation(
                title=title,
                recommendation=recommendation,
                rationale=trend.interpretation,
                priority=RecommendationPriority.MEDIUM,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding_title],
            )
        )

    for comparison in analysis.comparisons:
        finding_title = f"{comparison.name} comparison"
        if finding_title not in findings_by_type.get(
            FindingType.COMPARISON.value,
            set(),
        ):
            continue
        if comparison.absolute_change < 0:
            title = f"Review the {comparison.name} decrease"
            recommendation = (
                f"Review the observed change from "
                f"{comparison.baseline_label} to {comparison.target_label} "
                "before deciding on further action."
            )
        else:
            title = f"Validate the {comparison.name} improvement"
            recommendation = (
                f"Confirm the improvement from {comparison.baseline_label} "
                f"to {comparison.target_label} is sustained before changing "
                "plans."
            )
        recommendations.append(
            BusinessRecommendation(
                title=title,
                recommendation=recommendation,
                rationale=comparison.interpretation,
                priority=RecommendationPriority.MEDIUM,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding_title],
            )
        )

    for finding in analysis.findings:
        if finding.finding_type != FindingType.RANKING:
            continue
        evidence_values = (
            finding.evidence[0].values if finding.evidence else {}
        )
        entity = next(
            (
                value
                for value in evidence_values.values()
                if isinstance(value, str) and value
            ),
            finding.title,
        )
        recommendations.append(
            BusinessRecommendation(
                title=f"Assess {entity}'s measured position",
                recommendation=(
                    f"Review {entity}'s observed position against current "
                    "business priorities before deciding on follow-up."
                ),
                rationale=finding.description,
                priority=RecommendationPriority.LOW,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding.title],
            )
        )
        break

    for anomaly in analysis.anomalies:
        finding_title = f"Unusual {anomaly.metric_name} value"
        if finding_title not in findings_by_type.get(FindingType.ANOMALY.value, set()):
            continue
        recommendations.append(
            BusinessRecommendation(
                title=f"Verify the unusual {anomaly.metric_name} observation",
                recommendation=(
                    f"Review the returned {anomaly.metric_name} value for "
                    f"{anomaly.entity} and confirm its source before acting."
                ),
                rationale=anomaly.evidence,
                priority=RecommendationPriority.MEDIUM,
                timeframe=RecommendationTimeframe.IMMEDIATE,
                supporting_findings=[finding_title],
            )
        )
        break

    for finding in analysis.findings:
        if finding.finding_type != FindingType.CONTRIBUTION:
            continue
        segment = finding.title.partition(
            "Observed contribution from "
        )[2] or finding.title
        recommendations.append(
            BusinessRecommendation(
                title="Review the largest observed segment contribution",
                recommendation=(
                    f"Review the observed contribution from {segment} "
                    "before deciding on further action."
                ),
                rationale=finding.description,
                priority=RecommendationPriority.LOW,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding.title],
            )
        )
        break

    if not recommendations and analysis.findings and analysis.sufficient_data:
        finding = analysis.findings[0]
        recommendations.append(
            BusinessRecommendation(
                title="Review the verified result",
                recommendation=(
                    "Review this result alongside relevant operational "
                    "context before deciding whether follow-up is required."
                ),
                rationale=finding.description,
                priority=RecommendationPriority.LOW,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding.title],
            )
        )

    return recommendations[:3]