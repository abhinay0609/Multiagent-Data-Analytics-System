"""Assemble serializable report output from validated report content."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from pydantic import BaseModel

from reporting.executive_summary import build_executive_summary
from reporting.recommendation_engine import generate_recommendations
from schemas.analysis_schema import AnalysisResult
from schemas.report_schema import ChartSpecification, ReportResult


def assemble_report(
    draft: ReportResult,
    analysis: AnalysisResult,
) -> ReportResult:
    """Apply deterministic summaries, recommendations, and caveats."""
    report = draft.model_copy(deep=True)
    report.executive_summary = build_executive_summary(analysis)
    report.recommendations = generate_recommendations(analysis)
    report.assumptions = _merge(report.assumptions, analysis.assumptions)
    report.limitations = _merge(report.limitations, analysis.limitations)
    report.warnings = _merge(report.warnings, analysis.warnings)
    return report


def serialize_chart_specifications(
    charts: Sequence[ChartSpecification | Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Convert chart specs to JSON-compatible state values, never Figures."""
    if isinstance(charts, (str, bytes)):
        raise TypeError("charts must be a sequence of chart specifications.")
    serialized: list[dict[str, Any]] = []
    for chart in charts:
        if isinstance(chart, BaseModel):
            specification = ChartSpecification.model_validate(
                chart.model_dump(mode="json")
            )
        elif isinstance(chart, Mapping):
            specification = ChartSpecification.model_validate(chart)
        else:
            raise TypeError(
                "Each chart must be a ChartSpecification or mapping."
            )
        spec_values = specification.model_dump(mode="json")
        spec_values.pop("data")
        serialized.append(spec_values)
    return serialized


def _merge(first: Sequence[str], second: Sequence[str]) -> list[str]:
    return list(dict.fromkeys([*first, *second]))