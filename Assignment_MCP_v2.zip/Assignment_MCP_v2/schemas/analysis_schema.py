"""
Structured models for Analysis Agent output.

The Analysis Agent receives controlled query results and produces
evidence-based metrics, trends, anomalies, comparisons and insights.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class FindingType(str, Enum):
    """Supported analytical finding categories."""

    SUMMARY = "summary"
    TREND = "trend"
    COMPARISON = "comparison"
    RANKING = "ranking"
    ANOMALY = "anomaly"
    CONTRIBUTION = "contribution"
    ROOT_CAUSE = "root_cause"
    CORRELATION = "correlation"
    LIMITATION = "limitation"


class FindingImportance(str, Enum):
    """Business importance assigned to a finding."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class TrendDirection(str, Enum):
    """Direction of a measured trend."""

    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"
    VOLATILE = "volatile"
    INSUFFICIENT_DATA = "insufficient_data"


class MetricResult(BaseModel):
    """Calculated business metric."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    name: str = Field(min_length=1)
    value: int | float | str
    unit: Optional[str] = None
    aggregation: Optional[str] = None
    formatted_value: Optional[str] = None
    source_columns: list[str] = Field(
        default_factory=list
    )
    record_count: Optional[int] = Field(
        default=None,
        ge=0,
    )


class ComparisonResult(BaseModel):
    """Evidence-based comparison between two values or periods."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    name: str = Field(min_length=1)
    baseline_label: str = Field(min_length=1)
    target_label: str = Field(min_length=1)

    baseline_value: float
    target_value: float
    absolute_change: float
    percentage_change: Optional[float] = None
    interpretation: str = Field(min_length=1)
    source_columns: list[str] = Field(default_factory=list)


class TrendResult(BaseModel):
    """Time-series trend result."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    metric_name: str = Field(min_length=1)
    direction: TrendDirection
    start_value: Optional[float] = None
    end_value: Optional[float] = None
    absolute_change: Optional[float] = None
    percentage_change: Optional[float] = None
    period_count: int = Field(
        default=0,
        ge=0,
    )
    granularity: str = "month"
    periods: list[str] = Field(default_factory=list)
    values: list[float] = Field(default_factory=list)
    period_growth_percentages: list[Optional[float]] = Field(
        default_factory=list
    )
    dimension: Optional[str] = None
    segment: Optional[str] = None
    month_over_month_growth: list[Optional[float]] = Field(
        default_factory=list
    )
    quarter_over_quarter_growth: list[Optional[float]] = Field(
        default_factory=list
    )
    rolling_average: list[float] = Field(default_factory=list)
    rolling_window: Optional[int] = Field(default=None, ge=1)
    source_columns: list[str] = Field(default_factory=list)
    interpretation: str = Field(min_length=1)


class ContributionResult(BaseModel):
    """Measured segment contribution; it does not assert causality."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    dimension: str = Field(min_length=1)
    segment: str = Field(min_length=1)
    baseline_value: Optional[float] = None
    target_value: Optional[float] = None
    absolute_change: Optional[float] = None
    contribution_percentage: Optional[float] = None
    share_percentage: Optional[float] = None
    source_columns: list[str] = Field(default_factory=list)
    evidence: str = Field(min_length=1)


class AnomalyResult(BaseModel):
    """Anomaly discovered using a deterministic method."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    entity: str = Field(min_length=1)
    entity_column: Optional[str] = None
    metric_name: str = Field(min_length=1)
    observed_value: float
    expected_value: Optional[float] = None
    deviation: Optional[float] = None
    method: str = Field(min_length=1)
    source_columns: list[str] = Field(default_factory=list)
    severity: FindingImportance = FindingImportance.MEDIUM
    evidence: str = Field(min_length=1)


class EvidenceReference(BaseModel):
    """Traceable evidence supporting a finding."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    description: str = Field(min_length=1)
    table_names: list[str] = Field(
        default_factory=list
    )
    columns: list[str] = Field(
        default_factory=list
    )
    record_identifiers: list[str] = Field(
        default_factory=list
    )
    values: dict[str, Any] = Field(
        default_factory=dict
    )


class AnalyticalFinding(BaseModel):
    """One grounded business finding."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    title: str = Field(min_length=1)
    finding_type: FindingType
    importance: FindingImportance = FindingImportance.MEDIUM
    description: str = Field(min_length=1)
    evidence: list[EvidenceReference] = Field(
        min_length=1
    )
    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
    )
    caveat: Optional[str] = None


class AnalysisResult(BaseModel):
    """Validated output of the Analysis Agent."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    analysis_summary: str = Field(min_length=1)

    metrics: list[MetricResult] = Field(
        default_factory=list
    )
    comparisons: list[ComparisonResult] = Field(
        default_factory=list
    )
    trends: list[TrendResult] = Field(
        default_factory=list
    )
    anomalies: list[AnomalyResult] = Field(
        default_factory=list
    )
    findings: list[AnalyticalFinding] = Field(
        default_factory=list
    )

    contributing_factors: list[str] = Field(
        default_factory=list
    )
    contribution_details: list[ContributionResult] = Field(
        default_factory=list
    )
    assumptions: list[str] = Field(
        default_factory=list
    )
    limitations: list[str] = Field(
        default_factory=list
    )
    warnings: list[str] = Field(
        default_factory=list
    )

    analyzed_row_count: int = Field(
        default=0,
        ge=0,
    )
    source_columns: list[str] = Field(
        default_factory=list
    )

    sufficient_data: bool = True
    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
    )

    @field_validator("analysis_summary")
    @classmethod
    def validate_summary(cls, value: str) -> str:
        """Normalize the analytical summary."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "analysis_summary cannot be empty."
            )

        return clean_value

    @model_validator(mode="after")
    def validate_evidence(self) -> "AnalysisResult":
        """Require limitations when the available data is insufficient."""
        if (
            not self.sufficient_data
            and not self.limitations
        ):
            raise ValueError(
                "At least one limitation is required when data is insufficient."
            )

        return self