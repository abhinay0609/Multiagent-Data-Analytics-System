"""
Shared LangGraph workflow state.

This module defines the state contract passed between agents in the
multi-agent data analytics workflow.

Workflow state should contain serializable data only.

Do not store live objects such as:
- SQLAlchemy engines
- SQLAlchemy sessions
- Database connection managers
- Database registries
- LLM clients
- pandas DataFrames
- Plotly Figure objects
- Open files
- Logger instances

Instead, store logical identifiers, SQL strings, dictionaries, lists,
primitive values, and other JSON-compatible data.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from enum import Enum
from operator import add
from typing import Annotated, Any, Literal, Optional, TypedDict
from uuid import uuid4

from langchain_core.messages import BaseMessage
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
)
from typing_extensions import TypeAliasType


# =========================================================
# Type aliases
# =========================================================

JSONPrimitive = str | int | float | bool | None

JSONValue = TypeAliasType(
    "JSONValue",
    JSONPrimitive | list["JSONValue"] | dict[str, "JSONValue"],
)

WorkflowStatus = Literal[
    "initialized",
    "planning",
    "schema_discovery",
    "sql_generation",
    "sql_validation",
    "sql_execution",
    "analysis",
    "visualization",
    "response_generation",
    "completed",
    "failed",
    "requires_clarification",
    "requires_approval",
]

NextNode = Literal[
    "input_guardrail",
    "authorization",
    "intent_agent",
    "planning_agent",
    "schema_retrieval",
    "planner",
    "schema_agent",
    "sql_agent",
    "sql_validation",
    "sql_validator",
    "query_executor",
    "analysis_agent",
    "grounding_validator",
    "human_approval",
    "clarification",
    "reporting_agent",
    "output_guardrail",
    "visualization_agent",
    "response_agent",
    "end",
]


# =========================================================
# Enums
# =========================================================


class AgentName(str, Enum):
    """Logical agents participating in the analytics workflow."""

    INTENT_AGENT = "intent_agent"
    PLANNING_AGENT = "planning_agent"
    PLANNER = "planner"
    SCHEMA_AGENT = "schema_agent"
    SQL_AGENT = "sql_agent"
    SQL_VALIDATOR = "sql_validator"
    QUERY_EXECUTOR = "query_executor"
    ANALYSIS_AGENT = "analysis_agent"
    GROUNDING_VALIDATOR = "grounding_validator"
    VISUALIZATION_AGENT = "visualization_agent"
    RESPONSE_AGENT = "response_agent"
    REPORTING_AGENT = "reporting_agent"
    OUTPUT_GUARDRAIL = "output_guardrail"
    SYSTEM = "system"


class QueryIntent(str, Enum):
    """Supported high-level analytics request types."""

    DATA_QUERY = "data_query"
    AGGREGATION = "aggregation"
    COMPARISON = "comparison"
    TREND_ANALYSIS = "trend_analysis"
    RANKING = "ranking"
    DISTRIBUTION = "distribution"
    SCHEMA_QUESTION = "schema_question"
    VISUALIZATION = "visualization"
    GENERAL_QUESTION = "general_question"
    UNKNOWN = "unknown"


class VisualizationType(str, Enum):
    """Supported visualization categories."""

    NONE = "none"
    TABLE = "table"
    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    SCATTER = "scatter"
    HISTOGRAM = "histogram"
    BOX = "box"
    HEATMAP = "heatmap"
    KPI = "kpi"


class ErrorCategory(str, Enum):
    """Normalized workflow error categories."""

    VALIDATION = "validation"
    DATABASE = "database"
    SQL_GENERATION = "sql_generation"
    SQL_VALIDATION = "sql_validation"
    SQL_EXECUTION = "sql_execution"
    SCHEMA = "schema"
    LLM = "llm"
    ANALYSIS = "analysis"
    VISUALIZATION = "visualization"
    AUTHORIZATION = "authorization"
    TIMEOUT = "timeout"
    INTERNAL = "internal"


# =========================================================
# Pydantic state components
# =========================================================


class WorkflowError(BaseModel):
    """Structured workflow error."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    category: ErrorCategory
    message: str = Field(min_length=1)
    agent: Optional[AgentName] = None
    recoverable: bool = True
    technical_details: Optional[str] = None
    occurred_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    @field_validator("message")
    @classmethod
    def validate_message(
        cls,
        value: str,
    ) -> str:
        """Normalize and validate the error message."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Error message cannot be empty."
            )

        return clean_value


class ExecutionStep(BaseModel):
    """One planned or completed workflow step."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    step_id: str = Field(
        default_factory=lambda: str(uuid4())
    )
    sequence: int = Field(ge=1)
    agent: AgentName
    action: str = Field(min_length=1)
    status: Literal[
        "pending",
        "running",
        "completed",
        "failed",
        "skipped",
    ] = "pending"
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    output_summary: Optional[str] = None

    @field_validator("action")
    @classmethod
    def validate_action(
        cls,
        value: str,
    ) -> str:
        """Normalize and validate the step action."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Execution step action cannot be empty."
            )

        return clean_value


class VisualizationSpec(BaseModel):
    """
    Serializable visualization specification.

    The actual Plotly Figure should be created outside workflow state.
    """

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    chart_type: VisualizationType = VisualizationType.NONE
    title: Optional[str] = None
    x_column: Optional[str] = None
    y_columns: list[str] = Field(
        default_factory=list
    )
    color_column: Optional[str] = None
    aggregation: Optional[str] = None
    orientation: Literal[
        "vertical",
        "horizontal",
    ] = "vertical"
    options: dict[str, JSONValue] = Field(
        default_factory=dict
    )


class AgentTrace(BaseModel):
    """Serializable record of one agent execution."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    agent: AgentName
    action: str = Field(min_length=1)
    status: Literal[
        "started",
        "completed",
        "failed",
        "skipped",
    ]
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    details: Optional[str] = None

    @field_validator("action")
    @classmethod
    def validate_trace_action(
        cls,
        value: str,
    ) -> str:
        """Normalize and validate the trace action."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Agent trace action cannot be empty."
            )

        return clean_value


# =========================================================
# LangGraph state
# =========================================================


class AnalyticsState(TypedDict, total=False):
    """
    Shared state for the multi-agent analytics graph.

    Fields annotated with the add reducer append new values instead of
    replacing existing values when LangGraph merges node updates.
    """

    # Conversation messages
    messages: Annotated[list[BaseMessage], add]

    # Request identity and audit
    request_id: str
    conversation_id: Optional[str]
    user_id: Optional[str]
    created_at: str
    updated_at: str

    # User request
    user_query: str
    normalized_query: str
    clarification_question: Optional[str]
    clarification_response: Optional[str]

    # Workflow control
    status: WorkflowStatus
    current_agent: Optional[str]
    next_node: NextNode
    retry_count: int
    max_retries: int
    requires_human_approval: bool
    human_approved: Optional[bool]

    # Intent and planning
    intent: str
    intent_confidence: float
    intent_result: dict[str, JSONValue]
    permission_context: dict[str, JSONValue]
    scope_category: Optional[str]
    scope_reason: Optional[str]
    entities: dict[str, JSONValue]
    execution_plan: list[dict[str, JSONValue]]
    plan_result: dict[str, JSONValue]
    completed_steps: Annotated[
        list[dict[str, JSONValue]],
        add,
    ]

    # Database and schema
    database_name: str
    selected_tables: list[str]
    selected_columns: dict[str, list[str]]
    schema_context: str
    schema_metadata: dict[str, JSONValue]

    # SQL generation and validation
    generated_sql: Optional[str]
    validated_sql: Optional[str]
    sql_parameters: dict[str, JSONValue]
    sql_is_safe: bool
    sql_validation_errors: list[str]
    sql_explanation: Optional[str]
    sql_generation_result: dict[str, JSONValue]
    sql_validation_result: dict[str, JSONValue]

    # Query execution
    execution_result: dict[str, JSONValue]

    # Analysis
    analysis_summary: Optional[str]
    analysis_result: dict[str, JSONValue]
    grounding_result: dict[str, JSONValue]
    insights: list[str]
    metrics: dict[str, JSONValue]
    assumptions: list[str]
    warnings: list[str]

    # Visualization
    visualization_required: bool
    visualization_spec: dict[str, JSONValue]
    visualization_data: list[dict[str, JSONValue]]
    # Store serializable chart specs separately from query data and figures.
    chart_specifications: list[dict[str, JSONValue]]

    # Final response
    final_answer: Optional[str]
    safe_response: Optional[str]
    report_result: dict[str, JSONValue]
    terminal_error: bool
    output_guardrail_result: dict[str, JSONValue]
    response_metadata: dict[str, JSONValue]

    # Errors and observability
    errors: Annotated[
        list[dict[str, JSONValue]],
        add,
    ]
    agent_trace: Annotated[
        list[dict[str, JSONValue]],
        add,
    ]


# =========================================================
# State creation
# =========================================================


def utc_now_iso() -> str:
    """Return the current UTC time in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()


def create_initial_state(
    user_query: str,
    database_name: str = "northwind",
    user_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    max_retries: int = 2,
) -> AnalyticsState:
    """
    Create a complete initial analytics workflow state.

    Args:
        user_query:
            Natural-language analytics request.

        database_name:
            Logical database name registered in DatabaseRegistry.

        user_id:
            Optional authenticated user identifier.

        conversation_id:
            Optional conversation or chat identifier.

        max_retries:
            Maximum number of recoverable retries.
    """
    clean_query = _validate_required_text(
        user_query,
        "user_query",
    )

    clean_database_name = _validate_required_text(
        database_name,
        "database_name",
    ).lower()

    if user_id is not None:
        user_id = _validate_required_text(
            user_id,
            "user_id",
        )

    if conversation_id is not None:
        conversation_id = _validate_required_text(
            conversation_id,
            "conversation_id",
        )

    if not isinstance(max_retries, int):
        raise TypeError(
            "max_retries must be an integer."
        )

    if max_retries < 0:
        raise ValueError(
            "max_retries cannot be negative."
        )
    if max_retries > 5:
        raise ValueError(
            "max_retries cannot exceed 5."
        )

    current_time = utc_now_iso()

    state: AnalyticsState = {
        "messages": [],
        "request_id": str(uuid4()),
        "conversation_id": conversation_id,
        "user_id": user_id,
        "created_at": current_time,
        "updated_at": current_time,
        "user_query": clean_query,
        "normalized_query": clean_query,
        "clarification_question": None,
        "clarification_response": None,
        "status": "initialized",
        "current_agent": None,
        "next_node": "input_guardrail",
        "retry_count": 0,
        "max_retries": max_retries,
        "requires_human_approval": False,
        "human_approved": None,
        "intent": QueryIntent.UNKNOWN.value,
        "intent_confidence": 0.0,
        "intent_result": {},
        "permission_context": {},
        "scope_category": None,
        "scope_reason": None,
        "entities": {},
        "execution_plan": [],
        "plan_result": {},
        "completed_steps": [],
        "database_name": clean_database_name,
        "selected_tables": [],
        "selected_columns": {},
        "schema_context": "",
        "schema_metadata": {},
        "generated_sql": None,
        "validated_sql": None,
        "sql_parameters": {},
        "sql_is_safe": False,
        "sql_validation_errors": [],
        "sql_explanation": None,
        "sql_generation_result": {},
        "sql_validation_result": {},
        "execution_result": {},
        "analysis_summary": None,
        "analysis_result": {},
        "grounding_result": {},
        "insights": [],
        "metrics": {},
        "assumptions": [],
        "warnings": [],
        "visualization_required": False,
        "visualization_spec": VisualizationSpec().model_dump(
            mode="json"
        ),
        "visualization_data": [],
        "chart_specifications": [],
        "final_answer": None,
        "safe_response": None,
        "report_result": {},
        "terminal_error": False,
        "output_guardrail_result": {},
        "response_metadata": {},
        "errors": [],
        "agent_trace": [],
    }

    return state


# =========================================================
# State update helpers
# =========================================================


def state_update(
    **changes: Any,
) -> AnalyticsState:
    """
    Create a partial LangGraph state update.

    Graph nodes should return only the fields they modify.
    """
    update: AnalyticsState = {
        "updated_at": utc_now_iso(),
    }

    update.update(changes)

    return update


def add_error(
    state: AnalyticsState,
    category: ErrorCategory,
    message: str,
    agent: Optional[AgentName] = None,
    recoverable: bool = True,
    technical_details: Optional[str] = None,
) -> AnalyticsState:
    """
    Return a partial update containing one workflow error.

    This function does not mutate the provided state.
    """
    if not isinstance(category, ErrorCategory):
        raise TypeError(
            "category must be an ErrorCategory value."
        )

    if agent is not None and not isinstance(
        agent,
        AgentName,
    ):
        raise TypeError(
            "agent must be an AgentName value or None."
        )

    if not isinstance(recoverable, bool):
        raise TypeError(
            "recoverable must be a boolean."
        )

    error = WorkflowError(
        category=category,
        message=message,
        agent=agent,
        recoverable=recoverable,
        technical_details=technical_details,
    )

    current_retry_count = state.get(
        "retry_count",
        0,
    )

    update: AnalyticsState = {
        "updated_at": utc_now_iso(),
        "errors": [
            error.model_dump(mode="json")
        ],
    }

    if recoverable:
        update["retry_count"] = current_retry_count + 1
    else:
        update["status"] = "failed"
        update["next_node"] = "end"

    return update


def add_agent_trace(
    agent: AgentName,
    action: str,
    status: Literal[
        "started",
        "completed",
        "failed",
        "skipped",
    ],
    details: Optional[str] = None,
) -> AnalyticsState:
    """Return a partial update containing one agent trace."""
    trace = AgentTrace(
        agent=agent,
        action=action,
        status=status,
        details=details,
    )

    return {
        "updated_at": utc_now_iso(),
        "agent_trace": [
            trace.model_dump(mode="json")
        ],
    }


def add_completed_step(
    step: ExecutionStep,
) -> AnalyticsState:
    """Return a partial update containing one completed step."""
    if not isinstance(step, ExecutionStep):
        raise TypeError(
            "step must be an ExecutionStep instance."
        )

    return {
        "updated_at": utc_now_iso(),
        "completed_steps": [
            step.model_dump(mode="json")
        ],
    }


def should_retry(
    state: AnalyticsState,
) -> bool:
    """Return True if another workflow retry is allowed."""
    retry_count = state.get(
        "retry_count",
        0,
    )

    max_retries = state.get(
        "max_retries",
        0,
    )

    return retry_count < max_retries


def mark_completed(
    final_answer: str,
    response_metadata: Optional[
        dict[str, JSONValue]
    ] = None,
) -> AnalyticsState:
    """Return a partial update marking the workflow completed."""
    clean_answer = _validate_required_text(
        final_answer,
        "final_answer",
    )

    metadata = deepcopy(
        response_metadata or {}
    )

    validate_json_compatible(
        metadata,
        "response_metadata",
    )

    return {
        "updated_at": utc_now_iso(),
        "status": "completed",
        "current_agent": AgentName.RESPONSE_AGENT.value,
        "next_node": "end",
        "final_answer": clean_answer,
        "response_metadata": metadata,
    }


def mark_failed(
    message: str,
    category: ErrorCategory = ErrorCategory.INTERNAL,
    agent: Optional[AgentName] = None,
    technical_details: Optional[str] = None,
) -> AnalyticsState:
    """Return a partial update marking the workflow failed."""
    error = WorkflowError(
        category=category,
        message=message,
        agent=agent,
        recoverable=False,
        technical_details=technical_details,
    )

    return {
        "updated_at": utc_now_iso(),
        "status": "failed",
        "next_node": "end",
        "errors": [
            error.model_dump(mode="json")
        ],
    }


def copy_state(
    state: AnalyticsState,
) -> AnalyticsState:
    """Return a defensive deep copy of workflow state."""
    return deepcopy(state)


# =========================================================
# State validation
# =========================================================


def validate_json_compatible(
    value: Any,
    path: str = "state",
) -> None:
    """
    Validate that a value is safe for workflow state.

    LangChain BaseMessage objects are allowed because LangGraph message
    state uses these objects directly.
    """
    if value is None or isinstance(
        value,
        (str, int, float, bool),
    ):
        return

    if isinstance(value, BaseMessage):
        return

    if isinstance(value, list):
        for index, item in enumerate(value):
            validate_json_compatible(
                item,
                f"{path}[{index}]",
            )
        return

    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(
                    f"{path} contains a non-string dictionary key."
                )

            validate_json_compatible(
                item,
                f"{path}.{key}",
            )
        return

    raise TypeError(
        f"{path} contains unsupported state type "
        f"'{type(value).__name__}'."
    )


def validate_state(
    state: AnalyticsState,
) -> bool:
    """
    Validate required workflow fields and serialization safety.
    """
    if not isinstance(state, dict):
        raise TypeError(
            "state must be a dictionary."
        )

    required_fields = {
        "request_id",
        "user_query",
        "status",
        "next_node",
        "database_name",
        "retry_count",
        "max_retries",
        "errors",
    }

    missing_fields = sorted(
        field
        for field in required_fields
        if field not in state
    )

    if missing_fields:
        raise ValueError(
            "State is missing required fields: "
            + ", ".join(missing_fields)
        )

    _validate_required_text(
        state["request_id"],
        "request_id",
    )

    _validate_required_text(
        state["user_query"],
        "user_query",
    )

    _validate_required_text(
        state["database_name"],
        "database_name",
    )

    valid_statuses = {
        "initialized",
        "planning",
        "schema_discovery",
        "sql_generation",
        "sql_validation",
        "sql_execution",
        "analysis",
        "visualization",
        "response_generation",
        "completed",
        "failed",
        "requires_clarification",
        "requires_approval",
    }

    if state["status"] not in valid_statuses:
        raise ValueError(
            f"Unknown workflow status: {state['status']}"
        )

    valid_next_nodes = {
        "input_guardrail",
        "authorization",
        "intent_agent",
        "planning_agent",
        "schema_retrieval",
        "planner",
        "schema_agent",
        "sql_agent",
        "sql_validation",
        "sql_validator",
        "query_executor",
        "analysis_agent",
        "grounding_validator",
        "human_approval",
        "clarification",
        "reporting_agent",
        "output_guardrail",
        "visualization_agent",
        "response_agent",
        "end",
    }

    if state["next_node"] not in valid_next_nodes:
        raise ValueError(
            f"Unknown next node: {state['next_node']}"
        )

    retry_count = state["retry_count"]
    max_retries = state["max_retries"]

    if not isinstance(retry_count, int):
        raise TypeError(
            "retry_count must be an integer."
        )

    if not isinstance(max_retries, int):
        raise TypeError(
            "max_retries must be an integer."
        )

    if retry_count < 0:
        raise ValueError(
            "retry_count cannot be negative."
        )

    if max_retries < 0:
        raise ValueError(
            "max_retries cannot be negative."
        )

    validate_json_compatible(state)

    return True


# =========================================================
# Internal helpers
# =========================================================


def _validate_required_text(
    value: Any,
    field_name: str,
) -> str:
    """Validate and normalize required text."""
    if not isinstance(value, str):
        raise TypeError(
            f"{field_name} must be a string."
        )

    clean_value = value.strip()

    if not clean_value:
        raise ValueError(
            f"{field_name} cannot be empty."
        )

    return clean_value