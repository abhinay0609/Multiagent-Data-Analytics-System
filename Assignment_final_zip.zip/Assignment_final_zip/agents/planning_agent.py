"""Create a bounded, ordered analytics execution plan."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Mapping, Sequence

from pydantic import BaseModel

from agents._common import (
    AgentLLM,
    call_model_json,
    get_default_llm,
    render_prompt,
)
from schemas.intent_schema import IntentResult
from schemas.plan_schema import (
    AnalysisPlan,
    ExecutionControls,
    TaskType,
)


class PlanningAgent:
    """Create an AnalysisPlan without granting authorization or executing it."""

    def __init__(self, llm: AgentLLM | None = None) -> None:
        self._llm = llm if llm is not None else get_default_llm()

    def run(
        self,
        validated_intent: IntentResult | Mapping[str, Any],
        permission_context: BaseModel | Mapping[str, Any],
        available_database_metadata: Sequence[Mapping[str, Any] | Any],
        database_name: str,
        *,
        schema_context: Mapping[str, Any] | str | None = None,
        execution_policy: Mapping[str, Any] | None = None,
        human_approval_required: bool = False,
        approval_reason: str | None = None,
    ) -> AnalysisPlan:
        """Plan work using validated intent and explicit backend context."""
        intent = IntentResult.model_validate(validated_intent)
        if not isinstance(database_name, str) or not database_name.strip():
            raise ValueError("database_name must be a non-empty string.")
        if not isinstance(human_approval_required, bool):
            raise TypeError("human_approval_required must be a boolean.")

        permission = _permission_context(permission_context)
        allowed = permission.get("allowed")
        if not isinstance(allowed, bool):
            raise ValueError(
                "permission_context must include a boolean 'allowed' result."
            )
        if not allowed:
            raise PermissionError(
                str(permission.get("reason") or "Backend authorization denied.")
            )

        selected_database = database_name.strip().casefold()
        databases = _public_database_metadata(
            available_database_metadata
        )
        database_names = {
            str(item.get("name") or item.get("registry_name") or "")
            .strip()
            .casefold()
            for item in databases
        }
        if selected_database not in database_names:
            raise ValueError(
                f"Database '{selected_database}' is not in the supplied "
                "registry metadata."
            )

        policy = _execution_controls(
            execution_policy or {},
            human_approval_required=human_approval_required,
            approval_reason=approval_reason,
        )
        prompt = render_prompt(
            "planning_prompt.txt",
            {
                "INTENT_RESULT": intent,
                "PERMISSION_CONTEXT": permission,
                "LOGICAL_DATABASE_NAME": selected_database,
                "SCHEMA_CONTEXT": schema_context or {},
                "EXECUTION_POLICY": policy.model_dump(mode="json"),
                "CONVERSATION_CONTEXT": {},
            },
        )
        plan = call_model_json(self._llm, prompt, AnalysisPlan)

        if plan.data_requirements.database_name != selected_database:
            raise ValueError(
                "Planning Agent selected a database other than the "
                "authorized registry name."
            )
        if plan.controls != policy:
            raise ValueError(
                "Planning Agent changed the authoritative execution policy."
            )
        if intent.requires_clarification and not plan.requires_clarification:
            raise ValueError(
                "Planning Agent cannot clear a required user clarification."
            )
        if plan.requires_clarification and any(
            task.task_type
            in {
                TaskType.SQL_GENERATION,
                TaskType.SQL_VALIDATION,
                TaskType.QUERY_EXECUTION,
            }
            for task in plan.tasks
        ):
            raise ValueError(
                "A plan requiring clarification cannot schedule SQL work."
            )
        return plan


def _permission_context(
    value: BaseModel | Mapping[str, Any],
) -> dict[str, Any]:
    if isinstance(value, BaseModel):
        values = value.model_dump(mode="json")
    elif isinstance(value, Mapping):
        values = value
    else:
        raise TypeError("permission_context must be a model or mapping.")
    safe_fields = {
        "allowed",
        "reason",
        "missing_permission",
        "permissions",
        "allowed_databases",
        "role",
        "database_name",
    }
    return {
        key: item
        for key, item in values.items()
        if key in safe_fields
    }


def _public_database_metadata(
    values: Sequence[Mapping[str, Any] | Any],
) -> list[dict[str, Any]]:
    if isinstance(values, (str, bytes)):
        raise TypeError("available_database_metadata must be a sequence.")
    public_fields = {
        "name",
        "database_name",
        "backend",
        "driver",
        "host",
        "port",
        "description",
        "read_only",
        "is_default",
    }
    results: list[dict[str, Any]] = []
    for value in values:
        if isinstance(value, Mapping):
            record = value
        elif is_dataclass(value) and not isinstance(value, type):
            record = asdict(value)
        else:
            raise TypeError(
                "Each database metadata item must be a mapping or dataclass."
            )
        results.append(
            {
                key: item
                for key, item in record.items()
                if key in public_fields
            }
        )
    return results


def _execution_controls(
    supplied: Mapping[str, Any],
    *,
    human_approval_required: bool,
    approval_reason: str | None,
) -> ExecutionControls:
    from config.settings import settings

    if not isinstance(supplied, Mapping):
        raise TypeError("execution_policy must be a mapping.")
    if supplied.get("read_only_required", True) is not True:
        raise ValueError("Analytics plans must require read-only queries.")
    approval_required = (
        human_approval_required
        or bool(supplied.get("human_approval_required", False))
    )
    reason = approval_reason or supplied.get("approval_reason")
    values = {
        "max_sql_retries": supplied.get("max_sql_retries", 2),
        "max_result_rows": supplied.get(
            "max_result_rows",
            settings.MAX_QUERY_ROWS,
        ),
        "query_timeout_seconds": supplied.get(
            "query_timeout_seconds",
            settings.QUERY_TIMEOUT,
        ),
        "read_only_required": True,
        "human_approval_required": approval_required,
        "approval_reason": reason,
    }
    return ExecutionControls.model_validate(values)