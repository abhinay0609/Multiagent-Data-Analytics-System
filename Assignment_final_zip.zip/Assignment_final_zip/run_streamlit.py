# """Launch the Streamlit frontend."""
# from __future__ import annotations
# import subprocess
# import sys
# from pathlib import Path

# if __name__ == "__main__":
#     app = Path(__file__).with_name("streamlit_app.py")
#     raise SystemExit(subprocess.call([sys.executable, "-m", "streamlit", "run", str(app)]))


"""
Launch the Streamlit frontend.

Usage:
    python run_streamlit.py
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def main() -> int:
    """Start Streamlit using the active Python environment."""
    project_root = Path(
        __file__
    ).resolve().parent

    app_path = (
        project_root
        / "streamlit_app.py"
    )

    if not app_path.exists():
        print(
            f"Streamlit application not found: "
            f"{app_path}",
            file=sys.stderr,
        )

        return 1

    environment = os.environ.copy()

    environment.setdefault(
        "ANALYTICS_API_URL",
        "http://127.0.0.1:8000",
    )

    environment.setdefault(
        "ANALYTICS_CONNECT_TIMEOUT_SECONDS",
        "10",
    )

    environment.setdefault(
        "ANALYTICS_REQUEST_TIMEOUT_SECONDS",
        "900",
    )

    command = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(app_path),
        "--server.address",
        "127.0.0.1",
        "--server.port",
        environment.get(
            "STREAMLIT_SERVER_PORT",
            "8501",
        ),
        "--browser.gatherUsageStats",
        "false",
    ]

    print(
        "Starting Streamlit frontend..."
    )

    print(
        f"Application: {app_path}"
    )

    print(
        "API URL: "
        f"{environment['ANALYTICS_API_URL']}"
    )

    return subprocess.call(
        command,
        cwd=str(project_root),
        env=environment,
    )


if __name__ == "__main__":
    raise SystemExit(main())