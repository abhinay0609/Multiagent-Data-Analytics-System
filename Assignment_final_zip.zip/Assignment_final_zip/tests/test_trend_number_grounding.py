import numpy as np
import pandas as pd

from agents.analysis_agent import (
    _calculate_trends,
    _deterministic_summary,
)
from agents.reporting_agent import (
    ReportingAgent,
    _build_fallback_chart,
    _grounding_rows,
    _report_grounding_fallback,
)
from agents._common import call_narrative_json
from guardrails import GroundingResult, GroundingValidator
from reporting import create_figure
from schemas.report_schema import ReportResult
from schemas.analysis_schema import (
    AnalysisResult,
    AnalyticalFinding,
    EvidenceReference,
    FindingType,
    TrendDirection,
    TrendResult,
)
from schemas.intent_schema import IntentResult, QueryIntent
from schemas.sql_schema import QueryExecutionMetadata, QueryExecutionResult


def _validate(answer: str, rows):
    return GroundingValidator().validate(
        answer,
        rows,
        data_sufficient=True,
    )


def _trend_analysis() -> AnalysisResult:
    trend = TrendResult(
        metric_name="total_sales",
        direction=TrendDirection.INCREASING,
        start_value=100.0,
        end_value=123.4567,
        absolute_change=23.4567,
        percentage_change=23.4567,
        period_count=2,
        interpretation="Produce sales increased across the observed months.",
        granularity="month",
        periods=["2025-01", "2025-02"],
        values=[100.0, 123.4567],
        period_growth_percentages=[None, 23.4567],
        dimension="category",
        segment="Produce",
        month_over_month_growth=[None, 23.4567],
        quarter_over_quarter_growth=[None, 23.4567],
        rolling_average=[100.0, 111.72835],
        rolling_window=3,
        source_columns=["orderDate", "total_sales"],
    )
    return AnalysisResult(
        analysis_summary="Produce sales grew by 23.46%.",
        metric_aliases={
            "sales": ["total_sales"],
            "revenue": ["total_sales"],
            "growth": ["total_sales"],
            "percentage": ["total_sales"],
        },
        trends=[trend],
        findings=[
            AnalyticalFinding(
                title="Fastest-growing category",
                finding_type=FindingType.TREND,
                description="Produce sales grew by 23.46%.",
                evidence=[
                    EvidenceReference(
                        description=(
                            "Category growth calculated from monthly sales."
                        ),
                        table_names=["category", "salesorder", "orderdetail"],
                        columns=["orderDate", "categoryName", "total_sales"],
                        values={
                            "dimension": "category",
                            "segment": "Produce",
                            "percentage_change": 23.4567,
                        },
                    )
                ],
            )
        ],
        analyzed_row_count=2,
        source_columns=["orderDate", "categoryName", "total_sales"],
        confidence=0.95,
        sufficient_data=True,
    )


def _execution() -> QueryExecutionResult:
    records = [
        {
            "orderDate": "2025-01-01",
            "categoryName": "Produce",
            "total_sales": 100.0,
        },
        {
            "orderDate": "2025-02-01",
            "categoryName": "Produce",
            "total_sales": 123.4567,
        },
    ]
    return QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id="category-trend",
            database_name="northwind",
            row_count=len(records),
            columns=["orderDate", "categoryName", "total_sales"],
        ),
        records=records,
    )


def test_grounding_accepts_exact_and_display_rounded_values():
    rows = [{"sales": 23.4567}]

    assert _validate("Sales were 23.4567.", rows).grounded is True
    assert _validate("Sales were 23.46.", rows).grounded is True
    assert _validate("Sales were 23.45.", rows).grounded is False


def test_percentage_grounding_accepts_percent_and_ratio_evidence():
    percent_evidence = [{"growth": 23.4567}]
    ratio_evidence = [{"growth": 0.234567}]

    assert _validate("Growth was 23.46%.", percent_evidence).grounded is True
    assert _validate("Growth was 23.46%.", ratio_evidence).grounded is True
    assert _validate("Growth was 23.46.", ratio_evidence).grounded is False


def test_grounding_recurses_through_nested_numeric_trend_evidence():
    rows = [
        {
            "sales": {
                "values": np.array([100.0, 123.4567]),
                "period_growth_percentages": [None, "23.4567"],
                "monthly": (np.float64(0.234567), {np.int64(2)}),
                "rolling_window": "3",
            },
            "growth": 23.4567,
        }
    ]

    result = _validate(
        "Sales reached 123.46; growth was 23.46% over 2 periods "
        "using a 3-month rolling window.",
        rows,
    )
    assert result.grounded is True


def test_grounding_still_rejects_unrelated_numbers_and_nonpercent_scaling():
    assert _validate("Sales were 24.00.", [{"sales": 23.4567}]).grounded is False
    assert _validate("Sales were 23.46.", [{"sales": 0.234567}]).grounded is False


def test_metric_alias_requires_a_returned_supporting_column():
    validator = GroundingValidator()
    rows = [{"total_sales": 123.0}]

    supported = validator.validate(
        "Revenue increased across the returned categories.",
        rows,
        metric_aliases={"revenue": ["total_sales"]},
        data_sufficient=True,
    )
    unsupported = validator.validate(
        "Revenue increased across the returned categories.",
        rows,
        metric_aliases={"revenue": ["net_revenue"]},
        data_sufficient=True,
    )

    assert supported.grounded is True
    assert any(issue.code == "UNSUPPORTED_METRIC" for issue in unsupported.issues)


def test_validated_counts_confidence_and_rolling_window_are_grounded():
    rows = _grounding_rows(_execution(), _trend_analysis())
    result = GroundingValidator().validate(
        "1. Confidence is 0.95 across 2 rows; the chart uses a 3-month "
        "rolling window.",
        rows,
        data_sufficient=True,
        result_count=2,
    )

    assert result.grounded is True


def test_category_trend_evidence_and_report_fallback_are_grounded():
    execution = _execution()
    analysis = _trend_analysis()
    evidence_rows = _grounding_rows(execution, analysis)
    trend_evidence = next(
        row for row in evidence_rows if row.get("segment") == "Produce"
    )
    assert {
        "dimension",
        "segment",
        "start_value",
        "end_value",
        "absolute_change",
        "percentage_change",
        "period_count",
        "periods",
        "values",
        "period_growth_percentages",
        "month_over_month_growth",
        "quarter_over_quarter_growth",
    }.issubset(trend_evidence)

    class UnsupportedReportLLM:
        def generate_json(
            self,
            prompt,
            system_prompt=None,
            output_schema=None,
        ):
            return {
                "report_title": "Category trend report",
                "executive_summary": "The trend is summarized below.",
                "key_findings": [
                    {
                        "title": "Unsupported model finding",
                        "description": "Produce sales grew by 999%.",
                        "supporting_metric": "sales",
                        "supporting_value": "999%",
                    }
                ],
                "grounded": True,
                "confidence": 0.95,
            }

    report = ReportingAgent(llm=UnsupportedReportLLM()).run(
        IntentResult(
            original_question="Which categories are growing fastest over time?",
            normalized_question="Which categories are growing fastest over time?",
            intent=QueryIntent.TREND_ANALYSIS,
        ),
        execution,
        analysis,
        GroundingResult(grounded=True, issues=()),
        sql_validation_result={
            "referenced_tables": [
                "category",
                "salesorder",
                "orderdetail",
                "product",
            ]
        },
    )

    assert report.grounded is True
    assert [finding.title for finding in report.key_findings] == [
        "Fastest-growing category"
    ]
    assert len(report.recommendations) == 1
    assert report.charts[0].chart_type == "line"


def test_fallback_keeps_trend_findings_and_matching_recommendations_visible():
    analysis = _trend_analysis()
    ranking = analysis.findings[0].model_copy(
        update={"finding_type": FindingType.RANKING}
    )
    trend_finding = analysis.findings[0].model_copy(
        update={
            "title": "total_sales trend for Produce",
            "finding_type": FindingType.TREND,
        }
    )
    anomaly_findings = [
        AnalyticalFinding(
            title=f"Unusual total_sales value {index}",
            finding_type=FindingType.ANOMALY,
            description="A returned period has an unusual total_sales value.",
            evidence=[
                EvidenceReference(
                    description="Calculated from returned rows.",
                    columns=["orderDate", "total_sales"],
                    values={"total_sales": float(index)},
                )
            ],
        )
        for index in range(6)
    ]
    analysis.findings = [ranking, *anomaly_findings, trend_finding]

    report = _report_grounding_fallback(analysis)

    assert "total_sales trend for Produce" in {
        finding.title for finding in report.key_findings
    }
    assert report.recommendations
    assert report.recommendations[0].supporting_findings == [
        "total_sales trend for Produce"
    ]


def test_unsegmented_monthly_trend_summary_describes_its_own_direction():
    frame = pd.DataFrame(
        {
            "orderDate": [
                "2025-01-01",
                "2025-02-01",
                "2025-03-01",
            ],
            "total_sales": [100.0, 120.0, 150.0],
        }
    )
    intent = IntentResult(
        original_question="What is the monthly sales revenue?",
        normalized_question="What is the monthly sales revenue?",
        intent=QueryIntent.TREND_ANALYSIS,
    )
    trends, limitations = _calculate_trends(
        frame,
        {"total_sales": pd.to_numeric(frame["total_sales"])},
        intent,
    )

    assert limitations == []
    assert trends[0].interpretation == (
        "total_sales increased from 100.00 to 150.00 by 50.00% "
        "across the observed month periods."
    )
    assert _deterministic_summary(trends, [], sufficient=True) == (
        trends[0].interpretation
    )


def test_grounded_model_report_keeps_its_summary_and_recommendations():
    class DetailedReportLLM:
        def generate_json(
            self,
            prompt,
            system_prompt=None,
            output_schema=None,
        ):
            return {
                "report_title": "Category sales trend",
                "executive_summary": (
                    "Revenue increased for Produce across the returned months."
                ),
                "key_findings": [
                    {
                        "title": "Fastest-growing category",
                        "description": (
                            "Produce had the strongest increase in "
                            "total_sales among returned categories."
                        ),
                        "supporting_metric": "total_sales",
                        "supporting_value": "23.46%",
                    }
                ],
                "recommendations": [
                    {
                        "title": "Monitor category sales",
                        "recommendation": (
                            "Track total_sales by category over the next "
                            "reporting period."
                        ),
                        "rationale": (
                            "The recommendation follows the fastest-growing "
                            "category finding."
                        ),
                        "priority": "medium",
                        "timeframe": "short_term",
                        "supporting_findings": [
                            "Fastest-growing category"
                        ],
                    }
                ],
                "grounded": True,
                "grounding_notes": [],
                "confidence": 0.95,
            }

    report = ReportingAgent(llm=DetailedReportLLM()).run(
        IntentResult(
            original_question=(
                "Which categories show the fastest revenue growth?"
            ),
            normalized_question=(
                "Which categories show the fastest revenue growth?"
            ),
            intent=QueryIntent.TREND_ANALYSIS,
        ),
        _execution(),
        _trend_analysis(),
        GroundingResult(grounded=True, issues=()),
        sql_validation_result={
            "referenced_tables": [
                "category",
                "salesorder",
                "orderdetail",
            ]
        },
    )

    assert report.grounded is True
    assert report.executive_summary == (
        "Revenue increased for Produce across the returned months."
    )
    assert [item.title for item in report.recommendations] == [
        "Monitor category sales"
    ]


def test_fallback_charts_match_aggregation_ranking_and_trend_shapes():
    scalar_chart = _build_fallback_chart([{"customer_count": 91}])
    assert scalar_chart is not None
    assert scalar_chart.chart_type == "kpi"
    assert create_figure(
        scalar_chart,
        data=[{"customer_count": 91}],
    ) is not None

    ranking_chart = _build_fallback_chart(
        [
            {"productName": "Chai", "total_sales": 150.0},
            {"productName": "Chang", "total_sales": 100.0},
        ]
    )
    assert ranking_chart is not None
    assert ranking_chart.chart_type == "bar"
    assert ranking_chart.x_column == "productName"
    assert create_figure(
        ranking_chart,
        data=[
            {"productName": "Chai", "total_sales": 150.0},
            {"productName": "Chang", "total_sales": 100.0},
        ],
    ) is not None

    trend_chart = _build_fallback_chart(
        [
            {
                "orderDate": "2025-01-01",
                "categoryName": "Produce",
                "total_sales": 100.0,
            },
            {
                "orderDate": "2025-02-01",
                "categoryName": "Produce",
                "total_sales": 123.4567,
            },
        ]
    )
    assert trend_chart is not None
    assert trend_chart.chart_type == "line"
    assert trend_chart.x_column == "orderDate"
    assert create_figure(
        trend_chart,
        data=[
            {
                "orderDate": "2025-01-01",
                "categoryName": "Produce",
                "total_sales": 100.0,
            },
            {
                "orderDate": "2025-02-01",
                "categoryName": "Produce",
                "total_sales": 123.4567,
            },
        ],
    ) is not None

    segmented_chart = _build_fallback_chart(
        [
            {
                "orderDate": "2025-01-01",
                "categoryName": "Produce",
                "total_sales": 100.0,
            },
            {
                "orderDate": "2025-01-01",
                "categoryName": "Beverages",
                "total_sales": 80.0,
            },
        ]
    )
    assert segmented_chart is not None
    assert segmented_chart.chart_type == "line"
    assert segmented_chart.color_column == "categoryName"


def test_narrative_uses_ollama_after_primary_model_failure():
    class FailedPrimary:
        def generate_json(self, **kwargs):
            raise RuntimeError("Gemini unavailable.")

    class OllamaFallback:
        calls = 0

        def generate_json(self, **kwargs):
            self.calls += 1
            return {
                "report_title": "Fallback report",
                "executive_summary": "Verified findings are available.",
                "grounded": True,
            }

    fallback = OllamaFallback()
    report = call_narrative_json(
        FailedPrimary(),
        "prompt",
        ReportResult,
        fallback_llm=fallback,
    )

    assert report.report_title == "Fallback report"
    assert fallback.calls == 1
