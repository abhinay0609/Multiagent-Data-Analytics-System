"""
Integration tests for the Phase 3 SQL security boundary.

Run from the project root:

    python -m tests.test_sql
"""

from schemas.sql_schema import (
    SQLValidationStatus,
)
from sql_security.allowlist import (
    build_security_policy,
)
from sql_security.retry_handler import (
    RetryDecision,
    SQLRetryHandler,
)
from sql_security.sql_validator import (
    SQLValidator,
)


def assert_valid(
    validator: SQLValidator,
    sql: str,
) -> None:
    """Assert that a SQL query is approved."""
    result = validator.validate(sql)

    if (
        result.status
        != SQLValidationStatus.VALID.value
    ):
        print("\nUnexpected validation failure:")

        for issue in result.issues:
            print(
                f"- {issue.code}: {issue.message}"
            )

    assert (
        result.status
        == SQLValidationStatus.VALID.value
    )
    assert result.syntax_valid is True
    assert result.schema_valid is True
    assert result.security_valid is True
    assert result.read_only is True
    assert result.executable_sql is not None


def assert_invalid(
    validator: SQLValidator,
    sql: str,
    expected_code: str,
) -> None:
    """Assert that SQL is rejected with an expected issue."""
    result = validator.validate(sql)

    print(
        f"Rejected query issue codes: "
        f"{[issue.code for issue in result.issues]}"
    )

    assert (
        result.status
        != SQLValidationStatus.VALID.value
    )

    assert expected_code in {
        issue.code
        for issue in result.issues
    }

    assert result.executable_sql is None


def main() -> None:
    """Run Phase 3 SQL security tests."""
    print("=" * 60)
    print("Testing Phase 3 SQL Security Boundary")
    print("=" * 60)

    print("\n1. Building Northwind security policy")

    policy = build_security_policy(
        database_name="northwind"
    )

    print(
        f"Logical database : "
        f"{policy.logical_database_name}"
    )
    print(
        f"Physical database: "
        f"{policy.physical_database_name}"
    )
    print(
        f"Maximum rows     : "
        f"{policy.max_query_rows}"
    )
    print(
        f"Allowed tables   : "
        f"{sorted(policy.allowed_tables)}"
    )

    assert policy.is_table_allowed("customer")
    assert policy.is_table_allowed("salesorder")
    assert policy.is_table_allowed("orderdetail")
    assert not policy.is_table_allowed(
        "unknown_table"
    )
    assert not policy.is_schema_allowed(
        "mysql"
    )
    assert not policy.is_schema_allowed(
        "information_schema"
    )

    validator = SQLValidator(
        database_name="northwind",
        policy=policy,
    )

    print("\n2. Testing simple valid query")

    simple_result = validator.validate(
        """
        SELECT custId, companyName
        FROM customer
        LIMIT 10
        """
    )

    assert (
        simple_result.status
        == SQLValidationStatus.VALID.value
    )
    assert simple_result.row_limit == 10
    assert simple_result.limit_added is False
    assert "customer" in simple_result.referenced_tables

    print(
        f"Executable SQL: "
        f"{simple_result.executable_sql}"
    )

    print("\n3. Testing automatic LIMIT addition")

    no_limit_result = validator.validate(
        """
        SELECT custId, companyName
        FROM customer
        """
    )

    assert (
        no_limit_result.status
        == SQLValidationStatus.VALID.value
    )
    assert no_limit_result.limit_added is True
    assert (
        no_limit_result.row_limit
        == policy.max_query_rows
    )
    assert "LIMIT" in (
        no_limit_result.executable_sql or ""
    ).upper()

    print(
        f"Limited SQL: "
        f"{no_limit_result.executable_sql}"
    )

    print("\n4. Testing excessive LIMIT clamping")

    large_limit_result = validator.validate(
        """
        SELECT custId, companyName
        FROM customer
        LIMIT 50000
        """
    )

    assert (
        large_limit_result.status
        == SQLValidationStatus.VALID.value
    )
    assert large_limit_result.limit_added is True
    assert (
        large_limit_result.row_limit
        == policy.max_query_rows
    )

    print(
        f"Clamped SQL: "
        f"{large_limit_result.executable_sql}"
    )

    print("\n5. Testing valid joined aggregation")

    aggregation_sql = """
        SELECT
            c.companyName,
            SUM(od.unitPrice * od.quantity) AS total_sales
        FROM customer AS c
        JOIN salesorder AS so
            ON c.custId = so.custId
        JOIN orderdetail AS od
            ON so.orderId = od.orderId
        GROUP BY
            c.custId,
            c.companyName
        ORDER BY total_sales DESC
        LIMIT 5
    """

    aggregation_result = validator.validate(
        aggregation_sql
    )

    if (
        aggregation_result.status
        != SQLValidationStatus.VALID.value
    ):
        for issue in aggregation_result.issues:
            print(
                f"- {issue.code}: {issue.message}"
            )

    assert (
        aggregation_result.status
        == SQLValidationStatus.VALID.value
    )
    assert set(
        aggregation_result.referenced_tables
    ) == {
        "customer",
        "salesorder",
        "orderdetail",
    }
    assert aggregation_result.row_limit == 5

    print("Joined aggregation approved successfully.")

    print("\n6. Testing valid CTE query")

    cte_sql = """
        WITH customer_orders AS (
            SELECT
                custId,
                COUNT(*) AS order_count
            FROM salesorder
            GROUP BY custId
        )
        SELECT
            custId,
            order_count
        FROM customer_orders
        ORDER BY order_count DESC
        LIMIT 10
    """

    cte_result = validator.validate(cte_sql)

    if (
        cte_result.status
        != SQLValidationStatus.VALID.value
    ):
        for issue in cte_result.issues:
            print(
                f"- {issue.code}: {issue.message}"
            )

    assert (
        cte_result.status
        == SQLValidationStatus.VALID.value
    )
    assert "salesorder" in (
        cte_result.referenced_tables
    )

    print("CTE query approved successfully.")

    print("\n7. Blocking multiple statements")

    assert_invalid(
        validator,
        """
        SELECT * FROM customer;
        DELETE FROM customer;
        """,
        "MULTIPLE_STATEMENTS",
    )

    print("\n8. Blocking DELETE")

    assert_invalid(
        validator,
        "DELETE FROM customer WHERE custId = 1",
        "NON_READ_ONLY_STATEMENT",
    )

    print("\n9. Blocking UPDATE")

    assert_invalid(
        validator,
        "UPDATE product SET unitPrice = 0",
        "NON_READ_ONLY_STATEMENT",
    )

    print("\n10. Blocking DROP")

    assert_invalid(
        validator,
        "DROP TABLE customer",
        "NON_READ_ONLY_STATEMENT",
    )

    print("\n11. Blocking system-schema access")

    assert_invalid(
        validator,
        "SELECT * FROM mysql.user",
        "RESTRICTED_SCHEMA",
    )

    print("\n12. Blocking information_schema")

    assert_invalid(
        validator,
        """
        SELECT table_name
        FROM information_schema.tables
        """,
        "RESTRICTED_SCHEMA",
    )

    print("\n13. Blocking SLEEP function")

    assert_invalid(
        validator,
        "SELECT SLEEP(10)",
        "BLOCKED_FUNCTION",
    )

    print("\n14. Blocking LOAD_FILE function")

    assert_invalid(
        validator,
        "SELECT LOAD_FILE('/etc/passwd')",
        "BLOCKED_FUNCTION",
    )

    print("\n15. Blocking INTO OUTFILE")

    assert_invalid(
        validator,
        """
        SELECT *
        FROM customer
        INTO OUTFILE 'customers.csv'
        """,
        "BLOCKED_SQL_PATTERN",
    )

    print("\n16. Blocking SQL comments")

    assert_invalid(
        validator,
        """
        SELECT custId
        FROM customer
        -- generated query
        LIMIT 10
        """,
        "SQL_COMMENTS_NOT_ALLOWED",
    )

    print("\n17. Rejecting unknown table")

    unknown_table_result = validator.validate(
        """
        SELECT custId
        FROM customers
        LIMIT 10
        """
    )

    assert (
        unknown_table_result.status
        != SQLValidationStatus.VALID.value
    )
    assert "UNKNOWN_TABLE" in {
        issue.code
        for issue in unknown_table_result.issues
    }
    assert (
        unknown_table_result.retry_recommended
        is True
    )

    print(
        unknown_table_result.correction_feedback
    )

    print("\n18. Rejecting unknown qualified column")

    assert_invalid(
        validator,
        """
        SELECT c.unknownColumn
        FROM customer AS c
        LIMIT 10
        """,
        "INVALID_QUALIFIED_COLUMN",
    )

    print("\n19. Rejecting ambiguous column")

    ambiguous_result = validator.validate(
        """
        SELECT custId
        FROM customer AS c
        JOIN salesorder AS so
            ON c.custId = so.custId
        LIMIT 10
        """
    )

    assert (
        ambiguous_result.status
        != SQLValidationStatus.VALID.value
    )
    assert "AMBIGUOUS_COLUMN" in {
        issue.code
        for issue in ambiguous_result.issues
    }

    print("Ambiguous column rejected successfully.")

    print("\n20. Testing safe literal containing DROP")

    literal_result = validator.validate(
        """
        SELECT
            'DROP in sales is 10 percent' AS observation
        FROM customer
        LIMIT 1
        """
    )

    assert (
        literal_result.status
        == SQLValidationStatus.VALID.value
    )

    print("Keyword inside literal handled correctly.")

    print("\n21. Testing retry for unknown table")

    retry_handler = SQLRetryHandler(
        max_retries=2
    )

    retry_outcome = retry_handler.evaluate(
        validation_result=unknown_table_result,
        current_retry_count=0,
    )

    assert (
        retry_outcome.decision
        == RetryDecision.RETRY_ALLOWED
    )
    assert retry_outcome.should_retry is True
    assert retry_outcome.next_retry_count == 1
    assert retry_outcome.terminal is False

    feedback = retry_handler.build_agent_feedback(
        validation_result=unknown_table_result,
        retry_outcome=retry_outcome,
    )

    print(feedback)

    assert "Retry attempt: 1 of 2" in feedback
    assert "customers" in feedback

    print("\n22. Testing exhausted retries")

    exhausted_outcome = retry_handler.evaluate(
        validation_result=unknown_table_result,
        current_retry_count=2,
    )

    assert (
        exhausted_outcome.decision
        == RetryDecision.RETRY_EXHAUSTED
    )
    assert exhausted_outcome.should_retry is False
    assert exhausted_outcome.terminal is True

    print("Retry exhaustion handled successfully.")

    print("\n23. Testing terminal security failure")

    destructive_result = validator.validate(
        "DROP TABLE customer"
    )

    security_outcome = retry_handler.evaluate(
        validation_result=destructive_result,
        current_retry_count=0,
    )

    assert (
        security_outcome.decision
        == RetryDecision.TERMINAL_SECURITY_FAILURE
    )
    assert security_outcome.should_retry is False
    assert security_outcome.terminal is True

    print(
        "Destructive SQL correctly treated as a "
        "terminal security failure."
    )

    print("\n24. Testing state updates")

    retry_state_update = (
        retry_outcome.to_state_update()
    )

    assert (
        retry_state_update["status"]
        == "sql_generation"
    )
    assert (
        retry_state_update["next_node"]
        == "sql_agent"
    )
    assert retry_state_update["retry_count"] == 1
    assert (
        retry_state_update["sql_is_safe"]
        is False
    )

    valid_outcome = retry_handler.evaluate(
        validation_result=simple_result,
        current_retry_count=0,
    )

    valid_state_update = (
        valid_outcome.to_state_update()
    )

    assert (
        valid_state_update["next_node"]
        == "query_executor"
    )
    assert (
        valid_state_update["sql_is_safe"]
        is True
    )

    print("Retry state updates validated successfully.")

    print(
        "\nPhase 3 SQL security boundary "
        "tested successfully."
    )


if __name__ == "__main__":
    main()