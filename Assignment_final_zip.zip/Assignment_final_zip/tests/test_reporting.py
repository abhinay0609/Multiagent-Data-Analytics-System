"""Focused tests for report assembly and visualization boundaries.

Run from the project root with:

    python -m tests.test_reporting
"""

import plotly.graph_objects as go

from graph.state import create_initial_state, validate_json_compatible, validate_state
from reporting import (
    assemble_report,
    build_executive_summary,
    create_figure,
    generate_recommendations,
    serialize_chart_specifications,
)
from schemas.analysis_schema import (
    AnalysisResult,
    AnalyticalFinding,
    EvidenceReference,
    FindingType,
    TrendDirection,
    TrendResult,
)
from schemas.report_schema import ChartSpecification, ReportResult


def _analysis(*, sufficient_data: bool = True) -> AnalysisResult:
    return AnalysisResult(
        analysis_summary="Revenue declined across the returned periods.",
        findings=[
            AnalyticalFinding(
                title="revenue trend",
                finding_type=FindingType.TREND,
                description="Revenue decreased across the returned months.",
                evidence=[
                    EvidenceReference(
                        description="Calculated from returned rows.",
                        columns=["month", "revenue"],
                    )
                ],
            )
        ],
        trends=[
            TrendResult(
                metric_name="revenue",
                direction=TrendDirection.DECREASING,
                start_value=100.0,
                end_value=80.0,
                absolute_change=-20.0,
                percentage_change=-20.0,
                period_count=2,
                interpretation="Revenue decreased across the returned months.",
                source_columns=["month", "revenue"],
            )
        ],
        assumptions=["Revenue uses the supplied metric definition."],
        limitations=(
            ["The result covers only the requested date range."]
            if not sufficient_data
            else []
        ),
        sufficient_data=sufficient_data,
    )


def main() -> None:
    analysis = _analysis()
    summary = build_executive_summary(analysis)
    assert "Revenue declined" in summary
    assert "Key finding:" in summary

    recommendations = generate_recommendations(analysis)
    assert len(recommendations) == 1
    assert recommendations[0].supporting_findings == ["revenue trend"]
    assert generate_recommendations(_analysis(sufficient_data=False)) == []

    growing = _analysis()
    growing.trends[0] = growing.trends[0].model_copy(
        update={
            "direction": TrendDirection.INCREASING,
            "dimension": "category",
            "segment": "Produce",
            "interpretation": (
                "Produce revenue increased across the returned months."
            ),
        }
    )
    growing.findings[0] = growing.findings[0].model_copy(
        update={"title": "revenue trend for Produce"}
    )
    growth_recommendations = generate_recommendations(growing)
    assert growth_recommendations[0].title == "Monitor the increase in Produce"
    assert (
        growth_recommendations[0].supporting_findings
        == ["revenue trend for Produce"]
    )
    assert growth_recommendations[0].title != recommendations[0].title

    ranked_analysis = AnalysisResult(
        analysis_summary="Produce ranks first in the returned rows.",
        findings=[
            AnalyticalFinding(
                title="Leading category in returned rows",
                finding_type=FindingType.RANKING,
                description="Produce ranks first for total_sales.",
                evidence=[
                    EvidenceReference(
                        description="Rank calculated from returned rows.",
                        values={"category": "Produce", "total_sales": 150},
                    )
                ],
            )
        ],
        sufficient_data=True,
    )
    ranking_recommendations = generate_recommendations(ranked_analysis)
    assert ranking_recommendations[0].title == "Assess Produce's measured position"

    draft = ReportResult(
        report_title="Revenue report",
        executive_summary="Draft summary.",
        grounded=True,
    )
    report = assemble_report(draft, analysis)
    assert report.executive_summary == summary
    assert report.recommendations == recommendations
    assert report.assumptions == analysis.assumptions

    chart = ChartSpecification(
        chart_id="sales-by-category",
        chart_type="bar",
        title="Sales by category",
        x_column="category",
        y_columns=["sales"],
        data=[
            {"category": "A", "sales": 10},
            {"category": "B", "sales": 20},
        ],
        rationale="Compare returned sales across categories.",
    )
    figure = create_figure(chart)
    assert isinstance(figure, go.Figure)
    assert figure.data[0].type == "bar"

    specifications = serialize_chart_specifications([chart])
    assert "data" not in specifications[0]
    rendered_from_state_spec = create_figure(
        specifications[0],
        data=chart.data,
    )
    assert isinstance(rendered_from_state_spec, go.Figure)
    state = create_initial_state("Compare sales by category.")
    state["chart_specifications"] = specifications
    state["visualization_data"] = chart.data
    assert validate_state(state) is True
    assert isinstance(state["chart_specifications"][0], dict)
    try:
        validate_json_compatible({"figure": figure})
    except TypeError as exc:
        assert "Figure" in str(exc)
    else:
        raise AssertionError("A Plotly Figure was accepted in graph state.")

    kpi = ChartSpecification(
        chart_id="total-sales",
        chart_type="kpi",
        title="Total sales",
        y_columns=["sales"],
        data=[{"sales": 100}, {"sales": 50}],
        aggregation="sum",
        rationale="Summarize returned sales values.",
    )
    kpi_figure = create_figure(kpi)
    assert isinstance(kpi_figure, go.Figure)
    assert kpi_figure.data[0].value == 150

    chart_data = [
        {"label": "A", "period": "2025-01", "sales": 10, "cost": 4},
        {"label": "B", "period": "2025-02", "sales": 20, "cost": 8},
    ]
    other_charts = [
        ChartSpecification(
            chart_id="trend",
            chart_type="line",
            title="Sales trend",
            x_column="period",
            y_columns=["sales"],
            data=chart_data,
            rationale="Show sales over time.",
        ),
        ChartSpecification(
            chart_id="scatter",
            chart_type="scatter",
            title="Sales and cost",
            x_column="sales",
            y_columns=["cost"],
            data=chart_data,
            rationale="Compare two returned metrics.",
        ),
        ChartSpecification(
            chart_id="pie",
            chart_type="pie",
            title="Sales share",
            x_column="label",
            y_columns=["sales"],
            data=chart_data,
            rationale="Show sales share by label.",
        ),
        ChartSpecification(
            chart_id="histogram",
            chart_type="histogram",
            title="Sales distribution",
            x_column="sales",
            data=chart_data,
            rationale="Show the distribution of returned sales.",
        ),
        ChartSpecification(
            chart_id="box",
            chart_type="box",
            title="Sales by label",
            x_column="label",
            y_columns=["sales"],
            data=chart_data,
            rationale="Compare returned sales distributions.",
        ),
        ChartSpecification(
            chart_id="heatmap",
            chart_type="heatmap",
            title="Metric heatmap",
            x_column="label",
            y_columns=["sales", "cost"],
            data=chart_data,
            rationale="Compare returned metrics by label.",
        ),
        ChartSpecification(
            chart_id="table",
            chart_type="table",
            title="Sales table",
            data=chart_data,
            rationale="Show returned values in a table.",
        ),
    ]
    assert all(
        isinstance(create_figure(item), go.Figure)
        for item in other_charts
    )

    unsafe_options = chart.model_copy(
        update={"options": {"arbitrary_key": "ignored"}}
    )
    try:
        create_figure(unsafe_options)
    except ValueError as exc:
        assert "Unsupported Plotly layout options" in str(exc)
    else:
        raise AssertionError("Unknown chart options were silently accepted.")

    print("Reporting, chart-spec state, and Plotly rendering tests passed.")


if __name__ == "__main__":
    main()
