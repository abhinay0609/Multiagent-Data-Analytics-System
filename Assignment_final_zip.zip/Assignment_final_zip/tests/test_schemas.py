"""
Integration tests for Phase 2 structured schemas.

Run from the project root:

    python -m tests.test_schemas
"""

from pydantic import ValidationError

from schemas.analysis_schema import (
    AnalysisResult,
    AnalyticalFinding,
    EvidenceReference,
    FindingImportance,
    FindingType,
    MetricResult,
)
from schemas.intent_schema import (
    AggregationType,
    AnalysisType,
    ComparisonRequirement,
    ComparisonType,
    DimensionDefinition,
    IntentResult,
    MetricDefinition,
    QueryIntent,
    RankingRequirement,
    TimeGranularity,
    TimePeriod,
)
from schemas.plan_schema import (
    AgentType,
    AnalysisPlan,
    AnalyticalTask,
    DataRequirement,
    ExecutionControls,
    TaskType,
)
from schemas.report_schema import (
    BusinessRecommendation,
    ChartSpecification,
    ChartType,
    KeyFinding,
    RecommendationPriority,
    RecommendationTimeframe,
    ReportResult,
)
from schemas.sql_schema import (
    QueryExecutionMetadata,
    QueryExecutionResult,
    SQLGenerationResult,
    SQLStatementType,
    SQLValidationResult,
    SQLValidationStatus,
)
from schemas.user_schema import (
    LoginRequest,
    Permission,
    UserIdentity,
    UserRole,
)


def main() -> None:
    """Test all Phase 2 schema contracts."""
    print("=" * 60)
    print("Testing Phase 2 Structured Schemas")
    print("=" * 60)

    print("\n1. Testing IntentResult")

    intent = IntentResult(
        original_question=(
            "Show the top five customers by total sales."
        ),
        normalized_question=(
            "Rank customers by total sales and return the top five."
        ),
        intent=QueryIntent.RANKING,
        metrics=[
            MetricDefinition(
                name="total_sales",
                aggregation=AggregationType.SUM,
            )
        ],
        dimensions=[
            DimensionDefinition(
                name="customer"
            )
        ],
        time_period=TimePeriod(
            relative_period="all available data",
            granularity=TimeGranularity.NONE,
        ),
        comparison=ComparisonRequirement(
            required=False,
            comparison_type=ComparisonType.NONE,
        ),
        ranking=RankingRequirement(
            required=True,
            limit=5,
            rank_by="total_sales",
        ),
        analysis_types=[
            AnalysisType.AGGREGATION,
            AnalysisType.RANKING,
        ],
        visualization_required=True,
        requested_visualization="bar",
        requires_clarification=False,
        confidence=0.96,
    )

    intent_data = intent.model_dump(mode="json")

    assert intent_data["intent"] == "ranking"
    assert intent_data["ranking"]["limit"] == 5
    assert intent_data["confidence"] == 0.96

    print("IntentResult validated successfully.")

    print("\n2. Testing invalid intent clarification")

    try:
        IntentResult(
            original_question="Compare sales.",
            normalized_question="Compare sales.",
            intent=QueryIntent.COMPARISON,
            requires_clarification=True,
            confidence=0.4,
        )

    except ValidationError as exc:
        print(
            "Missing clarification question rejected successfully."
        )
        assert "clarification_question" in str(exc)

    else:
        raise AssertionError(
            "Invalid clarification output was accepted."
        )

    print("\n3. Testing AnalysisPlan")

    schema_task = AnalyticalTask(
        sequence=1,
        task_type=TaskType.SCHEMA_DISCOVERY,
        assigned_agent=AgentType.SQL_AGENT,
        title="Retrieve relevant schema",
        description=(
            "Retrieve customer, order and order-detail schema metadata."
        ),
        expected_output="Compact schema context",
    )

    sql_task = AnalyticalTask(
        sequence=2,
        task_type=TaskType.SQL_GENERATION,
        assigned_agent=AgentType.SQL_AGENT,
        title="Generate customer sales query",
        description=(
            "Generate a read-only aggregation query."
        ),
        depends_on=[schema_task.task_id],
        required_tables=[
            "customer",
            "salesorder",
            "orderdetail",
        ],
        expected_output="Validated MySQL SELECT query",
    )

    plan = AnalysisPlan(
        objective="Identify the top five customers by total sales.",
        strategy_summary=(
            "Join customers, orders and order details, aggregate revenue "
            "and rank the results."
        ),
        data_requirements=DataRequirement(
            database_name="northwind",
            required_tables=[
                "customer",
                "salesorder",
                "orderdetail",
            ],
            required_metrics=["total_sales"],
            required_dimensions=["customer"],
        ),
        tasks=[
            schema_task,
            sql_task,
        ],
        analysis_methods=[
            "aggregation",
            "ranking",
        ],
        visualization_required=True,
        recommended_visualizations=["bar"],
        controls=ExecutionControls(
            max_sql_retries=2,
            max_result_rows=1000,
            query_timeout_seconds=30,
            read_only_required=True,
        ),
        confidence=0.94,
    )

    plan_data = plan.model_dump(mode="json")

    assert len(plan_data["tasks"]) == 2
    assert plan_data["data_requirements"]["database_name"] == "northwind"

    print("AnalysisPlan validated successfully.")

    print("\n4. Testing SQLGenerationResult")

    sql_generation = SQLGenerationResult(
        database_name="northwind",
        sql_query=(
            "SELECT c.companyName, "
            "SUM(od.unitPrice * od.quantity) AS total_sales "
            "FROM customer c "
            "JOIN salesorder so ON c.customerId = so.customerId "
            "JOIN orderdetail od ON so.orderId = od.orderId "
            "GROUP BY c.customerId, c.companyName "
            "ORDER BY total_sales DESC "
            "LIMIT 5"
        ),
        statement_type=SQLStatementType.SELECT,
        referenced_tables=[
            "customer",
            "salesorder",
            "orderdetail",
        ],
        expected_columns=[
            "companyName",
            "total_sales",
        ],
        explanation=(
            "Aggregate order-detail revenue by customer and return "
            "the five highest totals."
        ),
        is_read_only=True,
        confidence=0.92,
    )

    assert sql_generation.is_read_only is True
    assert sql_generation.statement_type == "select"

    print("SQLGenerationResult validated successfully.")

    print("\n5. Testing SQLValidationResult")

    validation = SQLValidationResult(
        query_id=sql_generation.query_id,
        status=SQLValidationStatus.VALID,
        original_sql=sql_generation.sql_query,
        normalized_sql=sql_generation.sql_query,
        executable_sql=sql_generation.sql_query,
        statement_type=SQLStatementType.SELECT,
        syntax_valid=True,
        schema_valid=True,
        security_valid=True,
        read_only=True,
        referenced_tables=sql_generation.referenced_tables,
        row_limit=5,
        limit_added=False,
        issues=[],
    )

    assert validation.status == "valid"
    assert validation.security_valid is True

    print("SQLValidationResult validated successfully.")

    print("\n6. Testing QueryExecutionResult")

    execution = QueryExecutionResult(
        success=True,
        metadata=QueryExecutionMetadata(
            query_id=sql_generation.query_id,
            database_name="northwind",
            row_count=2,
            columns=[
                "companyName",
                "total_sales",
            ],
            execution_time_ms=25.5,
            truncated=False,
        ),
        records=[
            {
                "companyName": "Customer A",
                "total_sales": 15000.50,
            },
            {
                "companyName": "Customer B",
                "total_sales": 12000.25,
            },
        ],
    )

    assert execution.success is True
    assert execution.metadata.row_count == 2

    print("QueryExecutionResult validated successfully.")

    print("\n7. Testing AnalysisResult")

    evidence = EvidenceReference(
        description="Customer A has the highest calculated sales.",
        table_names=[
            "customer",
            "salesorder",
            "orderdetail",
        ],
        columns=[
            "companyName",
            "total_sales",
        ],
        values={
            "companyName": "Customer A",
            "total_sales": 15000.50,
        },
    )

    analysis = AnalysisResult(
        analysis_summary=(
            "Customer A generated the highest total sales in the result set."
        ),
        metrics=[
            MetricResult(
                name="highest_total_sales",
                value=15000.50,
                unit="currency",
                aggregation="sum",
                source_columns=["total_sales"],
                record_count=2,
            )
        ],
        findings=[
            AnalyticalFinding(
                title="Customer A leads total sales",
                finding_type=FindingType.RANKING,
                importance=FindingImportance.HIGH,
                description=(
                    "Customer A has the highest total sales among "
                    "the returned customers."
                ),
                evidence=[evidence],
                confidence=0.95,
            )
        ],
        analyzed_row_count=2,
        source_columns=[
            "companyName",
            "total_sales",
        ],
        sufficient_data=True,
        confidence=0.93,
    )

    assert analysis.sufficient_data is True
    assert len(analysis.findings) == 1

    print("AnalysisResult validated successfully.")

    print("\n8. Testing ReportResult")

    chart = ChartSpecification(
        chart_id="top-customers-bar",
        chart_type=ChartType.BAR,
        title="Top Customers by Total Sales",
        x_column="companyName",
        y_columns=["total_sales"],
        data=execution.records,
        rationale=(
            "A bar chart clearly compares total sales across customers."
        ),
    )

    recommendation = BusinessRecommendation(
        title="Protect high-value customer relationships",
        recommendation=(
            "Review account engagement and retention activity for "
            "the highest-value customers."
        ),
        rationale=(
            "A material portion of observed sales is concentrated among "
            "the leading customers."
        ),
        priority=RecommendationPriority.HIGH,
        timeframe=RecommendationTimeframe.SHORT_TERM,
        supporting_findings=[
            "Customer A leads total sales",
        ],
    )

    report = ReportResult(
        report_title="Top Customer Sales Analysis",
        executive_summary=(
            "The analysis ranked customers by total sales using "
            "Northwind order data."
        ),
        key_findings=[
            KeyFinding(
                title="Customer A ranks first",
                description=(
                    "Customer A has the highest sales in the query result."
                ),
                importance=RecommendationPriority.HIGH,
                supporting_metric="total_sales",
                supporting_value="15000.50",
            )
        ],
        charts=[chart],
        recommendations=[recommendation],
        generated_sql=sql_generation.sql_query,
        assumptions=[
            "Total sales is calculated as unit price multiplied by quantity."
        ],
        grounded=True,
        confidence=0.92,
    )

    assert report.grounded is True
    assert len(report.charts) == 1
    assert len(report.recommendations) == 1

    print("ReportResult validated successfully.")

    print("\n9. Testing user schemas")

    login = LoginRequest(
        username="business.manager",
        password="StrongPassword123",
    )

    user = UserIdentity(
        user_id="user-001",
        username="business.manager",
        display_name="Business Manager",
        role=UserRole.BUSINESS_MANAGER,
        permissions=[
            Permission.NORTHWIND_READ,
            Permission.SCHEMA_READ,
            Permission.ANALYTICS_EXECUTE,
            Permission.REPORTS_READ,
        ],
        allowed_databases=["northwind"],
    )

    assert login.username == "business.manager"
    assert user.role == "business_manager"
    assert "northwind:read" in user.permissions

    print("User schemas validated successfully.")

    print("\n10. Testing JSON serialization")

    complete_flow = {
        "intent": intent.model_dump(mode="json"),
        "plan": plan.model_dump(mode="json"),
        "sql_generation": sql_generation.model_dump(
            mode="json"
        ),
        "sql_validation": validation.model_dump(
            mode="json"
        ),
        "execution": execution.model_dump(mode="json"),
        "analysis": analysis.model_dump(mode="json"),
        "report": report.model_dump(mode="json"),
        "user": user.model_dump(mode="json"),
    }

    assert complete_flow["intent"]["intent"] == "ranking"
    assert complete_flow["report"]["grounded"] is True

    print("All models produced JSON-compatible dictionaries.")

    print(
        "\nPhase 2 structured schemas tested successfully."
    )


if __name__ == "__main__":
    main()