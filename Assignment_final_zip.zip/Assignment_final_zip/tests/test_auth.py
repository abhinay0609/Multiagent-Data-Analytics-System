"""Authentication and explicit RBAC tests.

Run from the project root:

    python -m tests.test_auth
"""

from time import time

from jose import jwt

from auth.authentication import (
    AuthenticationService,
    DuplicateUserError,
    InvalidCredentialsError,
)
from auth.authorization import AuthorizationService
from auth.jwt_handler import (
    InvalidAccessTokenError,
    JWTHandler,
)
from auth.password_manager import PasswordManager
from models.auth_models import ROLE_DEFINITIONS
from schemas.user_schema import (
    AuthorizationRequest,
    Permission,
    UserIdentity,
    UserRole,
    UserStatus,
)


def main() -> None:
    print("=" * 60)
    print("Testing Authentication and Role-Based Authorization")
    print("=" * 60)

    password_manager = PasswordManager()
    password_hash = password_manager.hash_password(
        "Correct-Horse-123!"
    )
    assert password_hash != "Correct-Horse-123!"
    assert password_manager.verify_password(
        "Correct-Horse-123!",
        password_hash,
    )
    assert not password_manager.verify_password(
        "wrong-password",
        password_hash,
    )
    assert not password_manager.verify_password(
        "anything",
        "not-a-password-hash",
    )

    try:
        password_manager.hash_password("short")
    except ValueError:
        pass
    else:
        raise AssertionError("Short password was accepted.")

    print("Password hashing and verification passed.")

    token_handler = JWTHandler(
        secret_key="test-signing-key-that-is-not-used-in-production",
        expires_in_seconds=300,
    )
    authentication = AuthenticationService(
        password_manager_instance=password_manager,
        jwt_handler_instance=token_handler,
    )

    administrator = authentication.register_user(
        username="admin.user",
        password="Admin-Password-123!",
        role=UserRole.ADMINISTRATOR,
        display_name="Administrator",
    )
    business_manager = authentication.register_user(
        username="business.manager",
        password="Manager-Password-123!",
        role=UserRole.BUSINESS_MANAGER,
        display_name="Business Manager",
    )
    employee = authentication.register_user(
        username="employee.user",
        password="Employee-Password-123!",
        role=UserRole.EMPLOYEE,
        display_name="Employee",
    )

    assert set(administrator.permissions) == {
        permission.value
        for permission in ROLE_DEFINITIONS[
            UserRole.ADMINISTRATOR
        ].permissions
    }
    assert set(business_manager.permissions) == {
        permission.value
        for permission in ROLE_DEFINITIONS[
            UserRole.BUSINESS_MANAGER
        ].permissions
    }
    assert employee.permissions == []
    assert employee.allowed_databases == []

    try:
        authentication.register_user(
            username="BUSINESS.MANAGER",
            password="Another-Password-123!",
            role=UserRole.EMPLOYEE,
        )
    except DuplicateUserError:
        pass
    else:
        raise AssertionError("Duplicate username was accepted.")

    print("Role permissions and account provisioning passed.")

    login_response = authentication.login(
        " BUSINESS.MANAGER ",
        "Manager-Password-123!",
    )
    assert login_response.user.username == "business.manager"
    assert login_response.access_token
    assert login_response.expires_in_seconds == 300

    token_payload = token_handler.decode_access_token(
        login_response.access_token
    )
    assert token_payload.sub == business_manager.user_id
    assert token_payload.role == UserRole.BUSINESS_MANAGER.value

    authenticated_user = authentication.authenticate_token(
        login_response.access_token
    )
    assert authenticated_user.user_id == business_manager.user_id
    assert (
        authentication.get_user_by_username("BUSINESS.MANAGER")
        == business_manager
    )
    assert (
        authentication.get_user_by_id(business_manager.user_id)
        == business_manager
    )
    assert (
        authentication.get_user_by_username("missing.user")
        is None
    )

    try:
        authentication.login(
            "business.manager",
            "Wrong-Password-123!",
        )
    except InvalidCredentialsError:
        pass
    else:
        raise AssertionError("Invalid credentials were accepted.")

    altered_parts = login_response.access_token.split(".")
    signature = list(altered_parts[2])
    signature[0] = "A" if signature[0] != "A" else "B"
    altered_parts[2] = "".join(signature)
    try:
        token_handler.decode_access_token(
            ".".join(altered_parts)
        )
    except InvalidAccessTokenError:
        pass
    else:
        raise AssertionError("Altered JWT signature was accepted.")

    now = int(time())
    expired_token = jwt.encode(
        {
            "sub": business_manager.user_id,
            "username": business_manager.username,
            "role": UserRole.BUSINESS_MANAGER.value,
            "permissions": business_manager.permissions,
            "allowed_databases": business_manager.allowed_databases,
            "iat": now - 60,
            "exp": now - 1,
            "jti": "expired-token",
        },
        "test-signing-key-that-is-not-used-in-production",
        algorithm="HS256",
    )
    try:
        token_handler.decode_access_token(expired_token)
    except InvalidAccessTokenError:
        pass
    else:
        raise AssertionError("Expired JWT was accepted.")

    print("Login, user lookup, and signed JWT validation passed.")

    authorization = AuthorizationService()
    assert authorization.authorize(
        administrator,
        Permission.NORTHWIND_READ,
        "northwind",
    ).allowed
    assert authorization.authorize(
        administrator,
        Permission.TRACES_READ,
    ).allowed
    assert authorization.authorize(
        business_manager,
        Permission.NORTHWIND_READ,
        "northwind",
    ).allowed
    assert authorization.authorize(
        administrator,
        Permission.ANALYTICS_EXECUTE,
        "northwind",
    ).allowed
    assert authorization.authorize(
        business_manager,
        Permission.ANALYTICS_EXECUTE,
        "northwind",
    ).allowed
    authorization_request = AuthorizationRequest(
        user=business_manager,
        required_permission=Permission.NORTHWIND_READ,
        database_name="northwind",
    )
    assert authorization.authorize(
        authorization_request.user,
        authorization_request.required_permission,
        authorization_request.database_name,
    ).allowed
    assert authorization.authorize(
        business_manager,
        Permission.SCHEMA_READ,
        "northwind",
    ).allowed
    assert authorization.authorize(
        business_manager,
        Permission.REPORTS_READ,
        "northwind",
    ).allowed
    assert not authorization.authorize(
        business_manager,
        Permission.TRACES_READ,
    ).allowed
    assert not authorization.authorize(
        employee,
        Permission.NORTHWIND_READ,
        "northwind",
    ).allowed
    assert not authorization.authorize(
        employee,
        Permission.ANALYTICS_EXECUTE,
        "northwind",
    ).allowed

    forged_employee = UserIdentity(
        user_id="forged-employee",
        username="forged.employee",
        display_name="Forged Employee",
        role=UserRole.EMPLOYEE,
        permissions=[Permission.NORTHWIND_READ],
        status=UserStatus.ACTIVE,
        allowed_databases=["northwind"],
    )
    assert not authorization.authorize(
        forged_employee,
        Permission.NORTHWIND_READ,
        "northwind",
    ).allowed

    wrong_database = authorization.authorize(
        business_manager,
        Permission.NORTHWIND_READ,
        "other_database",
    )
    assert not wrong_database.allowed

    inactive_user = UserIdentity(
        user_id="inactive-user",
        username="inactive.user",
        display_name="Inactive User",
        role=UserRole.ADMINISTRATOR,
        permissions=[
            Permission.NORTHWIND_READ,
            Permission.SCHEMA_READ,
            Permission.REPORTS_READ,
            Permission.TRACES_READ,
        ],
        status=UserStatus.INACTIVE,
        allowed_databases=["northwind"],
    )
    assert not authorization.authorize(
        inactive_user,
        Permission.NORTHWIND_READ,
        "northwind",
    ).allowed

    print("Administrator, manager, employee, and backend RBAC checks passed.")
    print("\nAuthentication and authorization tested successfully.")


if __name__ == "__main__":
    main()