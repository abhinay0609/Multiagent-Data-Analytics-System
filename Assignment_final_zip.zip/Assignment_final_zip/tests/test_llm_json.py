"""Offline tests for Ollama JSON and JSON-schema output modes.

Run from the project root with:

    python -m tests.test_llm_json
"""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

from services.llm_service import LLMService


class FakeRunnable:
    def __init__(self, response: Any) -> None:
        self.response = response
        self.messages: Any = None

    def invoke(self, messages: Any) -> Any:
        self.messages = messages
        return self.response


class FakeChatOllama:
    def __init__(self) -> None:
        self.output_format: str | None = None
        self.options: dict[str, Any] | None = None
        self.json_response = SimpleNamespace(
            content='{"answer":"valid"}'
        )
        self.schema: dict[str, Any] | None = None
        self.structured_method: str | None = None
        self.structured_response: Any = {
            "raw": None,
            "parsed": {"answer": "valid"},
            "parsing_error": None,
        }
        self.last_runnable: FakeRunnable | None = None

    def with_structured_output(
        self,
        schema: dict[str, Any],
        *,
        method: str,
        include_raw: bool,
    ) -> FakeRunnable:
        assert include_raw is True
        self.schema = schema
        self.structured_method = method
        self.last_runnable = FakeRunnable(self.structured_response)
        return self.last_runnable

    def bind(
        self,
        *,
        format: str,
        options: dict[str, Any],
    ) -> FakeRunnable:
        self.output_format = format
        self.options = options
        self.last_runnable = FakeRunnable(self.json_response)
        return self.last_runnable


def main() -> None:
    fake_client = FakeChatOllama()
    with patch(
        "services.llm_service.ChatOllama",
        return_value=fake_client,
    ):
        service = LLMService(
            model_name="test-model",
            base_url="http://localhost:11434",
        )

    schema = {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
    }
    structured = service.generate_json(
        "Return an answer.",
        output_schema=schema,
    )
    assert structured == {"answer": "valid"}
    assert fake_client.schema == schema
    assert fake_client.structured_method == "json_schema"

    fake_client.structured_response = {
        "raw": None,
        "parsed": None,
        "parsing_error": ValueError("Invalid structured response."),
    }
    try:
        service.generate_json(
            "Return an answer.",
            output_schema=schema,
        )
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid structured output was accepted.")

    generic_json = service.generate_json("Return a JSON object.")
    assert generic_json == {"answer": "valid"}
    assert fake_client.output_format == "json"
    assert fake_client.options == {
        "temperature": 0.1,
        "num_predict": 2048,
    }

    fake_client.json_response = SimpleNamespace(
        content='{"answer":"first","answer":"duplicate"}'
    )
    try:
        service.generate_json("Return a JSON object.")
    except ValueError:
        pass
    else:
        raise AssertionError("Duplicate JSON keys were accepted.")

    fake_client.json_response = SimpleNamespace(content="{invalid")
    try:
        service.generate_json("Return a JSON object.")
    except ValueError:
        pass
    else:
        raise AssertionError("Malformed JSON was accepted.")

    print("Ollama JSON mode and duplicate-key validation passed.")


if __name__ == "__main__":
    main()
