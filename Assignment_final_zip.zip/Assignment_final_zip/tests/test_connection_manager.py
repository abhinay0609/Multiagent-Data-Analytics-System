"""
Integration test for database/connection_manager.py.

Run from the project root using:

    python -m tests.test_connection_manager
"""

from database.connection_manager import (
    UnsafeQueryError,
    connection_manager,
)


def main() -> None:
    print("=" * 60)
    print("Testing MySQL Connection Manager")
    print("=" * 60)

    try:
        print("\n1. Database configuration")
        print(
            f"Backend : {connection_manager.backend_name}"
        )
        print(
            f"Driver  : {connection_manager.driver_name}"
        )
        print(
            f"Database: {connection_manager.database_name}"
        )

        print("\n2. Running health check")
        health = connection_manager.health_check()

        for key, value in health.items():
            print(f"{key}: {value}")

        if health["status"] != "healthy":
            raise RuntimeError(
                f"Health check failed: {health['error']}"
            )

        assert health["connection_ok"] == 1

        print("\n3. Running parameterized query")
        result = connection_manager.execute_read_only(
            """
            SELECT
                :message AS message,
                :number AS number
            """,
            {
                "message": "Database is working",
                "number": 100,
            },
        )

        print(f"Query result: {result}")

        assert len(result) == 1
        assert result[0]["message"] == "Database is working"
        assert result[0]["number"] == 100

        print("\n4. Reading Northwind tables")
        tables = connection_manager.execute_read_only(
            """
            SELECT
                table_name
            FROM information_schema.tables
            WHERE table_schema = :database_name
            ORDER BY table_name
            """,
            {
                "database_name": (
                    connection_manager.database_name
                )
            },
            max_rows=100,
        )

        print(f"Tables found: {len(tables)}")

        for table in tables:
            print(f"- {table['TABLE_NAME']}")

        print("\n5. Testing unsafe-query protection")

        try:
            connection_manager.execute_read_only(
                "DROP TABLE customers"
            )
        except UnsafeQueryError as exc:
            print(
                f"Unsafe query blocked successfully: {exc}"
            )
        else:
            raise AssertionError(
                "Unsafe SQL was not blocked."
            )

        print(
            "\nConnection manager tested successfully."
        )

    finally:
        connection_manager.dispose()


if __name__ == "__main__":
    main()