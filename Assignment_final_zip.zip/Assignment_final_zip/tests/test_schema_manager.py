"""
Integration tests for database/schema_manager.py.

Run from the project root:

    python -m tests.test_schema_manager
"""

from database.schema_manager import (
    SchemaNotFoundError,
    schema_manager,
)


def main() -> None:
    """Run schema manager integration checks."""
    print("=" * 60)
    print("Testing Schema Manager")
    print("=" * 60)

    manager = schema_manager

    try:
        # =================================================
        # Complete schema loading
        # =================================================

        print("\n1. Loading complete database schema")

        schema = manager.get_database_schema(
            database_name="northwind",
            refresh=True,
        )

        print(
            f"Registry name      : {schema['registry_name']}"
        )
        print(
            f"Physical database  : "
            f"{schema['physical_database_name']}"
        )
        print(
            f"Backend            : {schema['backend']}"
        )
        print(
            f"Driver             : {schema['driver']}"
        )
        print(
            f"Read only          : {schema['read_only']}"
        )
        print(
            f"Table count        : {schema['table_count']}"
        )
        print(
            f"Relationship count : "
            f"{schema['relationship_count']}"
        )

        assert schema["registry_name"] == "northwind"
        assert schema["physical_database_name"] == "northwind_db"
        assert schema["backend"] == "mysql"
        assert schema["table_count"] > 0
        assert len(schema["tables"]) == schema["table_count"]

        # =================================================
        # Cache
        # =================================================

        print("\n2. Checking schema cache")

        assert manager.is_cached("northwind")

        cached_schema = manager.get_database_schema(
            "northwind"
        )

        assert cached_schema == schema

        cache_status = manager.cache_status()

        print(f"Cache status: {cache_status}")

        assert "northwind" in cache_status
        assert cache_status["northwind"]["cached"] is True
        assert cache_status["northwind"]["expired"] is False

        # =================================================
        # Tables
        # =================================================

        print("\n3. Listing tables")

        tables = manager.list_tables("northwind")

        print(f"Tables found: {len(tables)}")

        for table in tables:
            print(f"- {table}")

        assert len(tables) > 0

        first_table = tables[0]

        # =================================================
        # Table schema
        # =================================================

        print("\n4. Reading table schema")

        table_schema = manager.get_table_schema(
            table_name=first_table,
            database_name="northwind",
        )

        print(f"Table       : {table_schema['table_name']}")
        print(f"Columns     : {len(table_schema['columns'])}")
        print(
            f"Primary key : "
            f"{table_schema['primary_key']['columns']}"
        )
        print(
            f"Foreign keys: "
            f"{len(table_schema['foreign_keys'])}"
        )

        for column in table_schema["columns"]:
            print(
                f"- {column['name']}: "
                f"{column['type']}, "
                f"nullable={column['nullable']}"
            )

        assert table_schema["table_name"] == first_table
        assert len(table_schema["columns"]) > 0

        first_column = table_schema["columns"][0]["name"]

        # =================================================
        # Existence checks
        # =================================================

        print("\n5. Testing table and column existence")

        assert manager.table_exists(
            table_name=first_table,
            database_name="northwind",
        )

        assert not manager.table_exists(
            table_name="__missing_table__",
            database_name="northwind",
        )

        assert manager.column_exists(
            table_name=first_table,
            column_name=first_column,
            database_name="northwind",
        )

        assert not manager.column_exists(
            table_name=first_table,
            column_name="__missing_column__",
            database_name="northwind",
        )

        print(
            f"Verified table '{first_table}' and "
            f"column '{first_column}'."
        )

        # =================================================
        # Column metadata
        # =================================================

        print("\n6. Reading column metadata")

        column = manager.get_column(
            table_name=first_table,
            column_name=first_column,
            database_name="northwind",
        )

        print(f"Column metadata: {column}")

        assert column["name"] == first_column

        # =================================================
        # Table search
        # =================================================

        print("\n7. Searching tables")

        search_fragment = first_table[:3]

        matched_tables = manager.search_tables(
            search_term=search_fragment,
            database_name="northwind",
        )

        print(
            f"Table search '{search_fragment}': "
            f"{matched_tables}"
        )

        assert first_table in matched_tables

        # =================================================
        # Column search
        # =================================================

        print("\n8. Searching columns")

        column_fragment = first_column[:3]

        matched_columns = manager.search_columns(
            search_term=column_fragment,
            database_name="northwind",
        )

        print(
            f"Column search '{column_fragment}': "
            f"{matched_columns[:10]}"
        )

        assert any(
            match["table_name"] == first_table
            and match["column_name"] == first_column
            for match in matched_columns
        )

        # =================================================
        # Relationships
        # =================================================

        print("\n9. Reading database relationships")

        relationships = manager.get_relationships(
            "northwind"
        )

        print(
            f"Relationships found: {len(relationships)}"
        )

        for relationship in relationships[:10]:
            print(
                f"- {relationship['source_table']}."
                f"{relationship['source_columns']} -> "
                f"{relationship['target_table']}."
                f"{relationship['target_columns']}"
            )

        related_tables = manager.get_related_tables(
            table_name=first_table,
            database_name="northwind",
        )

        print(
            f"Relationships for '{first_table}': "
            f"{len(related_tables)}"
        )

        # =================================================
        # LLM schema context
        # =================================================

        print("\n10. Building LLM schema context")

        selected_tables = tables[: min(3, len(tables))]

        schema_context = manager.build_schema_context(
            database_name="northwind",
            table_names=selected_tables,
            include_relationships=True,
            include_indexes=False,
            max_tables=3,
            max_characters=5000,
        )

        print("-" * 60)
        print(schema_context)
        print("-" * 60)

        assert "Database:" in schema_context
        assert "Tables:" in schema_context
        assert selected_tables[0] in schema_context
        assert len(schema_context) <= 5000

        # =================================================
        # Relevant context
        # =================================================

        print("\n11. Building relevant schema context")

        relevant_context = manager.get_relevant_schema_context(
            search_terms=[
                "customer",
                "order",
            ],
            database_name="northwind",
            max_tables=8,
            max_characters=8000,
        )

        print("-" * 60)
        print(relevant_context)
        print("-" * 60)

        assert "Database:" in relevant_context
        assert "Tables:" in relevant_context
        assert len(relevant_context) <= 8000

        # =================================================
        # Missing table
        # =================================================

        print("\n12. Testing missing-table handling")

        try:
            manager.get_table_schema(
                table_name="__missing_table__",
                database_name="northwind",
            )

        except SchemaNotFoundError as exc:
            print(
                f"Missing table rejected successfully: {exc}"
            )

        else:
            raise AssertionError(
                "Missing table was not rejected."
            )

        # =================================================
        # Cache invalidation
        # =================================================

        print("\n13. Testing cache invalidation")

        removed = manager.invalidate_cache(
            "northwind"
        )

        assert removed is True
        assert not manager.is_cached("northwind")

        reloaded_schema = manager.get_database_schema(
            "northwind"
        )

        assert manager.is_cached("northwind")
        assert (
            reloaded_schema["table_count"]
            == schema["table_count"]
        )

        print(
            "Cache invalidation and reload completed successfully."
        )

        print(
            "\nSchema manager tested successfully."
        )

    finally:
        manager.clear_cache()
        manager.registry.dispose()


if __name__ == "__main__":
    main()