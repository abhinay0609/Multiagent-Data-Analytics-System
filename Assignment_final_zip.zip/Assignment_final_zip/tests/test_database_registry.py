"""
Integration tests for database/database_registry.py.

Run from the project root:

    python -m tests.test_database_registry
"""

from database.database_registry import (
    DatabaseAlreadyRegisteredError,
    DatabaseNotRegisteredError,
    DatabaseRegistryError,
    database_registry,
    initialize_database_registry,
)


def main() -> None:
    """Run database registry integration checks."""
    print("=" * 60)
    print("Testing Database Registry")
    print("=" * 60)

    registry = initialize_database_registry()

    try:
        # =================================================
        # Registry initialization
        # =================================================

        print("\n1. Checking registry initialization")

        print(
            f"Registered databases: {registry.count()}"
        )
        print(
            f"Default database    : {registry.get_default_name()}"
        )

        assert registry.count() >= 1
        assert registry.contains("northwind")
        assert registry.get_default_name() == "northwind"

        # =================================================
        # Registration metadata
        # =================================================

        print("\n2. Listing registered databases")

        registrations = registry.list_databases()

        for registration in registrations:
            print(
                f"- Name: {registration['name']}, "
                f"Database: {registration['database_name']}, "
                f"Backend: {registration['backend']}, "
                f"Driver: {registration['driver']}, "
                f"Read only: {registration['read_only']}, "
                f"Default: {registration['is_default']}"
            )

        northwind_registration = registry.get_registration(
            "northwind"
        )

        assert northwind_registration.database_name == "northwind_db"
        assert northwind_registration.backend == "mysql"
        assert northwind_registration.driver == "pymysql"
        assert northwind_registration.read_only is True
        assert northwind_registration.is_default is True

        # =================================================
        # Health check
        # =================================================

        print("\n3. Running registry health check")

        health = registry.health_check("northwind")

        for key, value in health.items():
            print(f"{key}: {value}")

        if health["status"] != "healthy":
            raise RuntimeError(
                f"Database health check failed: "
                f"{health.get('error')}"
            )

        assert health["connection_ok"] == 1
        assert health["registry_name"] == "northwind"

        # =================================================
        # Table discovery
        # =================================================

        print("\n4. Listing database tables")

        tables = registry.list_tables("northwind")

        print(f"Tables found: {len(tables)}")

        for table in tables:
            print(f"- {table}")

        if not tables:
            raise AssertionError(
                "No tables were found in northwind_db."
            )

        # =================================================
        # Table-existence checks
        # =================================================

        print("\n5. Testing table existence")

        first_table = tables[0]

        assert registry.table_exists(
            table_name=first_table,
            database_name="northwind",
        )

        assert not registry.table_exists(
            table_name="__table_that_does_not_exist__",
            database_name="northwind",
        )

        print(f"Verified existing table: {first_table}")

        # =================================================
        # Schema inspection
        # =================================================

        print("\n6. Inspecting table schema")

        schema = registry.get_table_schema(
            table_name=first_table,
            database_name="northwind",
        )

        print(f"Table       : {schema['table_name']}")
        print(f"Columns     : {len(schema['columns'])}")
        print(
            f"Primary key : "
            f"{schema['primary_key']['columns']}"
        )
        print(
            f"Foreign keys: {len(schema['foreign_keys'])}"
        )
        print(f"Indexes     : {len(schema['indexes'])}")

        for column in schema["columns"]:
            print(
                f"- {column['name']}: "
                f"{column['type']}, "
                f"nullable={column['nullable']}"
            )

        assert schema["table_name"] == first_table
        assert len(schema["columns"]) > 0

        # =================================================
        # Read-only execution
        # =================================================

        print("\n7. Executing a read-only query")

        result = registry.execute_read_only(
            query=(
                "SELECT "
                ":message AS message, "
                ":value AS value"
            ),
            parameters={
                "message": "Registry is working",
                "value": 100,
            },
            database_name="northwind",
        )

        print(f"Result: {result}")

        assert len(result) == 1
        assert result[0]["message"] == "Registry is working"
        assert result[0]["value"] == 100

        # =================================================
        # Read-only enforcement
        # =================================================

        print("\n8. Checking read-only enforcement")

        try:
            registry.execute_trusted(
                query=(
                    "DELETE FROM customers "
                    "WHERE 1 = 0"
                ),
                database_name="northwind",
            )

        except DatabaseRegistryError as exc:
            print(
                f"Trusted write blocked successfully: {exc}"
            )

        else:
            raise AssertionError(
                "Trusted write execution was not blocked."
            )

        # =================================================
        # Unknown database handling
        # =================================================

        print("\n9. Checking unknown database handling")

        try:
            registry.get("unknown_database")

        except DatabaseNotRegisteredError as exc:
            print(
                f"Unknown database rejected successfully: {exc}"
            )

        else:
            raise AssertionError(
                "Unknown database was not rejected."
            )

        # =================================================
        # Duplicate registration handling
        # =================================================

        print("\n10. Checking duplicate registration")

        existing_manager = registry.get("northwind")

        try:
            registry.register(
                name="northwind",
                connection_manager=existing_manager,
            )

        except DatabaseAlreadyRegisteredError as exc:
            print(
                f"Duplicate registration blocked successfully: {exc}"
            )

        else:
            raise AssertionError(
                "Duplicate registration was not rejected."
            )

        # =================================================
        # Database summary
        # =================================================

        print("\n11. Generating database summary")

        summary = registry.get_database_summary(
            "northwind"
        )

        print(
            f"Registry name: "
            f"{summary['registration']['name']}"
        )
        print(
            f"Database name: "
            f"{summary['registration']['database_name']}"
        )
        print(
            f"Table count  : {summary['table_count']}"
        )

        assert (
            summary["registration"]["name"]
            == "northwind"
        )
        assert summary["table_count"] == len(tables)
        assert summary["tables"] == tables

        # =================================================
        # Health check for all databases
        # =================================================

        print("\n12. Running all registry health checks")

        all_health = registry.health_check_all()

        assert "northwind" in all_health
        assert all_health["northwind"]["status"] == "healthy"

        print(
            f"Health checks completed: "
            f"{list(all_health.keys())}"
        )

        print(
            "\nDatabase registry tested successfully."
        )

    finally:
        registry.dispose()


if __name__ == "__main__":
    main()