# tests/test_llm_service.py

from services.llm_service import LLMService


def main() -> None:
    print("=" * 60)
    print("Testing Ollama LLM Service")
    print("=" * 60)

    llm_service = LLMService()

    print(f"Model    : {llm_service.model_name}")
    print(f"Base URL : {llm_service.base_url}")

    print("\n1. Running health check...")

    health = llm_service.health_check()

    for key, value in health.items():
        print(f"{key}: {value}")

    if health["status"] != "healthy":
        raise RuntimeError(
            f"Ollama health check failed: {health.get('error')}"
        )

    print("\n2. Testing normal text generation...")

    response = llm_service.generate(
        prompt=(
            "In one sentence, explain the purpose of "
            "a data analytics agent."
        ),
        system_prompt=(
            "You are an AI assistant in a multi-agent "
            "data analytics system."
        ),
    )

    print("Response:")
    print(response)

    print("\n3. Testing structured JSON generation...")

    json_response = llm_service.generate_json(
        prompt=(
            "Return an object containing the keys "
            "'intent', 'dataset_required', and 'confidence'. "
            "The user request is: Analyze monthly sales trends."
        ),
        system_prompt=(
            "You classify requests for a data analytics system."
        ),
    )

    print("JSON response:")
    print(json_response)

    print("\nLLM service test completed successfully.")


if __name__ == "__main__":
    main()