# tests/test_settings.py

from config.settings import settings

print("App:", settings.APP_NAME)

print(
    "Model:",
    settings.OLLAMA_MODEL
)

print(
    "Ollama URL:",
    settings.OLLAMA_BASE_URL
)

print(
    "DB String:",
    settings.MYSQL_CONNECTION_STRING
)

settings.validate()

print("\n✅ Settings loaded successfully")