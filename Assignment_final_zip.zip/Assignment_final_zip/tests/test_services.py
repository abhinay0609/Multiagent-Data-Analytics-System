"""Offline tests for schema, analytics, and report services.

Run from the project root with:

    python -m tests.test_services
"""

from __future__ import annotations

from typing import Any, Mapping

from auth.authorization import AuthorizationService
from graph.state import AnalyticsState
from schemas.report_schema import ReportResult
from schemas.user_schema import Permission, UserIdentity, UserRole
from services.analytics_service import (
    AnalyticsAuthenticationError,
    AnalyticsService,
)
from services.report_service import (
    ReportService,
    ReportUnavailableError,
)
from services.schema_service import (
    SchemaAccessDeniedError,
    SchemaService,
)


class FakeAuthentication:
    def __init__(self, identity: UserIdentity | None) -> None:
        self.identity = identity

    def get_user_by_username(self, username: str) -> UserIdentity | None:
        if (
            self.identity is not None
            and self.identity.username == username.casefold()
        ):
            return self.identity
        return None


class FakeRegistry:
    def __init__(self, registered: bool = True) -> None:
        self.registered = registered

    def contains(self, name: str) -> bool:
        return self.registered and name == "northwind"


class FakeSchemaManager:
    def __init__(self) -> None:
        self.schema = {
            "registry_name": "northwind",
            "physical_database_name": "northwind_db",
            "table_names": ["salesorder"],
            "tables": {
                "salesorder": {
                    "columns": [{"name": "sales", "type": "DECIMAL"}]
                }
            },
        }

    def get_database_schema(self, database_name: str | None = None):
        return self.schema

    def list_tables(self, database_name: str | None = None):
        return list(self.schema["table_names"])

    def get_table_schema(
        self,
        table_name: str,
        database_name: str | None = None,
    ):
        return self.schema["tables"][table_name]

    def build_schema_context(
        self,
        database_name: str | None = None,
        **kwargs: Any,
    ):
        return "TABLE salesorder\n- sales: DECIMAL"


class FakeWorkflow:
    def __init__(self, *, approved: bool = True) -> None:
        self.input_state: AnalyticsState | None = None
        self.approved = approved

    def invoke(self, input: Mapping[str, Any], config: Any = None, **kwargs: Any):
        self.input_state = dict(input)
        report = ReportResult(
            report_title="Sales report",
            executive_summary="Sales results were reviewed.",
            grounded=True,
            confidence=0.9,
        ).model_dump(mode="json")
        report["generated_sql"] = "SELECT private_internal_column"
        return {
            **input,
            "status": "completed",
            "next_node": "end",
            "final_answer": "Sales report\n\nSales results were reviewed.",
            "report_result": report,
            "execution_result": {
                "success": True,
                "metadata": {"row_count": 1},
                "records": [{"customer": "Example", "revenue": 15}],
            },
            "analysis_result": {"sufficient_data": True},
            "chart_specifications": [
                {
                    "chart_id": "revenue-by-customer",
                    "chart_type": "bar",
                    "title": "Revenue by customer",
                    "x_column": "customer",
                    "y_columns": ["revenue"],
                    "rationale": "Compare customer revenue.",
                }
            ],
            "visualization_data": [
                {"customer": "Example", "revenue": 10}
            ],
            "output_guardrail_result": {
                "approved": self.approved,
                "grounded": self.approved,
                "issues": [],
            },
        }


def _identity(role: UserRole = UserRole.BUSINESS_MANAGER) -> UserIdentity:
    permissions = (
        [Permission.NORTHWIND_READ, Permission.SCHEMA_READ]
        if role == UserRole.BUSINESS_MANAGER
        else []
    )
    return UserIdentity(
        user_id="service-user",
        username=(
            "rahul" if role == UserRole.BUSINESS_MANAGER else "employee"
        ),
        display_name="Test User",
        role=role,
        permissions=permissions,
        allowed_databases=(
            ["northwind"] if role == UserRole.BUSINESS_MANAGER else []
        ),
    )


def main() -> None:
    print("=" * 60)
    print("Testing Phase 12 Services")
    print("=" * 60)

    identity = _identity()
    schema_manager = FakeSchemaManager()
    schema_service = SchemaService(
        registry=FakeRegistry(),  # type: ignore[arg-type]
        schema_manager=schema_manager,  # type: ignore[arg-type]
        authentication=FakeAuthentication(identity),  # type: ignore[arg-type]
        authorization=AuthorizationService(),
    )
    tables = schema_service.list_tables("rahul")
    assert tables == ["salesorder"]
    table_schema = schema_service.get_table_schema(
        "rahul",
        "salesorder",
    )
    assert table_schema["columns"][0]["name"] == "sales"
    table_schema["columns"].clear()
    assert schema_manager.schema["tables"]["salesorder"]["columns"]
    assert "TABLE salesorder" in schema_service.build_schema_context("rahul")

    denied_service = SchemaService(
        registry=FakeRegistry(),  # type: ignore[arg-type]
        schema_manager=FakeSchemaManager(),  # type: ignore[arg-type]
        authentication=FakeAuthentication(_identity(UserRole.EMPLOYEE)),  # type: ignore[arg-type]
        authorization=AuthorizationService(),
    )
    try:
        denied_service.list_tables("employee")
    except SchemaAccessDeniedError:
        pass
    else:
        raise AssertionError("Employee schema access should be denied.")

    workflow = FakeWorkflow()
    analytics = AnalyticsService(
        workflow,  # type: ignore[arg-type]
        authentication=FakeAuthentication(identity),  # type: ignore[arg-type]
    )
    result = analytics.analyze(
        user_question="Show the top five customers by revenue.",
        username="rahul",
        database_name="northwind",
    )
    assert result.status == "completed"
    assert result.database_name == "northwind"
    assert workflow.input_state is not None
    assert workflow.input_state["user_id"] == identity.user_id
    assert result.report is not None
    assert "generated_sql" not in result.report
    assert "query_results" not in result.model_dump()
    assert result.chart_specifications[0]["chart_id"] == (
        "revenue-by-customer"
    )
    assert result.visualization_data == [
        {"customer": "Example", "revenue": 10}
    ]
    assert result.query_executed is True
    assert result.row_count == 1
    assert result.result_rows == 1
    assert result.execution_error is None
    assert result.sufficient_data is True
    assert result.grounded is True

    rejected_result = AnalyticsService(
        FakeWorkflow(approved=False),  # type: ignore[arg-type]
        authentication=FakeAuthentication(identity),  # type: ignore[arg-type]
    ).analyze("Show sales.", "rahul")
    assert rejected_result.final_answer is None
    assert rejected_result.report is None
    assert rejected_result.chart_specifications == []
    assert rejected_result.visualization_data == []
    assert rejected_result.query_executed is True
    assert rejected_result.row_count == 1
    assert rejected_result.grounded is False

    guardrail_failure = AnalyticsService._public_result(
        {
            "request_id": "guardrail-failure",
            "status": "failed",
            "database_name": "northwind",
            "current_agent": "output_guardrail",
            "output_guardrail_result": {
                "approved": False,
                "grounded": False,
                "issues": [
                    "UNSUPPORTED_NUMBER: A value was not grounded."
                ],
            },
            "errors": [
                {
                    "category": "validation",
                    "message": "The response did not pass final safety validation.",
                    "recoverable": False,
                }
            ],
        }
    )
    assert guardrail_failure.errors[0]["diagnostic_codes"] == [
        "UNSUPPORTED_NUMBER"
    ]

    try:
        AnalyticsService(
            workflow,  # type: ignore[arg-type]
            authentication=FakeAuthentication(None),  # type: ignore[arg-type]
        ).analyze("Show sales.", "unknown")
    except AnalyticsAuthenticationError:
        pass
    else:
        raise AssertionError("Unknown usernames should be rejected.")

    reports = ReportService()
    report = reports.get_report(result)
    assert report.report_title == "Sales report"
    assert report.generated_sql is None
    assert reports.format_report(result) == result.final_answer
    assert reports.format_report(result.model_dump()) == result.final_answer
    try:
        reports.get_report({"status": "requires_clarification"})
    except ReportUnavailableError:
        pass
    else:
        raise AssertionError("A missing report should be reported.")

    print("Authorized schema access, analytics invocation,")
    print("safe result shaping, and report retrieval passed.")


if __name__ == "__main__":
    main()
