"""Contract checks for the five agent prompt templates.

Run from the project root with:

    python -m tests.test_prompts
"""

import json
from pathlib import Path
from typing import Type

from pydantic import BaseModel

from schemas.intent_schema import IntentResult
from schemas.plan_schema import AnalysisPlan
from schemas.report_schema import ReportResult


PROMPTS_DIR = Path(__file__).resolve().parents[1] / "prompts"
STRUCTURED_PROMPTS: dict[str, Type[BaseModel]] = {
    "intent_prompt.txt": IntentResult,
    "planning_prompt.txt": AnalysisPlan,
    "reporting_prompt.txt": ReportResult,
}
REQUIRED_SECTIONS = (
    "ROLE",
    "ALLOWED RESPONSIBILITIES",
    "REQUIRED INPUT",
    "CONSTRAINTS",
    "FAILURE BEHAVIOR",
    "EXAMPLES",
)


def _read_prompt(filename: str) -> str:
    prompt = (PROMPTS_DIR / filename).read_text(encoding="utf-8")
    assert prompt.strip(), f"{filename} must not be empty."
    for section in REQUIRED_SECTIONS:
        assert section in prompt, f"{filename} is missing {section}."
    assert (
        "EXPECTED OUTPUT" in prompt
        or "EXPECTED STRUCTURED OUTPUT" in prompt
    ), f"{filename} must define its output."
    assert "fabricat" in prompt.lower(), (
        f"{filename} must prohibit fabricated information."
    )
    return prompt


def main() -> None:
    for filename, model in STRUCTURED_PROMPTS.items():
        prompt = _read_prompt(filename)
        examples = [
            json.loads(line)
            for line in prompt.splitlines()
            if line.strip().startswith("{") and line.strip().endswith("}")
        ]
        assert len(examples) >= 1, (
            f"{filename} must include at least one JSON example."
        )
        for example in examples:
            model.model_validate(example)

    sql_prompt = _read_prompt("sql_prompt.txt")
    assert "Output exactly one MySQL SELECT or read-only WITH query" in sql_prompt
    assert "does not validate or execute the query" in sql_prompt
    assert "return an empty response" in sql_prompt
    assert "SELECT c.companyName" in sql_prompt

    analysis_prompt = _read_prompt("analysis_prompt.txt")
    analysis_fields = {
        "analysis_summary",
        "assumptions",
        "limitations",
        "warnings",
    }
    analysis_examples = [
        json.loads(line)
        for line in analysis_prompt.splitlines()
        if line.strip().startswith("{") and line.strip().endswith("}")
    ]
    assert len(analysis_examples) == 2
    for example in analysis_examples:
        assert set(example) == analysis_fields
    assert "Pandas and NumPy" in analysis_prompt
    assert "Do not perform arithmetic" in analysis_prompt

    print("All five prompt templates satisfy their content and schema contracts.")


if __name__ == "__main__":
    main()
