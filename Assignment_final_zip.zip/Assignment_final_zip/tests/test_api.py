"""Offline tests for FastAPI authentication, analytics, reports, and health.

Run from the project root with:

    python -m tests.test_api
"""

from __future__ import annotations

from typing import Any

from fastapi.testclient import TestClient

from app.dependencies import AppDependencies, ReportStore
from app.main import create_app
from app.startup import provision_bootstrap_admin
from auth.authentication import AuthenticationService
from auth.authorization import AuthorizationService
from auth.jwt_handler import JWTHandler
from auth.password_manager import PasswordManager
from schemas.report_schema import ChartSpecification, ChartType, ReportResult
from schemas.user_schema import UserRole
from services.report_service import ReportService
from services.analytics_service import AnalyticsServiceResult


class FakeAnalyticsService:
    def __init__(self) -> None:
        report = ReportResult(
            report_title="Revenue report",
            executive_summary="Revenue results were reviewed.",
            charts=[
                ChartSpecification(
                    chart_id="revenue-by-customer",
                    chart_type=ChartType.BAR,
                    title="Revenue by customer",
                    x_column="customer",
                    y_columns=["revenue"],
                    data=[
                        {"customer": "Example", "revenue": 15}
                    ],
                    rationale="Compare customer revenue.",
                )
            ],
            grounded=True,
        )
        self.result = AnalyticsServiceResult(
            request_id="request-123",
            status="completed",
            database_name="northwind",
            final_answer="Revenue report is ready.",
            report=report.model_dump(mode="json"),
            chart_specifications=[
                {
                    "chart_id": "revenue-by-customer",
                    "chart_type": "bar",
                    "title": "Revenue by customer",
                    "x_column": "customer",
                    "y_columns": ["revenue"],
                    "rationale": "Compare customer revenue.",
                }
            ],
            visualization_data=[
                {"customer": "Example", "revenue": 15}
            ],
            errors=[],
            retry_count=0,
            requires_human_approval=False,
            grounded=True,
        )
        self.last_username: str | None = None
        self.last_question: str | None = None
        self.last_database_name: str | None = None
        self.last_max_retries: int | None = None

    def analyze(
        self,
        user_question: str,
        username: str,
        database_name: str,
        *,
        max_retries: int,
    ) -> AnalyticsServiceResult:
        self.last_username = username
        self.last_question = user_question
        self.last_database_name = database_name
        self.last_max_retries = max_retries
        return self.result


class FakeRegistry:
    def __init__(self, healthy: bool = True) -> None:
        self.healthy = healthy

    def health_check_all(self) -> dict[str, dict[str, Any]]:
        return {
            "northwind": {
                "status": "healthy" if self.healthy else "unhealthy",
                "database": "northwind_db",
                "backend": "mysql",
                "host": "internal-host",
            }
        }

    def dispose(self) -> None:
        return None


class FakeLLM:
    model_name = "test-model"

    def __init__(self, healthy: bool = True) -> None:
        self.healthy = healthy

    def health_check(self) -> dict[str, Any]:
        return {
            "status": "healthy" if self.healthy else "unhealthy",
            "provider": "ollama",
            "model": self.model_name,
            "base_url": "http://internal-host:11434",
            "response": "OK",
        }


def main() -> None:
    authentication = AuthenticationService(
        password_manager_instance=PasswordManager(),
        jwt_handler_instance=JWTHandler(
            secret_key="test-signing-key-for-api-tests-only",
            expires_in_seconds=300,
        ),
    )
    manager = authentication.register_user(
        "business.manager",
        "Manager-Password-123!",
        UserRole.BUSINESS_MANAGER,
    )
    authentication.register_user(
        "employee.user",
        "Employee-Password-123!",
        UserRole.EMPLOYEE,
    )
    authentication.register_user(
        "other.manager",
        "Other-Manager-123!",
        UserRole.BUSINESS_MANAGER,
    )
    analytics = FakeAnalyticsService()
    dependencies = AppDependencies(
        authentication=authentication,
        authorization=AuthorizationService(),
        analytics=analytics,  # type: ignore[arg-type]
        reports=ReportService(),
        llm=FakeLLM(),  # type: ignore[arg-type]
        registry=FakeRegistry(),  # type: ignore[arg-type]
        report_store=ReportStore(),
    )

    bootstrap_authentication = AuthenticationService(
        password_manager_instance=PasswordManager(),
        jwt_handler_instance=JWTHandler(
            secret_key="test-bootstrap-key-for-api-tests-only",
            expires_in_seconds=300,
        ),
    )
    bootstrap_dependencies = AppDependencies(
        authentication=bootstrap_authentication,
        authorization=AuthorizationService(),
        analytics=analytics,  # type: ignore[arg-type]
        reports=ReportService(),
        llm=FakeLLM(),  # type: ignore[arg-type]
        registry=FakeRegistry(),  # type: ignore[arg-type]
    )
    provision_bootstrap_admin(
        bootstrap_dependencies,
        username="bootstrap.admin",
        password="Bootstrap-Admin-123!",
        display_name="Bootstrap Administrator",
    )
    bootstrap_identity = bootstrap_authentication.get_user_by_username(
        "bootstrap.admin"
    )
    assert bootstrap_identity is not None
    assert bootstrap_identity.role == UserRole.ADMINISTRATOR

    with TestClient(create_app(dependencies)) as client:
        health = client.get("/health")
        assert health.status_code == 200
        assert health.json() == {"status": "healthy"}

        database_health = client.get("/health/database")
        assert database_health.status_code == 200
        assert database_health.json()["status"] == "healthy"
        assert (
            database_health.json()["databases"]["northwind"] == "healthy"
        )
        assert "host" not in database_health.text
        assert "northwind_db" not in database_health.text

        llm_health = client.get("/health/llm")
        assert llm_health.status_code == 200
        assert llm_health.json() == {
            "status": "healthy",
            "provider": "ollama",
            "model": "test-model",
        }

        invalid_login = client.post(
            "/api/auth/login",
            json={
                "username": "business.manager",
                "password": "Wrong-Password-123!",
            },
        )
        assert invalid_login.status_code == 401, invalid_login.text

        login = client.post(
            "/api/auth/login",
            json={
                "username": "business.manager",
                "password": "Manager-Password-123!",
            },
        )
        assert login.status_code == 200
        token = login.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}

        missing_token = client.post(
            "/api/analytics/query",
            json={"question": "Show revenue."},
        )
        assert missing_token.status_code == 401
        invalid_token = client.post(
            "/api/analytics/query",
            headers={"Authorization": "Bearer invalid.token.value"},
            json={"question": "Show revenue."},
        )
        assert invalid_token.status_code == 401

        query = client.post(
            "/api/analytics/query",
            headers=headers,
            json={"question": "Show revenue."},
        )
        assert query.status_code == 200, query.text
        assert analytics.last_username == manager.username
        assert analytics.last_question == "Show revenue."
        assert analytics.last_database_name == "northwind"
        assert analytics.last_max_retries == 2
        assert query.json()["request_id"] == "request-123"

        report = client.get(
            "/api/reports/request-123",
            headers=headers,
        )
        assert report.status_code == 200
        report_payload = report.json()
        assert report_payload["report"]["report_title"] == "Revenue report"
        assert report_payload["report"]["charts"][0]["data"] == []
        assert report_payload["visualization_data"] == [
            {"customer": "Example", "revenue": 15}
        ]

        employee_login = client.post(
            "/api/auth/login",
            json={
                "username": "employee.user",
                "password": "Employee-Password-123!",
            },
        )
        employee_headers = {
            "Authorization": (
                f"Bearer {employee_login.json()['access_token']}"
            )
        }
        denied_query = client.post(
            "/api/analytics/query",
            headers=employee_headers,
            json={"question": "Show revenue."},
        )
        assert denied_query.status_code == 403
        hidden_report = client.get(
            "/api/reports/request-123",
            headers=employee_headers,
        )
        assert hidden_report.status_code == 404

        other_login = client.post(
            "/api/auth/login",
            json={
                "username": "other.manager",
                "password": "Other-Manager-123!",
            },
        )
        other_headers = {
            "Authorization": f"Bearer {other_login.json()['access_token']}"
        }
        other_report = client.get(
            "/api/reports/request-123",
            headers=other_headers,
        )
        assert other_report.status_code == 404

        analytics.result = analytics.result.model_copy(
            update={
                "status": "failed",
                "final_answer": None,
                "errors": [
                    {
                        "category": "llm",
                        "message": "The planning response could not be validated.",
                        "recoverable": False,
                    }
                ],
            }
        )
        failed_query = client.post(
            "/api/analytics/query",
            headers=headers,
            json={"question": "Show revenue."},
        )
        assert failed_query.status_code == 502
        assert failed_query.json()["detail"]["errors"][0]["category"] == "llm"

    unhealthy_dependencies = AppDependencies(
        authentication=authentication,
        authorization=AuthorizationService(),
        analytics=analytics,  # type: ignore[arg-type]
        reports=ReportService(),
        llm=FakeLLM(healthy=False),  # type: ignore[arg-type]
        registry=FakeRegistry(healthy=False),  # type: ignore[arg-type]
    )
    with TestClient(create_app(unhealthy_dependencies)) as client:
        assert client.get("/health/database").status_code == 503
        assert client.get("/health/llm").status_code == 503

    print("Login/JWT, RBAC, analytics, report ownership, and health passed.")


if __name__ == "__main__":
    main()
