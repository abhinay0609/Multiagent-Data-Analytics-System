"""
Integration tests for the Phase 4 database execution layer.

Run from the project root:

    python -m tests.test_query_executor
"""

from datetime import date, datetime, time, timezone
from decimal import Decimal

from sqlalchemy.exc import OperationalError, ProgrammingError

from database.connection_manager import DatabaseQueryError
from database.mysql_engine import (
    check_mysql_health,
    get_connection_manager,
    get_mysql_engine,
)
from database.query_executor import (
    InvalidValidatedQueryError,
    QueryAuthorizationError,
    QueryExecutor,
    ResultNormalizationError,
)
from schemas.user_schema import (
    Permission,
    UserIdentity,
    UserRole,
    UserStatus,
)
from sql_security.sql_validator import (
    SQLValidator,
)


def main() -> None:
    """Run Phase 4 database execution tests."""
    print("=" * 60)
    print("Testing Phase 4 Database Execution Layer")
    print("=" * 60)

    print("\n0. Classifying recoverable execution errors")

    transient_error = DatabaseQueryError(
        "Wrapped database error."
    )
    transient_error.__cause__ = OperationalError(
        "SELECT 1",
        {},
        TimeoutError("connection timeout"),
    )
    permanent_error = DatabaseQueryError(
        "Wrapped database error."
    )
    permanent_error.__cause__ = ProgrammingError(
        "SELECT 1",
        {},
        Exception("invalid SQL"),
    )

    assert QueryExecutor._is_retryable_error(transient_error) is True
    assert QueryExecutor._is_retryable_error(permanent_error) is False
    print("Transient failures retry; permanent failures do not.")

    print("\n1. Testing MySQL compatibility helpers")

    connection_manager = get_connection_manager(
        "northwind"
    )
    engine = get_mysql_engine(
        "northwind"
    )

    assert engine is connection_manager.engine

    health = check_mysql_health(
        "northwind"
    )

    for key, value in health.items():
        print(f"{key}: {value}")

    assert health["status"] == "healthy"
    assert health["connection_ok"] == 1

    print(
        "MySQL helpers reuse the registered "
        "ConnectionManager successfully."
    )

    print("\n2. Creating authorized test user")

    authorized_user = UserIdentity(
        user_id="user-001",
        username="business.manager",
        display_name="Business Manager",
        role=UserRole.BUSINESS_MANAGER,
        permissions=[
            Permission.NORTHWIND_READ,
            Permission.SCHEMA_READ,
            Permission.ANALYTICS_EXECUTE,
            Permission.REPORTS_READ,
        ],
        status=UserStatus.ACTIVE,
        allowed_databases=[
            "northwind",
        ],
    )

    assert (
        Permission.NORTHWIND_READ.value
        in {
            str(permission)
            for permission
            in authorized_user.permissions
        }
        or "northwind:read"
        in {
            str(permission)
            for permission
            in authorized_user.permissions
        }
    )

    print(
        f"Authorized user: "
        f"{authorized_user.username}"
    )

    print("\n3. Creating QueryExecutor")

    executor = QueryExecutor(
        default_database_name="northwind",
        max_rows=100,
        query_timeout_seconds=30,
        binary_encoding="base64",
    )

    authorization = executor.authorize(
        user=authorized_user,
        database_name="northwind",
    )

    print(
        f"Authorization allowed: "
        f"{authorization.allowed}"
    )
    print(
        f"Authorization reason : "
        f"{authorization.reason}"
    )

    assert authorization.allowed is True
    assert (
        authorization.required_permission
        == "northwind:read"
    )

    print("\n4. Validating SQL before execution")

    validator = SQLValidator(
        database_name="northwind"
    )

    validation_result = validator.validate(
        """
        SELECT
            custId,
            companyName,
            country
        FROM customer
        ORDER BY custId
        LIMIT 5
        """
    )

    print(
        f"Validation status : "
        f"{validation_result.status}"
    )
    print(
        f"Executable SQL   : "
        f"{validation_result.executable_sql}"
    )

    assert (
        str(validation_result.status)
        == "valid"
    )
    assert validation_result.executable_sql is not None
    assert validation_result.security_valid is True
    assert validation_result.schema_valid is True
    assert validation_result.read_only is True

    print("\n5. Executing validated query")

    execution_result = executor.execute(
        validation_result=validation_result,
        user=authorized_user,
        database_name="northwind",
    )

    print(
        f"Success           : "
        f"{execution_result.success}"
    )
    print(
        f"Rows              : "
        f"{execution_result.metadata.row_count}"
    )
    print(
        f"Columns           : "
        f"{execution_result.metadata.columns}"
    )
    print(
        f"Execution time ms : "
        f"{execution_result.metadata.execution_time_ms}"
    )
    print(
        f"Truncated         : "
        f"{execution_result.metadata.truncated}"
    )

    for record in execution_result.records:
        print(record)

    assert execution_result.success is True
    assert (
        execution_result.metadata.database_name
        == "northwind"
    )
    assert (
        execution_result.metadata.row_count
        == len(execution_result.records)
    )
    assert execution_result.metadata.row_count <= 5
    assert "custId" in (
        execution_result.metadata.columns
    )
    assert "companyName" in (
        execution_result.metadata.columns
    )
    assert execution_result.error_message is None

    print(
        "Validated query executed successfully."
    )

    print("\n6. Testing stricter execution row limit")

    larger_validation = validator.validate(
        """
        SELECT
            custId,
            companyName
        FROM customer
        ORDER BY custId
        LIMIT 20
        """
    )

    limited_result = executor.execute(
        validation_result=larger_validation,
        user=authorized_user,
        max_rows=3,
    )

    print(
        f"Rows returned with max_rows=3: "
        f"{limited_result.metadata.row_count}"
    )

    assert limited_result.success is True
    assert limited_result.metadata.row_count <= 3

    print(
        "Runtime row limit enforced successfully."
    )

    print("\n7. Testing Decimal normalization")

    decimal_record = executor.normalize_records(
        [
            {
                "whole_decimal": Decimal("100"),
                "fractional_decimal": (
                    Decimal("123.45")
                ),
            }
        ]
    )

    assert (
        decimal_record[0]["whole_decimal"]
        == 100
    )
    assert (
        decimal_record[0]["fractional_decimal"]
        == 123.45
    )

    print(decimal_record)

    print("\n8. Testing date and time normalization")

    temporal_record = executor.normalize_records(
        [
            {
                "date_value": date(
                    2026,
                    11,
                    17,
                ),
                "datetime_value": datetime(
                    2026,
                    11,
                    17,
                    10,
                    30,
                    0,
                    tzinfo=timezone.utc,
                ),
                "time_value": time(
                    10,
                    30,
                    0,
                ),
            }
        ]
    )

    assert (
        temporal_record[0]["date_value"]
        == "2026-11-17"
    )
    assert (
        temporal_record[0]["datetime_value"]
        == "2026-11-17T10:30:00+00:00"
    )
    assert (
        temporal_record[0]["time_value"]
        == "10:30:00"
    )

    print(temporal_record)

    print("\n9. Testing binary normalization")

    binary_record = executor.normalize_records(
        [
            {
                "binary_value": b"northwind",
            }
        ]
    )

    binary_output = (
        binary_record[0]["binary_value"]
    )

    assert binary_output["encoding"] == "base64"
    assert binary_output["size_bytes"] == 9
    assert isinstance(
        binary_output["data"],
        str,
    )

    print(binary_record)

    print("\n10. Testing non-finite number handling")

    numeric_record = executor.normalize_records(
        [
            {
                "nan_value": float("nan"),
                "positive_infinity": float("inf"),
                "negative_infinity": float("-inf"),
            }
        ]
    )

    assert numeric_record[0]["nan_value"] is None
    assert (
        numeric_record[0]["positive_infinity"]
        is None
    )
    assert (
        numeric_record[0]["negative_infinity"]
        is None
    )

    print(numeric_record)

    print("\n11. Rejecting unvalidated SQL")

    invalid_validation = validator.validate(
        """
        SELECT unknownColumn
        FROM customer
        """
    )

    try:
        executor.execute(
            validation_result=invalid_validation,
            user=authorized_user,
        )

    except InvalidValidatedQueryError as exc:
        print(
            f"Invalid SQL rejected successfully: "
            f"{exc}"
        )

    else:
        raise AssertionError(
            "Invalid SQL was executed."
        )

    print("\n12. Rejecting unauthorized user")

    unauthorized_user = UserIdentity(
        user_id="user-002",
        username="employee.user",
        display_name="Employee User",
        role=UserRole.EMPLOYEE,
        permissions=[],
        status=UserStatus.ACTIVE,
        allowed_databases=[],
    )

    try:
        executor.execute(
            validation_result=validation_result,
            user=unauthorized_user,
            database_name="northwind",
        )

    except QueryAuthorizationError as exc:
        print(
            f"Unauthorized user rejected successfully: "
            f"{exc}"
        )

    else:
        raise AssertionError(
            "Unauthorized user was allowed "
            "to execute SQL."
        )

    print("\n13. Rejecting missing permission")

    missing_permission_user = UserIdentity(
        user_id="user-003",
        username="limited.manager",
        display_name="Limited Manager",
        role=UserRole.BUSINESS_MANAGER,
        permissions=[
            Permission.SCHEMA_READ,
        ],
        status=UserStatus.ACTIVE,
        allowed_databases=[
            "northwind",
        ],
    )

    try:
        executor.execute(
            validation_result=validation_result,
            user=missing_permission_user,
        )

    except QueryAuthorizationError as exc:
        print(
            f"Missing permission rejected successfully: "
            f"{exc}"
        )

    else:
        raise AssertionError(
            "User without northwind:read "
            "was allowed to execute SQL."
        )

    print("\n14. Rejecting inactive account")

    inactive_user = UserIdentity(
        user_id="user-004",
        username="inactive.manager",
        display_name="Inactive Manager",
        role=UserRole.BUSINESS_MANAGER,
        permissions=[
            Permission.NORTHWIND_READ,
        ],
        status=UserStatus.INACTIVE,
        allowed_databases=[
            "northwind",
        ],
    )

    try:
        executor.execute(
            validation_result=validation_result,
            user=inactive_user,
        )

    except QueryAuthorizationError as exc:
        print(
            f"Inactive user rejected successfully: "
            f"{exc}"
        )

    else:
        raise AssertionError(
            "Inactive user was allowed "
            "to execute SQL."
        )

    print("\n15. Rejecting unsupported result object")

    try:
        executor.normalize_records(
            [
                {
                    "unsupported": object(),
                }
            ]
        )

    except ResultNormalizationError as exc:
        print(
            f"Unsupported value rejected successfully: "
            f"{exc}"
        )

    else:
        raise AssertionError(
            "Unsupported result value was accepted."
        )

    print(
        "\nPhase 4 database execution layer "
        "tested successfully."
    )

    executor.registry.dispose()


if __name__ == "__main__":
    main()