"""
Focused diagnostic for the Planning Agent contract.

Run:

    python -m tests.test_planning_agent_diagnostic
"""

from schemas.plan_schema import (
    AgentType,
    AnalysisPlan,
    AnalyticalTask,
    DataRequirement,
    ExecutionControls,
    TaskType,
)
from schemas.intent_schema import (
    AggregationType,
    DimensionDefinition,
    IntentResult,
    MetricDefinition,
    QueryIntent,
    RankingRequirement,
)
from agents.planning_agent import PlanningAgent
from services.llm_service import llm_service


def main() -> None:
    print("=" * 60)
    print("Planning Agent Contract Diagnostic")
    print("=" * 60)

    print("\n1. Testing AnalysisPlan directly")

    schema_task = AnalyticalTask(
        task_id="schema",
        sequence=1,
        task_type=TaskType.SCHEMA_DISCOVERY,
        assigned_agent=AgentType.SQL_AGENT,
        title="Discover relevant schema",
        description=(
            "Confirm customer, sales-order and "
            "order-detail schema fields."
        ),
        depends_on=[],
        required_tables=[
            "customer",
            "salesorder",
            "orderdetail",
        ],
        required_columns={},
        expected_output=(
            "Relevant table and relationship metadata"
        ),
        optional=False,
    )

    sql_task = AnalyticalTask(
        task_id="sql",
        sequence=2,
        task_type=TaskType.SQL_GENERATION,
        assigned_agent=AgentType.SQL_AGENT,
        title="Generate customer sales query",
        description=(
            "Aggregate total sales by customer and "
            "return the five highest totals."
        ),
        depends_on=["schema"],
        required_tables=[
            "customer",
            "salesorder",
            "orderdetail",
        ],
        required_columns={},
        expected_output=(
            "One candidate read-only MySQL query"
        ),
        optional=False,
    )

    plan = AnalysisPlan(
        objective=(
            "Rank customers by total sales and "
            "return the top five."
        ),
        strategy_summary=(
            "Discover the schema, generate and validate "
            "read-only SQL, execute it, then analyze "
            "and report the results."
        ),
        data_requirements=DataRequirement(
            database_name="northwind",
            required_tables=[
                "customer",
                "salesorder",
                "orderdetail",
            ],
            required_columns={},
            required_metrics=[
                "total_sales",
            ],
            required_dimensions=[
                "customer",
            ],
            requires_schema_discovery=True,
        ),
        tasks=[
            schema_task,
            sql_task,
        ],
        analysis_methods=[
            "aggregation",
            "ranking",
        ],
        visualization_required=True,
        recommended_visualizations=[
            "bar",
        ],
        reporting_required=True,
        controls=ExecutionControls(
            max_sql_retries=2,
            max_result_rows=1000,
            query_timeout_seconds=30,
            read_only_required=True,
            human_approval_required=False,
            approval_reason=None,
        ),
        assumptions=[],
        risks=[],
        requires_clarification=False,
        clarification_question=None,
        confidence=0.95,
    )

    print(
        plan.model_dump_json(
            indent=2
        )
    )

    assert plan.objective
    assert len(plan.tasks) == 2
    assert (
        plan.data_requirements.database_name
        == "northwind"
    )

    print(
        "\nAnalysisPlan contract is valid."
    )

    print("\n2. Testing PlanningAgent with the configured Ollama service")
    question = "Show the top five customers by total sales."
    intent = IntentResult(
        original_question=question,
        normalized_question="Rank customers by total sales.",
        intent=QueryIntent.RANKING,
        metrics=[
            MetricDefinition(
                name="total_sales",
                aggregation=AggregationType.SUM,
            )
        ],
        dimensions=[DimensionDefinition(name="customer")],
        ranking=RankingRequirement(
            required=True,
            limit=5,
            sort_direction="descending",
            rank_by="total_sales",
        ),
        confidence=0.95,
    )
    planning_agent = PlanningAgent(llm=llm_service)
    generated_plan = planning_agent.run(
        validated_intent=intent,
        permission_context={
            "allowed": True,
            "reason": "Diagnostic authorization context only.",
            "permissions": ["northwind:read"],
            "allowed_databases": ["northwind"],
            "database_name": "northwind",
        },
        available_database_metadata=[
            {
                "name": "northwind",
                "database_name": "northwind_db",
                "backend": "mysql",
                "read_only": True,
            }
        ],
        database_name="northwind",
        schema_context={
            "tables": ["customer", "salesorder", "orderdetail"],
            "relationships": [],
        },
        execution_policy={
            "max_sql_retries": 2,
            "max_result_rows": 1000,
            "query_timeout_seconds": 30,
            "read_only_required": True,
        },
    )
    print(generated_plan.model_dump_json(indent=2))

    assert generated_plan.data_requirements.database_name == "northwind"
    assert generated_plan.controls.read_only_required is True
    assert any(
        task.task_type == TaskType.SQL_GENERATION
        for task in generated_plan.tasks
    )
    print("\nReal Ollama PlanningAgent contract is valid.")

if __name__ == "__main__":
    main()