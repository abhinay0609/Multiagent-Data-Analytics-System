from agents.intent_agent import normalize_intent_from_question
from schemas.intent_schema import (
    AggregationType, AnalysisType, IntentResult, QueryIntent, SortDirection,
    TimeGranularity,
)


def base(question):
    return IntentResult(
        original_question=question,
        normalized_question=question,
        intent=QueryIntent.UNKNOWN,
        confidence=0.8,
    )


def test_lowest_customers_is_ascending_customer_sales_ranking():
    result = normalize_intent_from_question(
        base("Which five customers generated the lowest total sales?"),
        "Which five customers generated the lowest total sales?",
    )
    assert result.intent == QueryIntent.RANKING
    assert result.ranking.required is True
    assert result.ranking.sort_direction == SortDirection.ASCENDING
    assert result.ranking.limit == 5
    assert result.dimensions[0].name == "customer"
    assert result.metrics[0].name == "total_sales"


def test_products_are_not_customers():
    question = "Which products generated the highest total sales?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.RANKING
    assert result.dimensions[0].name == "product"
    assert result.ranking.sort_direction == SortDirection.DESCENDING


def test_average_sales_per_order_is_scalar_aggregation():
    question = "What is the average sales value per order?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.AGGREGATION
    assert result.ranking.required is False
    assert result.dimensions == []
    assert result.metrics[0].name == "average_sales_per_order"
    assert result.metrics[0].aggregation == AggregationType.AVERAGE


def test_customer_count_by_country_is_count_ranking():
    question = "Which countries have the highest number of customers?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.RANKING
    assert result.dimensions[0].name == "country"
    assert result.metrics[0].name == "customer_count"
    assert result.metrics[0].aggregation == AggregationType.COUNT
    assert result.ranking.sort_direction == SortDirection.DESCENDING


def test_customer_count_is_scalar_aggregation_not_general_question():
    question = "How many customers are there?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.AGGREGATION
    assert result.metrics[0].name == "customer_count"
    assert result.metrics[0].aggregation == AggregationType.COUNT
    assert result.dimensions == []
    assert result.ranking.required is False


def test_product_count_is_scalar_aggregation():
    question = "How many products are there?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.AGGREGATION
    assert result.metrics[0].name == "product_count"
    assert result.metrics[0].aggregation == AggregationType.COUNT
    assert result.dimensions == []


def test_monthly_revenue_trend_requests_anomaly_analysis():
    question = "Show the monthly revenue trend and highlight unusual months"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.TREND_ANALYSIS
    assert result.metrics[0].name == "total_sales"
    assert result.metrics[0].aggregation == AggregationType.SUM
    assert result.time_period.granularity == TimeGranularity.MONTH
    assert AnalysisType.TREND in result.analysis_types
    assert AnalysisType.ANOMALY in result.analysis_types


def test_category_growth_question_requests_a_monthly_category_trend():
    question = "Which categories are growing fastest over time?"
    result = normalize_intent_from_question(base(question), question)

    assert result.intent == QueryIntent.TREND_ANALYSIS
    assert result.metrics[0].name == "total_sales"
    assert result.metrics[0].aggregation == AggregationType.SUM
    assert [dimension.name for dimension in result.dimensions] == ["category"]
    assert result.time_period.granularity == TimeGranularity.MONTH
    assert AnalysisType.TREND in result.analysis_types


def test_product_supplier_projection_is_data_query():
    from schemas.intent_schema import QueryIntent
    question = "Show product names with supplier names."
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.DATA_QUERY
    assert [item.name for item in result.dimensions] == [
        "product_name", "supplier_name"
    ]


def test_customers_without_orders_is_data_query_with_null_semantics():
    from schemas.intent_schema import FilterOperator, QueryIntent
    question = "Which customers have never placed an order?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.DATA_QUERY
    assert result.dimensions[0].name == "customer"
    assert len(result.filters) == 1
    assert result.filters[0].field == "salesorder.orderId"
    assert result.filters[0].operator == FilterOperator.IS_NULL


def test_lowest_ranking_direction_does_not_inherit_default_descending():
    question = "Which five customers generated the lowest total sales?"
    result = normalize_intent_from_question(base(question), question)
    assert result.ranking.sort_direction == SortDirection.ASCENDING
    assert result.ranking.limit == 5
