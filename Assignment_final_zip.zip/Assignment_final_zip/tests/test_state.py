"""
Tests for core/state.py.

Run from the project root:

    python -m tests.test_state
"""

from datetime import datetime

from graph.state import (
    AgentName,
    ErrorCategory,
    ExecutionStep,
    QueryIntent,
    VisualizationSpec,
    VisualizationType,
    add_agent_trace,
    add_completed_step,
    add_error,
    copy_state,
    create_initial_state,
    mark_completed,
    mark_failed,
    should_retry,
    state_update,
    validate_json_compatible,
    validate_state,
)


def apply_update(
    state: dict,
    update: dict,
) -> dict:
    """
    Apply a partial update for test purposes.

    LangGraph normally applies reducers automatically. This helper
    simulates append behavior for reducer-controlled list fields.
    """
    append_fields = {
        "errors",
        "agent_trace",
        "completed_steps",
        "messages",
    }

    result = copy_state(state)

    for key, value in update.items():
        if key in append_fields:
            existing_value = result.get(key, [])
            result[key] = existing_value + value
        else:
            result[key] = value

    return result


def main() -> None:
    """Run state integration checks."""
    print("=" * 60)
    print("Testing Analytics Workflow State")
    print("=" * 60)

    # =====================================================
    # Initial state
    # =====================================================

    print("\n1. Creating initial state")

    state = create_initial_state(
        user_query=(
            "Show the top five customers by total sales."
        ),
        database_name="northwind",
        user_id="test-user",
        conversation_id="test-conversation",
        max_retries=2,
    )

    print(f"Request ID    : {state['request_id']}")
    print(f"User query    : {state['user_query']}")
    print(f"Database      : {state['database_name']}")
    print(f"Status        : {state['status']}")
    print(f"Next node     : {state['next_node']}")
    print(f"Intent        : {state['intent']}")
    print(f"Maximum retry : {state['max_retries']}")

    assert state["status"] == "initialized"
    assert state["next_node"] == "input_guardrail"
    assert state["database_name"] == "northwind"
    assert state["retry_count"] == 0
    assert state["max_retries"] == 2
    assert state["intent"] == QueryIntent.UNKNOWN.value
    assert state["execution_result"] == {}
    assert state["errors"] == []

    # =====================================================
    # State validation
    # =====================================================

    print("\n2. Validating initial state")

    assert validate_state(state) is True

    created_at = datetime.fromisoformat(
        state["created_at"]
    )

    assert created_at.tzinfo is not None

    print("Initial state is valid.")

    # =====================================================
    # Planner update
    # =====================================================

    print("\n3. Creating planner update")

    planner_update = state_update(
        status="planning",
        current_agent=AgentName.PLANNER.value,
        next_node="schema_agent",
        intent=QueryIntent.RANKING.value,
        intent_confidence=0.96,
        entities={
            "metric": "total sales",
            "dimension": "customer",
            "limit": 5,
        },
        selected_tables=[
            "customer",
            "salesorder",
            "orderdetail",
            "product",
        ],
    )

    state = apply_update(
        state,
        planner_update,
    )

    assert state["status"] == "planning"
    assert state["next_node"] == "schema_agent"
    assert state["intent"] == "ranking"
    assert state["intent_confidence"] == 0.96

    print("Planner update applied successfully.")

    # =====================================================
    # Execution plan
    # =====================================================

    print("\n4. Testing execution steps")

    step = ExecutionStep(
        sequence=1,
        agent=AgentName.SCHEMA_AGENT,
        action="Retrieve relevant Northwind schema.",
        status="completed",
        started_at=datetime.now().astimezone(),
        completed_at=datetime.now().astimezone(),
        output_summary=(
            "Selected customer, salesorder and orderdetail."
        ),
    )

    step_update = add_completed_step(step)

    state = apply_update(
        state,
        step_update,
    )

    assert len(state["completed_steps"]) == 1
    assert (
        state["completed_steps"][0]["agent"]
        == AgentName.SCHEMA_AGENT.value
    )

    print("Execution step stored successfully.")

    # =====================================================
    # Agent tracing
    # =====================================================

    print("\n5. Testing agent trace")

    trace_update = add_agent_trace(
        agent=AgentName.SQL_AGENT,
        action="Generate read-only aggregation query.",
        status="completed",
        details="Generated one SELECT statement.",
    )

    state = apply_update(
        state,
        trace_update,
    )

    assert len(state["agent_trace"]) == 1
    assert (
        state["agent_trace"][0]["agent"]
        == AgentName.SQL_AGENT.value
    )
    assert (
        state["agent_trace"][0]["status"]
        == "completed"
    )

    print("Agent trace stored successfully.")

    # =====================================================
    # Recoverable errors
    # =====================================================

    print("\n6. Testing recoverable error handling")

    error_update = add_error(
        state=state,
        category=ErrorCategory.SQL_VALIDATION,
        message="Generated query requires correction.",
        agent=AgentName.SQL_VALIDATOR,
        recoverable=True,
        technical_details="Unknown column customer.totalSales.",
    )

    state = apply_update(
        state,
        error_update,
    )

    assert len(state["errors"]) == 1
    assert state["retry_count"] == 1
    assert should_retry(state) is True
    assert (
        state["errors"][0]["category"]
        == ErrorCategory.SQL_VALIDATION.value
    )

    print(
        f"Recoverable error recorded. "
        f"Retry count: {state['retry_count']}"
    )

    # =====================================================
    # Retry limit
    # =====================================================

    print("\n7. Testing retry limit")

    second_error_update = add_error(
        state=state,
        category=ErrorCategory.SQL_VALIDATION,
        message="Second SQL validation failure.",
        agent=AgentName.SQL_VALIDATOR,
        recoverable=True,
    )

    state = apply_update(
        state,
        second_error_update,
    )

    assert state["retry_count"] == 2
    assert should_retry(state) is False

    print("Retry limit enforced successfully.")

    # =====================================================
    # Visualization specification
    # =====================================================

    print("\n8. Testing visualization specification")

    visualization = VisualizationSpec(
        chart_type=VisualizationType.BAR,
        title="Top Five Customers by Total Sales",
        x_column="customer_name",
        y_columns=["total_sales"],
        orientation="vertical",
        options={
            "show_values": True,
            "currency": "USD",
        },
    )

    visualization_update = state_update(
        visualization_required=True,
        visualization_spec=visualization.model_dump(
            mode="json"
        ),
    )

    state = apply_update(
        state,
        visualization_update,
    )

    assert state["visualization_required"] is True
    assert (
        state["visualization_spec"]["chart_type"]
        == "bar"
    )

    print("Visualization specification is valid.")

    # =====================================================
    # Completion
    # =====================================================

    print("\n9. Testing successful completion")

    completed_update = mark_completed(
        final_answer=(
            "The analysis identified the five customers "
            "with the highest total sales."
        ),
        response_metadata={
            "row_count": 5,
            "visualization": "bar",
        },
    )

    completed_state = apply_update(
        state,
        completed_update,
    )

    assert completed_state["status"] == "completed"
    assert completed_state["next_node"] == "end"
    assert completed_state["final_answer"] is not None

    print("Workflow completion state is valid.")

    # =====================================================
    # Failure
    # =====================================================

    print("\n10. Testing terminal failure")

    failed_update = mark_failed(
        message="Database query execution failed.",
        category=ErrorCategory.DATABASE,
        agent=AgentName.QUERY_EXECUTOR,
        technical_details="Connection timeout.",
    )

    failed_state = apply_update(
        create_initial_state("Test failure path."),
        failed_update,
    )

    assert failed_state["status"] == "failed"
    assert failed_state["next_node"] == "end"
    assert len(failed_state["errors"]) == 1
    assert (
        failed_state["errors"][0]["recoverable"]
        is False
    )

    print("Terminal failure state is valid.")

    # =====================================================
    # Defensive copying
    # =====================================================

    print("\n11. Testing defensive state copy")

    copied_state = copy_state(completed_state)
    copied_state["selected_tables"].append(
        "temporary_table"
    )

    assert (
        "temporary_table"
        not in completed_state["selected_tables"]
    )

    print("Defensive copying works correctly.")

    # =====================================================
    # Unsupported state objects
    # =====================================================

    print("\n12. Testing serialization protection")

    try:
        validate_json_compatible(
            {
                "invalid_object": object(),
            }
        )

    except TypeError as exc:
        print(
            f"Unsupported object rejected successfully: {exc}"
        )

    else:
        raise AssertionError(
            "Unsupported state object was not rejected."
        )

    # =====================================================
    # Final validation
    # =====================================================

    print("\n13. Running final state validation")

    assert validate_state(completed_state) is True

    print("\nState enhancement tested successfully.")


if __name__ == "__main__":
    main()