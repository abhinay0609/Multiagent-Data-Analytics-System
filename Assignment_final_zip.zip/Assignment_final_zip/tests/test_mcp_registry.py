from mcp_integration.registry.server_registry import get_server


def test_get_server_loads_packaged_registry_config():
    server = get_server()

    assert server["enabled"] is True
    assert server["url"] == "http://127.0.0.1:8001/mcp"
