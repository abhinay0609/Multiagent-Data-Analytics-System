"""Offline tests for the Gemini adapter and narrative-model routing."""

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from agents._common import get_narrative_llm
from services.gemini_service import GeminiService


class FakeModels:
    def __init__(self) -> None:
        self.response = SimpleNamespace(text='{"summary":"Grounded."}')
        self.call: dict[str, object] | None = None

    def generate_content(self, **kwargs: object) -> SimpleNamespace:
        self.call = kwargs
        return self.response


def test_generate_json_uses_schema_and_rejects_duplicate_keys() -> None:
    models = FakeModels()
    fake_client = SimpleNamespace(models=models)
    schema = {
        "type": "object",
        "properties": {"summary": {"type": "string"}},
        "required": ["summary"],
    }

    with patch(
        "services.gemini_service.genai.Client",
        return_value=fake_client,
    ) as client_factory:
        service = GeminiService(api_key="test-key")
        result = service.generate_json(
            "Summarize the supplied evidence.",
            system_prompt="Use only supplied evidence.",
            output_schema=schema,
        )

    assert result == {"summary": "Grounded."}
    client_factory.assert_called_once()
    assert models.call is not None
    config = models.call["config"]
    assert config.response_mime_type == "application/json"
    assert config.response_json_schema == schema
    assert config.system_instruction == "Use only supplied evidence."

    models.response = SimpleNamespace(
        text='{"summary":"first","summary":"second"}'
    )
    with patch(
        "services.gemini_service.genai.Client",
        return_value=fake_client,
    ):
        service = GeminiService(api_key="test-key")
        with pytest.raises(ValueError, match="invalid JSON"):
            service.generate_json("Summarize.")


def test_service_requires_a_key_and_narrative_routing_falls_back_to_ollama() -> None:
    with patch("services.gemini_service.settings.GEMINI_API_KEY", ""):
        with pytest.raises(ValueError, match="GEMINI_API_KEY"):
            GeminiService()

    sentinel = object()
    with (
        patch("config.settings.settings.GEMINI_API_KEY", ""),
        patch("agents._common.get_default_llm", return_value=sentinel),
    ):
        assert get_narrative_llm() is sentinel


def test_narrative_routing_uses_gemini_when_a_key_is_configured() -> None:
    sentinel = object()
    with (
        patch("config.settings.settings.GEMINI_API_KEY", "configured"),
        patch(
            "services.gemini_service.get_gemini_service",
            return_value=sentinel,
        ),
    ):
        assert get_narrative_llm() is sentinel
