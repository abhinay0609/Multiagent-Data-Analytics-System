"""Focused tests for the deterministic analytics modules.

Run from the project root with:

    python -m tests.test_analytics
"""

import pandas as pd

from analytics import (
    analyze_contributions,
    analyze_trend,
    compare_groups,
    detect_anomalies,
    generate_insights,
)


def main() -> None:
    comparison = compare_groups(
        pd.DataFrame(
            {
                "period": ["2024", "2024", "2025"],
                "sales": [40.0, 60.0, 150.0],
            }
        ),
        "sales",
        "period",
        "2024",
        "2025",
    )
    assert comparison is not None
    assert comparison.absolute_change == 50.0
    assert comparison.percentage_change == 50.0
    assert comparison.source_columns == ["period", "sales"]
    zero_baseline = compare_groups(
        pd.DataFrame({"period": ["before", "after"], "sales": [0.0, 5.0]}),
        "sales",
        "period",
        "before",
        "after",
    )
    assert zero_baseline is not None
    assert zero_baseline.percentage_change is None

    trend = analyze_trend(
        pd.DataFrame(
            {
                "date": [
                    "2025-01-15",
                    "2025-02-15",
                    "2025-03-15",
                    "2025-04-15",
                    "2025-05-15",
                    "2025-06-15",
                ],
                "sales": [10, 20, 30, 40, 50, 60],
            }
        ),
        "date",
        "sales",
        rolling_window=3,
    )
    assert trend is not None
    assert trend.direction == "increasing"
    assert trend.month_over_month_growth[1] == 100.0
    assert trend.quarter_over_quarter_growth[1] == 150.0
    assert trend.rolling_average[-1] == 50.0
    assert trend.source_columns == ["date", "sales"]

    anomalous = detect_anomalies(
        [10.0] * 11 + [1000.0],
        entities=[f"customer-{index}" for index in range(12)],
    )
    assert len(anomalous) == 1
    assert anomalous[0].entity == "customer-11"
    assert {"iqr", "z_score", "rolling_mean"}.issubset(
        set(anomalous[0].method.split(", "))
    )
    rolling_only = detect_anomalies(
        [10.0, 10.0, 10.0, 100.0],
        methods=("rolling_mean",),
        rolling_window=3,
        rolling_deviation_threshold_percent=50.0,
    )
    assert len(rolling_only) == 1
    assert rolling_only[0].method == "rolling_mean"

    contributions = analyze_contributions(
        pd.DataFrame(
            {
                "year": [2024, 2024, 2024, 2025, 2025, 2025],
                "category": ["A", "A", "B", "A", "A", "B"],
                "product": ["a1", "a2", "b1", "a1", "a2", "b1"],
                "sales": [100.0, 20.0, 100.0, 50.0, 20.0, 90.0],
            }
        ),
        "sales",
        ["category", "product"],
        period_column="year",
        baseline=2024,
        target=2025,
    )
    category_a = next(
        item
        for item in contributions
        if item.dimension == "category" and item.segment == "A"
    )
    assert category_a.absolute_change == -50.0
    assert round(category_a.contribution_percentage or 0) == 83
    findings = generate_insights(contributions=contributions)
    assert findings
    assert all(
        item.caveat and "not proof of causality" in item.caveat
        for item in findings
    )
    print("Comparison, trend, anomaly, contribution, and insight tests passed.")


if __name__ == "__main__":
    main()
