"""
Structured models for Reporting Agent output.

The Reporting Agent transforms validated analysis into an executive
summary, grounded findings, chart specifications and recommendations.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class ChartType(str, Enum):
    """Supported report visualization types."""

    NONE = "none"
    TABLE = "table"
    KPI = "kpi"
    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    SCATTER = "scatter"
    HISTOGRAM = "histogram"
    BOX = "box"
    HEATMAP = "heatmap"


class RecommendationPriority(str, Enum):
    """Priority assigned to a business recommendation."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class RecommendationTimeframe(str, Enum):
    """Expected timeframe for a recommendation."""

    IMMEDIATE = "immediate"
    SHORT_TERM = "short_term"
    MEDIUM_TERM = "medium_term"
    LONG_TERM = "long_term"


class ChartSpecification(BaseModel):
    """Serializable Plotly-oriented chart specification."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    chart_id: str = Field(min_length=1)
    chart_type: ChartType
    title: str = Field(min_length=1)

    x_column: Optional[str] = None
    y_columns: list[str] = Field(
        default_factory=list
    )
    color_column: Optional[str] = None

    aggregation: Optional[str] = None
    orientation: Literal["vertical", "horizontal"] = "vertical"

    data: list[dict[str, Any]] = Field(
        default_factory=list
    )
    options: dict[str, Any] = Field(
        default_factory=dict
    )

    rationale: str = Field(min_length=1)

    @model_validator(mode="after")
    def validate_chart(self) -> "ChartSpecification":
        """Validate axis requirements for chart types."""
        axis_charts = {
            ChartType.BAR,
            ChartType.LINE,
            ChartType.SCATTER,
            ChartType.BOX,
        }

        if self.chart_type in axis_charts:
            if not self.x_column:
                raise ValueError(
                    "x_column is required for the selected chart type."
                )

            if not self.y_columns:
                raise ValueError(
                    "At least one y_column is required for the selected chart."
                )

        return self


class KeyFinding(BaseModel):
    """Report-ready key finding."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    title: str = Field(min_length=1)
    description: str = Field(min_length=1)
    importance: RecommendationPriority = RecommendationPriority.MEDIUM
    supporting_metric: Optional[str] = None
    supporting_value: Optional[str] = None
    evidence_reference: Optional[str] = None


class BusinessRecommendation(BaseModel):
    """Grounded and actionable business recommendation."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    title: str = Field(min_length=1)
    recommendation: str = Field(min_length=1)
    rationale: str = Field(min_length=1)

    priority: RecommendationPriority
    timeframe: RecommendationTimeframe

    expected_impact: Optional[str] = None
    owner_role: Optional[str] = None

    supporting_findings: list[str] = Field(
        min_length=1
    )
    risks: list[str] = Field(
        default_factory=list
    )


class ReportResult(BaseModel):
    """Validated output of the Reporting Agent."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    report_title: str = Field(min_length=1)
    executive_summary: str = Field(min_length=1)

    key_findings: list[KeyFinding] = Field(
        default_factory=list
    )
    charts: list[ChartSpecification] = Field(
        default_factory=list
    )
    recommendations: list[BusinessRecommendation] = Field(
        default_factory=list
    )

    methodology_summary: Optional[str] = None
    generated_sql: Optional[str] = None

    assumptions: list[str] = Field(
        default_factory=list
    )
    limitations: list[str] = Field(
        default_factory=list
    )
    warnings: list[str] = Field(
        default_factory=list
    )

    grounded: bool = False
    grounding_notes: list[str] = Field(
        default_factory=list
    )

    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
    )

    @field_validator(
        "report_title",
        "executive_summary",
    )
    @classmethod
    def normalize_report_text(cls, value: str) -> str:
        """Normalize required report text."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Report text cannot be empty."
            )

        return clean_value

    @model_validator(mode="after")
    def validate_grounding(self) -> "ReportResult":
        """Require notes when the report is not fully grounded."""
        if not self.grounded and not self.grounding_notes:
            raise ValueError(
                "grounding_notes are required when grounded is False."
            )

        return self