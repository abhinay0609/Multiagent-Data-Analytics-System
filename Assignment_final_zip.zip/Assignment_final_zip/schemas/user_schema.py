"""
User, authentication and authorization schemas.

These models define API-safe contracts for login, identity, JWT tokens,
roles and permissions. Password hashes must never be returned to clients.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SecretStr,
    field_validator,
)


class UserRole(str, Enum):
    """Supported application roles."""

    ADMINISTRATOR = "administrator"
    BUSINESS_MANAGER = "business_manager"
    EMPLOYEE = "employee"


class Permission(str, Enum):
    """Supported authorization permissions."""

    NORTHWIND_READ = "northwind:read"
    SCHEMA_READ = "schema:read"
    ANALYTICS_EXECUTE = "analytics:execute"
    REPORTS_READ = "reports:read"
    TRACES_READ = "traces:read"
    USERS_MANAGE = "users:manage"


class UserStatus(str, Enum):
    """Lifecycle state of a user account."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    LOCKED = "locked"


class LoginRequest(BaseModel):
    """Login request accepted by FastAPI or Streamlit."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    username: str = Field(
        min_length=3,
        max_length=100,
    )
    password: SecretStr = Field(
        min_length=8,
        max_length=256,
    )

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        """Normalize the login username."""
        clean_value = value.strip().lower()

        if not clean_value:
            raise ValueError(
                "username cannot be empty."
            )

        return clean_value


class UserIdentity(BaseModel):
    """Safe user identity shared with services and workflow state."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    user_id: str = Field(min_length=1)
    username: str = Field(
        min_length=3,
        max_length=100,
    )
    display_name: str = Field(min_length=1)
    role: UserRole
    permissions: list[Permission] = Field(
        default_factory=list
    )
    status: UserStatus = UserStatus.ACTIVE
    allowed_databases: list[str] = Field(
        default_factory=list
    )

    @field_validator(
        "user_id",
        "username",
        "display_name",
    )
    @classmethod
    def normalize_identity_text(cls, value: str) -> str:
        """Normalize user identity text."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "User identity fields cannot be empty."
            )

        return clean_value


class UserRecord(BaseModel):
    """
    Internal persisted user record.

    This model is for authentication storage only and must not be returned
    directly from API endpoints.
    """

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    user_id: str = Field(min_length=1)
    username: str = Field(
        min_length=3,
        max_length=100,
    )
    display_name: str = Field(min_length=1)
    password_hash: str = Field(min_length=1)

    role: UserRole
    permissions: list[Permission] = Field(
        default_factory=list
    )
    status: UserStatus = UserStatus.ACTIVE
    allowed_databases: list[str] = Field(
        default_factory=list
    )


class TokenPayload(BaseModel):
    """Validated claims stored inside a JWT."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    sub: str = Field(min_length=1)
    username: str = Field(min_length=1)
    role: UserRole
    permissions: list[Permission] = Field(
        default_factory=list
    )
    allowed_databases: list[str] = Field(
        default_factory=list
    )

    issued_at: int = Field(ge=0)
    expires_at: int = Field(ge=0)
    token_id: str = Field(min_length=1)


class TokenResponse(BaseModel):
    """Authentication response returned after successful login."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    access_token: str = Field(min_length=1)
    token_type: str = "bearer"
    expires_in_seconds: int = Field(gt=0)
    user: UserIdentity


class AuthorizationRequest(BaseModel):
    """Permission check request."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    user: UserIdentity
    required_permission: Permission
    database_name: Optional[str] = None


class AuthorizationResult(BaseModel):
    """Result of deterministic authorization checking."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    allowed: bool
    reason: str = Field(min_length=1)
    missing_permission: Optional[str] = None