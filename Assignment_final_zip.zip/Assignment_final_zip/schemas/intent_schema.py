"""
Structured models for Intent Agent input and output.

The Intent Agent converts a natural-language business question into a
validated analytical request containing metrics, dimensions, filters,
time periods, comparison requirements and clarification requirements.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class QueryIntent(str, Enum):
    """Supported high-level user intentions."""

    DATA_QUERY = "data_query"
    AGGREGATION = "aggregation"
    COMPARISON = "comparison"
    TREND_ANALYSIS = "trend_analysis"
    RANKING = "ranking"
    DISTRIBUTION = "distribution"
    ANOMALY_DETECTION = "anomaly_detection"
    ROOT_CAUSE_ANALYSIS = "root_cause_analysis"
    SCHEMA_QUESTION = "schema_question"
    VISUALIZATION = "visualization"
    GENERAL_QUESTION = "general_question"
    UNKNOWN = "unknown"


class AnalysisType(str, Enum):
    """Deterministic or LLM-assisted analytical operations."""

    SUMMARY = "summary"
    AGGREGATION = "aggregation"
    COMPARISON = "comparison"
    TREND = "trend"
    RANKING = "ranking"
    DISTRIBUTION = "distribution"
    ANOMALY = "anomaly"
    ROOT_CAUSE = "root_cause"
    CONTRIBUTION = "contribution"


class AggregationType(str, Enum):
    """Supported SQL and analytical aggregations."""

    SUM = "sum"
    AVERAGE = "average"
    COUNT = "count"
    DISTINCT_COUNT = "distinct_count"
    MINIMUM = "minimum"
    MAXIMUM = "maximum"
    MEDIAN = "median"
    NONE = "none"


class FilterOperator(str, Enum):
    """Operators allowed in structured business filters."""

    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    GREATER_THAN = "greater_than"
    GREATER_THAN_OR_EQUAL = "greater_than_or_equal"
    LESS_THAN = "less_than"
    LESS_THAN_OR_EQUAL = "less_than_or_equal"
    IN = "in"
    NOT_IN = "not_in"
    BETWEEN = "between"
    CONTAINS = "contains"
    STARTS_WITH = "starts_with"
    ENDS_WITH = "ends_with"
    IS_NULL = "is_null"
    IS_NOT_NULL = "is_not_null"


class TimeGranularity(str, Enum):
    """Supported time-series grouping levels."""

    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    QUARTER = "quarter"
    YEAR = "year"
    NONE = "none"


class ComparisonType(str, Enum):
    """Supported business comparison types."""

    PERIOD_OVER_PERIOD = "period_over_period"
    CATEGORY_COMPARISON = "category_comparison"
    ENTITY_COMPARISON = "entity_comparison"
    BENCHMARK_COMPARISON = "benchmark_comparison"
    NONE = "none"


class SortDirection(str, Enum):
    """Supported ranking directions."""

    ASCENDING = "ascending"
    DESCENDING = "descending"


class MetricDefinition(BaseModel):
    """Metric or KPI requested by the user."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    name: str = Field(min_length=1)
    aggregation: AggregationType = AggregationType.NONE
    alias: Optional[str] = None
    description: Optional[str] = None

    @field_validator("name", "alias", "description")
    @classmethod
    def normalize_optional_text(
        cls,
        value: Optional[str],
    ) -> Optional[str]:
        """Trim text fields and reject blank required values."""
        if value is None:
            return None

        clean_value = value.strip()

        if not clean_value:
            return None

        return clean_value


class DimensionDefinition(BaseModel):
    """Dimension used for grouping, segmentation or comparison."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    name: str = Field(min_length=1)
    description: Optional[str] = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        """Normalize the dimension name."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Dimension name cannot be empty."
            )

        return clean_value


class FilterCondition(BaseModel):
    """Structured filter extracted from a business question."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    field: str = Field(min_length=1)
    operator: FilterOperator
    value: Any = None

    @field_validator("field")
    @classmethod
    def validate_field(cls, value: str) -> str:
        """Normalize the filter field."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Filter field cannot be empty."
            )

        return clean_value

    @model_validator(mode="after")
    def validate_operator_value(self) -> "FilterCondition":
        """Validate that the value matches the selected operator."""
        no_value_operators = {
            FilterOperator.IS_NULL,
            FilterOperator.IS_NOT_NULL,
        }

        collection_operators = {
            FilterOperator.IN,
            FilterOperator.NOT_IN,
            FilterOperator.BETWEEN,
        }

        if (
            self.operator not in no_value_operators
            and self.value is None
        ):
            raise ValueError(
                f"Operator '{self.operator.value}' requires a value."
            )

        if (
            self.operator in collection_operators
            and not isinstance(self.value, list)
        ):
            raise ValueError(
                f"Operator '{self.operator.value}' requires a list value."
            )

        if (
            self.operator == FilterOperator.BETWEEN
            and isinstance(self.value, list)
            and len(self.value) != 2
        ):
            raise ValueError(
                "The BETWEEN operator requires exactly two values."
            )

        return self


class TimePeriod(BaseModel):
    """Time range and grouping requirement."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    start_date: Optional[str] = None
    end_date: Optional[str] = None
    relative_period: Optional[str] = None
    granularity: TimeGranularity = TimeGranularity.NONE
    time_column_hint: Optional[str] = None

    @model_validator(mode="after")
    def validate_period(self) -> "TimePeriod":
        """Require both absolute dates when either one is provided."""
        if bool(self.start_date) != bool(self.end_date):
            raise ValueError(
                "Both start_date and end_date must be supplied together."
            )

        return self


class ComparisonRequirement(BaseModel):
    """Comparison requested by the business user."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    required: bool = False
    comparison_type: ComparisonType = ComparisonType.NONE
    baseline: Optional[str] = None
    target: Optional[str] = None
    comparison_dimension: Optional[str] = None
    calculate_absolute_change: bool = True
    calculate_percentage_change: bool = True

    @model_validator(mode="after")
    def validate_comparison(self) -> "ComparisonRequirement":
        """Ensure comparison details agree with the required flag."""
        if (
            self.required
            and self.comparison_type == ComparisonType.NONE
        ):
            raise ValueError(
                "comparison_type is required when comparison is requested."
            )

        if (
            not self.required
            and self.comparison_type != ComparisonType.NONE
        ):
            raise ValueError(
                "comparison_type must be 'none' when comparison is not required."
            )

        return self


class RankingRequirement(BaseModel):
    """Ranking or top/bottom-N requirement."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    required: bool = False
    limit: Optional[int] = Field(
        default=None,
        ge=1,
        le=1000,
    )
    sort_direction: SortDirection = SortDirection.DESCENDING
    rank_by: Optional[str] = None

    @model_validator(mode="after")
    def validate_ranking(self) -> "RankingRequirement":
        """Require a limit when ranking is requested."""
        if self.required and self.limit is None:
            raise ValueError(
                "Ranking limit is required when ranking is requested."
            )

        return self


class IntentResult(BaseModel):
    """Validated output of the Intent Understanding Agent."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    original_question: str = Field(min_length=1)
    normalized_question: str = Field(min_length=1)

    intent: QueryIntent = QueryIntent.UNKNOWN

    metrics: list[MetricDefinition] = Field(
        default_factory=list
    )
    dimensions: list[DimensionDefinition] = Field(
        default_factory=list
    )
    filters: list[FilterCondition] = Field(
        default_factory=list
    )

    time_period: Optional[TimePeriod] = None
    comparison: ComparisonRequirement = Field(
        default_factory=ComparisonRequirement
    )
    ranking: RankingRequirement = Field(
        default_factory=RankingRequirement
    )

    analysis_types: list[AnalysisType] = Field(
        default_factory=list
    )

    visualization_required: bool = False
    requested_visualization: Optional[str] = None

    requires_clarification: bool = False
    clarification_question: Optional[str] = None
    missing_information: list[str] = Field(
        default_factory=list
    )

    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
    )

    reasoning_summary: Optional[str] = None

    @field_validator(
        "original_question",
        "normalized_question",
    )
    @classmethod
    def validate_questions(cls, value: str) -> str:
        """Normalize required question text."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Question text cannot be empty."
            )

        return clean_value

    @model_validator(mode="after")
    def validate_clarification(self) -> "IntentResult":
        """Require a clarification question when clarification is needed."""
        if (
            self.requires_clarification
            and not self.clarification_question
        ):
            raise ValueError(
                "clarification_question is required when "
                "requires_clarification is True."
            )

        if (
            not self.requires_clarification
            and self.clarification_question
        ):
            raise ValueError(
                "clarification_question must be empty when "
                "requires_clarification is False."
            )

        if (
            self.intent == QueryIntent.RANKING
            and not self.ranking.required
        ):
            raise ValueError(
                "ranking.required must be True for ranking intent."
            )

        return self
