"""
Structured models for SQL generation, validation and execution.

These models carry SQL Agent output through deterministic validation
and controlled read-only execution.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional
from uuid import uuid4

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class SQLDialect(str, Enum):
    """Supported SQL dialects."""

    MYSQL = "mysql"


class SQLStatementType(str, Enum):
    """SQL statement types recognized by the security layer."""

    SELECT = "select"
    WITH = "with"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    CREATE = "create"
    ALTER = "alter"
    DROP = "drop"
    TRUNCATE = "truncate"
    COMMAND = "command"
    UNKNOWN = "unknown"


class SQLValidationStatus(str, Enum):
    """Outcome of SQL validation."""

    NOT_VALIDATED = "not_validated"
    VALID = "valid"
    INVALID = "invalid"
    REQUIRES_CORRECTION = "requires_correction"


class SQLIssueSeverity(str, Enum):
    """Severity of a SQL validation issue."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class SQLValidationIssue(BaseModel):
    """One syntax, schema or security problem."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    severity: SQLIssueSeverity = SQLIssueSeverity.ERROR
    location: Optional[str] = None
    suggestion: Optional[str] = None


class SQLGenerationResult(BaseModel):
    """Validated output of the SQL Generation Agent."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    query_id: str = Field(
        default_factory=lambda: str(uuid4())
    )
    database_name: str = Field(min_length=1)
    dialect: SQLDialect = SQLDialect.MYSQL

    sql_query: str = Field(min_length=1)
    statement_type: SQLStatementType = SQLStatementType.SELECT

    referenced_tables: list[str] = Field(
        default_factory=list
    )
    referenced_columns: dict[str, list[str]] = Field(
        default_factory=dict
    )
    expected_columns: list[str] = Field(
        default_factory=list
    )

    parameters: dict[str, Any] = Field(
        default_factory=dict
    )

    explanation: str = Field(min_length=1)
    assumptions: list[str] = Field(
        default_factory=list
    )

    is_read_only: bool = True
    retry_attempt: int = Field(
        default=0,
        ge=0,
        le=5,
    )
    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
    )

    @field_validator(
        "database_name",
        "sql_query",
        "explanation",
    )
    @classmethod
    def normalize_required_text(cls, value: str) -> str:
        """Normalize required SQL fields."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Required SQL text cannot be empty."
            )

        return clean_value

    @model_validator(mode="after")
    def validate_read_only_intent(self) -> "SQLGenerationResult":
        """
        Reject explicitly non-read-only claims.

        Deterministic validation is still required before execution.
        """
        if not self.is_read_only:
            raise ValueError(
                "SQLGenerationResult must represent a read-only query."
            )

        allowed_types = {
            SQLStatementType.SELECT,
            SQLStatementType.WITH,
        }

        if self.statement_type not in allowed_types:
            raise ValueError(
                "Only SELECT or WITH statements are allowed."
            )

        return self


class SQLValidationResult(BaseModel):
    """Output of deterministic SQL validation and guardrails."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    query_id: str
    status: SQLValidationStatus

    original_sql: str = Field(min_length=1)
    normalized_sql: Optional[str] = None
    executable_sql: Optional[str] = None

    statement_type: SQLStatementType = SQLStatementType.UNKNOWN

    syntax_valid: bool = False
    schema_valid: bool = False
    security_valid: bool = False
    read_only: bool = False

    referenced_tables: list[str] = Field(
        default_factory=list
    )
    referenced_columns: dict[str, list[str]] = Field(
        default_factory=dict
    )

    row_limit: Optional[int] = Field(
        default=None,
        ge=1,
    )
    limit_added: bool = False

    issues: list[SQLValidationIssue] = Field(
        default_factory=list
    )

    retry_recommended: bool = False
    correction_feedback: Optional[str] = None

    @model_validator(mode="after")
    def validate_result_consistency(self) -> "SQLValidationResult":
        """Keep the validation status consistent with validation flags."""
        all_valid = (
            self.syntax_valid
            and self.schema_valid
            and self.security_valid
            and self.read_only
        )

        if (
            self.status == SQLValidationStatus.VALID
            and not all_valid
        ):
            raise ValueError(
                "A valid SQL result requires all validation checks to pass."
            )

        if (
            self.status == SQLValidationStatus.VALID
            and not self.executable_sql
        ):
            raise ValueError(
                "executable_sql is required for a valid SQL result."
            )

        if (
            self.status != SQLValidationStatus.VALID
            and not self.issues
        ):
            raise ValueError(
                "Invalid SQL validation results must contain at least one issue."
            )

        return self


class QueryExecutionMetadata(BaseModel):
    """Metadata captured during controlled query execution."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    query_id: str
    database_name: str
    row_count: int = Field(
        default=0,
        ge=0,
    )
    columns: list[str] = Field(
        default_factory=list
    )
    execution_time_ms: float = Field(
        default=0.0,
        ge=0.0,
    )
    truncated: bool = False
    timeout_seconds: Optional[int] = Field(
        default=None,
        ge=1,
    )


class QueryExecutionResult(BaseModel):
    """Serializable output of the Query Executor."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    success: bool
    metadata: QueryExecutionMetadata
    records: list[dict[str, Any]] = Field(
        default_factory=list
    )
    error_message: Optional[str] = None
    retryable: bool = False

    @model_validator(mode="after")
    def validate_execution_result(self) -> "QueryExecutionResult":
        """Require an error message for unsuccessful execution."""
        if not self.success and not self.error_message:
            raise ValueError(
                "error_message is required when query execution fails."
            )

        if (
            self.success
            and self.metadata.row_count != len(self.records)
        ):
            raise ValueError(
                "metadata.row_count must match the number of records."
            )

        return self