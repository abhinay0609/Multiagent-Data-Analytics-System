"""
Structured models for Planning Agent output.

The Planning Agent transforms validated intent into an ordered,
explainable analytical execution plan.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional
from uuid import uuid4

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class TaskType(str, Enum):
    """Supported task types in an analytical plan."""

    SCHEMA_DISCOVERY = "schema_discovery"
    SQL_GENERATION = "sql_generation"
    SQL_VALIDATION = "sql_validation"
    QUERY_EXECUTION = "query_execution"
    DATA_PREPARATION = "data_preparation"
    AGGREGATION = "aggregation"
    COMPARISON = "comparison"
    TREND_ANALYSIS = "trend_analysis"
    ANOMALY_DETECTION = "anomaly_detection"
    ROOT_CAUSE_ANALYSIS = "root_cause_analysis"
    VISUALIZATION = "visualization"
    REPORTING = "reporting"


class TaskStatus(str, Enum):
    """Execution status of a planned task."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class AgentType(str, Enum):
    """Agents available in the five-agent workflow."""

    INTENT_AGENT = "intent_agent"
    PLANNING_AGENT = "planning_agent"
    SQL_AGENT = "sql_agent"
    ANALYSIS_AGENT = "analysis_agent"
    REPORTING_AGENT = "reporting_agent"
    SYSTEM = "system"


class AnalyticalTask(BaseModel):
    """One ordered task in the analytical execution plan."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    task_id: str = Field(
        default_factory=lambda: str(uuid4())
    )
    sequence: int = Field(ge=1)
    task_type: TaskType
    assigned_agent: AgentType

    title: str = Field(min_length=1)
    description: str = Field(min_length=1)

    depends_on: list[str] = Field(
        default_factory=list
    )
    required_tables: list[str] = Field(
        default_factory=list
    )
    required_columns: dict[str, list[str]] = Field(
        default_factory=dict
    )

    expected_output: str = Field(min_length=1)
    status: TaskStatus = TaskStatus.PENDING
    optional: bool = False

    @field_validator(
        "title",
        "description",
        "expected_output",
    )
    @classmethod
    def normalize_required_text(cls, value: str) -> str:
        """Normalize required task text."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Task text fields cannot be empty."
            )

        return clean_value


class DataRequirement(BaseModel):
    """Tables, columns and filters needed by the plan."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    database_name: str = Field(min_length=1)
    required_tables: list[str] = Field(
        default_factory=list
    )
    required_columns: dict[str, list[str]] = Field(
        default_factory=dict
    )
    required_metrics: list[str] = Field(
        default_factory=list
    )
    required_dimensions: list[str] = Field(
        default_factory=list
    )
    requires_schema_discovery: bool = True

    @field_validator("database_name")
    @classmethod
    def validate_database_name(cls, value: str) -> str:
        """Normalize the logical registry database name."""
        clean_value = value.strip().lower()

        if not clean_value:
            raise ValueError(
                "database_name cannot be empty."
            )

        return clean_value


class ExecutionControls(BaseModel):
    """Deterministic limits applied to execution."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
    )

    max_sql_retries: int = Field(
        default=2,
        ge=0,
        le=5,
    )
    max_result_rows: int = Field(
        default=1000,
        ge=1,
        le=10000,
    )
    query_timeout_seconds: int = Field(
        default=30,
        ge=1,
        le=300,
    )
    read_only_required: bool = True
    human_approval_required: bool = False
    approval_reason: Optional[str] = None

    @model_validator(mode="after")
    def validate_approval(self) -> "ExecutionControls":
        """Require an explanation for human approval."""
        if (
            self.human_approval_required
            and not self.approval_reason
        ):
            raise ValueError(
                "approval_reason is required when human approval is required."
            )

        return self


class AnalysisPlan(BaseModel):
    """Validated output of the Planning Agent."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=True,
    )

    plan_id: str = Field(
        default_factory=lambda: str(uuid4())
    )
    objective: str = Field(min_length=1)
    strategy_summary: str = Field(min_length=1)

    data_requirements: DataRequirement
    tasks: list[AnalyticalTask] = Field(
        min_length=1
    )

    analysis_methods: list[str] = Field(
        default_factory=list
    )
    visualization_required: bool = False
    recommended_visualizations: list[str] = Field(
        default_factory=list
    )
    reporting_required: bool = True

    controls: ExecutionControls = Field(
        default_factory=ExecutionControls
    )

    assumptions: list[str] = Field(
        default_factory=list
    )
    risks: list[str] = Field(
        default_factory=list
    )

    requires_clarification: bool = False
    clarification_question: Optional[str] = None

    confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
    )

    @field_validator(
        "objective",
        "strategy_summary",
    )
    @classmethod
    def normalize_plan_text(cls, value: str) -> str:
        """Normalize required plan text."""
        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                "Plan text cannot be empty."
            )

        return clean_value

    @model_validator(mode="after")
    def validate_plan(self) -> "AnalysisPlan":
        """Validate task ordering and clarification consistency."""
        has_schema_task = any(
            task.task_type == TaskType.SCHEMA_DISCOVERY
            for task in self.tasks
        )
        if (
            self.data_requirements.requires_schema_discovery
            and not has_schema_task
        ):
            existing_ids = {task.task_id for task in self.tasks}
            schema_task_id = "schema"
            suffix = 1
            while schema_task_id in existing_ids:
                schema_task_id = f"schema_discovery_{suffix}"
                suffix += 1
            for task in self.tasks:
                task.sequence += 1
            self.tasks.insert(
                0,
                AnalyticalTask(
                    task_id=schema_task_id,
                    sequence=1,
                    task_type=TaskType.SCHEMA_DISCOVERY,
                    assigned_agent=AgentType.SQL_AGENT,
                    title="Discover relevant schema",
                    description=(
                        "Retrieve the registered schema needed by this plan."
                    ),
                    required_tables=(
                        self.data_requirements.required_tables
                    ),
                    expected_output=(
                        "Relevant table, column, and relationship metadata"
                    ),
                ),
            )

        task_type_aliases = {
            "schema": TaskType.SCHEMA_DISCOVERY,
            "schema_discovery": TaskType.SCHEMA_DISCOVERY,
            "sql": TaskType.SQL_GENERATION,
            "sql_generation": TaskType.SQL_GENERATION,
            "validate": TaskType.SQL_VALIDATION,
            "validation": TaskType.SQL_VALIDATION,
            "sql_validation": TaskType.SQL_VALIDATION,
            "execute": TaskType.QUERY_EXECUTION,
            "execution": TaskType.QUERY_EXECUTION,
            "query_execution": TaskType.QUERY_EXECUTION,
        }
        task_ids = {task.task_id for task in self.tasks}
        tasks_by_type: dict[TaskType, list[AnalyticalTask]] = {}
        for task in self.tasks:
            tasks_by_type.setdefault(task.task_type, []).append(task)
        for task in self.tasks:
            normalized_dependencies = []
            for dependency in task.depends_on:
                task_type = task_type_aliases.get(dependency.casefold())
                candidates = (
                    tasks_by_type.get(task_type, [])
                    if dependency not in task_ids and task_type is not None
                    else []
                )
                if len(candidates) == 1:
                    dependency = candidates[0].task_id
                normalized_dependencies.append(dependency)
            task.depends_on = list(dict.fromkeys(normalized_dependencies))

        schema_tasks = [
            task
            for task in self.tasks
            if task.task_type == TaskType.SCHEMA_DISCOVERY
        ]
        if schema_tasks:
            schema_task_id = min(
                schema_tasks,
                key=lambda task: task.sequence,
            ).task_id
            for task in self.tasks:
                if task.task_type != TaskType.SQL_GENERATION:
                    continue
                dependencies = [
                    schema_task_id
                    if dependency == "schema"
                    else dependency
                    for dependency in task.depends_on
                ]
                if self.data_requirements.requires_schema_discovery:
                    dependencies.append(schema_task_id)
                task.depends_on = list(dict.fromkeys(dependencies))

        sequences = [
            task.sequence
            for task in self.tasks
        ]

        if len(sequences) != len(set(sequences)):
            raise ValueError(
                "Task sequence numbers must be unique."
            )

        if sequences != sorted(sequences):
            raise ValueError(
                "Tasks must be ordered by sequence."
            )

        task_ids = {
            task.task_id
            for task in self.tasks
        }

        for task in self.tasks:
            unknown_dependencies = [
                dependency
                for dependency in task.depends_on
                if dependency not in task_ids
            ]

            if unknown_dependencies:
                raise ValueError(
                    f"Task '{task.task_id}' contains unknown dependencies: "
                    + ", ".join(unknown_dependencies)
                )

        if (
            self.requires_clarification
            and not self.clarification_question
        ):
            raise ValueError(
                "clarification_question is required when clarification "
                "is needed."
            )

        return self