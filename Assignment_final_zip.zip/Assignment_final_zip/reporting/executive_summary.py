"""Prepare concise executive summaries from validated analysis output."""

from __future__ import annotations

from schemas.analysis_schema import AnalysisResult


def build_executive_summary(
    analysis: AnalysisResult,
    *,
    max_characters: int = 600,
) -> str:
    """Summarize supported findings and clearly disclose limited evidence."""
    if (
        isinstance(max_characters, bool)
        or not isinstance(max_characters, int)
        or max_characters < 80
    ):
        raise ValueError("max_characters must be an integer of at least 80.")

    if not analysis.sufficient_data:
        limitation = (
            analysis.limitations[0]
            if analysis.limitations
            else "The available result data is insufficient."
        )
        summary = f"The analysis is incomplete. {limitation}"
    else:
        statements = [analysis.analysis_summary]
        if (
            analysis.findings
            and analysis.findings[0].description
            not in analysis.analysis_summary
        ):
            statements.append(
                f"Key finding: {analysis.findings[0].description}"
            )
        summary = " ".join(
            statement.strip()
            for statement in statements
            if statement.strip()
        )

    if len(summary) <= max_characters:
        return summary
    shortened = summary[: max_characters - 1].rsplit(" ", 1)[0].rstrip(" ,;:")
    return shortened + "…"