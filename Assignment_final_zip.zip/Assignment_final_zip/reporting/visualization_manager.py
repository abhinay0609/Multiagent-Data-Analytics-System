# """Build Plotly figures from chart specifications at the render boundary."""

# from __future__ import annotations

# from collections.abc import Mapping
# from typing import Any

# import numpy as np
# import pandas as pd
# import plotly.express as px
# import plotly.graph_objects as go

# from schemas.report_schema import ChartSpecification, ChartType


# _LAYOUT_OPTIONS = {
#     "barmode",
#     "height",
#     "hovermode",
#     "legend",
#     "margin",
#     "showlegend",
#     "template",
#     "width",
#     "xaxis_title",
#     "yaxis_title",
# }


# def create_figure(
#     chart: ChartSpecification | Mapping[str, Any],
#     *,
#     data: list[dict[str, Any]] | None = None,
# ) -> go.Figure | None:
#     """Create a Plotly figure from a serializable chart specification.

#     This function is intended for a UI or reporting boundary. Callers should
#     keep the ChartSpecification, not the returned Figure, in workflow state.
#     """
#     values = (
#         chart.model_dump(mode="json")
#         if isinstance(chart, ChartSpecification)
#         else dict(chart)
#     )
#     if data is not None:
#         values["data"] = data
#     specification = ChartSpecification.model_validate(values)
#     chart_type = ChartType(specification.chart_type)
#     if chart_type == ChartType.NONE:
#         return None

#     data = pd.DataFrame.from_records(specification.data)
#     if data.empty:
#         raise ValueError("Chart data is required to create a Plotly figure.")
#     axis_columns = [
#         column
#         for column in (
#             specification.x_column,
#             specification.color_column,
#             *specification.y_columns,
#         )
#         if column is not None
#     ]
#     missing_columns = [column for column in axis_columns if column not in data]
#     if missing_columns:
#         raise ValueError(
#             "Chart references missing data columns: "
#             + ", ".join(missing_columns)
#         )

#     if chart_type == ChartType.TABLE:
#         figure = _table_figure(data, specification.title)
#     elif chart_type == ChartType.KPI:
#         figure = _kpi_figure(data, specification)
#     elif chart_type == ChartType.BAR:
#         _require_axes(specification)
#         figure = px.bar(
#             data,
#             x=specification.x_column,
#             y=specification.y_columns,
#             color=specification.color_column,
#             orientation=specification.orientation[:1],
#             title=specification.title,
#         )
#     elif chart_type == ChartType.LINE:
#         _require_axes(specification)
#         figure = px.line(
#             data,
#             x=specification.x_column,
#             y=specification.y_columns,
#             color=specification.color_column,
#             title=specification.title,
#         )
#     elif chart_type == ChartType.SCATTER:
#         _require_axes(specification)
#         figure = px.scatter(
#             data,
#             x=specification.x_column,
#             y=specification.y_columns[0],
#             color=specification.color_column,
#             title=specification.title,
#         )
#     elif chart_type == ChartType.BOX:
#         _require_axes(specification)
#         figure = px.box(
#             data,
#             x=specification.x_column,
#             y=specification.y_columns,
#             color=specification.color_column,
#             title=specification.title,
#         )
#     elif chart_type == ChartType.PIE:
#         if not specification.x_column or not specification.y_columns:
#             raise ValueError("Pie charts require x_column and one y_column.")
#         figure = px.pie(
#             data,
#             names=specification.x_column,
#             values=specification.y_columns[0],
#             title=specification.title,
#         )
#     elif chart_type == ChartType.HISTOGRAM:
#         value_column = (
#             specification.x_column
#             or (specification.y_columns[0] if specification.y_columns else None)
#         )
#         if value_column is None:
#             raise ValueError("Histograms require an x_column or y_column.")
#         figure = px.histogram(data, x=value_column, title=specification.title)
#     elif chart_type == ChartType.HEATMAP:
#         if not specification.x_column or not specification.y_columns:
#             raise ValueError(
#                 "Heatmaps require a row-label x_column and numeric y_columns."
#             )
#         matrix = data[specification.y_columns].apply(
#             pd.to_numeric,
#             errors="coerce",
#         )
#         if matrix.isna().any().any():
#             raise ValueError("Heatmap value columns must contain numeric data.")
#         values = matrix.to_numpy(dtype=float)
#         if not np.isfinite(values).all():
#             raise ValueError("Heatmap values must be finite.")
#         figure = go.Figure(
#             data=go.Heatmap(
#                 x=specification.y_columns,
#                 y=data[specification.x_column].astype(str),
#                 z=values,
#             )
#         )
#     else:
#         raise ValueError(f"Unsupported chart type: {chart_type.value}.")

#     options = specification.options
#     unsupported = set(options) - _LAYOUT_OPTIONS
#     if unsupported:
#         raise ValueError(
#             "Unsupported Plotly layout options: "
#             + ", ".join(sorted(unsupported))
#         )
#     figure.update_layout(title=specification.title, **options)
#     return figure


# def _require_axes(specification: ChartSpecification) -> None:
#     if not specification.x_column or not specification.y_columns:
#         raise ValueError("This chart type requires x_column and y_columns.")


# def _table_figure(data: pd.DataFrame, title: str) -> go.Figure:
#     return go.Figure(
#         data=[
#             go.Table(
#                 header={"values": [str(column) for column in data.columns]},
#                 cells={
#                     "values": [
#                         data[column].astype(str).tolist()
#                         for column in data.columns
#                     ]
#                 },
#             )
#         ],
#         layout={"title": title},
#     )


# def _kpi_figure(
#     data: pd.DataFrame,
#     specification: ChartSpecification,
# ) -> go.Figure:
#     value_column = (
#         specification.y_columns[0]
#         if specification.y_columns
#         else specification.x_column
#     )
#     if value_column is None or value_column not in data:
#         raise ValueError("KPI charts require a numeric value column.")
#     values = pd.to_numeric(data[value_column], errors="coerce").dropna()
#     if values.empty:
#         raise ValueError("KPI value column contains no numeric values.")
#     aggregation = (specification.aggregation or "first").casefold()
#     aggregations = {
#         "first": lambda series: float(series.iloc[0]),
#         "sum": lambda series: float(series.sum()),
#         "average": lambda series: float(series.mean()),
#         "min": lambda series: float(series.min()),
#         "max": lambda series: float(series.max()),
#     }
#     if aggregation not in aggregations:
#         raise ValueError(
#             "KPI aggregation must be first, sum, average, min, or max."
#         )
#     value = aggregations[aggregation](values)
#     if not np.isfinite(value):
#         raise ValueError("KPI value must be finite.")
#     return go.Figure(
#         data=[
#             go.Indicator(
#                 mode="number",
#                 value=value,
#                 title={"text": specification.title},
#             )
#         ]
#     )


"""
Build Plotly figures from validated chart specifications.

Plotly Figure objects are created only at the UI/reporting boundary.
Chart specifications and visualization records remain JSON-compatible
inside API responses and LangGraph state.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from loguru import logger

from schemas.report_schema import (
    ChartSpecification,
    ChartType,
)


class VisualizationError(ValueError):
    """Raised when a chart specification cannot be rendered safely."""


_LAYOUT_OPTIONS = {
    "barmode",
    "height",
    "hovermode",
    "legend",
    "margin",
    "showlegend",
    "template",
    "width",
    "xaxis_title",
    "yaxis_title",
}


def create_figure(
    chart: ChartSpecification | Mapping[str, Any],
    *,
    data: Sequence[Mapping[str, Any]] | None = None,
) -> go.Figure | None:
    """
    Create a Plotly figure from one chart specification.

    Args:
        chart:
            Pydantic ChartSpecification or JSON-compatible mapping.

        data:
            Optional visualization records. When supplied, these records
            replace chart.data from the specification.

    Returns:
        A Plotly Figure, or None for ChartType.NONE.

    Raises:
        VisualizationError:
            If the specification or data cannot be rendered safely.
    """
    try:
        raw_specification = (
            chart.model_dump(mode="json")
            if isinstance(chart, ChartSpecification)
            else dict(chart)
        )

        if data is not None:
            raw_specification["data"] = [
                dict(record)
                for record in data
                if isinstance(record, Mapping)
            ]

        specification = (
            ChartSpecification.model_validate(
                raw_specification
            )
        )

        chart_type = ChartType(
            specification.chart_type
        )

        if chart_type == ChartType.NONE:
            return None

        data_frame = pd.DataFrame.from_records(
            specification.data
        )

        if data_frame.empty:
            raise VisualizationError(
                "Chart data is empty."
            )

        _validate_axis_columns(
            data_frame=data_frame,
            specification=specification,
        )

        figure = _build_chart(
            data_frame=data_frame,
            specification=specification,
            chart_type=chart_type,
        )

        _apply_layout_options(
            figure=figure,
            specification=specification,
        )

        return figure

    except VisualizationError:
        raise

    except Exception as exc:
        raise VisualizationError(
            f"Could not create visualization: {exc}"
        ) from exc


def create_figures(
    chart_specifications: Sequence[
        ChartSpecification | Mapping[str, Any]
    ],
    *,
    data: Sequence[Mapping[str, Any]],
    request_id: str | None = None,
) -> list[tuple[dict[str, Any], go.Figure]]:
    """
    Create all renderable figures.

    Invalid chart specifications are logged and skipped so one bad chart
    does not prevent other charts from rendering.
    """
    rendered: list[
        tuple[dict[str, Any], go.Figure]
    ] = []

    for index, chart in enumerate(
        chart_specifications
    ):
        chart_mapping = (
            chart.model_dump(mode="json")
            if isinstance(chart, ChartSpecification)
            else dict(chart)
        )

        chart_id = str(
            chart_mapping.get(
                "chart_id",
                f"chart_{index}",
            )
        )

        chart_type = str(
            chart_mapping.get(
                "chart_type",
                "unknown",
            )
        )

        try:
            figure = create_figure(
                chart_mapping,
                data=data,
            )

            if figure is None:
                continue

            rendered.append(
                (chart_mapping, figure)
            )

            logger.info(
                "[request_id={}] [VISUALIZATION] "
                "chart_id={} type={} rows={} rendered=true",
                request_id or "unknown",
                chart_id,
                chart_type,
                len(data),
            )

        except VisualizationError as exc:
            logger.warning(
                "[request_id={}] [VISUALIZATION] "
                "chart_id={} type={} rows={} "
                "rendered=false reason={}",
                request_id or "unknown",
                chart_id,
                chart_type,
                len(data),
                exc,
            )

    return rendered


def _build_chart(
    *,
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
    chart_type: ChartType,
) -> go.Figure:
    """Dispatch a validated specification to its chart builder."""
    if chart_type == ChartType.TABLE:
        return _table_figure(
            data_frame,
            specification.title,
        )

    if chart_type == ChartType.KPI:
        return _kpi_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.BAR:
        return _bar_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.LINE:
        return _line_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.SCATTER:
        return _scatter_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.BOX:
        return _box_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.PIE:
        return _pie_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.HISTOGRAM:
        return _histogram_figure(
            data_frame,
            specification,
        )

    if chart_type == ChartType.HEATMAP:
        return _heatmap_figure(
            data_frame,
            specification,
        )

    raise VisualizationError(
        f"Unsupported chart type: "
        f"{chart_type.value}."
    )


def _bar_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a vertical or horizontal bar chart."""
    _require_axes(specification)

    orientation = _normalize_orientation(
        specification.orientation
    )

    x_column = specification.x_column

    if x_column is None:
        raise VisualizationError(
            "Bar charts require x_column."
        )

    y_column = specification.y_columns[0]

    if orientation == "h":
        metric_column, category_column = (
            _resolve_horizontal_axes(
                data_frame=data_frame,
                x_column=x_column,
                y_column=y_column,
            )
        )

        sorted_frame = data_frame.sort_values(
            by=metric_column,
            ascending=True,
            kind="stable",
        )

        figure = px.bar(
            sorted_frame,
            x=metric_column,
            y=category_column,
            color=(
                specification.color_column
                if specification.color_column
                else None
            ),
            orientation="h",
            text=metric_column,
            title=specification.title,
        )

        figure.update_traces(
            texttemplate="%{x:,.2f}",
            textposition="outside",
            cliponaxis=False,
        )

        figure.update_xaxes(
            title=_display_name(
                metric_column
            ),
            tickformat=",.2f",
        )

        figure.update_yaxes(
            title=_display_name(
                category_column
            ),
            categoryorder="array",
            categoryarray=(
                sorted_frame[
                    category_column
                ].astype(str).tolist()
            ),
        )

        return figure

    category_column = x_column

    numeric_columns = list(
        specification.y_columns
    )

    for column in numeric_columns:
        _require_numeric_column(
            data_frame,
            column,
        )

    sorted_frame = data_frame.copy()

    if len(numeric_columns) == 1:
        sorted_frame = sorted_frame.sort_values(
            by=numeric_columns[0],
            ascending=False,
            kind="stable",
        )

    figure = px.bar(
        sorted_frame,
        x=category_column,
        y=numeric_columns,
        color=(
            specification.color_column
            if specification.color_column
            else None
        ),
        barmode=str(
            specification.options.get(
                "barmode",
                "group",
            )
        ),
        title=specification.title,
    )

    figure.update_yaxes(
        tickformat=",.2f"
    )

    return figure


def _line_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a line chart with optional date sorting."""
    _require_axes(specification)

    x_column = specification.x_column

    if x_column is None:
        raise VisualizationError(
            "Line charts require x_column."
        )

    working_frame = data_frame.copy()

    converted_dates = pd.to_datetime(
        working_frame[x_column],
        errors="coerce",
    )

    if converted_dates.notna().all():
        working_frame[x_column] = (
            converted_dates
        )

        working_frame = (
            working_frame.sort_values(
                by=x_column,
                kind="stable",
            )
        )

    for column in specification.y_columns:
        _require_numeric_column(
            working_frame,
            column,
        )

    figure = px.line(
        working_frame,
        x=x_column,
        y=list(specification.y_columns),
        color=(
            specification.color_column
            if specification.color_column
            else None
        ),
        markers=True,
        title=specification.title,
    )

    figure.update_yaxes(
        tickformat=",.2f"
    )

    return figure


def _scatter_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a scatter chart."""
    _require_axes(specification)

    x_column = specification.x_column

    if x_column is None:
        raise VisualizationError(
            "Scatter charts require x_column."
        )

    y_column = specification.y_columns[0]

    _require_numeric_column(
        data_frame,
        x_column,
    )

    _require_numeric_column(
        data_frame,
        y_column,
    )

    return px.scatter(
        data_frame,
        x=x_column,
        y=y_column,
        color=(
            specification.color_column
            if specification.color_column
            else None
        ),
        title=specification.title,
    )


def _box_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a box plot."""
    if not specification.y_columns:
        raise VisualizationError(
            "Box charts require at least one y column."
        )

    y_column = specification.y_columns[0]

    _require_numeric_column(
        data_frame,
        y_column,
    )

    return px.box(
        data_frame,
        x=specification.x_column,
        y=y_column,
        color=(
            specification.color_column
            if specification.color_column
            else None
        ),
        title=specification.title,
    )


def _pie_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a pie chart for a small category set."""
    if (
        not specification.x_column
        or not specification.y_columns
    ):
        raise VisualizationError(
            "Pie charts require x_column "
            "and one y column."
        )

    if len(data_frame) > 10:
        raise VisualizationError(
            "Pie charts support at most 10 categories. "
            "Use a bar chart for larger category sets."
        )

    value_column = (
        specification.y_columns[0]
    )

    _require_numeric_column(
        data_frame,
        value_column,
    )

    return px.pie(
        data_frame,
        names=specification.x_column,
        values=value_column,
        title=specification.title,
    )


def _histogram_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a histogram."""
    value_column = (
        specification.x_column
        or (
            specification.y_columns[0]
            if specification.y_columns
            else None
        )
    )

    if value_column is None:
        raise VisualizationError(
            "Histograms require an x or y column."
        )

    _require_numeric_column(
        data_frame,
        value_column,
    )

    return px.histogram(
        data_frame,
        x=value_column,
        title=specification.title,
    )


def _heatmap_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a heatmap from row labels and numeric measures."""
    if (
        not specification.x_column
        or not specification.y_columns
    ):
        raise VisualizationError(
            "Heatmaps require a row-label x_column "
            "and numeric y_columns."
        )

    matrix = data_frame[
        list(specification.y_columns)
    ].apply(
        pd.to_numeric,
        errors="coerce",
    )

    if matrix.isna().any().any():
        raise VisualizationError(
            "Heatmap value columns must be numeric."
        )

    numeric_values = matrix.to_numpy(
        dtype=float
    )

    if not np.isfinite(
        numeric_values
    ).all():
        raise VisualizationError(
            "Heatmap values must be finite."
        )

    return go.Figure(
        data=go.Heatmap(
            x=list(
                specification.y_columns
            ),
            y=data_frame[
                specification.x_column
            ].astype(str),
            z=numeric_values,
            colorbar={
                "title": "Value",
            },
        ),
        layout={
            "title": specification.title,
        },
    )


def _table_figure(
    data_frame: pd.DataFrame,
    title: str,
) -> go.Figure:
    """Build a Plotly table."""
    display_frame = data_frame.copy()

    for column in display_frame.columns:
        if pd.api.types.is_numeric_dtype(
            display_frame[column]
        ):
            display_frame[column] = (
                display_frame[column].map(
                    lambda value: (
                        f"{value:,.2f}"
                        if pd.notna(value)
                        else ""
                    )
                )
            )

    return go.Figure(
        data=[
            go.Table(
                header={
                    "values": [
                        _display_name(
                            str(column)
                        )
                        for column
                        in display_frame.columns
                    ],
                    "align": "left",
                },
                cells={
                    "values": [
                        display_frame[
                            column
                        ].astype(str).tolist()
                        for column
                        in display_frame.columns
                    ],
                    "align": "left",
                },
            )
        ],
        layout={
            "title": title,
        },
    )


def _kpi_figure(
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    """Build a KPI indicator from a numeric column."""
    value_column = (
        specification.y_columns[0]
        if specification.y_columns
        else specification.x_column
    )

    if (
        value_column is None
        or value_column not in data_frame
    ):
        raise VisualizationError(
            "KPI charts require a numeric value column."
        )

    numeric_values = pd.to_numeric(
        data_frame[value_column],
        errors="coerce",
    ).dropna()

    if numeric_values.empty:
        raise VisualizationError(
            "KPI value column contains no numeric values."
        )

    aggregation = (
        specification.aggregation
        or "first"
    ).casefold()

    aggregations = {
        "first": (
            lambda series: float(
                series.iloc[0]
            )
        ),
        "sum": (
            lambda series: float(
                series.sum()
            )
        ),
        "average": (
            lambda series: float(
                series.mean()
            )
        ),
        "mean": (
            lambda series: float(
                series.mean()
            )
        ),
        "min": (
            lambda series: float(
                series.min()
            )
        ),
        "minimum": (
            lambda series: float(
                series.min()
            )
        ),
        "max": (
            lambda series: float(
                series.max()
            )
        ),
        "maximum": (
            lambda series: float(
                series.max()
            )
        ),
    }

    if aggregation not in aggregations:
        raise VisualizationError(
            "KPI aggregation must be first, sum, "
            "average, mean, min, minimum, max, "
            "or maximum."
        )

    value = aggregations[
        aggregation
    ](numeric_values)

    if not np.isfinite(value):
        raise VisualizationError(
            "KPI value must be finite."
        )

    return go.Figure(
        data=[
            go.Indicator(
                mode="number",
                value=value,
                title={
                    "text": (
                        specification.title
                    ),
                },
                number={
                    "valueformat": ",.2f",
                },
            )
        ]
    )


def _validate_axis_columns(
    *,
    data_frame: pd.DataFrame,
    specification: ChartSpecification,
) -> None:
    """Validate that every configured chart column exists."""
    axis_columns = [
        column
        for column in (
            specification.x_column,
            specification.color_column,
            *specification.y_columns,
        )
        if column is not None
    ]

    missing_columns = [
        column
        for column in axis_columns
        if column not in data_frame.columns
    ]

    if missing_columns:
        raise VisualizationError(
            "Chart references missing columns: "
            + ", ".join(
                missing_columns
            )
            + ". Available columns: "
            + ", ".join(
                str(column)
                for column
                in data_frame.columns
            )
        )


def _require_axes(
    specification: ChartSpecification,
) -> None:
    """Require x and y fields for axis-based charts."""
    if (
        not specification.x_column
        or not specification.y_columns
    ):
        raise VisualizationError(
            "This chart requires x_column "
            "and at least one y column."
        )


def _require_numeric_column(
    data_frame: pd.DataFrame,
    column: str,
) -> None:
    """Require a column containing numeric values."""
    if column not in data_frame.columns:
        raise VisualizationError(
            f"Column '{column}' does not exist."
        )

    converted = pd.to_numeric(
        data_frame[column],
        errors="coerce",
    )

    if converted.isna().all():
        raise VisualizationError(
            f"Column '{column}' must contain "
            f"numeric values."
        )

    data_frame[column] = converted


def _resolve_horizontal_axes(
    *,
    data_frame: pd.DataFrame,
    x_column: str,
    y_column: str,
) -> tuple[str, str]:
    """
    Resolve numeric metric and categorical axes.

    Supports both:
    - x=numeric, y=categorical
    - x=categorical, y=numeric
    """
    x_numeric = pd.to_numeric(
        data_frame[x_column],
        errors="coerce",
    )

    y_numeric = pd.to_numeric(
        data_frame[y_column],
        errors="coerce",
    )

    if x_numeric.notna().all():
        data_frame[x_column] = x_numeric
        return x_column, y_column

    if y_numeric.notna().all():
        data_frame[y_column] = y_numeric
        return y_column, x_column

    raise VisualizationError(
        "Horizontal bar charts require one numeric "
        "column and one categorical column."
    )


def _normalize_orientation(
    orientation: str,
) -> str:
    """Convert schema orientation into Plotly orientation."""
    normalized = str(
        orientation
    ).strip().casefold()

    if normalized in {
        "horizontal",
        "h",
    }:
        return "h"

    if normalized in {
        "vertical",
        "v",
    }:
        return "v"

    raise VisualizationError(
        "orientation must be horizontal or vertical."
    )


def _apply_layout_options(
    *,
    figure: go.Figure,
    specification: ChartSpecification,
) -> None:
    """Apply allowlisted layout options and common styling."""
    options = dict(
        specification.options or {}
    )

    unsupported = (
        set(options)
        - _LAYOUT_OPTIONS
    )

    if unsupported:
        raise VisualizationError(
            "Unsupported Plotly layout options: "
            + ", ".join(
                sorted(unsupported)
            )
        )

    options.setdefault(
        "template",
        "plotly_dark",
    )

    options.setdefault(
        "margin",
        {
            "l": 30,
            "r": 30,
            "t": 70,
            "b": 40,
        },
    )

    figure.update_layout(
        title={
            "text": specification.title,
            "x": 0.02,
            "xanchor": "left",
        },
        hoverlabel={
            "namelength": -1,
        },
        legend_title_text="",
        **options,
    )


def _display_name(
    column: str,
) -> str:
    """Convert a database column name into a readable label."""
    return (
        column.replace("_", " ")
        .strip()
        .title()
    )