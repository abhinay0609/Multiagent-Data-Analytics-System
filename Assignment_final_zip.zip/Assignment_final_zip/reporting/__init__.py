"""Reporting helpers; Plotly figures are created only at render time."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from schemas.report_schema import ChartSpecification

from reporting.executive_summary import build_executive_summary
from reporting.recommendation_engine import generate_recommendations
from reporting.report_generator import (
    assemble_report,
    serialize_chart_specifications,
)

if TYPE_CHECKING:
    import plotly.graph_objects as go


def create_figure(
    chart: ChartSpecification | Mapping[str, Any],
    *,
    data: list[dict[str, Any]] | None = None,
) -> go.Figure | None:
    """Create a Plotly figure lazily at the UI/reporting boundary."""
    from reporting.visualization_manager import create_figure as render

    return render(chart, data=data)

__all__ = [
    "assemble_report",
    "build_executive_summary",
    "create_figure",
    "generate_recommendations",
    "serialize_chart_specifications",
]