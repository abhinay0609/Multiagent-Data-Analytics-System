"""Build and compile the five-agent LangGraph workflow."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from time import perf_counter
from typing import Any

from loguru import logger
from langgraph.graph import END, START, StateGraph

from graph.nodes import (
    WorkflowDependencies,
    build_nodes,
    create_default_dependencies,
)
from graph.router import (
    route_after_analysis,
    route_after_authorization,
    route_after_execution,
    route_after_grounding,
    route_after_human_approval,
    route_after_input,
    route_after_intent,
    route_after_planning,
    route_after_schema,
    route_after_sql_generation,
    route_after_sql_validation,
)
from graph.state import AnalyticsState


def build_workflow(
    dependencies: WorkflowDependencies | None = None,
    *,
    database_name: str = "northwind",
) -> Any:
    """Build the workflow with production defaults or injected test services."""
    selected_dependencies = dependencies or create_default_dependencies(
        database_name
    )
    nodes = build_nodes(selected_dependencies)

    graph = StateGraph(AnalyticsState)
    graph_nodes = {
        "input_guardrail": nodes.input_guardrail,
        "authorization": nodes.authorization,
        "intent_agent": nodes.intent,
        "planning_agent": nodes.planning,
        "schema_retrieval": nodes.schema_retrieval,
        "sql_agent": nodes.sql_generation,
        "sql_validation": nodes.sql_validation,
        "human_approval": nodes.human_approval,
        "query_executor": nodes.query_execution,
        "analysis_agent": nodes.analysis,
        "grounding_validator": nodes.grounding,
        "reporting_agent": nodes.reporting,
        "clarification": nodes.clarification,
        "output_guardrail": nodes.output_guardrail,
    }
    for node_name, node in graph_nodes.items():
        graph.add_node(node_name, _logged_node(node_name, node))

    graph.add_edge(START, "input_guardrail")
    graph.add_conditional_edges(
        "input_guardrail",
        route_after_input,
        {
            "authorization": "authorization",
            "clarification": "clarification",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "authorization",
        route_after_authorization,
        {
            "intent_agent": "intent_agent",
            "query_executor": "query_executor",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "intent_agent",
        route_after_intent,
        {
            "planning_agent": "planning_agent",
            "schema_retrieval": "schema_retrieval",
            "clarification": "clarification",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "planning_agent",
        route_after_planning,
        {
            "schema_retrieval": "schema_retrieval",
            "clarification": "clarification",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "schema_retrieval",
        route_after_schema,
        {
            "sql_agent": "sql_agent",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "sql_agent",
        route_after_sql_generation,
        {
            "sql_validation": "sql_validation",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "sql_validation",
        route_after_sql_validation,
        {
            "sql_agent": "sql_agent",
            "human_approval": "human_approval",
            "query_executor": "query_executor",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "human_approval",
        route_after_human_approval,
        {
            "query_executor": "query_executor",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "query_executor",
        route_after_execution,
        {
            "sql_agent": "sql_agent",
            "analysis_agent": "analysis_agent",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "analysis_agent",
        route_after_analysis,
        {
            "grounding_validator": "grounding_validator",
            "reporting_agent": "reporting_agent",
        },
    )
    graph.add_conditional_edges(
        "grounding_validator",
        route_after_grounding,
        {"reporting_agent": "reporting_agent"},
    )
    graph.add_edge("reporting_agent", "output_guardrail")
    graph.add_edge("clarification", "output_guardrail")
    graph.add_edge("output_guardrail", END)

    return graph.compile()


def _logged_node(
    node_name: str,
    node: Callable[[AnalyticsState], AnalyticsState],
) -> Callable[[AnalyticsState], AnalyticsState]:
    """Log safe execution metadata around every workflow transition."""

    def invoke(state: AnalyticsState) -> AnalyticsState:
        logger.bind(
            request_id=str(state.get("request_id", "-")), stage=node_name
        ).info("node_before {}", _execution_log_fields(state, node_name))
        started = perf_counter()
        try:
            update = node(state)
        except Exception as exc:
            logger.bind(
                request_id=str(state.get("request_id", "-")), stage=node_name
            ).exception("node_failed error_type={}", type(exc).__name__)
            raise

        elapsed_ms = round((perf_counter() - started) * 1000.0, 3)
        update = dict(update)
        update["stage_timings"] = [{
            "stage": node_name,
            "duration_ms": elapsed_ms,
            "status": "completed",
        }]
        updated_state = dict(state)
        updated_state.update(update)
        logger.bind(
            request_id=str(updated_state.get("request_id", "-")), stage=node_name
        ).info("node_after {} duration_ms={}", _execution_log_fields(updated_state, node_name), elapsed_ms)
        return update

    return invoke


def _execution_log_fields(
    state: Mapping[str, Any],
    node_name: str,
) -> dict[str, Any]:
    execution = state.get("execution_result", {})
    execution = execution if isinstance(execution, Mapping) else {}
    metadata = execution.get("metadata", {})
    metadata = metadata if isinstance(metadata, Mapping) else {}
    records = execution.get("records", [])
    records = records if isinstance(records, list) else []
    analysis = state.get("analysis_result", {})
    analysis = analysis if isinstance(analysis, Mapping) else {}
    grounding = state.get("grounding_result", {})
    grounding = grounding if isinstance(grounding, Mapping) else {}
    report = state.get("report_result", {})
    report = report if isinstance(report, Mapping) else {}
    output_guardrail = state.get("output_guardrail_result", {})
    output_guardrail = (
        output_guardrail if isinstance(output_guardrail, Mapping) else {}
    )
    latest_error = state.get("errors", [])
    latest_error = (
        latest_error[-1]
        if isinstance(latest_error, list) and latest_error
        else {}
    )
    if not isinstance(latest_error, Mapping):
        latest_error = {}

    analysis_grounded = grounding.get("grounded")
    report_grounded = report.get("grounded")
    output_grounded = output_guardrail.get("grounded")
    analysis_grounding_codes = _grounding_codes(
        grounding.get("issues", [])
    )
    report_grounding_codes = _grounding_codes(
        report.get("grounding_notes", [])
    )
    output_grounding_codes = _grounding_codes(
        output_guardrail.get("grounding_issues", [])
    )
    grounded = (
        report_grounded and output_grounded
        if isinstance(report_grounded, bool)
        and isinstance(output_grounded, bool)
        else (
            output_grounded
            if isinstance(output_grounded, bool)
            else (
                report_grounded
                if isinstance(report_grounded, bool)
                else analysis_grounded
            )
        )
    )

    execution_error = (
        execution.get("success") is False
        or bool(execution.get("error_message"))
        if execution
        else latest_error.get("category") == "sql_execution"
    )
    execution_attempted = bool(execution) or (
        latest_error.get("category") == "sql_execution"
    )
    row_count = metadata.get("row_count")
    if isinstance(row_count, bool) or not isinstance(row_count, int):
        row_count = len(records)
    return {
        "request_id": state.get("request_id"),
        "user_query": str(state.get("user_query", ""))[:300],
        "workflow_node": node_name,
        "intent": state.get("intent"),
        "selected_tables": state.get("selected_tables", []),
        "generated_sql_present": bool(state.get("generated_sql")),
        "generated_sql_redacted": _redact_sql(state.get("generated_sql")),
        "validated_sql_present": bool(state.get("validated_sql")),
        "validated_sql_redacted": _redact_sql(state.get("validated_sql")),
        "result_columns": (
            metadata.get("columns", [])
            or execution.get("columns", [])
        ),
        "first_three_rows": _safe_preview(records[:3]),
        "analysis_present": bool(analysis),
        "report_present": bool(report),
        "status": state.get("status"),
        "next_node": state.get("next_node"),
        "retry_count": state.get("retry_count"),
        "query_executed": execution_attempted,
        "execution_succeeded": execution.get("success") is True,
        "result_rows": len(records),
        "row_count": row_count,
        "execution_error": execution_error,
        "execution_error_category": (
            latest_error.get("category")
            if execution_error
            and latest_error.get("category") == "sql_execution"
            else None
        ),
        "sufficient_data": analysis.get("sufficient_data"),
        "grounded": grounded,
        "analysis_grounded": analysis_grounded,
        "report_grounded": report_grounded,
        "output_grounded": output_grounded,
        "analysis_grounding_issue_codes": analysis_grounding_codes,
        "report_grounding_issue_codes": report_grounding_codes,
        "output_grounding_issue_codes": output_grounding_codes,
    }


def _grounding_codes(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    codes: set[str] = set()
    for value in values:
        if isinstance(value, Mapping):
            code = value.get("code")
        elif isinstance(value, str):
            code = value.partition(":")[0]
        else:
            continue
        if isinstance(code, str) and code.strip():
            codes.add(code.strip())
    return sorted(codes)


def _redact_sql(value: Any) -> str | None:
    """Keep SQL shape useful for debugging while masking literal values."""
    import re
    if not isinstance(value, str) or not value.strip():
        return None
    redacted = re.sub(r"'(?:''|[^'])*'", "'?'", value)
    redacted = re.sub(r'"(?:""|[^"])*"', '"?"', redacted)
    redacted = re.sub(r"(?<![A-Za-z_])\\b\\d+(?:\\.\\d+)?\\b", "?", redacted)
    return redacted[:3000]


def _safe_preview(rows: list[Any]) -> list[dict[str, Any]]:
    """Bound and truncate result previews so log volume stays predictable."""
    preview: list[dict[str, Any]] = []
    for row in rows[:3]:
        if not isinstance(row, Mapping):
            continue
        preview.append({
            str(key): (str(value)[:120] if value is not None else None)
            for key, value in list(row.items())[:20]
        })
    return preview
