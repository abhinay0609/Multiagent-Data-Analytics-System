# Multi-Agent Data Analytics System — FastAPI + Streamlit

A five-agent analytics workflow using FastAPI, LangGraph, Ollama, MySQL and deterministic SQL/data validation.

## Current scope

This package includes a FastAPI backend and a Streamlit frontend. Streamlit authenticates through the API and submits analytics requests; it does not generate SQL or bypass backend authorization.

Workflow:
1. Input guardrail and backend authorization
2. Intent Understanding Agent
3. Planning Agent
4. Schema retrieval from the registered MySQL database
5. SQL Generation Agent
6. Deterministic SQL validation and bounded correction retries
7. Read-only query execution
8. Analysis Agent (Pandas/NumPy calculations + LLM interpretation)
9. Grounding validation
10. Reporting Agent and final output guardrail

Ollama handles intent, planning, and SQL generation. When GEMINI_API_KEY is
configured, Gemini handles the analysis and reporting narratives; otherwise
those agents use Ollama. Both agents retain deterministic fallbacks. Backend
permissions, SQL safety, database execution and numeric calculations remain
deterministic.

## Requirements

- Windows 10/11 or Linux
- Python 3.12 recommended for the pinned dependency set
- MySQL Server with the Northwind schema imported as `northwind_db`
- Ollama installed and running
- A MySQL account with SELECT-only permissions on `northwind_db`

Do not use the MySQL root account for normal analytics execution. The DB account used by the application should be read-only.

## Setup (Windows PowerShell)

Run these commands from the project root (the folder containing `run_api.py`):

```powershell
# 1. Create and activate a virtual environment
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1

# 2. Upgrade pip and install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 3. Create your local environment file
Copy-Item .env.example .env
# Edit .env and enter your own MySQL credentials, JWT secret, and bootstrap admin password.
# Add a Google AI Studio API key as GEMINI_API_KEY to enable Gemini for analysis/report narratives.

# 4. Check that Ollama is available and download the configured model
# Gemini is a hosted API model; install the google-genai package via requirements
# and configure GEMINI_API_KEY in .env (there is no local Gemini model to pull).
ollama serve
# In a second PowerShell window:
ollama pull llama3.2
ollama list

# 5. Start the API
python run_api.py
```

If PowerShell blocks activation, run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

If Python 3.12 is not installed, use an installed supported Python version and create a fresh virtual environment. Do not reuse a virtual environment created by another Python version.

## Run the Streamlit frontend

Start the API in one terminal:

```powershell
python run_api.py
```

Start Streamlit in a second terminal:

```powershell
python -m streamlit run streamlit_app.py
# or
python run_streamlit.py
```

Open the local Streamlit URL shown in the terminal (normally
`http://localhost:8501`). Sign in using the bootstrap administrator or another
account provisioned by your application. Set `ANALYTICS_API_URL` if the API is
not running at `http://127.0.0.1:8000`. Analytics requests wait up to 900
seconds by default; set `ANALYTICS_REQUEST_TIMEOUT_SECONDS` to adjust this for
your environment.

## Logging

Loguru writes concise console logs and rotating daily files under `logs/`.
Every workflow stage includes the request ID and stage name. Logs include
state-transition summaries, selected tables, SQL-presence/validation metadata,
result columns/counts and safe report diagnostics. Do not log secrets or full
customer result sets. Files rotate at 10 MB and are retained for 14 days.

## Verify the backend

Open:
- `http://127.0.0.1:8000/health`
- `http://127.0.0.1:8000/health/database`
- `http://127.0.0.1:8000/health/llm`
- `http://127.0.0.1:8000/docs`

Log in through the authentication endpoint in Swagger (`POST /api/auth/login`) using the bootstrap admin credentials configured in `.env`. Copy the returned access token.

Then call `POST /api/analytics/query` with a Bearer token and a JSON body such as:

```json
{
  "question": "Show top 5 customers by total sales",
  "database_name": "northwind",
  "max_retries": 2
}
```

Second test:
```json
{
  "question": "Which employees handled the highest value orders?",
  "database_name": "northwind",
  "max_retries": 2
}
```

The second question is interpreted as employee-level ranking by aggregated order-line value when the schema exposes the Employees → Orders → Order Details relationships. The SQL agent must use the exact table and column names retrieved from your live schema. If you mean individual highest-value orders rather than employees ranked by total value, ask: "Show the 10 highest-value individual orders with the employee who handled each order."

## What to expect in the API response

For a successful request, the response model includes:
- `status`
- `final_answer` (executive summary and returned result table)
- `report` (structured executive summary, findings, charts, recommendations, assumptions and limitations)
- `chart_specifications`
- `visualization_data`
- `query_executed`, `row_count`, `result_rows`
- `grounded`, `sufficient_data`
- `errors` and `retry_count`

A failed request returns HTTP 502 with a safe `detail` object containing a user-facing `final_answer`, `request_id`, retry count and normalized error information. SQL candidates and database credentials are not returned.

## Run tests

```powershell
python -m pytest -q
```

Some tests require the local MySQL database or Ollama service. Run the full suite with those dependencies available. If a test is environment-dependent, inspect its fixture/marker before treating a local integration failure as a code regression.

## Security and housekeeping

- `.env` is local-only and must never be committed or shared.
- `.env.example` contains placeholders only.
- Rotate database and bootstrap credentials if a real `.env` was shared outside your machine.
- Do not put passwords, JWT secrets, raw SQL with sensitive literals, or full customer records in logs.
- The API's database user should have SELECT-only grants.
- Keep `.venv`, `__pycache__`, `.pytest_cache`, generated logs and local secrets out of source-control archives.

## Known next phase

Once API responses are stable, build the Streamlit UI to consume the API. Add request-correlated UI/backend logging and a report visualization layer; do not duplicate SQL generation, authorization or workflow logic in Streamlit.


## Final output-grounding fix (20 Nov 2026)

The Reporting Agent and final Output Guardrail now include structured values
from `AnalysisResult.findings[*].evidence[*].values` and record identifiers,
in addition to raw SQL rows and calculated metrics/comparisons/trends/anomalies.
This fixes false `UNSUPPORTED_NUMBER` failures when a report accurately repeats
a calculated number retained in finding evidence but absent from top-level
metric collections. Numeric grounding and all safety checks remain enabled;
this change does not bypass the guardrail.

After replacing the project folder, run `python -m compileall .`, restart the
API, and retest. If it still fails, capture the full
`output_guardrail_result.issues` list rather than disabling final validation.


# V2 MCP integration and observability

## MCP design
V2 adds one Northwind Analytics MCP Server. The MCP server exposes:
- `list_databases`
- `get_database_schema`
- `get_schema_context`
- `get_table_schema`
- `get_table_relationships`
- `get_table_sample`
- `execute_readonly_query`

The lightweight YAML registry is at `mcp_integration/registry/registry_config.yaml`.
The synchronous LangGraph-facing client is `mcp_integration/client/mcp_client.py`.
The server is `mcp_integration/server/database_server.py`.

The current workflow uses MCP for SQL-agent schema-context discovery when
`MCP_ENABLED=true`. Existing SchemaService authorization and the established
SQL validation + QueryExecutor execution boundary remain in place. This is
intentional: MCP standardizes tool access without bypassing the existing
per-user authorization and SQL security path. The server's read-only execution
tool is provided for controlled integration/testing; do not expose it to
untrusted networks or route production requests through it until per-user
identity/authorization propagation is implemented end-to-end.

## MCP setup
Install dependencies:
```powershell
python -m pip install -r requirements.txt
```
Copy `.env.example` to `.env`, configure MySQL, Gemini and JWT credentials.
Set:
```env
MCP_ENABLED=true
MCP_HOST=127.0.0.1
MCP_PORT=8001
GEMINI_API_KEY=your_key
GEMINI_MODEL=gemini-2.5-flash
```
Start the MCP server in terminal 1:
```powershell
python -m mcp_integration.server.database_server
```
Start the FastAPI backend in terminal 2:
```powershell
python run_api.py
```
Start Streamlit in terminal 3:
```powershell
python -m streamlit run streamlit_app.py
```
If the MCP server is unavailable, set `MCP_ENABLED=false` and restart the API;
schema context then uses the existing SchemaService path.

## LLM routing
Deterministic SQL templates remain first for supported query shapes. For
LLM-generated SQL, Gemini is preferred when `GEMINI_API_KEY` is configured;
Ollama is the fallback when Gemini generation fails. Analysis and reporting
already use the shared narrative-model routing (Gemini first, Ollama fallback).
Numeric grounding is less brittle: a rounded/derived numeric token alone no
longer blocks a report. Entity, metric, schema, causal-claim and secret-leak
checks remain active. Treat model-generated recommendations as hypotheses
supported by observed patterns, not causal proof.

## Streamlit observability
The result panel now shows the final SQL used, per-node duration, and summed
workflow node time. API logs continue to include request IDs and node-level
start/end records. The summed stage time is not wall-clock time: it excludes
some request/API/frontend overhead and should be interpreted as the sum of
timed LangGraph node executions.

## Query validation checklist
Run these after connecting the Northwind MySQL database:
1. `How many customers are there?`
2. `Show the top 5 customers by total sales.`
3. `Which five customers generated the lowest total sales?`
4. `Show total sales by country.`
5. `Show net revenue for orders shipped to Germany.`
6. `Show the monthly revenue trend and highlight unusual months.`
7. `Which product categories contribute the most to total sales?`

Important schema check: the Germany-shipping question is only valid if the
actual sales-order schema contains a ship-country field. The workflow must
not silently substitute customer.country. If the field is absent, clarify
that the database cannot answer the requested shipping-country filter.
Monthly anomaly analysis needs enough distinct monthly observations; when
there are too few months, the report must state that limitation.

## Verification
Run:
```powershell
python -m compileall -q agents analytics api app auth config database graph guardrails mcp_integration services
pytest -q
```
End-to-end query success requires the user's local MySQL database and Gemini
API key; those external services are not available in a source-only build
environment. Validate all seven queries against the live Northwind schema
before presenting the ZIP as production-ready.
