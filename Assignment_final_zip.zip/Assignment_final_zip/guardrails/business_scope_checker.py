"""Classify user requests against the analytics MVP business scope."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class RequestCategory(str, Enum):
    """Top-level business-scope decision for a request."""

    SUPPORTED_ANALYTICS = "supported_analytics"
    SCHEMA_QUESTION = "schema_question"
    GENERAL_CONVERSATION = "general_conversation"
    UNSAFE_DATABASE_REQUEST = "unsafe_database_request"
    UNSUPPORTED_PREDICTIVE = "unsupported_predictive"
    DATABASE_MODIFICATION = "database_modification"
    UNSUPPORTED_DATABASE = "unsupported_database"
    CLARIFICATION_REQUIRED = "clarification_required"
    OUT_OF_SCOPE = "out_of_scope"


@dataclass(frozen=True)
class BusinessScopeResult:
    """Deterministic classification and routing guidance."""

    category: RequestCategory
    supported: bool
    reason: str
    requires_clarification: bool = False
    clarification_question: str | None = None
    requires_human_approval: bool = False


class BusinessScopeChecker:
    """Classify analytics, schema, unsafe, and out-of-scope requests."""

    _MODIFICATION_PATTERNS = (
        re.compile(
            r"\b(?:delete|erase|overwrite)\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?:drop|truncate|alter)\s+"
            r"(?:the\s+)?(?:(?:\w+)\s+){0,2}"
            r"(?:tables?|databases?|records?|rows?|data|"
            r"customers?|products?|orders?|employees?|suppliers?)\b|"
            r"\binsert\s+into\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?:update|modify|change|remove|create)\s+"
            r"(?:the\s+)?(?:database|table|record|row|data|customer|"
            r"product|order|employee|supplier)\b",
            re.IGNORECASE,
        ),
    )
    _UNSAFE_PATTERNS = (
        re.compile(r"\bmysql\s*\.\s*user\b", re.IGNORECASE),
        re.compile(r"\binformation_schema\b", re.IGNORECASE),
        re.compile(
            r"\b(?:system|internal)\s+(?:database|schema|tables?)\b",
            re.IGNORECASE,
        ),
    )
    _PREDICTIVE_PATTERN = re.compile(
        r"\b(?:predict|forecast|project|projection|"
        r"future\s+(?:sales|revenue|demand)|"
        r"next\s+(?:year|quarter|month).{0,30}\b(?:sales|revenue|demand))\b",
        re.IGNORECASE,
    )
    _SCHEMA_PATTERN = re.compile(
        r"\b(?:schema|tables?|columns?|"
        r"table\s+names?|column\s+names?|"
        r"fields?|database\s+structure|relationships?)\b",
        re.IGNORECASE,
    )
    _COMPARISON_PATTERN = re.compile(
        r"\b(?:compare|comparison|versus|vs\.?|year.over.year|"
        r"month.over.month)\b",
        re.IGNORECASE,
    )
    _TIME_OR_DIMENSION_PATTERN = re.compile(
        r"\b(?:by|between|from|to|during|in|for|"
        r"year|years|quarter|quarters|month|months|week|weeks|"
        r"day|days|period|periods|region|regions|category|categories|"
        r"product|products|customer|customers|"
        r"\d{4})\b|"
        r"\b(?:last|previous|current|this|past|next)\s+"
        r"(?:year|quarter|month|week|day)\b",
        re.IGNORECASE,
    )
    _DOMAIN_PATTERN = re.compile(
        r"\b(?:sales?|revenue|orders?|customers?|products?|"
        r"employees?|suppliers?|categories|shipments?|regions?|"
        r"territories|prices?|quantities|inventory|stock|"
        r"northwind)\b",
        re.IGNORECASE,
    )
    _GENERAL_PATTERN = re.compile(
        r"^\s*(?:hi|hello|hey|good morning|good afternoon|"
        r"good evening|thanks|thank you|who are you|"
        r"what can you do)\b",
        re.IGNORECASE,
    )
    _SENSITIVE_DATA_PATTERN = re.compile(
        r"\b(?:email(?:s)?|phone(?:\s+numbers?)?|mobile|"
        r"home\s+address(?:es)?|personal\s+data|"
        r"contact\s+details|individual\s+customer\s+records?)\b",
        re.IGNORECASE,
    )
    _BULK_EXPORT_PATTERN = re.compile(
        r"\b(?:export|download|dump|extract)\b|"
        r"\b(?:all|every|entire)\s+"
        r"(?:customers?|customer\s+records?|orders?|records?|rows?)\b",
        re.IGNORECASE,
    )
    _OTHER_DATABASES = re.compile(
        r"\b(?:postgres(?:ql)?|oracle|sql\s+server|snowflake|"
        r"bigquery|redshift|mongodb|salesforce|sap)\b",
        re.IGNORECASE,
    )
    _NAMED_DATASET_PATTERNS = (
        re.compile(
            r"\b(?:database|dataset|schema)\s+"
            r"(?:named|called)\s+([A-Za-z][\w-]*)\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?!(?:the|a|an|this|that|my)\b)"
            r"([A-Za-z][\w-]*)\s+"
            r"(?:database|dataset|schema)\b",
            re.IGNORECASE,
        ),
    )

    def __init__(
        self,
        supported_databases: tuple[str, ...] = (
            "northwind",
            "northwind_db",
        ),
    ) -> None:
        if not supported_databases:
            raise ValueError("supported_databases cannot be empty.")

        normalized_databases = {
            self._normalize_name(name)
            for name in supported_databases
        }
        self._supported_databases = frozenset(
            normalized_databases
        )

    def check(
        self,
        request: str,
        database_name: str = "northwind",
    ) -> BusinessScopeResult:
        """Return a deterministic scope classification for a request."""
        if not isinstance(request, str):
            raise TypeError("request must be a string.")

        if not isinstance(database_name, str):
            raise TypeError("database_name must be a string.")

        clean_request = request.strip()
        if not clean_request:
            raise ValueError("request cannot be empty.")

        normalized_database = self._normalize_name(database_name)

        if (
            normalized_database not in self._supported_databases
            or self._OTHER_DATABASES.search(clean_request)
            or self._mentions_unsupported_dataset(clean_request)
        ):
            return self._result(
                RequestCategory.UNSUPPORTED_DATABASE,
                "Only the configured Northwind database is supported.",
            )

        if any(
            pattern.search(clean_request)
            for pattern in self._MODIFICATION_PATTERNS
        ):
            return self._result(
                RequestCategory.DATABASE_MODIFICATION,
                "Database modifications are not allowed; the analytics "
                "service is read-only.",
            )

        if any(
            pattern.search(clean_request)
            for pattern in self._UNSAFE_PATTERNS
        ):
            return self._result(
                RequestCategory.UNSAFE_DATABASE_REQUEST,
                "System and internal database schemas are not available.",
            )

        if self._PREDICTIVE_PATTERN.search(clean_request):
            return self._result(
                RequestCategory.UNSUPPORTED_PREDICTIVE,
                "Predictive and future forecasting features are outside "
                "the current MVP scope.",
            )

        if (
            self._COMPARISON_PATTERN.search(clean_request)
            and not self._TIME_OR_DIMENSION_PATTERN.search(
                clean_request
            )
        ):
            return BusinessScopeResult(
                category=RequestCategory.CLARIFICATION_REQUIRED,
                supported=False,
                reason="The comparison target or period is missing.",
                requires_clarification=True,
                clarification_question=(
                    "Which time periods or business categories would you "
                    "like to compare?"
                ),
            )

        if self._SCHEMA_PATTERN.search(clean_request):
            return self._result(
                RequestCategory.SCHEMA_QUESTION,
                "Schema and table-discovery questions are supported.",
                supported=True,
            )

        if self._GENERAL_PATTERN.search(clean_request):
            return self._result(
                RequestCategory.GENERAL_CONVERSATION,
                "This is general conversation rather than a database "
                "analytics request.",
            )

        if self._DOMAIN_PATTERN.search(clean_request):
            requires_approval = bool(
                self._SENSITIVE_DATA_PATTERN.search(clean_request)
                or self._BULK_EXPORT_PATTERN.search(clean_request)
            )
            reason = (
                "The analytics request is within the Northwind MVP scope."
            )
            if requires_approval:
                reason += (
                    " Sensitive or bulk record-level data requires "
                    "human approval before execution."
                )

            return self._result(
                RequestCategory.SUPPORTED_ANALYTICS,
                reason,
                supported=True,
                requires_human_approval=requires_approval,
            )

        return self._result(
            RequestCategory.OUT_OF_SCOPE,
            "The request is not a supported Northwind analytics or "
            "schema question.",
        )

    @staticmethod
    def _normalize_name(name: str) -> str:
        if not isinstance(name, str):
            raise TypeError("Database names must be strings.")
        clean_name = name.strip().casefold()
        if not clean_name:
            raise ValueError("Database names cannot be empty.")
        return clean_name

    def _mentions_unsupported_dataset(self, request: str) -> bool:
        for pattern in self._NAMED_DATASET_PATTERNS:
            for match in pattern.finditer(request):
                requested_name = next(
                    (
                        group
                        for group in match.groups()
                        if group is not None
                    ),
                    "",
                ).casefold()
                if (
                    requested_name
                    and requested_name not in self._supported_databases
                ):
                    return True
        return False

    @staticmethod
    def _result(
        category: RequestCategory,
        reason: str,
        supported: bool = False,
        requires_human_approval: bool = False,
    ) -> BusinessScopeResult:
        return BusinessScopeResult(
            category=category,
            supported=supported,
            reason=reason,
            requires_human_approval=requires_human_approval,
        )


business_scope_checker = BusinessScopeChecker()