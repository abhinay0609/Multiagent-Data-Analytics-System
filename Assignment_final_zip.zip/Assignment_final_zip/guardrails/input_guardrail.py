"""Validate, sanitize, and classify untrusted user input."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from guardrails.business_scope_checker import (
    BusinessScopeChecker,
    BusinessScopeResult,
    RequestCategory,
    business_scope_checker,
)


@dataclass(frozen=True)
class InputGuardrailResult:
    """Input decision returned to the calling workflow."""

    accepted: bool
    normalized_input: str | None
    category: RequestCategory | None
    reason: str
    requires_clarification: bool = False
    clarification_question: str | None = None
    requires_human_approval: bool = False
    issue_code: str | None = None
    scope_result: BusinessScopeResult | None = None

    @property
    def should_continue_to_analytics(self) -> bool:
        """Return whether the request can enter analytical processing."""
        return (
            self.accepted
            and self.category
            in {
                RequestCategory.SUPPORTED_ANALYTICS,
                RequestCategory.SCHEMA_QUESTION,
            }
            and not self.requires_clarification
            and not self.requires_human_approval
        )


class InputGuardrail:
    """Reject malformed, unsafe, or unsupported requests before planning."""

    _DIRECT_SQL_PATTERN = re.compile(
        r"^\s*(?:```(?:sql)?\s*)?"
        r"(?:SELECT|WITH|INSERT|UPDATE|DELETE|DROP|ALTER|"
        r"CREATE|TRUNCATE|REPLACE)\b",
        re.IGNORECASE,
    )
    _INJECTION_PATTERNS = (
        re.compile(
            r"\bUNION\s+(?:ALL\s+)?SELECT\b",
            re.IGNORECASE,
        ),
        re.compile(
            r";\s*(?:SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|"
            r"TRUNCATE|REPLACE)\b",
            re.IGNORECASE,
        ),
        re.compile(r"/\*|\*/|--(?=\s|$)", re.IGNORECASE),
        re.compile(
            r"""['"]\s*(?:OR|AND)\s+"""
            r"""(?:['"]?\w+['"]?\s*=\s*['"]?\w+|"""
            r"""['"]?\d+['"]?\s*=\s*['"]?\d+)""",
            re.IGNORECASE,
        ),
    )
    _PROMPT_INJECTION_PATTERNS = (
        re.compile(
            r"\b(?:ignore|disregard|forget)\b.{0,50}\b"
            r"(?:previous|prior|above|all)\s+"
            r"(?:instructions?|rules?|messages?)\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?:reveal|print|show|repeat|expose)\b.{0,40}\b"
            r"(?:system|developer|internal)\s+"
            r"(?:prompt|instructions?|message)\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?:override|bypass|jailbreak)\b.{0,40}\b"
            r"(?:guardrails?|instructions?|polic(?:y|ies)|rules?)\b",
            re.IGNORECASE,
        ),
        re.compile(
            r"\bact\s+as\s+(?:an?\s+)?(?:unrestricted|unfiltered|"
            r"jailbroken)\b",
            re.IGNORECASE,
        ),
    )
    _CREDENTIAL_PATTERN = re.compile(
        r"\b(?:passwords?|credentials?|api[\s_-]*keys?|"
        r"access\s+tokens?|private\s+keys?|connection\s+strings?|"
        r"database\s+urls?|secrets?)\b",
        re.IGNORECASE,
    )

    def __init__(
        self,
        max_characters: int = 2000,
        scope_checker: BusinessScopeChecker | None = None,
    ) -> None:
        if not isinstance(max_characters, int):
            raise TypeError("max_characters must be an integer.")
        if max_characters < 1:
            raise ValueError("max_characters must be at least 1.")
        if (
            scope_checker is not None
            and not isinstance(scope_checker, BusinessScopeChecker)
        ):
            raise TypeError(
                "scope_checker must be a BusinessScopeChecker instance."
            )

        self._max_characters = max_characters
        self._scope_checker = (
            scope_checker
            if scope_checker is not None
            else business_scope_checker
        )

    def validate(
        self,
        user_input: str,
        database_name: str = "northwind",
    ) -> InputGuardrailResult:
        """Sanitize and evaluate a user request before it reaches agents."""
        if not isinstance(user_input, str):
            raise TypeError("user_input must be a string.")

        clean_input = self._sanitize(user_input)
        if not clean_input:
            return self._reject(
                RequestCategory.OUT_OF_SCOPE,
                "Enter a question before continuing.",
                "EMPTY_INPUT",
            )

        if len(clean_input) > self._max_characters:
            return self._reject(
                RequestCategory.OUT_OF_SCOPE,
                f"Requests must be {self._max_characters} characters "
                "or fewer.",
                "INPUT_TOO_LONG",
            )

        if any(
            pattern.search(clean_input)
            for pattern in self._PROMPT_INJECTION_PATTERNS
        ):
            return self._reject(
                RequestCategory.UNSAFE_DATABASE_REQUEST,
                "The request attempts to override internal instructions "
                "and cannot be processed.",
                "PROMPT_INJECTION",
                clean_input,
            )

        if self._CREDENTIAL_PATTERN.search(clean_input):
            return self._reject(
                RequestCategory.UNSAFE_DATABASE_REQUEST,
                "Requests to disclose credentials or secrets are not "
                "allowed.",
                "CREDENTIAL_REQUEST",
                clean_input,
            )

        if self._is_sql_injection(clean_input):
            return self._reject(
                RequestCategory.UNSAFE_DATABASE_REQUEST,
                "Direct SQL and SQL-injection patterns are not accepted "
                "as user questions.",
                "SQL_INJECTION",
                clean_input,
            )

        scope_result = self._scope_checker.check(
            request=clean_input,
            database_name=database_name,
        )

        if scope_result.category in {
            RequestCategory.DATABASE_MODIFICATION,
            RequestCategory.UNSAFE_DATABASE_REQUEST,
            RequestCategory.UNSUPPORTED_PREDICTIVE,
            RequestCategory.UNSUPPORTED_DATABASE,
            RequestCategory.OUT_OF_SCOPE,
        }:
            return InputGuardrailResult(
                accepted=False,
                normalized_input=clean_input,
                category=scope_result.category,
                reason=scope_result.reason,
                requires_clarification=(
                    scope_result.requires_clarification
                ),
                clarification_question=(
                    scope_result.clarification_question
                ),
                requires_human_approval=(
                    scope_result.requires_human_approval
                ),
                issue_code=scope_result.category.value.upper(),
                scope_result=scope_result,
            )

        return InputGuardrailResult(
            accepted=True,
            normalized_input=clean_input,
            category=scope_result.category,
            reason=scope_result.reason,
            requires_clarification=(
                scope_result.requires_clarification
            ),
            clarification_question=(
                scope_result.clarification_question
            ),
            requires_human_approval=(
                scope_result.requires_human_approval
            ),
            scope_result=scope_result,
        )

    @classmethod
    def _is_sql_injection(cls, value: str) -> bool:
        if cls._DIRECT_SQL_PATTERN.search(value):
            return True
        return any(
            pattern.search(value)
            for pattern in cls._INJECTION_PATTERNS
        )

    @staticmethod
    def _sanitize(value: str) -> str:
        sanitized = "".join(
            " "
            if unicodedata.category(character) == "Cc"
            and character not in {"\n", "\t", "\r"}
            else character
            for character in value
        )
        return sanitized.strip()

    @staticmethod
    def _reject(
        category: RequestCategory,
        reason: str,
        issue_code: str,
        normalized_input: str | None = None,
    ) -> InputGuardrailResult:
        return InputGuardrailResult(
            accepted=False,
            normalized_input=normalized_input,
            category=category,
            reason=reason,
            issue_code=issue_code,
        )


input_guardrail = InputGuardrail()