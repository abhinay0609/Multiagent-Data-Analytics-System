"""Screen final responses before they are returned to a user."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from guardrails.grounding_validator import (
    GroundingResult,
    GroundingValidator,
    grounding_validator,
)


@dataclass(frozen=True)
class OutputGuardrailResult:
    """Whether a response may be displayed and the validated text."""

    approved: bool
    output: str | None
    issues: tuple[str, ...]
    grounding_result: GroundingResult


class OutputGuardrail:
    """Block secret leakage, internal traces, and ungrounded claims."""

    _SECRET_PATTERNS = (
        re.compile(
            r"\b(?:password|passwd|secret|api[\s_-]*key|"
            r"access[\s_-]*token|private[\s_-]*key|"
            r"connection[\s_-]*string)\b\s*(?::|=|\bis\b)\s*\S+",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?:credentials?|login\s+details?)\b"
            r"\s*(?::|=|\bare\b)\s*\S+",
            re.IGNORECASE,
        ),
        re.compile(
            r"\b(?:mysql|postgres(?:ql)?)://[^/\s:@]+:"
            r"[^@\s/]+@",
            re.IGNORECASE,
        ),
        re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
        re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    )
    _INTERNAL_PROMPT_PATTERN = re.compile(
        r"\b(?:system|developer|internal)\s+"
        r"(?:prompt|instructions?|message)\b|"
        r"\b(?:ignore|disregard)\s+(?:all\s+)?"
        r"(?:previous|prior|above)\s+instructions\b",
        re.IGNORECASE,
    )
    _STACK_TRACE_PATTERN = re.compile(
        r"Traceback\s+\(most\s+recent\s+call\s+last\):|"
        r"^\s*File\s+['\"].*?['\"],\s+line\s+\d+|"
        r"^\s*[A-Za-z_][\w.]*"
        r"(?:Error|Exception):",
        re.IGNORECASE | re.MULTILINE,
    )
    _DESTRUCTIVE_SQL_PATTERN = re.compile(
        r"\b(?:drop\s+(?:table|database)|delete\s+(?:from|all)|"
        r"truncate(?:\s+table)?|alter\s+(?:table|database)|"
        r"update\s+\w+\s+set|insert\s+into)\b",
        re.IGNORECASE,
    )
    _DESTRUCTIVE_ACTION_PATTERN = re.compile(
        r"\b(?:delete|remove|erase|truncate|overwrite|drop)\b"
        r".{0,60}\b(?:database|table|data|records?|rows?|"
        r"customers?|orders?|products?)\b",
        re.IGNORECASE,
    )
    _RECOMMENDATION_PATTERN = re.compile(
        r"\b(?:recommend(?:ation)?|should|must|need\s+to|"
        r"suggest(?:s|ed)?|consider|please|run|execute|perform)\b",
        re.IGNORECASE,
    )
    _NEGATION_PATTERN = re.compile(
        r"\b(?:do\s+not|don't|never|avoid|should\s+not|must\s+not)\b",
        re.IGNORECASE,
    )

    def __init__(
        self,
        grounding_validator_instance: GroundingValidator | None = None,
    ) -> None:
        if (
            grounding_validator_instance is not None
            and not isinstance(
                grounding_validator_instance,
                GroundingValidator,
            )
        ):
            raise TypeError(
                "grounding_validator_instance must be a "
                "GroundingValidator instance."
            )
        self._grounding_validator = (
            grounding_validator_instance
            if grounding_validator_instance is not None
            else grounding_validator
        )

    def validate(
        self,
        answer: str,
        query_results: Sequence[Mapping[str, Any]],
        *,
        result_columns: Sequence[str] | None = None,
        referenced_tables: Sequence[str] = (),
        known_tables: Sequence[str] = (),
        known_columns: Sequence[str] = (),
        metric_aliases: Mapping[str, Sequence[str]] | None = None,
        user_query: str | None = None,
        data_sufficient: bool | None = None,
        result_count: int | None = None,
    ) -> OutputGuardrailResult:
        """Return displayable output only when every check succeeds."""
        if not isinstance(answer, str):
            raise TypeError("answer must be a string.")

        clean_answer = answer.strip()
        issues: list[str] = []

        if not clean_answer:
            issues.append("EMPTY_OUTPUT: Final output cannot be empty.")

        if any(pattern.search(clean_answer) for pattern in self._SECRET_PATTERNS):
            issues.append(
                "SECRET_LEAK: Final output contains a credential or "
                "connection secret."
            )

        if self._INTERNAL_PROMPT_PATTERN.search(clean_answer):
            issues.append(
                "INTERNAL_PROMPT_LEAK: Final output exposes internal "
                "instructions or prompt content."
            )

        if self._STACK_TRACE_PATTERN.search(clean_answer):
            issues.append(
                "STACK_TRACE: Final output contains a raw stack trace."
            )

        if self._contains_destructive_recommendation(clean_answer):
            issues.append(
                "DESTRUCTIVE_RECOMMENDATION: Final output recommends a "
                "destructive database operation."
            )

        grounding = self._grounding_validator.validate(
            answer=clean_answer,
            query_results=query_results,
            result_columns=result_columns,
            referenced_tables=referenced_tables,
            known_tables=known_tables,
            known_columns=known_columns,
            metric_aliases=metric_aliases,
            user_query=user_query,
            data_sufficient=data_sufficient,
            result_count=result_count,
        )
        issues.extend(
            f"{issue.code}: {issue.message}"
            for issue in grounding.issues
        )

        unique_issues = tuple(dict.fromkeys(issues))
        approved = not unique_issues
        return OutputGuardrailResult(
            approved=approved,
            output=clean_answer if approved else None,
            issues=unique_issues,
            grounding_result=grounding,
        )

    @classmethod
    def _contains_destructive_recommendation(
        cls,
        answer: str,
    ) -> bool:
        for sentence in re.split(r"(?<=[.!?])\s+", answer):
            destructive_action = (
                cls._DESTRUCTIVE_SQL_PATTERN.search(sentence)
                or cls._DESTRUCTIVE_ACTION_PATTERN.search(sentence)
            )
            if not destructive_action:
                continue
            if cls._NEGATION_PATTERN.search(sentence):
                continue
            if (
                cls._RECOMMENDATION_PATTERN.search(sentence)
                or destructive_action.start() == 0
            ):
                return True
        return False


output_guardrail = OutputGuardrail()