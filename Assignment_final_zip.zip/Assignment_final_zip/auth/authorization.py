"""Backend role and database permission enforcement."""

from __future__ import annotations

from enum import Enum

from models.auth_models import ROLE_DEFINITIONS
from schemas.user_schema import (
    AuthorizationResult,
    Permission,
    UserIdentity,
    UserRole,
    UserStatus,
)


class AuthorizationService:
    """Authorize operations using explicit, server-defined permissions."""

    _PERMISSION_DATABASES: dict[Permission, str | None] = {
        Permission.NORTHWIND_READ: "northwind",
        Permission.SCHEMA_READ: "northwind",
        Permission.REPORTS_READ: "northwind",
        Permission.ANALYTICS_EXECUTE: "northwind",
        Permission.TRACES_READ: None,
        Permission.USERS_MANAGE: None,
    }

    def __init__(
        self,
        default_database_name: str = "northwind",
    ) -> None:
        self._default_database_name = self._normalize_database_name(
            default_database_name
        )

    def authorize(
        self,
        user: UserIdentity,
        required_permission: Permission | str,
        database_name: str | None = None,
    ) -> AuthorizationResult:
        """Return a backend authorization decision for a user operation."""
        if not isinstance(user, UserIdentity):
            raise TypeError("user must be a UserIdentity instance.")
        if isinstance(required_permission, str):
            try:
                required_permission = Permission(required_permission)
            except ValueError:
                return self._deny(
                    f"Permission '{required_permission}' is not recognized."
                )
        elif not isinstance(required_permission, Permission):
            raise TypeError(
                "required_permission must be a Permission or string."
            )

        username = user.username
        if self._enum_value(user.status) != UserStatus.ACTIVE.value:
            return self._deny(
                f"User account '{username}' is not active."
            )

        role_name = self._enum_value(user.role)
        try:
            role = UserRole(role_name)
        except ValueError:
            return self._deny(
                f"User '{username}' has an unsupported role."
            )

        role_definition = ROLE_DEFINITIONS[role]
        assigned_permissions = {
            self._enum_value(permission)
            for permission in user.permissions
        }
        effective_permissions = {
            permission.value
            for permission in role_definition.permissions
        } & assigned_permissions

        required_value = required_permission.value
        if required_value not in effective_permissions:
            return self._deny(
                f"User '{username}' does not have permission "
                f"'{required_value}'.",
                missing_permission=required_value,
            )

        required_database = self._PERMISSION_DATABASES.get(
            required_permission
        )
        selected_database: str | None = None

        if required_database is not None:
            selected_database = self._normalize_database_name(
                database_name or self._default_database_name
            )
            if selected_database != required_database:
                return self._deny(
                    f"Permission '{required_value}' does not grant "
                    f"access to database '{selected_database}'."
                )

            user_databases = {
                self._normalize_database_name(name)
                for name in user.allowed_databases
            }
            if (
                selected_database not in user_databases
                or selected_database
                not in role_definition.allowed_databases
            ):
                return self._deny(
                    f"User '{username}' is not authorized for database "
                    f"'{selected_database}'."
                )

        scope_description = (
            f"database '{selected_database}'"
            if selected_database is not None
            else "this operation"
        )
        return AuthorizationResult(
            allowed=True,
            reason=(
                f"User '{username}' is authorized for "
                f"'{required_value}' on {scope_description}."
            ),
        )

    @staticmethod
    def _deny(
        reason: str,
        missing_permission: str | None = None,
    ) -> AuthorizationResult:
        return AuthorizationResult(
            allowed=False,
            reason=reason,
            missing_permission=missing_permission,
        )

    @staticmethod
    def _enum_value(value: object) -> str:
        if isinstance(value, Enum):
            return str(value.value)
        if isinstance(value, str):
            return value
        raise TypeError("User permission fields must be strings or enums.")

    @staticmethod
    def _normalize_database_name(name: str) -> str:
        if not isinstance(name, str):
            raise TypeError("database_name must be a string.")
        normalized = name.strip().casefold()
        if not normalized:
            raise ValueError("database_name cannot be empty.")
        return normalized


authorization_service = AuthorizationService()