"""Signed access-token creation and validation."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Mapping
from uuid import uuid4

from jose import JWTError, jwt
from pydantic import ValidationError

from config.settings import settings
from schemas.user_schema import (
    TokenPayload,
    UserIdentity,
    UserRole,
    UserStatus,
)


class InvalidAccessTokenError(ValueError):
    """Raised when an access token is malformed, invalid, or expired."""


class JWTHandler:
    """Create and verify JWT access tokens using application settings."""

    _SUPPORTED_ALGORITHMS = frozenset(
        {"HS256", "HS384", "HS512"}
    )

    def __init__(
        self,
        secret_key: str | None = None,
        algorithm: str | None = None,
        expires_in_seconds: int | None = None,
    ) -> None:
        resolved_secret = (
            settings.JWT_SECRET_KEY
            if secret_key is None
            else secret_key
        )
        resolved_algorithm = (
            settings.JWT_ALGORITHM
            if algorithm is None
            else algorithm
        )
        resolved_expiration = (
            settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60
            if expires_in_seconds is None
            else expires_in_seconds
        )

        if not isinstance(resolved_secret, str) or not resolved_secret:
            raise ValueError("JWT secret_key cannot be empty.")
        if resolved_algorithm not in self._SUPPORTED_ALGORITHMS:
            raise ValueError(
                "JWT algorithm must be one of HS256, HS384, or HS512."
            )
        if not isinstance(resolved_expiration, int):
            raise TypeError("expires_in_seconds must be an integer.")
        if resolved_expiration < 1:
            raise ValueError("expires_in_seconds must be at least 1.")

        self._secret_key = resolved_secret
        self._algorithm = resolved_algorithm
        self._expires_in_seconds = resolved_expiration

    @property
    def expires_in_seconds(self) -> int:
        """Return the configured default access-token lifetime."""
        return self._expires_in_seconds

    def create_access_token(
        self,
        user: UserIdentity,
        expires_delta: timedelta | None = None,
    ) -> str:
        """Sign an access token containing safe user claims."""
        if not isinstance(user, UserIdentity):
            raise TypeError("user must be a UserIdentity instance.")

        if self._enum_value(user.status) != UserStatus.ACTIVE.value:
            raise ValueError("Cannot create a token for an inactive user.")

        lifetime = (
            timedelta(seconds=self._expires_in_seconds)
            if expires_delta is None
            else expires_delta
        )
        if not isinstance(lifetime, timedelta):
            raise TypeError("expires_delta must be a timedelta or None.")

        lifetime_seconds = int(lifetime.total_seconds())
        if lifetime_seconds < 1:
            raise ValueError("Token lifetime must be at least one second.")

        issued_at = datetime.now(timezone.utc)
        issued_at_seconds = int(issued_at.timestamp())
        expires_at_seconds = issued_at_seconds + lifetime_seconds
        role = UserRole(self._enum_value(user.role))

        claims: dict[str, Any] = {
            "sub": user.user_id,
            "username": user.username,
            "role": role.value,
            "permissions": [
                self._enum_value(permission)
                for permission in user.permissions
            ],
            "allowed_databases": list(user.allowed_databases),
            "iat": issued_at_seconds,
            "exp": expires_at_seconds,
            "jti": str(uuid4()),
        }

        return jwt.encode(
            claims,
            self._secret_key,
            algorithm=self._algorithm,
        )

    def decode_access_token(
        self,
        token: str,
    ) -> TokenPayload:
        """Verify signature and expiry, then validate token claims."""
        if not isinstance(token, str):
            raise TypeError("token must be a string.")
        if not token.strip():
            raise InvalidAccessTokenError("Access token cannot be empty.")

        try:
            claims = jwt.decode(
                token,
                self._secret_key,
                algorithms=[self._algorithm],
                options={
                    "require_exp": True,
                    "require_iat": True,
                    "require_sub": True,
                },
            )
            if not isinstance(claims, Mapping):
                raise InvalidAccessTokenError(
                    "Access token claims are invalid."
                )

            return TokenPayload(
                sub=claims["sub"],
                username=claims["username"],
                role=claims["role"],
                permissions=claims["permissions"],
                allowed_databases=claims["allowed_databases"],
                issued_at=claims["iat"],
                expires_at=claims["exp"],
                token_id=claims["jti"],
            )
        except InvalidAccessTokenError:
            raise
        except (
            JWTError,
            ValidationError,
            KeyError,
            TypeError,
            ValueError,
        ) as exc:
            raise InvalidAccessTokenError(
                "Access token is invalid or expired."
            ) from exc

    @staticmethod
    def _enum_value(value: object) -> str:
        if isinstance(value, Enum):
            return str(value.value)
        if isinstance(value, str):
            return value
        raise TypeError("Token identity fields must be strings or enums.")


jwt_handler = JWTHandler()


def create_access_token(
    user: UserIdentity,
    expires_delta: timedelta | None = None,
) -> str:
    """Module-level helper for creating a signed access token."""
    return jwt_handler.create_access_token(
        user,
        expires_delta=expires_delta,
    )


def decode_access_token(token: str) -> TokenPayload:
    """Module-level helper for validating a signed access token."""
    return jwt_handler.decode_access_token(token)