"""Authentication, signed-token, and authorization services."""

from auth.authentication import (
    AuthenticationError,
    AuthenticationService,
    DuplicateUserError,
    InvalidCredentialsError,
    authentication_service,
)
from auth.authorization import (
    AuthorizationService,
    authorization_service,
)
from auth.jwt_handler import (
    InvalidAccessTokenError,
    JWTHandler,
    create_access_token,
    decode_access_token,
    jwt_handler,
)
from auth.password_manager import (
    PasswordManager,
    hash_password,
    password_manager,
    verify_password,
)

__all__ = [
    "AuthenticationError",
    "AuthenticationService",
    "AuthorizationService",
    "DuplicateUserError",
    "InvalidAccessTokenError",
    "InvalidCredentialsError",
    "JWTHandler",
    "PasswordManager",
    "authentication_service",
    "authorization_service",
    "create_access_token",
    "decode_access_token",
    "hash_password",
    "jwt_handler",
    "password_manager",
    "verify_password",
]