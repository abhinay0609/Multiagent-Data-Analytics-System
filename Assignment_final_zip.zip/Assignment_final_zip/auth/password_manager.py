"""Password hashing and verification for local application accounts."""

from __future__ import annotations

from passlib.context import CryptContext
from passlib.exc import PasslibSecurityError


_PASSWORD_CONTEXT = CryptContext(
    schemes=["pbkdf2_sha256"],
    pbkdf2_sha256__rounds=600_000,
    deprecated="auto",
)


class PasswordManager:
    """Hash passwords with PBKDF2-SHA256 and verify stored hashes."""

    def hash_password(self, password: str) -> str:
        """Return a salted password hash suitable for storage."""
        self._validate_password(password)
        return _PASSWORD_CONTEXT.hash(password)

    def verify_password(
        self,
        password: str,
        password_hash: str,
    ) -> bool:
        """Compare a candidate password without exposing hash errors."""
        if not isinstance(password, str):
            raise TypeError("password must be a string.")
        if not isinstance(password_hash, str):
            raise TypeError("password_hash must be a string.")
        if not password_hash:
            return False

        try:
            return _PASSWORD_CONTEXT.verify(
                password,
                password_hash,
            )
        except (PasslibSecurityError, ValueError):
            return False

    @staticmethod
    def _validate_password(password: str) -> None:
        if not isinstance(password, str):
            raise TypeError("password must be a string.")
        if len(password) < 8:
            raise ValueError(
                "Passwords must contain at least 8 characters."
            )
        if not password.strip():
            raise ValueError("Password cannot contain only whitespace.")
        if len(password) > 256:
            raise ValueError(
                "Passwords cannot exceed 256 characters."
            )


password_manager = PasswordManager()


def hash_password(password: str) -> str:
    """Module-level helper for hashing a password."""
    return password_manager.hash_password(password)


def verify_password(
    password: str,
    password_hash: str,
) -> bool:
    """Module-level helper for password verification."""
    return password_manager.verify_password(
        password,
        password_hash,
    )