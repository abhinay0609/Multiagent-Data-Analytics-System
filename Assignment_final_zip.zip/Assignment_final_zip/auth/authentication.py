"""MVP user lookup, login, and authenticated-token resolution."""

from __future__ import annotations

from threading import RLock
from typing import Sequence
from uuid import uuid4

from pydantic import ValidationError

from auth.jwt_handler import (
    InvalidAccessTokenError,
    JWTHandler,
    jwt_handler,
)
from auth.password_manager import (
    PasswordManager,
    password_manager,
)
from models.auth_models import (
    InternalUser,
    ROLE_DEFINITIONS,
)
from schemas.user_schema import (
    LoginRequest,
    TokenResponse,
    UserIdentity,
    UserRole,
    UserStatus,
)


class AuthenticationError(RuntimeError):
    """Base error for authentication operations."""


class InvalidCredentialsError(AuthenticationError):
    """Raised when a login cannot be authenticated."""


class DuplicateUserError(AuthenticationError):
    """Raised when a username or user identifier is already registered."""


class AuthenticationService:
    """Authenticate accounts and return server-created user identities.

    The default store is in-memory for the MVP. Applications should load
    internal account records from their approved user store at startup.
    """

    def __init__(
        self,
        users: Sequence[InternalUser] = (),
        password_manager_instance: PasswordManager | None = None,
        jwt_handler_instance: JWTHandler | None = None,
    ) -> None:
        if (
            password_manager_instance is not None
            and not isinstance(password_manager_instance, PasswordManager)
        ):
            raise TypeError(
                "password_manager_instance must be a PasswordManager."
            )
        if (
            jwt_handler_instance is not None
            and not isinstance(jwt_handler_instance, JWTHandler)
        ):
            raise TypeError(
                "jwt_handler_instance must be a JWTHandler."
            )
        if any(not isinstance(user, InternalUser) for user in users):
            raise TypeError("users must contain InternalUser instances.")

        self._password_manager = (
            password_manager_instance
            if password_manager_instance is not None
            else password_manager
        )
        self._jwt_handler = (
            jwt_handler_instance
            if jwt_handler_instance is not None
            else jwt_handler
        )
        self._users_by_username: dict[str, InternalUser] = {}
        self._users_by_id: dict[str, InternalUser] = {}
        self._lock = RLock()
        self._dummy_password_hash: str | None = None

        for user in users:
            self._store_user(user)

    def register_user(
        self,
        username: str,
        password: str,
        role: UserRole,
        display_name: str | None = None,
        status: UserStatus = UserStatus.ACTIVE,
    ) -> UserIdentity:
        """Provision an account with permissions assigned by role policy.

        This method is for trusted setup/admin code and must not be exposed
        as an unauthenticated client operation.
        """
        try:
            login_request = LoginRequest(
                username=username,
                password=password,
            )
        except ValidationError as exc:
            raise ValueError(
                "Username or password does not meet the account policy."
            ) from exc

        if not isinstance(role, UserRole):
            raise TypeError("role must be a UserRole value.")
        if not isinstance(status, UserStatus):
            raise TypeError("status must be a UserStatus value.")
        if display_name is not None and not isinstance(display_name, str):
            raise TypeError("display_name must be a string or None.")

        normalized_username = login_request.username
        clean_display_name = (
            normalized_username
            if display_name is None
            else display_name.strip()
        )
        if not clean_display_name:
            raise ValueError("display_name cannot be empty.")

        role_policy = ROLE_DEFINITIONS[role]
        internal_user = InternalUser(
            user_id=str(uuid4()),
            username=normalized_username,
            display_name=clean_display_name,
            password_hash=self._password_manager.hash_password(
                login_request.password.get_secret_value()
            ),
            role=role,
            permissions=role_policy.permissions,
            status=status,
            allowed_databases=role_policy.allowed_databases,
        )

        with self._lock:
            self._store_user(internal_user)

        return internal_user.to_identity()

    def login(
        self,
        username: str,
        password: str,
    ) -> TokenResponse:
        """Verify credentials and issue a signed access token."""
        try:
            request = LoginRequest(
                username=username,
                password=password,
            )
        except ValidationError as exc:
            raise InvalidCredentialsError(
                "Invalid username or password."
            ) from exc

        normalized_username = request.username
        with self._lock:
            user = self._users_by_username.get(normalized_username)

        candidate_password = request.password.get_secret_value()
        if user is None:
            self._password_manager.verify_password(
                candidate_password,
                self._get_dummy_password_hash(),
            )
            raise InvalidCredentialsError(
                "Invalid username or password."
            )

        password_matches = self._password_manager.verify_password(
            candidate_password,
            user.password_hash,
        )
        if (
            not password_matches
            or user.status != UserStatus.ACTIVE
        ):
            raise InvalidCredentialsError(
                "Invalid username or password."
            )

        identity = user.to_identity()
        token = self._jwt_handler.create_access_token(identity)
        return TokenResponse(
            access_token=token,
            expires_in_seconds=self._jwt_handler.expires_in_seconds,
            user=identity,
        )

    def authenticate_token(self, token: str) -> UserIdentity:
        """Resolve a verified token to the current active account."""
        payload = self._jwt_handler.decode_access_token(token)

        with self._lock:
            user = self._users_by_id.get(payload.sub)

        if (
            user is None
            or user.status != UserStatus.ACTIVE
            or user.username != payload.username
        ):
            raise InvalidAccessTokenError(
                "Access token is invalid or expired."
            )

        return user.to_identity()

    def get_user_by_username(
        self,
        username: str,
    ) -> UserIdentity | None:
        """Look up a user without exposing internal password data."""
        if not isinstance(username, str):
            raise TypeError("username must be a string.")

        with self._lock:
            user = self._users_by_username.get(
                username.strip().casefold()
            )
        return user.to_identity() if user is not None else None

    def get_user_by_id(
        self,
        user_id: str,
    ) -> UserIdentity | None:
        """Look up a user by ID without exposing internal password data."""
        if not isinstance(user_id, str):
            raise TypeError("user_id must be a string.")

        with self._lock:
            user = self._users_by_id.get(user_id.strip())
        return user.to_identity() if user is not None else None

    def _store_user(self, user: InternalUser) -> None:
        normalized_username = user.username.strip().casefold()
        if (
            normalized_username in self._users_by_username
            or user.user_id in self._users_by_id
        ):
            raise DuplicateUserError(
                f"User '{normalized_username}' is already registered."
            )
        self._users_by_username[normalized_username] = user
        self._users_by_id[user.user_id] = user

    def _get_dummy_password_hash(self) -> str:
        with self._lock:
            if self._dummy_password_hash is None:
                self._dummy_password_hash = (
                    self._password_manager.hash_password(
                        str(uuid4())
                    )
                )
            return self._dummy_password_hash


authentication_service = AuthenticationService()