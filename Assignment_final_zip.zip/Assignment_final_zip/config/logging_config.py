"""Central Loguru configuration with safe, rotating request logs."""
from __future__ import annotations

import sys
from pathlib import Path
from loguru import logger
from config.settings import BASE_DIR, settings


def configure_logging() -> None:
    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logger.remove()
    fmt = (
        "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<8} | "
        "request_id={extra[request_id]} | stage={extra[stage]} | {message}"
    )
    logger.configure(extra={"request_id": "-", "stage": "app"})
    logger.add(sys.stderr, level=settings.LOG_LEVEL, format=fmt, enqueue=True)
    logger.add(
        str(log_dir / "analytics_{time:YYYY-MM-DD}.log"),
        level=settings.LOG_LEVEL,
        format=fmt,
        rotation="10 MB",
        retention="14 days",
        compression="zip",
        enqueue=True,
        encoding="utf-8",
    )


def request_logger(request_id: str, stage: str):
    """Return a logger bound to non-secret request/stage identifiers."""
    return logger.bind(request_id=request_id, stage=stage)
