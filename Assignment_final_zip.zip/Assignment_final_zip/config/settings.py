"""
Centralized application configuration.

Loads environment variables from the project's .env file and provides
reusable, validated settings across the application.
"""

import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from sqlalchemy.engine import URL


# Project root:
# multi_agent_data_analytics/
# ├── .env
# ├── config/
# │   └── settings.py
# └── ...
BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"

# Load .env explicitly from the project root.
load_dotenv(dotenv_path=ENV_FILE)


def get_int_env(name: str, default: int) -> int:
    """
    Read an integer environment variable with a clear validation error.
    """
    value = os.getenv(name, str(default)).strip()

    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(
            f"Environment variable {name} must be an integer. "
            f"Received: {value!r}"
        ) from exc


def get_bool_env(name: str, default: bool = False) -> bool:
    """
    Read a boolean environment variable.

    Accepted true values:
        true, 1, yes, on

    Accepted false values:
        false, 0, no, off
    """
    default_value = "true" if default else "false"
    value = os.getenv(name, default_value).strip().lower()

    if value in {"true", "1", "yes", "on"}:
        return True

    if value in {"false", "0", "no", "off"}:
        return False

    raise ValueError(
        f"Environment variable {name} must be a boolean. "
        f"Received: {value!r}"
    )


class Settings:
    """Central application settings."""

    # =====================================================
    # Application
    # =====================================================

    APP_NAME: str = os.getenv(
        "APP_NAME",
        "Multi Agent Analytics",
    ).strip()

    APP_ENV: str = os.getenv(
        "APP_ENV",
        "development",
    ).strip().lower()

    LOG_LEVEL: str = os.getenv(
        "LOG_LEVEL",
        "INFO",
    ).strip().upper()

    # =====================================================
    # Ollama / LLM
    # =====================================================

    OLLAMA_BASE_URL: str = os.getenv(
        "OLLAMA_BASE_URL",
        "http://localhost:11434",
    ).strip().rstrip("/")

    OLLAMA_MODEL: str = os.getenv(
        "OLLAMA_MODEL",
        "llama3.2",
    ).strip()

    OLLAMA_TEMPERATURE: float = float(
        os.getenv(
            "OLLAMA_TEMPERATURE",
            "0.1",
        ).strip()
    )

    GEMINI_API_KEY: str = os.getenv(
        "GEMINI_API_KEY",
        "",
    ).strip()

    GEMINI_MODEL: str = os.getenv(
        "GEMINI_MODEL",
        "gemini-2.5-flash",
    ).strip()

    GEMINI_TEMPERATURE: float = float(
        os.getenv(
            "GEMINI_TEMPERATURE",
            "0.1",
        ).strip()
    )

    GEMINI_TIMEOUT_SECONDS: int = get_int_env(
        "GEMINI_TIMEOUT_SECONDS",
        60,
    )

    MCP_ENABLED: bool = get_bool_env("MCP_ENABLED", False)

    # =====================================================
    # MySQL database
    # =====================================================

    DB_DRIVER: str = os.getenv(
        "DB_DRIVER",
        "mysql+pymysql",
    ).strip()

    DB_HOST: str = os.getenv(
        "DB_HOST",
        "localhost",
    ).strip()

    DB_PORT: int = get_int_env(
        "DB_PORT",
        3306,
    )

    DB_NAME: str = os.getenv(
        "DB_NAME",
        "northwind_db",
    ).strip()

    DB_USER: str = os.getenv(
        "DB_USER",
        "root",
    ).strip()

    DB_PASSWORD: str = os.getenv(
        "DB_PASSWORD",
        "",
    )

    DB_CHARSET: str = os.getenv(
        "DB_CHARSET",
        "utf8mb4",
    ).strip()

    DB_ECHO: bool = get_bool_env(
        "DB_ECHO",
        False,
    )

    DB_POOL_SIZE: int = get_int_env(
        "DB_POOL_SIZE",
        5,
    )

    DB_MAX_OVERFLOW: int = get_int_env(
        "DB_MAX_OVERFLOW",
        10,
    )

    DB_POOL_TIMEOUT: int = get_int_env(
        "DB_POOL_TIMEOUT",
        30,
    )

    DB_POOL_RECYCLE: int = get_int_env(
        "DB_POOL_RECYCLE",
        1800,
    )

    DB_CONNECT_TIMEOUT: int = get_int_env(
        "DB_CONNECT_TIMEOUT",
        10,
    )

    # =====================================================
    # Query safeguards
    # =====================================================

    QUERY_TIMEOUT: int = get_int_env(
        "QUERY_TIMEOUT",
        30,
    )

    MAX_QUERY_ROWS: int = get_int_env(
        "MAX_QUERY_ROWS",
        1000,
    )

    # =====================================================
    # Authentication
    # =====================================================

    JWT_SECRET_KEY: str = os.getenv(
        "JWT_SECRET_KEY",
        "change_this_secret",
    )

    JWT_ALGORITHM: str = os.getenv(
        "JWT_ALGORITHM",
        "HS256",
    ).strip()

    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = get_int_env(
        "JWT_ACCESS_TOKEN_EXPIRE_MINUTES",
        60,
    )

    API_BOOTSTRAP_ADMIN_USERNAME: str = os.getenv(
        "API_BOOTSTRAP_ADMIN_USERNAME",
        "",
    ).strip()

    API_BOOTSTRAP_ADMIN_PASSWORD: str = os.getenv(
        "API_BOOTSTRAP_ADMIN_PASSWORD",
        "",
    )

    API_BOOTSTRAP_ADMIN_DISPLAY_NAME: str = os.getenv(
        "API_BOOTSTRAP_ADMIN_DISPLAY_NAME",
        "API Administrator",
    ).strip()

    # =====================================================
    # Helper properties
    # =====================================================

    @property
    def MYSQL_CONNECTION_URL(self) -> URL:
        """
        Return a SQLAlchemy URL object.

        Using URL.create() safely handles passwords containing characters
        such as @, :, /, #, %, or spaces.
        """
        return URL.create(
            drivername=self.DB_DRIVER,
            username=self.DB_USER,
            password=self.DB_PASSWORD,
            host=self.DB_HOST,
            port=self.DB_PORT,
            database=self.DB_NAME,
            query={
                "charset": self.DB_CHARSET,
            },
        )

    @property
    def MYSQL_CONNECTION_STRING(self) -> str:
        """
        Return the complete SQLAlchemy connection string.

        Avoid printing this value because it contains the DB password.
        """
        return self.MYSQL_CONNECTION_URL.render_as_string(
            hide_password=False
        )

    @property
    def SAFE_MYSQL_CONNECTION_STRING(self) -> str:
        """
        Return a password-masked connection string for logs.
        """
        return self.MYSQL_CONNECTION_URL.render_as_string(
            hide_password=True
        )

    @property
    def OLLAMA_CONFIG(self) -> dict[str, Any]:
        """Return configuration accepted by ChatOllama."""
        return {
            "base_url": self.OLLAMA_BASE_URL,
            "model": self.OLLAMA_MODEL,
            "temperature": self.OLLAMA_TEMPERATURE,
        }

    # =====================================================
    # Validation
    # =====================================================

    def validate(self) -> bool:
        """Validate critical application settings."""
        required_settings = {
            "APP_NAME": self.APP_NAME,
            "OLLAMA_BASE_URL": self.OLLAMA_BASE_URL,
            "OLLAMA_MODEL": self.OLLAMA_MODEL,
            "DB_DRIVER": self.DB_DRIVER,
            "DB_HOST": self.DB_HOST,
            "DB_NAME": self.DB_NAME,
            "DB_USER": self.DB_USER,
            "JWT_SECRET_KEY": self.JWT_SECRET_KEY,
        }

        missing = [
            name
            for name, value in required_settings.items()
            if not value
        ]

        if missing:
            raise ValueError(
                "Missing required environment variables: "
                + ", ".join(missing)
            )

        if not self.OLLAMA_BASE_URL.startswith(
            ("http://", "https://")
        ):
            raise ValueError(
                "OLLAMA_BASE_URL must begin with "
                "'http://' or 'https://'."
            )

        if not 1 <= self.DB_PORT <= 65535:
            raise ValueError(
                "DB_PORT must be between 1 and 65535."
            )

        if self.DB_POOL_SIZE < 1:
            raise ValueError(
                "DB_POOL_SIZE must be at least 1."
            )

        if self.DB_MAX_OVERFLOW < 0:
            raise ValueError(
                "DB_MAX_OVERFLOW cannot be negative."
            )

        if self.QUERY_TIMEOUT < 1:
            raise ValueError(
                "QUERY_TIMEOUT must be at least 1 second."
            )

        if self.MAX_QUERY_ROWS < 1:
            raise ValueError(
                "MAX_QUERY_ROWS must be at least 1."
            )

        if not 0.0 <= self.OLLAMA_TEMPERATURE <= 2.0:
            raise ValueError(
                "OLLAMA_TEMPERATURE must be between 0.0 and 2.0."
            )

        if not self.GEMINI_MODEL:
            raise ValueError("GEMINI_MODEL cannot be empty.")

        if not 0.0 <= self.GEMINI_TEMPERATURE <= 2.0:
            raise ValueError(
                "GEMINI_TEMPERATURE must be between 0.0 and 2.0."
            )

        if self.GEMINI_TIMEOUT_SECONDS < 1:
            raise ValueError(
                "GEMINI_TIMEOUT_SECONDS must be at least 1 second."
            )

        if (
            self.APP_ENV != "development"
            and self.JWT_SECRET_KEY == "change_this_secret"
        ):
            raise ValueError(
                "JWT_SECRET_KEY must be changed outside development."
            )

        return True


# Singleton configuration instance.
settings = Settings()
settings.validate()