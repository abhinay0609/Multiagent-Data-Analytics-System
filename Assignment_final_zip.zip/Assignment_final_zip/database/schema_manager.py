"""
Database schema discovery and context management.

Provides:
- Database schema discovery through DatabaseRegistry
- In-memory schema caching
- Table and column metadata lookup
- Foreign-key relationship discovery
- Compact schema context for SQL-generating agents
- Cache refresh and invalidation
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from threading import RLock
from time import monotonic
from typing import Any, Optional

from loguru import logger

from database.database_registry import (
    DatabaseMetadataError,
    DatabaseNotRegisteredError,
    DatabaseRegistry,
    database_registry,
    initialize_database_registry,
)


# =========================================================
# Exceptions
# =========================================================


class SchemaManagerError(RuntimeError):
    """Base exception for schema manager operations."""


class SchemaNotFoundError(SchemaManagerError):
    """Raised when requested schema metadata cannot be found."""


class SchemaCacheError(SchemaManagerError):
    """Raised when schema cache operations fail."""


# =========================================================
# Cache model
# =========================================================


@dataclass
class SchemaCacheEntry:
    """Cached schema metadata for one registered database."""

    created_at: float
    expires_at: float
    schema: dict[str, Any]

    def is_expired(self) -> bool:
        """Return True when the cache entry has expired."""
        return monotonic() >= self.expires_at


# =========================================================
# Schema manager
# =========================================================


class SchemaManager:
    """
    Discover, cache, search and format database schema metadata.

    Database connections are obtained from DatabaseRegistry. This class
    does not create SQLAlchemy engines or handle database credentials.
    """

    def __init__(
        self,
        registry: Optional[DatabaseRegistry] = None,
        cache_ttl_seconds: int = 300,
    ) -> None:
        if registry is not None and not isinstance(
            registry,
            DatabaseRegistry,
        ):
            raise TypeError(
                "registry must be a DatabaseRegistry instance."
            )

        if not isinstance(cache_ttl_seconds, int):
            raise TypeError(
                "cache_ttl_seconds must be an integer."
            )

        if cache_ttl_seconds < 1:
            raise ValueError(
                "cache_ttl_seconds must be at least 1."
            )

        self._registry = (
            registry
            if registry is not None
            else initialize_database_registry()
        )

        self._cache_ttl_seconds = cache_ttl_seconds
        self._cache: dict[str, SchemaCacheEntry] = {}
        self._lock = RLock()

        logger.info(
            "SchemaManager initialized with cache TTL of {} seconds.",
            cache_ttl_seconds,
        )

    # =====================================================
    # Properties
    # =====================================================

    @property
    def registry(self) -> DatabaseRegistry:
        """Return the configured DatabaseRegistry."""
        return self._registry

    @property
    def cache_ttl_seconds(self) -> int:
        """Return the schema cache duration in seconds."""
        return self._cache_ttl_seconds

    # =====================================================
    # Schema loading and caching
    # =====================================================

    def get_database_schema(
        self,
        database_name: Optional[str] = None,
        refresh: bool = False,
    ) -> dict[str, Any]:
        """
        Return complete schema metadata for a registered database.

        Cached metadata is returned unless refresh is True, the cache
        entry does not exist, or the cache entry has expired.
        """
        if not isinstance(refresh, bool):
            raise TypeError(
                "refresh must be a boolean."
            )

        registry_name = self._resolve_registry_name(
            database_name
        )

        if not refresh:
            cached_schema = self._get_cached_schema(
                registry_name
            )

            if cached_schema is not None:
                logger.debug(
                    "Returning cached schema for database '{}'.",
                    registry_name,
                )
                return cached_schema

        schema = self._load_database_schema(
            registry_name
        )

        self._store_schema_in_cache(
            registry_name,
            schema,
        )

        return deepcopy(schema)

    def refresh_schema(
        self,
        database_name: Optional[str] = None,
    ) -> dict[str, Any]:
        """Force schema discovery and replace the cached entry."""
        return self.get_database_schema(
            database_name=database_name,
            refresh=True,
        )

    def invalidate_cache(
        self,
        database_name: Optional[str] = None,
    ) -> bool:
        """
        Remove one cached schema.

        Returns True if a cache entry was removed.
        """
        registry_name = self._resolve_registry_name(
            database_name
        )

        with self._lock:
            removed_entry = self._cache.pop(
                registry_name,
                None,
            )

        if removed_entry is not None:
            logger.info(
                "Invalidated schema cache for database '{}'.",
                registry_name,
            )
            return True

        return False

    def clear_cache(self) -> None:
        """Remove all cached schema metadata."""
        with self._lock:
            self._cache.clear()

        logger.info(
            "Cleared all schema cache entries."
        )

    def is_cached(
        self,
        database_name: Optional[str] = None,
    ) -> bool:
        """Return True if an unexpired cache entry exists."""
        registry_name = self._resolve_registry_name(
            database_name
        )

        with self._lock:
            entry = self._cache.get(registry_name)

            if entry is None:
                return False

            if entry.is_expired():
                self._cache.pop(
                    registry_name,
                    None,
                )
                return False

            return True

    def cache_status(self) -> dict[str, dict[str, Any]]:
        """Return cache status without returning complete schemas."""
        current_time = monotonic()

        with self._lock:
            status: dict[str, dict[str, Any]] = {}

            for name, entry in self._cache.items():
                remaining_seconds = max(
                    0.0,
                    entry.expires_at - current_time,
                )

                status[name] = {
                    "cached": True,
                    "expired": entry.is_expired(),
                    "remaining_seconds": round(
                        remaining_seconds,
                        2,
                    ),
                    "table_count": entry.schema.get(
                        "table_count",
                        0,
                    ),
                }

            return status

    # =====================================================
    # Table and column access
    # =====================================================

    def list_tables(
        self,
        database_name: Optional[str] = None,
        refresh: bool = False,
    ) -> list[str]:
        """Return sorted table names from schema metadata."""
        schema = self.get_database_schema(
            database_name=database_name,
            refresh=refresh,
        )

        return list(schema["table_names"])

    def get_table_schema(
        self,
        table_name: str,
        database_name: Optional[str] = None,
        refresh: bool = False,
    ) -> dict[str, Any]:
        """Return schema metadata for one table."""
        clean_table_name = self._validate_text(
            table_name,
            "Table name",
        )

        database_schema = self.get_database_schema(
            database_name=database_name,
            refresh=refresh,
        )

        table_lookup = {
            name.casefold(): schema
            for name, schema
            in database_schema["tables"].items()
        }

        table_schema = table_lookup.get(
            clean_table_name.casefold()
        )

        if table_schema is None:
            raise SchemaNotFoundError(
                f"Table '{clean_table_name}' was not found in "
                f"database '{database_schema['registry_name']}'."
            )

        return deepcopy(table_schema)

    def get_table_columns(
        self,
        table_name: str,
        database_name: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Return column metadata for one table."""
        table_schema = self.get_table_schema(
            table_name=table_name,
            database_name=database_name,
        )

        return deepcopy(table_schema["columns"])

    def get_column(
        self,
        table_name: str,
        column_name: str,
        database_name: Optional[str] = None,
    ) -> dict[str, Any]:
        """Return metadata for one column."""
        clean_column_name = self._validate_text(
            column_name,
            "Column name",
        )

        columns = self.get_table_columns(
            table_name=table_name,
            database_name=database_name,
        )

        for column in columns:
            if (
                column["name"].casefold()
                == clean_column_name.casefold()
            ):
                return deepcopy(column)

        raise SchemaNotFoundError(
            f"Column '{clean_column_name}' was not found "
            f"in table '{table_name}'."
        )

    def table_exists(
        self,
        table_name: str,
        database_name: Optional[str] = None,
    ) -> bool:
        """Return True if the table exists."""
        clean_table_name = self._validate_text(
            table_name,
            "Table name",
        )

        table_names = self.list_tables(
            database_name=database_name,
        )

        return clean_table_name.casefold() in {
            name.casefold()
            for name in table_names
        }

    def column_exists(
        self,
        table_name: str,
        column_name: str,
        database_name: Optional[str] = None,
    ) -> bool:
        """Return True if a column exists in a table."""
        clean_column_name = self._validate_text(
            column_name,
            "Column name",
        )

        try:
            columns = self.get_table_columns(
                table_name=table_name,
                database_name=database_name,
            )
        except SchemaNotFoundError:
            return False

        return clean_column_name.casefold() in {
            column["name"].casefold()
            for column in columns
        }

    # =====================================================
    # Search
    # =====================================================

    def search_tables(
        self,
        search_term: str,
        database_name: Optional[str] = None,
    ) -> list[str]:
        """Search table names with a case-insensitive partial match."""
        clean_search_term = self._validate_text(
            search_term,
            "Search term",
        ).casefold()

        return [
            table_name
            for table_name in self.list_tables(database_name)
            if clean_search_term in table_name.casefold()
        ]

    def search_columns(
        self,
        search_term: str,
        database_name: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Search column names across all tables."""
        clean_search_term = self._validate_text(
            search_term,
            "Search term",
        ).casefold()

        schema = self.get_database_schema(
            database_name=database_name,
        )

        matches: list[dict[str, Any]] = []

        for table_name, table_schema in schema["tables"].items():
            for column in table_schema["columns"]:
                if clean_search_term in column["name"].casefold():
                    matches.append(
                        {
                            "table_name": table_name,
                            "column_name": column["name"],
                            "column_type": column["type"],
                            "nullable": column["nullable"],
                        }
                    )

        return matches

    # =====================================================
    # Relationships
    # =====================================================

    def get_relationships(
        self,
        database_name: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Return all foreign-key relationships."""
        schema = self.get_database_schema(
            database_name=database_name,
        )

        return deepcopy(
            schema["relationships"]
        )

    def get_related_tables(
        self,
        table_name: str,
        database_name: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Return relationships involving a requested table."""
        clean_table_name = self._validate_text(
            table_name,
            "Table name",
        )

        if not self.table_exists(
            clean_table_name,
            database_name,
        ):
            raise SchemaNotFoundError(
                f"Table '{clean_table_name}' does not exist."
            )

        relationships = self.get_relationships(
            database_name=database_name,
        )

        return [
            relationship
            for relationship in relationships
            if (
                relationship["source_table"].casefold()
                == clean_table_name.casefold()
                or relationship["target_table"].casefold()
                == clean_table_name.casefold()
            )
        ]

    # =====================================================
    # LLM schema context
    # =====================================================

    def build_schema_context(
        self,
        database_name: Optional[str] = None,
        table_names: Optional[list[str]] = None,
        include_relationships: bool = True,
        include_indexes: bool = False,
        max_tables: int = 25,
        max_characters: int = 12000,
    ) -> str:
        """Build compact schema context for an LLM or SQL agent."""
        if not isinstance(include_relationships, bool):
            raise TypeError(
                "include_relationships must be a boolean."
            )

        if not isinstance(include_indexes, bool):
            raise TypeError(
                "include_indexes must be a boolean."
            )

        if not isinstance(max_tables, int):
            raise TypeError(
                "max_tables must be an integer."
            )

        if max_tables < 1:
            raise ValueError(
                "max_tables must be at least 1."
            )

        if not isinstance(max_characters, int):
            raise TypeError(
                "max_characters must be an integer."
            )

        if max_characters < 100:
            raise ValueError(
                "max_characters must be at least 100."
            )

        schema = self.get_database_schema(
            database_name=database_name,
        )

        selected_tables = self._resolve_selected_tables(
            schema=schema,
            table_names=table_names,
            max_tables=max_tables,
        )

        lines = [
            f"Database: {schema['physical_database_name']}",
            f"Registry name: {schema['registry_name']}",
            f"Database type: {schema['backend']}",
            "",
            "Tables:",
        ]

        for table_name in selected_tables:
            table_schema = schema["tables"][table_name]

            primary_key_columns = set(
                table_schema["primary_key"]["columns"]
            )

            lines.append("")
            lines.append(f"TABLE {table_name}")

            for column in table_schema["columns"]:
                attributes: list[str] = []

                if column["name"] in primary_key_columns:
                    attributes.append("PRIMARY KEY")

                if not column["nullable"]:
                    attributes.append("NOT NULL")

                if column.get("autoincrement") is True:
                    attributes.append("AUTO INCREMENT")

                attribute_text = ""

                if attributes:
                    attribute_text = (
                        f" [{', '.join(attributes)}]"
                    )

                lines.append(
                    f"  - {column['name']}: "
                    f"{column['type']}{attribute_text}"
                )

            if (
                include_indexes
                and table_schema["indexes"]
            ):
                lines.append("  INDEXES:")

                for index in table_schema["indexes"]:
                    unique_text = (
                        " UNIQUE"
                        if index["unique"]
                        else ""
                    )

                    columns_text = ", ".join(
                        index["columns"]
                    )

                    lines.append(
                        f"    - {index['name']}: "
                        f"{columns_text}{unique_text}"
                    )

        if include_relationships:
            selected_lookup = {
                table.casefold()
                for table in selected_tables
            }

            selected_relationships = [
                relationship
                for relationship in schema["relationships"]
                if (
                    relationship["source_table"].casefold()
                    in selected_lookup
                    and relationship["target_table"].casefold()
                    in selected_lookup
                )
            ]

            if selected_relationships:
                lines.append("")
                lines.append("Relationships:")

                for relationship in selected_relationships:
                    source_columns = ", ".join(
                        relationship["source_columns"]
                    )

                    target_columns = ", ".join(
                        relationship["target_columns"]
                    )

                    lines.append(
                        f"  - {relationship['source_table']}."
                        f"({source_columns}) -> "
                        f"{relationship['target_table']}."
                        f"({target_columns})"
                    )

        context = "\n".join(lines)

        if len(context) > max_characters:
            truncation_message = (
                "\n\n[Schema context truncated.]"
            )

            available_length = max(
                0,
                max_characters - len(truncation_message),
            )

            context = (
                context[:available_length].rstrip()
                + truncation_message
            )

        return context

    def get_relevant_schema_context(
        self,
        search_terms: list[str],
        database_name: Optional[str] = None,
        max_tables: int = 10,
        max_characters: int = 8000,
    ) -> str:
        """
        Build schema context for tables related to search terms.

        A table receives a higher score for matching its table name and
        a smaller score for matching its column names.
        """
        if not isinstance(search_terms, list):
            raise TypeError(
                "search_terms must be a list of strings."
            )

        if not isinstance(max_tables, int) or max_tables < 1:
            raise ValueError(
                "max_tables must be a positive integer."
            )

        normalized_terms: set[str] = set()

        for term in search_terms:
            if not isinstance(term, str):
                raise TypeError(
                    "Every search term must be a string."
                )

            clean_term = term.strip().casefold()

            if clean_term:
                normalized_terms.add(clean_term)

        if not normalized_terms:
            raise ValueError(
                "search_terms must contain at least one "
                "non-empty string."
            )

        schema = self.get_database_schema(
            database_name=database_name,
        )

        scored_tables: list[tuple[int, str]] = []

        for table_name, table_schema in schema["tables"].items():
            score = 0
            normalized_table_name = table_name.casefold()

            for term in normalized_terms:
                if term in normalized_table_name:
                    score += 3

                for column in table_schema["columns"]:
                    if term in column["name"].casefold():
                        score += 1

            if score > 0:
                scored_tables.append(
                    (score, table_name)
                )

        scored_tables.sort(
            key=lambda item: (
                -item[0],
                item[1].casefold(),
            )
        )

        selected_tables = [
            table_name
            for _, table_name
            in scored_tables[:max_tables]
        ]

        if not selected_tables:
            selected_tables = schema["table_names"][:max_tables]

        selected_tables = self._include_related_tables(
            selected_tables=selected_tables,
            relationships=schema["relationships"],
            max_tables=max_tables,
        )

        return self.build_schema_context(
            database_name=database_name,
            table_names=selected_tables,
            include_relationships=True,
            include_indexes=False,
            max_tables=max_tables,
            max_characters=max_characters,
        )

    # =====================================================
    # Internal loading
    # =====================================================

    def _load_database_schema(
        self,
        registry_name: str,
    ) -> dict[str, Any]:
        """Load complete schema metadata from DatabaseRegistry."""
        try:
            registration = self._registry.get_registration(
                registry_name
            )

            table_names = self._registry.list_tables(
                database_name=registry_name,
            )

            tables: dict[str, dict[str, Any]] = {}
            relationships: list[dict[str, Any]] = []

            for table_name in table_names:
                table_schema = self._registry.get_table_schema(
                    table_name=table_name,
                    database_name=registry_name,
                )

                tables[table_name] = table_schema

                for foreign_key in table_schema["foreign_keys"]:
                    target_table = foreign_key.get(
                        "referred_table"
                    )

                    if not target_table:
                        continue

                    relationships.append(
                        {
                            "constraint_name": foreign_key.get(
                                "name"
                            ),
                            "source_table": table_name,
                            "source_columns": foreign_key.get(
                                "columns",
                                [],
                            ),
                            "target_schema": foreign_key.get(
                                "referred_schema"
                            ),
                            "target_table": target_table,
                            "target_columns": foreign_key.get(
                                "referred_columns",
                                [],
                            ),
                        }
                    )

            schema = {
                "registry_name": registration.name,
                "physical_database_name": (
                    registration.database_name
                ),
                "backend": registration.backend,
                "driver": registration.driver,
                "read_only": registration.read_only,
                "table_count": len(table_names),
                "table_names": table_names,
                "tables": tables,
                "relationship_count": len(relationships),
                "relationships": relationships,
            }

            logger.info(
                "Loaded schema for database '{}': {} tables and "
                "{} relationships.",
                registry_name,
                len(table_names),
                len(relationships),
            )

            return schema

        except (
            DatabaseNotRegisteredError,
            DatabaseMetadataError,
        ) as exc:
            raise SchemaManagerError(
                f"Could not load schema for database "
                f"'{registry_name}': {exc}"
            ) from exc

        except Exception as exc:
            logger.exception(
                "Unexpected schema loading error for database '{}'.",
                registry_name,
            )

            raise SchemaManagerError(
                f"Unexpected error while loading schema for "
                f"database '{registry_name}'."
            ) from exc

    def _get_cached_schema(
        self,
        registry_name: str,
    ) -> Optional[dict[str, Any]]:
        """Return a cached schema if it exists and has not expired."""
        with self._lock:
            entry = self._cache.get(registry_name)

            if entry is None:
                return None

            if entry.is_expired():
                self._cache.pop(
                    registry_name,
                    None,
                )

                logger.debug(
                    "Schema cache expired for database '{}'.",
                    registry_name,
                )

                return None

            return deepcopy(entry.schema)

    def _store_schema_in_cache(
        self,
        registry_name: str,
        schema: dict[str, Any],
    ) -> None:
        """Store schema metadata in the cache."""
        current_time = monotonic()

        entry = SchemaCacheEntry(
            created_at=current_time,
            expires_at=(
                current_time
                + self._cache_ttl_seconds
            ),
            schema=deepcopy(schema),
        )

        with self._lock:
            self._cache[registry_name] = entry

        logger.debug(
            "Stored schema for database '{}' in cache.",
            registry_name,
        )

    # =====================================================
    # Internal helpers
    # =====================================================

    def _resolve_registry_name(
        self,
        database_name: Optional[str],
    ) -> str:
        """Resolve an explicit or default registry name."""
        if database_name is None:
            return self._registry.get_default_name()

        if not isinstance(database_name, str):
            raise TypeError(
                "database_name must be a string or None."
            )

        clean_name = database_name.strip().lower()

        if not clean_name:
            raise ValueError(
                "database_name cannot be empty."
            )

        if not self._registry.contains(clean_name):
            raise SchemaNotFoundError(
                f"Database '{clean_name}' is not registered."
            )

        return clean_name

    def _resolve_selected_tables(
        self,
        schema: dict[str, Any],
        table_names: Optional[list[str]],
        max_tables: int,
    ) -> list[str]:
        """Validate and resolve table selection for schema context."""
        available_tables = schema["table_names"]

        if table_names is None:
            return available_tables[:max_tables]

        if not isinstance(table_names, list):
            raise TypeError(
                "table_names must be a list of strings or None."
            )

        if not table_names:
            raise ValueError(
                "table_names cannot be an empty list."
            )

        available_lookup = {
            table_name.casefold(): table_name
            for table_name in available_tables
        }

        selected: list[str] = []
        unknown_tables: list[str] = []

        for table_name in table_names:
            if not isinstance(table_name, str):
                raise TypeError(
                    "Every table name must be a string."
                )

            clean_name = table_name.strip()

            if not clean_name:
                continue

            canonical_name = available_lookup.get(
                clean_name.casefold()
            )

            if canonical_name is None:
                unknown_tables.append(clean_name)
                continue

            if canonical_name not in selected:
                selected.append(canonical_name)

        if unknown_tables:
            raise SchemaNotFoundError(
                "Unknown tables: "
                + ", ".join(unknown_tables)
            )

        if not selected:
            raise ValueError(
                "No valid table names were provided."
            )

        return selected[:max_tables]

    @staticmethod
    def _include_related_tables(
        selected_tables: list[str],
        relationships: list[dict[str, Any]],
        max_tables: int,
    ) -> list[str]:
        """Add directly related tables while respecting max_tables."""
        result = list(selected_tables)

        result_lookup = {
            table.casefold()
            for table in result
        }

        for relationship in relationships:
            if len(result) >= max_tables:
                break

            source_table = relationship["source_table"]
            target_table = relationship["target_table"]

            source_selected = (
                source_table.casefold()
                in result_lookup
            )

            target_selected = (
                target_table.casefold()
                in result_lookup
            )

            related_table: Optional[str] = None

            if source_selected and not target_selected:
                related_table = target_table

            elif target_selected and not source_selected:
                related_table = source_table

            if related_table is not None:
                result.append(related_table)
                result_lookup.add(
                    related_table.casefold()
                )

        return result[:max_tables]

    @staticmethod
    def _validate_text(
        value: str,
        label: str,
    ) -> str:
        """Validate a table, column or search string."""
        if not isinstance(value, str):
            raise TypeError(
                f"{label} must be a string."
            )

        clean_value = value.strip()

        if not clean_value:
            raise ValueError(
                f"{label} cannot be empty."
            )

        return clean_value


# =========================================================
# Shared application schema manager
# =========================================================

initialize_database_registry()

schema_manager = SchemaManager(
    registry=database_registry,
    cache_ttl_seconds=300,
)