"""
Central registry for approved database connections.

The registry provides:
- Registration of approved database connections
- Controlled retrieval of connection managers
- Health checks for registered databases
- Database metadata and table discovery
- Schema inspection
- Safe cleanup of connection pools

Agents should retrieve databases through this registry instead of
creating SQLAlchemy engines directly.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from threading import RLock
from typing import Any, Mapping, Optional

from loguru import logger
from sqlalchemy import inspect
from sqlalchemy.engine import URL
from sqlalchemy.exc import SQLAlchemyError

from database.connection_manager import ConnectionManager


class DatabaseRegistryError(RuntimeError):
    """Base exception for database registry operations."""


class DatabaseAlreadyRegisteredError(DatabaseRegistryError):
    """Raised when a database name is already registered."""


class DatabaseNotRegisteredError(DatabaseRegistryError):
    """Raised when a requested database is not registered."""


class DatabaseMetadataError(DatabaseRegistryError):
    """Raised when database metadata cannot be retrieved."""


@dataclass(frozen=True)
class DatabaseRegistration:
    """Public metadata describing a registered database."""

    name: str
    database_name: str
    backend: str
    driver: str
    host: Optional[str]
    port: Optional[int]
    description: str
    read_only: bool
    is_default: bool


class DatabaseRegistry:
    """
    Maintain approved database connections for the application.

    The registry maps logical names, such as "northwind", to shared
    ConnectionManager instances. Database credentials are not exposed
    through the public metadata API.
    """

    def __init__(self) -> None:
        self._connections: dict[str, ConnectionManager] = {}
        self._metadata: dict[str, DatabaseRegistration] = {}
        self._default_name: Optional[str] = None
        self._lock = RLock()

    def register(
        self,
        name: str,
        connection_manager: ConnectionManager,
        description: str = "",
        read_only: bool = True,
        make_default: bool = False,
        replace_existing: bool = False,
    ) -> DatabaseRegistration:
        """Register an approved database connection."""
        normalized_name = self._normalize_name(name)

        if not isinstance(connection_manager, ConnectionManager):
            raise TypeError(
                "connection_manager must be a ConnectionManager instance."
            )

        if not isinstance(description, str):
            raise TypeError("description must be a string.")

        if not isinstance(read_only, bool):
            raise TypeError("read_only must be a boolean.")

        if not isinstance(make_default, bool):
            raise TypeError("make_default must be a boolean.")

        if not isinstance(replace_existing, bool):
            raise TypeError("replace_existing must be a boolean.")

        old_manager: Optional[ConnectionManager] = None

        with self._lock:
            if normalized_name in self._connections and not replace_existing:
                raise DatabaseAlreadyRegisteredError(
                    f"Database '{normalized_name}' is already registered."
                )

            old_manager = self._connections.get(normalized_name)
            registration = DatabaseRegistration(
                name=normalized_name,
                database_name=connection_manager.database_name,
                backend=connection_manager.backend_name,
                driver=connection_manager.driver_name,
                host=connection_manager.engine.url.host,
                port=connection_manager.engine.url.port,
                description=description.strip(),
                read_only=read_only,
                is_default=False,
            )

            self._connections[normalized_name] = connection_manager
            self._metadata[normalized_name] = registration

            if self._default_name is None or make_default:
                self._set_default_locked(normalized_name)
            else:
                self._refresh_default_flags_locked()

            final_registration = self._metadata[normalized_name]

        if (
            replace_existing
            and old_manager is not None
            and old_manager is not connection_manager
        ):
            old_manager.dispose()

        logger.info(
            "Registered database '{}' using physical database '{}'.",
            normalized_name,
            final_registration.database_name,
        )

        return final_registration

    def register_from_url(
        self,
        name: str,
        connection_url: URL | str,
        description: str = "",
        read_only: bool = True,
        make_default: bool = False,
        replace_existing: bool = False,
        echo: bool = False,
    ) -> DatabaseRegistration:
        """Create and register a ConnectionManager from an approved URL.

        Do not pass user-generated or LLM-generated connection URLs into
        this method.
        """
        if not isinstance(connection_url, (URL, str)):
            raise TypeError(
                "connection_url must be a SQLAlchemy URL or string."
            )

        manager = ConnectionManager(
            connection_url=connection_url,
            echo=echo,
        )

        try:
            return self.register(
                name=name,
                connection_manager=manager,
                description=description,
                read_only=read_only,
                make_default=make_default,
                replace_existing=replace_existing,
            )
        except Exception:
            manager.dispose()
            raise

    def unregister(
        self,
        name: str,
        dispose: bool = True,
    ) -> bool:
        """Remove a database registration and optionally dispose its pool."""
        normalized_name = self._normalize_name(name)

        if not isinstance(dispose, bool):
            raise TypeError("dispose must be a boolean.")

        with self._lock:
            manager = self._connections.pop(normalized_name, None)
            self._metadata.pop(normalized_name, None)

            if manager is None:
                return False

            if self._default_name == normalized_name:
                self._default_name = next(iter(self._connections), None)

            self._refresh_default_flags_locked()

        if dispose:
            manager.dispose()

        logger.info("Unregistered database '{}'.", normalized_name)
        return True

    def get(
        self,
        name: Optional[str] = None,
    ) -> ConnectionManager:
        """Retrieve a registered ConnectionManager, defaulting if omitted."""
        with self._lock:
            selected_name = self._resolve_name_locked(name)
            manager = self._connections.get(selected_name)

            if manager is None:
                raise DatabaseNotRegisteredError(
                    f"Database '{selected_name}' is not registered."
                )

            return manager

    def get_registration(
        self,
        name: Optional[str] = None,
    ) -> DatabaseRegistration:
        """Return public metadata for a registered database."""
        with self._lock:
            selected_name = self._resolve_name_locked(name)
            registration = self._metadata.get(selected_name)

            if registration is None:
                raise DatabaseNotRegisteredError(
                    f"Database '{selected_name}' is not registered."
                )

            return registration

    def get_default_name(self) -> str:
        """Return the logical name of the default database."""
        with self._lock:
            if self._default_name is None:
                raise DatabaseNotRegisteredError(
                    "No default database has been registered."
                )

            return self._default_name

    def set_default(self, name: str) -> None:
        """Set the default registered database."""
        normalized_name = self._normalize_name(name)

        with self._lock:
            if normalized_name not in self._connections:
                raise DatabaseNotRegisteredError(
                    f"Database '{normalized_name}' is not registered."
                )

            self._set_default_locked(normalized_name)

        logger.info("Default database set to '{}'.", normalized_name)

    def contains(self, name: str) -> bool:
        """Return True if a logical database name is registered."""
        normalized_name = self._normalize_name(name)

        with self._lock:
            return normalized_name in self._connections

    def list_databases(self) -> list[dict[str, Any]]:
        """Return public metadata for all registered databases."""
        with self._lock:
            return [
                asdict(self._metadata[name])
                for name in sorted(self._metadata)
            ]

    def count(self) -> int:
        """Return the number of registered databases."""
        with self._lock:
            return len(self._connections)

    def execute_read_only(
        self,
        query: str,
        parameters: Optional[Mapping[str, Any]] = None,
        database_name: Optional[str] = None,
        max_rows: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Execute a validated read-only query on a registered database."""
        manager = self.get(database_name)
        return manager.execute_read_only(
            query=query,
            parameters=parameters,
            max_rows=max_rows,
        )

    def execute_trusted(
        self,
        query: str,
        parameters: Optional[Mapping[str, Any]] = None,
        database_name: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Execute application-managed SQL unless the registration is read-only.

        Never use this method for user-generated or LLM-generated SQL.
        """
        registration = self.get_registration(database_name)

        if registration.read_only:
            raise DatabaseRegistryError(
                f"Database '{registration.name}' is registered as read-only."
            )

        manager = self.get(registration.name)
        return manager.execute(
            query=query,
            parameters=parameters,
        )

    def list_tables(
        self,
        database_name: Optional[str] = None,
        include_views: bool = False,
    ) -> list[str]:
        """Return sorted table names, optionally including SQL views."""
        if not isinstance(include_views, bool):
            raise TypeError("include_views must be a boolean.")

        manager = self.get(database_name)

        try:
            inspector = inspect(manager.engine)
            names = list(inspector.get_table_names())

            if include_views:
                names.extend(inspector.get_view_names())

            return sorted(set(names))
        except SQLAlchemyError as exc:
            logger.exception("Failed to retrieve database tables.")
            raise DatabaseMetadataError(
                "Could not retrieve database tables."
            ) from exc

    def table_exists(
        self,
        table_name: str,
        database_name: Optional[str] = None,
    ) -> bool:
        """Return True if the requested table or view exists."""
        clean_table_name = self._validate_table_name(table_name)
        table_names = self.list_tables(
            database_name=database_name,
            include_views=True,
        )

        return clean_table_name.casefold() in {
            name.casefold() for name in table_names
        }

    def get_table_schema(
        self,
        table_name: str,
        database_name: Optional[str] = None,
    ) -> dict[str, Any]:
        """Return column, primary-key, foreign-key and index metadata."""
        clean_table_name = self._validate_table_name(table_name)
        manager = self.get(database_name)

        try:
            inspector = inspect(manager.engine)

            if not inspector.has_table(clean_table_name):
                raise DatabaseMetadataError(
                    f"Table '{clean_table_name}' does not exist."
                )

            columns = inspector.get_columns(clean_table_name)
            primary_key = inspector.get_pk_constraint(clean_table_name)
            foreign_keys = inspector.get_foreign_keys(clean_table_name)
            indexes = inspector.get_indexes(clean_table_name)

            return {
                "table_name": clean_table_name,
                "columns": [
                    {
                        "name": column["name"],
                        "type": str(column["type"]),
                        "nullable": column.get("nullable", True),
                        "default": self._serialize_value(
                            column.get("default")
                        ),
                        "autoincrement": self._serialize_value(
                            column.get("autoincrement")
                        ),
                        "comment": column.get("comment"),
                    }
                    for column in columns
                ],
                "primary_key": {
                    "name": primary_key.get("name"),
                    "columns": primary_key.get("constrained_columns", []),
                },
                "foreign_keys": [
                    {
                        "name": foreign_key.get("name"),
                        "columns": foreign_key.get("constrained_columns", []),
                        "referred_schema": foreign_key.get("referred_schema"),
                        "referred_table": foreign_key.get("referred_table"),
                        "referred_columns": foreign_key.get(
                            "referred_columns",
                            [],
                        ),
                    }
                    for foreign_key in foreign_keys
                ],
                "indexes": [
                    {
                        "name": index.get("name"),
                        "columns": index.get("column_names", []),
                        "unique": bool(index.get("unique", False)),
                    }
                    for index in indexes
                ],
            }
        except DatabaseMetadataError:
            raise
        except SQLAlchemyError as exc:
            logger.exception(
                "Failed to inspect table '{}'.",
                clean_table_name,
            )
            raise DatabaseMetadataError(
                f"Could not inspect table '{clean_table_name}'."
            ) from exc

    def get_database_summary(
        self,
        database_name: Optional[str] = None,
    ) -> dict[str, Any]:
        """Return a compact summary for agents and API responses."""
        registration = self.get_registration(database_name)
        tables = self.list_tables(registration.name)

        return {
            "registration": asdict(registration),
            "table_count": len(tables),
            "tables": tables,
        }

    def health_check(
        self,
        name: Optional[str] = None,
    ) -> dict[str, Any]:
        """Run a health check for one registered database."""
        registration = self.get_registration(name)
        manager = self.get(registration.name)

        return {
            "registry_name": registration.name,
            **manager.health_check(),
        }

    def health_check_all(self) -> dict[str, dict[str, Any]]:
        """Run health checks for every registered database."""
        with self._lock:
            names = list(self._connections)

        return {
            name: self.health_check(name)
            for name in names
        }

    def dispose(
        self,
        name: Optional[str] = None,
    ) -> None:
        """Dispose one pool or all pools while retaining registrations."""
        if name is not None:
            self.get(name).dispose()
            return

        with self._lock:
            managers = list(self._connections.values())

        for manager in managers:
            manager.dispose()

        logger.info("Disposed all registered database connection pools.")

    def clear(
        self,
        dispose: bool = True,
    ) -> None:
        """Remove every registration and optionally dispose its pool."""
        if not isinstance(dispose, bool):
            raise TypeError("dispose must be a boolean.")

        with self._lock:
            managers = list(self._connections.values())
            self._connections.clear()
            self._metadata.clear()
            self._default_name = None

        if dispose:
            for manager in managers:
                manager.dispose()

        logger.info("Database registry cleared.")

    def _resolve_name_locked(
        self,
        name: Optional[str],
    ) -> str:
        """Resolve an explicit or default name while the lock is held."""
        if name is not None:
            return self._normalize_name(name)

        if self._default_name is None:
            raise DatabaseNotRegisteredError(
                "No default database has been registered."
            )

        return self._default_name

    def _set_default_locked(self, name: str) -> None:
        """Set the default database while the lock is held."""
        self._default_name = name
        self._refresh_default_flags_locked()

    def _refresh_default_flags_locked(self) -> None:
        """Update metadata with the current default status under the lock."""
        for name, registration in list(self._metadata.items()):
            self._metadata[name] = replace(
                registration,
                is_default=name == self._default_name,
            )

    @staticmethod
    def _normalize_name(name: str) -> str:
        """Validate and normalize a logical registry name."""
        if not isinstance(name, str):
            raise TypeError("Database registry name must be a string.")

        normalized_name = name.strip().lower()

        if not normalized_name:
            raise ValueError("Database registry name cannot be empty.")

        if not all(
            character.isalnum() or character in {"_", "-"}
            for character in normalized_name
        ):
            raise ValueError(
                "Database registry name may contain only letters, "
                "numbers, underscores and hyphens."
            )

        return normalized_name

    @staticmethod
    def _validate_table_name(table_name: str) -> str:
        """Validate a table name used for metadata inspection."""
        if not isinstance(table_name, str):
            raise TypeError("Table name must be a string.")

        clean_table_name = table_name.strip()

        if not clean_table_name:
            raise ValueError("Table name cannot be empty.")

        return clean_table_name

    @staticmethod
    def _serialize_value(value: Any) -> Any:
        """Convert non-primitive metadata values into strings."""
        if value is None or isinstance(value, (str, int, float, bool)):
            return value

        return str(value)


database_registry = DatabaseRegistry()


def initialize_database_registry() -> DatabaseRegistry:
    """Register application-configured databases idempotently."""
    if not database_registry.contains("northwind"):
        northwind_manager = ConnectionManager()
        database_registry.register(
            name="northwind",
            connection_manager=northwind_manager,
            description=(
                "Northwind database used by the multi-agent "
                "data analytics system."
            ),
            read_only=True,
            make_default=True,
        )

    return database_registry