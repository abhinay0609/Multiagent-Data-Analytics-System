"""
MySQL engine compatibility and access helpers.

This module does not create a SQLAlchemy engine. It delegates engine,
session and health access to ConnectionManager instances already
registered in DatabaseRegistry.

This prevents duplicate SQLAlchemy connection pools.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator, Optional

from sqlalchemy import Engine
from sqlalchemy.orm import Session

from database.connection_manager import ConnectionManager
from database.database_registry import (
    DatabaseRegistry,
    database_registry,
    initialize_database_registry,
)


DEFAULT_DATABASE_NAME = "northwind"


def get_database_registry() -> DatabaseRegistry:
    """
    Return the initialized shared DatabaseRegistry.

    Repeated calls are safe because initialize_database_registry()
    is idempotent.
    """
    return initialize_database_registry()


def get_connection_manager(
    database_name: str = DEFAULT_DATABASE_NAME,
    registry: Optional[DatabaseRegistry] = None,
) -> ConnectionManager:
    """
    Return the shared ConnectionManager for an approved database.

    Args:
        database_name:
            Logical database registry name, such as "northwind".

        registry:
            Optional registry instance, primarily for testing.

    Returns:
        Existing ConnectionManager from DatabaseRegistry.

    Important:
        This function does not accept a database connection URL and
        does not create a new SQLAlchemy engine.
    """
    clean_database_name = _validate_database_name(
        database_name
    )

    active_registry = (
        registry
        if registry is not None
        else get_database_registry()
    )

    if not isinstance(active_registry, DatabaseRegistry):
        raise TypeError(
            "registry must be a DatabaseRegistry instance."
        )

    return active_registry.get(
        clean_database_name
    )


def get_mysql_engine(
    database_name: str = DEFAULT_DATABASE_NAME,
    registry: Optional[DatabaseRegistry] = None,
) -> Engine:
    """
    Return the existing SQLAlchemy engine for an approved database.

    No additional engine or connection pool is created.
    """
    manager = get_connection_manager(
        database_name=database_name,
        registry=registry,
    )

    return manager.engine


def create_mysql_session(
    database_name: str = DEFAULT_DATABASE_NAME,
    registry: Optional[DatabaseRegistry] = None,
) -> Session:
    """
    Create a SQLAlchemy session using the registered connection manager.

    The caller must close the returned session. Prefer mysql_session_scope()
    when transactional session lifecycle management is needed.
    """
    manager = get_connection_manager(
        database_name=database_name,
        registry=registry,
    )

    return manager.create_session()


@contextmanager
def mysql_session_scope(
    database_name: str = DEFAULT_DATABASE_NAME,
    registry: Optional[DatabaseRegistry] = None,
) -> Generator[Session, None, None]:
    """
    Yield a transactional SQLAlchemy session.

    The underlying ConnectionManager commits successful transactions,
    rolls back failed transactions and always closes the session.

    Application analytics queries should normally use QueryExecutor rather
    than accessing sessions directly.
    """
    manager = get_connection_manager(
        database_name=database_name,
        registry=registry,
    )

    with manager.session_scope() as session:
        yield session


def get_mysql_session(
    database_name: str = DEFAULT_DATABASE_NAME,
    registry: Optional[DatabaseRegistry] = None,
) -> Generator[Session, None, None]:
    """
    Yield a session for FastAPI dependency injection.

    Example:

        from fastapi import Depends
        from sqlalchemy.orm import Session

        def endpoint(
            session: Session = Depends(get_mysql_session)
        ):
            return {"status": "ok"}
    """
    manager = get_connection_manager(
        database_name=database_name,
        registry=registry,
    )

    yield from manager.get_session()


def check_mysql_health(
    database_name: str = DEFAULT_DATABASE_NAME,
    registry: Optional[DatabaseRegistry] = None,
) -> dict[str, Any]:
    """Run a database health check through DatabaseRegistry."""
    clean_database_name = _validate_database_name(
        database_name
    )

    active_registry = (
        registry
        if registry is not None
        else get_database_registry()
    )

    if not isinstance(active_registry, DatabaseRegistry):
        raise TypeError(
            "registry must be a DatabaseRegistry instance."
        )

    return active_registry.health_check(
        clean_database_name
    )


def dispose_mysql_connections(
    database_name: Optional[str] = None,
    registry: Optional[DatabaseRegistry] = None,
) -> None:
    """
    Dispose one or all registered connection pools.

    Registrations remain available. SQLAlchemy can reconnect if the
    registered manager is used again.
    """
    active_registry = (
        registry
        if registry is not None
        else get_database_registry()
    )

    if not isinstance(active_registry, DatabaseRegistry):
        raise TypeError(
            "registry must be a DatabaseRegistry instance."
        )

    if database_name is None:
        active_registry.dispose()
        return

    active_registry.dispose(
        _validate_database_name(database_name)
    )


def _validate_database_name(
    database_name: str,
) -> str:
    """Validate and normalize a logical database name."""
    if not isinstance(database_name, str):
        raise TypeError(
            "database_name must be a string."
        )

    clean_database_name = (
        database_name.strip().casefold()
    )

    if not clean_database_name:
        raise ValueError(
            "database_name cannot be empty."
        )

    return clean_database_name