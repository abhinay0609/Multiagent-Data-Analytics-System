"""
Centralized MySQL connection management.

Provides:
- SQLAlchemy engine lifecycle
- Safe session handling
- Automatic commit and rollback
- Database connectivity checks
- Parameterized SQL execution
- Restricted read-only query execution for analytics
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator, Mapping, Optional

from loguru import logger
from sqlalchemy import Engine, Result, create_engine, text
from sqlalchemy.engine import URL
from sqlalchemy.exc import DBAPIError, OperationalError, SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker
from sqlglot import exp, parse

from config.settings import settings


class DatabaseConnectionError(RuntimeError):
    """Raised when the application cannot connect to MySQL."""


class DatabaseQueryError(RuntimeError):
    """Raised when database query execution fails."""


class UnsafeQueryError(ValueError):
    """Raised when a query violates read-only restrictions."""


class ConnectionManager:
    """
    Manage SQLAlchemy database connections and sessions.

    A single shared ConnectionManager should normally be used throughout
    the application because the SQLAlchemy Engine manages connection pooling.
    """

    def __init__(
        self,
        connection_url: Optional[URL | str] = None,
        echo: Optional[bool] = None,
    ) -> None:
        settings.validate()

        self._connection_url = (
            connection_url
            if connection_url is not None
            else settings.MYSQL_CONNECTION_URL
        )

        self._echo = settings.DB_ECHO if echo is None else echo

        self._engine: Engine = self._create_engine()

        self._session_factory = sessionmaker(
            bind=self._engine,
            class_=Session,
            autoflush=False,
            autocommit=False,
            expire_on_commit=False,
        )

        logger.info(
            "ConnectionManager initialized for database '{}' on {}:{}",
            settings.DB_NAME,
            settings.DB_HOST,
            settings.DB_PORT,
        )

    # =====================================================
    # Properties
    # =====================================================

    @property
    def engine(self) -> Engine:
        """Return the configured SQLAlchemy engine."""
        return self._engine

    @property
    def session_factory(self) -> sessionmaker:
        """Return the configured SQLAlchemy session factory."""
        return self._session_factory

    @property
    def database_name(self) -> str:
        """Return the configured database name."""
        return self._engine.url.database or ""

    @property
    def backend_name(self) -> str:
        """Return the database backend name, such as mysql."""
        return self._engine.url.get_backend_name()

    @property
    def driver_name(self) -> str:
        """Return the database driver name, such as pymysql."""
        return self._engine.url.get_driver_name()

    # =====================================================
    # Engine creation
    # =====================================================

    def _create_engine(self) -> Engine:
        """
        Create the SQLAlchemy engine and connection pool.

        pool_pre_ping checks pooled connections before reuse.

        pool_recycle replaces older MySQL connections before they become
        stale because of server-side connection timeouts.
        """
        try:
            engine = create_engine(
                self._connection_url,
                echo=self._echo,
                pool_pre_ping=True,
                pool_size=settings.DB_POOL_SIZE,
                max_overflow=settings.DB_MAX_OVERFLOW,
                pool_timeout=settings.DB_POOL_TIMEOUT,
                pool_recycle=settings.DB_POOL_RECYCLE,
                connect_args={
                    "connect_timeout": settings.DB_CONNECT_TIMEOUT,
                    "read_timeout": settings.QUERY_TIMEOUT,
                    "write_timeout": settings.QUERY_TIMEOUT,
                    "charset": settings.DB_CHARSET,
                },
            )

            return engine

        except Exception as exc:
            logger.exception(
                "Failed to create the SQLAlchemy engine."
            )

            raise DatabaseConnectionError(
                "Could not initialize the MySQL database engine."
            ) from exc

    # =====================================================
    # Session management
    # =====================================================

    def create_session(self) -> Session:
        """
        Create and return a SQLAlchemy session.

        A manually created session must be closed by the caller.
        Prefer session_scope() for normal application operations.
        """
        return self._session_factory()

    @contextmanager
    def session_scope(self) -> Generator[Session, None, None]:
        """
        Provide a transactional database session.

        The transaction is committed automatically when successful.
        If an exception occurs, the transaction is rolled back.
        The session is always closed.
        """
        session = self.create_session()

        try:
            yield session
            session.commit()

        except Exception:
            session.rollback()

            logger.exception(
                "Database transaction failed and was rolled back."
            )

            raise

        finally:
            session.close()

    def get_session(self) -> Generator[Session, None, None]:
        """
        Yield a database session for FastAPI dependency injection.

        Example:

            from fastapi import Depends
            from sqlalchemy.orm import Session

            def route(
                session: Session = Depends(
                    connection_manager.get_session
                )
            ):
                return {"status": "ok"}
        """
        session = self.create_session()

        try:
            yield session

        finally:
            session.close()

    # =====================================================
    # Health check
    # =====================================================

    def health_check(self) -> dict[str, Any]:
        """
        Check MySQL connectivity and return server information.

        Database credentials are not included in the returned result.
        """
        try:
            with self._engine.connect() as connection:
                row = connection.execute(
                    text(
                        """
                        SELECT
                            1 AS connection_ok,
                            DATABASE() AS database_name,
                            VERSION() AS server_version
                        """
                    )
                ).mappings().one()

            return {
                "status": "healthy",
                "connection_ok": row["connection_ok"],
                "backend": self.backend_name,
                "driver": self.driver_name,
                "database": row["database_name"],
                "server_version": row["server_version"],
                "host": settings.DB_HOST,
                "port": settings.DB_PORT,
            }

        except OperationalError as exc:
            error_message = self._connection_error_hint(exc)

            logger.error(
                "MySQL connection failed: {}",
                error_message,
            )

            return {
                "status": "unhealthy",
                "backend": self.backend_name,
                "driver": self.driver_name,
                "database": settings.DB_NAME,
                "host": settings.DB_HOST,
                "port": settings.DB_PORT,
                "error": error_message,
            }

        except SQLAlchemyError as exc:
            error_message = self._safe_error_message(exc)

            logger.exception(
                "Database health check failed."
            )

            return {
                "status": "unhealthy",
                "backend": self.backend_name,
                "driver": self.driver_name,
                "database": settings.DB_NAME,
                "host": settings.DB_HOST,
                "port": settings.DB_PORT,
                "error": error_message,
            }

    def test_connection(self) -> bool:
        """Return True when the database health check succeeds."""
        return self.health_check()["status"] == "healthy"

    # =====================================================
    # Trusted query execution
    # =====================================================

    def execute(
        self,
        query: str,
        parameters: Optional[Mapping[str, Any]] = None,
    ) -> list[dict[str, Any]]:
        """
        Execute trusted, parameterized application SQL.

        This method can execute SELECT, INSERT, UPDATE, and DELETE
        statements. Do not use it for SQL generated by an LLM or user.

        Example:

            manager.execute(
                "SELECT * FROM orders WHERE order_id = :order_id",
                {"order_id": 10248},
            )
        """
        normalized_query = self._validate_non_empty_query(query)
        query_parameters = dict(parameters or {})

        try:
            with self.session_scope() as session:
                result = session.execute(
                    text(normalized_query),
                    query_parameters,
                )

                return self._result_to_dicts(result)

        except DBAPIError as exc:
            logger.exception(
                "Database query execution failed."
            )

            raise DatabaseQueryError(
                self._safe_error_message(exc)
            ) from exc

        except SQLAlchemyError as exc:
            logger.exception(
                "SQLAlchemy query execution failed."
            )

            raise DatabaseQueryError(
                "The database query could not be executed."
            ) from exc

    # =====================================================
    # Read-only analytics query execution
    # =====================================================

    def execute_read_only(
        self,
        query: str,
        parameters: Optional[Mapping[str, Any]] = None,
        max_rows: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """
        Execute one validated, read-only SELECT or WITH query.

        This method is intended for analytics queries produced by agents.
        SQLGlot is used to reject multiple statements and data-changing SQL.

        The returned records are restricted by MAX_QUERY_ROWS.
        """
        normalized_query = self._validate_read_only_query(query)
        query_parameters = dict(parameters or {})

        row_limit = (
            settings.MAX_QUERY_ROWS
            if max_rows is None
            else max_rows
        )

        if not isinstance(row_limit, int):
            raise TypeError(
                "max_rows must be an integer."
            )

        if row_limit < 1:
            raise ValueError(
                "max_rows must be at least 1."
            )

        row_limit = min(
            row_limit,
            settings.MAX_QUERY_ROWS,
        )

        try:
            with self._engine.connect() as connection:
                result = connection.execute(
                    text(normalized_query),
                    query_parameters,
                )

                rows = result.mappings().fetchmany(
                    row_limit + 1
                )

            if len(rows) > row_limit:
                logger.warning(
                    "Query returned more than {} rows. "
                    "The result was truncated.",
                    row_limit,
                )

                rows = rows[:row_limit]

            return [
                dict(row)
                for row in rows
            ]

        except DBAPIError as exc:
            logger.exception(
                "Read-only database query failed."
            )

            raise DatabaseQueryError(
                self._safe_error_message(exc)
            ) from exc

        except SQLAlchemyError as exc:
            logger.exception(
                "SQLAlchemy read-only query failed."
            )

            raise DatabaseQueryError(
                "The read-only query could not be executed."
            ) from exc

    # =====================================================
    # Validation helpers
    # =====================================================

    @staticmethod
    def _validate_non_empty_query(query: str) -> str:
        """Validate and normalize the SQL query string."""
        if not isinstance(query, str):
            raise TypeError(
                "SQL query must be a string."
            )

        normalized_query = query.strip()

        if not normalized_query:
            raise ValueError(
                "SQL query cannot be empty."
            )

        return normalized_query

    @staticmethod
    def _validate_read_only_query(query: str) -> str:
        """
        Permit exactly one read-only SELECT-style statement.

        Statements such as INSERT, UPDATE, DELETE, CREATE, ALTER,
        DROP, TRUNCATE, GRANT, REVOKE, and database commands are rejected.
        """
        normalized_query = (
            ConnectionManager._validate_non_empty_query(query)
        )

        try:
            statements = parse(
                normalized_query,
                read="mysql",
            )

        except Exception as exc:
            raise UnsafeQueryError(
                f"Invalid MySQL query: {exc}"
            ) from exc

        if len(statements) != 1:
            raise UnsafeQueryError(
                "Only one SQL statement is allowed."
            )

        statement = statements[0]

        if statement is None:
            raise UnsafeQueryError(
                "The SQL statement could not be parsed."
            )

        prohibited_expression_names = {
            "Insert",
            "Update",
            "Delete",
            "Drop",
            "Alter",
            "Create",
            "Command",
            "Merge",
            "TruncateTable",
            "Grant",
            "Revoke",
            "Use",
            "Set",
            "Transaction",
            "Commit",
            "Rollback",
        }

        for node in statement.walk():
            if node.__class__.__name__ in prohibited_expression_names:
                raise UnsafeQueryError(
                    "Only read-only SELECT or WITH queries are allowed."
                )

        if statement.find(exp.Select) is None:
            raise UnsafeQueryError(
                "The SQL statement must contain a SELECT query."
            )

        return normalized_query

    # =====================================================
    # Result and error helpers
    # =====================================================

    @staticmethod
    def _result_to_dicts(
        result: Result[Any],
    ) -> list[dict[str, Any]]:
        """Convert SQLAlchemy result rows into dictionaries."""
        if not result.returns_rows:
            return []

        return [
            dict(row)
            for row in result.mappings().all()
        ]

    @staticmethod
    def _safe_error_message(
        exception: Exception,
    ) -> str:
        """
        Return the original database error without exposing the URL.
        """
        original_error = getattr(
            exception,
            "orig",
            exception,
        )

        return str(original_error)

    @staticmethod
    def _connection_error_hint(
        exception: OperationalError,
    ) -> str:
        """Translate common MySQL errors into actionable messages."""
        original_error = getattr(
            exception,
            "orig",
            exception,
        )

        error_code = None

        if getattr(original_error, "args", None):
            error_code = original_error.args[0]

        hints = {
            1044: (
                f"MySQL user '{settings.DB_USER}' does not have permission "
                f"to access database '{settings.DB_NAME}'."
            ),
            1045: (
                "MySQL rejected the username or password. "
                "Check DB_USER and DB_PASSWORD in the .env file."
            ),
            1049: (
                f"Database '{settings.DB_NAME}' does not exist. "
                "Create the database or correct DB_NAME in the .env file."
            ),
            2003: (
                "MySQL could not be reached. Confirm that the MySQL "
                "service is running and verify DB_HOST and DB_PORT."
            ),
            2005: (
                "The MySQL hostname could not be resolved. "
                "Check DB_HOST in the .env file."
            ),
        }

        return hints.get(
            error_code,
            str(original_error),
        )

    # =====================================================
    # Connection cleanup
    # =====================================================

    def dispose(self) -> None:
        """Close all pooled database connections."""
        self._engine.dispose()

        logger.info(
            "Database connection pool disposed."
        )


# Shared application-level connection manager.
connection_manager = ConnectionManager()