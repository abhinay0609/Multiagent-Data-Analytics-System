"""
Controlled execution of validated read-only SQL.

QueryExecutor:
- Accepts only SQLValidationResult objects
- Requires successful Phase 3 validation
- Verifies user permission and database access
- Uses DatabaseRegistry rather than arbitrary connection URLs
- Executes through ConnectionManager.execute_read_only()
- Captures execution time
- Enforces maximum result rows
- Normalizes MySQL values into JSON-compatible values
- Returns QueryExecutionResult
"""

from __future__ import annotations

import base64
import math
from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal
from enum import Enum
from time import perf_counter
from typing import Any, Mapping, Optional
from uuid import UUID

from loguru import logger
from sqlalchemy.exc import (
    DBAPIError,
    OperationalError,
    TimeoutError as SQLAlchemyTimeoutError,
)

from auth.authorization import AuthorizationService
from config.settings import settings
from database.connection_manager import (
    DatabaseQueryError,
)
from database.database_registry import (
    DatabaseNotRegisteredError,
    DatabaseRegistry,
    database_registry,
    initialize_database_registry,
)
from schemas.sql_schema import (
    QueryExecutionMetadata,
    QueryExecutionResult,
    SQLValidationResult,
    SQLValidationStatus,
)
from schemas.user_schema import (
    Permission,
    UserIdentity,
)


class QueryExecutionError(RuntimeError):
    """Base exception for controlled query execution."""


class InvalidValidatedQueryError(QueryExecutionError):
    """Raised when SQL has not passed the Phase 3 boundary."""


class QueryAuthorizationError(QueryExecutionError):
    """Raised when the user cannot access the requested database."""


class ResultNormalizationError(QueryExecutionError):
    """Raised when query results cannot be safely serialized."""


@dataclass(frozen=True)
class ExecutionAuthorization:
    """
    Normalized authorization decision used by QueryExecutor.

    This is an internal execution component and is not returned as a
    client-facing API object.
    """

    allowed: bool
    database_name: str
    required_permission: str
    reason: str


class QueryExecutor:
    """
    Execute validated read-only SQL through approved database connections.

    QueryExecutor never accepts:
    - a connection URL
    - raw SQL as the primary execution input
    - an SQLAlchemy Engine
    - an SQLAlchemy Session

    It only accepts a valid SQLValidationResult containing executable_sql.
    """

    def __init__(
        self,
        registry: Optional[DatabaseRegistry] = None,
        default_database_name: str = "northwind",
        max_rows: Optional[int] = None,
        query_timeout_seconds: Optional[int] = None,
        binary_encoding: str = "base64",
    ) -> None:
        self._registry = (
            registry
            if registry is not None
            else initialize_database_registry()
        )

        if not isinstance(
            self._registry,
            DatabaseRegistry,
        ):
            raise TypeError(
                "registry must be a DatabaseRegistry instance."
            )

        self._default_database_name = (
            self._validate_database_name(
                default_database_name
            )
        )
        self._authorization_service = AuthorizationService(
            default_database_name=self._default_database_name,
        )

        resolved_max_rows = (
            settings.MAX_QUERY_ROWS
            if max_rows is None
            else max_rows
        )

        if not isinstance(resolved_max_rows, int):
            raise TypeError(
                "max_rows must be an integer."
            )

        if resolved_max_rows < 1:
            raise ValueError(
                "max_rows must be at least 1."
            )

        self._max_rows = min(
            resolved_max_rows,
            settings.MAX_QUERY_ROWS,
        )

        resolved_timeout = (
            settings.QUERY_TIMEOUT
            if query_timeout_seconds is None
            else query_timeout_seconds
        )

        if not isinstance(resolved_timeout, int):
            raise TypeError(
                "query_timeout_seconds must be an integer."
            )

        if resolved_timeout < 1:
            raise ValueError(
                "query_timeout_seconds must be at least 1."
            )

        self._query_timeout_seconds = (
            resolved_timeout
        )

        allowed_binary_encodings = {
            "base64",
            "hex",
            "metadata",
        }

        if binary_encoding not in allowed_binary_encodings:
            raise ValueError(
                "binary_encoding must be one of: "
                "base64, hex, metadata."
            )

        self._binary_encoding = binary_encoding

    # =====================================================
    # Properties
    # =====================================================

    @property
    def registry(self) -> DatabaseRegistry:
        """Return the configured DatabaseRegistry."""
        return self._registry

    @property
    def default_database_name(self) -> str:
        """Return the default logical database name."""
        return self._default_database_name

    @property
    def max_rows(self) -> int:
        """Return the maximum number of result records."""
        return self._max_rows

    @property
    def query_timeout_seconds(self) -> int:
        """Return the configured query timeout."""
        return self._query_timeout_seconds

    # =====================================================
    # Execution
    # =====================================================

    def execute(
        self,
        validation_result: SQLValidationResult,
        user: UserIdentity,
        database_name: Optional[str] = None,
        parameters: Optional[
            Mapping[str, Any]
        ] = None,
        max_rows: Optional[int] = None,
    ) -> QueryExecutionResult:
        """
        Execute one validated read-only SQL query.

        Args:
            validation_result:
                SQLValidationResult from Phase 3. The result must have
                status='valid' and contain executable_sql.

            user:
                Authenticated user identity used for authorization.

            database_name:
                Approved logical registry name. Defaults to northwind.

            parameters:
                Named SQL parameters. Values are passed separately to
                SQLAlchemy and are never interpolated into SQL text.

            max_rows:
                Optional stricter row limit. This cannot exceed:
                - QueryExecutor.max_rows
                - settings.MAX_QUERY_ROWS
                - the validated SQL row limit

        Returns:
            QueryExecutionResult containing JSON-compatible records and
            structured execution metadata.
        """
        self._validate_validation_result(
            validation_result
        )

        if not isinstance(user, UserIdentity):
            raise TypeError(
                "user must be a UserIdentity instance."
            )

        selected_database = (
            self._validate_database_name(
                database_name
                or self._default_database_name
            )
        )

        authorization = self.authorize(
            user=user,
            database_name=selected_database,
        )

        if not authorization.allowed:
            raise QueryAuthorizationError(
                authorization.reason
            )

        execution_limit = self._resolve_execution_limit(
            validation_result=validation_result,
            requested_max_rows=max_rows,
        )

        query_parameters = dict(
            parameters or {}
        )

        started_at = perf_counter()

        try:
            records = self._registry.execute_read_only(
                query=validation_result.executable_sql,
                parameters=query_parameters,
                database_name=selected_database,
                max_rows=execution_limit,
            )

            elapsed_ms = (
                perf_counter() - started_at
            ) * 1000.0

            normalized_records = (
                self.normalize_records(records)
            )

            columns = self._extract_columns(
                normalized_records
            )

            truncated = self._infer_truncation(
                validation_result=validation_result,
                returned_count=len(
                    normalized_records
                ),
                execution_limit=execution_limit,
            )

            metadata = QueryExecutionMetadata(
                query_id=validation_result.query_id,
                database_name=selected_database,
                row_count=len(normalized_records),
                columns=columns,
                execution_time_ms=round(
                    elapsed_ms,
                    3,
                ),
                truncated=truncated,
                timeout_seconds=(
                    self._query_timeout_seconds
                ),
            )

            logger.info(
                "Executed validated query '{}' on database '{}' "
                "for user '{}'. Rows: {}, elapsed: {:.3f} ms",
                validation_result.query_id,
                selected_database,
                user.username,
                len(normalized_records),
                elapsed_ms,
            )

            return QueryExecutionResult(
                success=True,
                metadata=metadata,
                records=normalized_records,
                error_message=None,
            )

        except (
            DatabaseQueryError,
            DatabaseNotRegisteredError,
        ) as exc:
            elapsed_ms = (
                perf_counter() - started_at
            ) * 1000.0

            logger.error(
                "Validated query '{}' failed: {}",
                validation_result.query_id,
                str(exc),
            )

            return QueryExecutionResult(
                success=False,
                metadata=QueryExecutionMetadata(
                    query_id=(
                        validation_result.query_id
                    ),
                    database_name=(
                        selected_database
                    ),
                    row_count=0,
                    columns=[],
                    execution_time_ms=round(
                        elapsed_ms,
                        3,
                    ),
                    truncated=False,
                    timeout_seconds=(
                        self._query_timeout_seconds
                    ),
                ),
                records=[],
                error_message=self._safe_error_message(
                    exc
                ),
                retryable=self._is_retryable_error(exc),
            )

        except Exception as exc:
            elapsed_ms = (
                perf_counter() - started_at
            ) * 1000.0

            logger.exception(
                "Unexpected query execution error for query '{}'.",
                validation_result.query_id,
            )

            return QueryExecutionResult(
                success=False,
                metadata=QueryExecutionMetadata(
                    query_id=(
                        validation_result.query_id
                    ),
                    database_name=(
                        selected_database
                    ),
                    row_count=0,
                    columns=[],
                    execution_time_ms=round(
                        elapsed_ms,
                        3,
                    ),
                    truncated=False,
                    timeout_seconds=(
                        self._query_timeout_seconds
                    ),
                ),
                records=[],
                error_message=self._safe_error_message(
                    exc
                ),
                retryable=self._is_retryable_error(exc),
            )

    # =====================================================
    # Authorization
    # =====================================================

    def authorize(
        self,
        user: UserIdentity,
        database_name: str,
    ) -> ExecutionAuthorization:
        """
        Apply deterministic user and database authorization.

        For Northwind, the required permission is northwind:read.
        AuthorizationService applies the role policy and the supplied
        identity's explicit permissions. The registry check remains local
        to this final execution boundary.
        """
        if not isinstance(user, UserIdentity):
            raise TypeError(
                "user must be a UserIdentity instance."
            )

        selected_database = (
            self._validate_database_name(
                database_name
            )
        )

        if not self._registry.contains(
            selected_database
        ):
            return ExecutionAuthorization(
                allowed=False,
                database_name=selected_database,
                required_permission=(
                    self._required_permission(
                        selected_database
                    )
                ),
                reason=(
                    f"Database '{selected_database}' "
                    f"is not registered."
                ),
            )

        required_permission = (
            self._required_permission(
                selected_database
            )
        )
        authorization_result = self._authorization_service.authorize(
            user=user,
            required_permission=Permission(required_permission),
            database_name=selected_database,
        )
        return ExecutionAuthorization(
            allowed=authorization_result.allowed,
            database_name=selected_database,
            required_permission=required_permission,
            reason=authorization_result.reason,
        )

    @staticmethod
    def _required_permission(
        database_name: str,
    ) -> str:
        """Return the read permission required for a database."""
        permission_map = {
            "northwind": (
                Permission.NORTHWIND_READ.value
            ),
        }

        required_permission = (
            permission_map.get(database_name)
        )

        if required_permission is None:
            raise QueryAuthorizationError(
                f"No execution permission mapping exists "
                f"for database '{database_name}'."
            )

        return required_permission

    # =====================================================
    # Phase 3 boundary validation
    # =====================================================

    @staticmethod
    def _validate_validation_result(
        validation_result: SQLValidationResult,
    ) -> None:
        """
        Require successful Phase 3 validation before execution.

        QueryExecutor never accepts a raw SQL string as a substitute.
        """
        if not isinstance(
            validation_result,
            SQLValidationResult,
        ):
            raise TypeError(
                "validation_result must be an "
                "SQLValidationResult instance."
            )

        status = QueryExecutor._enum_or_string(
            validation_result.status
        )

        if status != SQLValidationStatus.VALID.value:
            raise InvalidValidatedQueryError(
                "Only SQL with validation status 'valid' "
                "may be executed."
            )

        if not validation_result.syntax_valid:
            raise InvalidValidatedQueryError(
                "SQL syntax validation did not pass."
            )

        if not validation_result.schema_valid:
            raise InvalidValidatedQueryError(
                "SQL schema validation did not pass."
            )

        if not validation_result.security_valid:
            raise InvalidValidatedQueryError(
                "SQL security validation did not pass."
            )

        if not validation_result.read_only:
            raise InvalidValidatedQueryError(
                "Only read-only SQL may be executed."
            )

        if not validation_result.executable_sql:
            raise InvalidValidatedQueryError(
                "Validated SQL does not contain executable_sql."
            )

    # =====================================================
    # Limit enforcement
    # =====================================================

    def _resolve_execution_limit(
        self,
        validation_result: SQLValidationResult,
        requested_max_rows: Optional[int],
    ) -> int:
        """Resolve the strictest applicable row limit."""
        applicable_limits = [
            self._max_rows,
            settings.MAX_QUERY_ROWS,
        ]

        if validation_result.row_limit is not None:
            applicable_limits.append(
                validation_result.row_limit
            )

        if requested_max_rows is not None:
            if not isinstance(
                requested_max_rows,
                int,
            ):
                raise TypeError(
                    "max_rows must be an integer."
                )

            if requested_max_rows < 1:
                raise ValueError(
                    "max_rows must be at least 1."
                )

            applicable_limits.append(
                requested_max_rows
            )

        return min(applicable_limits)

    @staticmethod
    def _infer_truncation(
        validation_result: SQLValidationResult,
        returned_count: int,
        execution_limit: int,
    ) -> bool:
        """
        Infer whether the execution boundary may have truncated results.

        This flag means the returned count reached the enforced boundary.
        It does not claim that additional rows definitely existed.
        """
        if returned_count < execution_limit:
            return False

        if validation_result.limit_added:
            return True

        if (
            validation_result.row_limit is not None
            and execution_limit
            < validation_result.row_limit
        ):
            return True

        return False

    # =====================================================
    # Result normalization
    # =====================================================

    def normalize_records(
        self,
        records: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Convert database records into JSON-compatible dictionaries."""
        if not isinstance(records, list):
            raise TypeError(
                "records must be a list."
            )

        normalized_records: list[
            dict[str, Any]
        ] = []

        for row_index, record in enumerate(records):
            if not isinstance(record, dict):
                raise ResultNormalizationError(
                    f"Record at index {row_index} "
                    f"must be a dictionary."
                )

            normalized_record: dict[str, Any] = {}

            for key, value in record.items():
                normalized_key = str(key)

                normalized_record[
                    normalized_key
                ] = self.normalize_value(
                    value,
                    path=(
                        f"records[{row_index}]"
                        f".{normalized_key}"
                    ),
                )

            normalized_records.append(
                normalized_record
            )

        return normalized_records

    def normalize_value(
        self,
        value: Any,
        path: str = "value",
    ) -> Any:
        """
        Convert a MySQL/Python value into JSON-compatible data.

        Conversion rules:
        - None, bool, int and str remain unchanged
        - finite float remains float
        - NaN and infinity become None
        - Decimal becomes int when integral, otherwise float
        - datetime/date/time become ISO 8601 strings
        - bytes and bytearray use configured encoding
        - UUID and Enum become strings
        - tuples and sets become lists
        - lists and dictionaries are normalized recursively
        """
        if value is None:
            return None

        if isinstance(value, bool):
            return value

        if isinstance(value, int):
            return value

        if isinstance(value, float):
            if math.isnan(value) or math.isinf(value):
                return None

            return value

        if isinstance(value, str):
            return value

        if isinstance(value, Decimal):
            if not value.is_finite():
                return None

            if value == value.to_integral_value():
                return int(value)

            return float(value)

        if isinstance(value, datetime):
            return value.isoformat()

        if isinstance(value, date):
            return value.isoformat()

        if isinstance(value, time):
            return value.isoformat()

        if isinstance(
            value,
            (bytes, bytearray, memoryview),
        ):
            return self._normalize_binary(
                bytes(value)
            )

        if isinstance(value, UUID):
            return str(value)

        if isinstance(value, Enum):
            return self.normalize_value(
                value.value,
                path=path,
            )

        if isinstance(value, Mapping):
            return {
                str(key): self.normalize_value(
                    nested_value,
                    path=f"{path}.{key}",
                )
                for key, nested_value
                in value.items()
            }

        if isinstance(value, (list, tuple, set)):
            return [
                self.normalize_value(
                    item,
                    path=f"{path}[{index}]",
                )
                for index, item
                in enumerate(value)
            ]

        raise ResultNormalizationError(
            f"{path} contains unsupported value type "
            f"'{type(value).__name__}'."
        )

    def _normalize_binary(
        self,
        value: bytes,
    ) -> dict[str, Any]:
        """Normalize binary data without exposing raw bytes."""
        if self._binary_encoding == "base64":
            return {
                "encoding": "base64",
                "data": base64.b64encode(
                    value
                ).decode("ascii"),
                "size_bytes": len(value),
            }

        if self._binary_encoding == "hex":
            return {
                "encoding": "hex",
                "data": value.hex(),
                "size_bytes": len(value),
            }

        return {
            "encoding": "metadata",
            "data": None,
            "size_bytes": len(value),
        }

    @staticmethod
    def _extract_columns(
        records: list[dict[str, Any]],
    ) -> list[str]:
        """
        Return result columns in stable first-seen order.

        This also supports results where later records contain additional
        keys, although ordinary SQL results normally have fixed columns.
        """
        columns: list[str] = []
        seen: set[str] = set()

        for record in records:
            for column in record:
                if column not in seen:
                    seen.add(column)
                    columns.append(column)

        return columns

    # =====================================================
    # Other helpers
    # =====================================================

    @staticmethod
    def _validate_database_name(
        database_name: str,
    ) -> str:
        """Validate and normalize a logical database name."""
        if not isinstance(database_name, str):
            raise TypeError(
                "database_name must be a string."
            )

        clean_database_name = (
            database_name.strip().casefold()
        )

        if not clean_database_name:
            raise ValueError(
                "database_name cannot be empty."
            )

        return clean_database_name

    @staticmethod
    def _enum_or_string(
        value: Any,
    ) -> str:
        """Return a consistent value for enum or string fields."""
        if isinstance(value, Enum):
            return str(value.value)

        if hasattr(value, "value"):
            return str(value.value)

        return str(value)

    @staticmethod
    def _is_retryable_error(exception: Exception) -> bool:
        """Mark only transient SQLAlchemy connection failures as retryable."""
        cause = exception.__cause__
        if isinstance(
            cause,
            (OperationalError, SQLAlchemyTimeoutError),
        ):
            return True
        return (
            isinstance(cause, DBAPIError)
            and cause.connection_invalidated
        )

    @staticmethod
    def _safe_error_message(
        exception: Exception,
    ) -> str:
        """
        Return an application-safe execution error.

        Credentials and complete database connection URLs are not included.
        """
        if isinstance(
            exception,
            DatabaseNotRegisteredError,
        ):
            return (
                "The requested database is not available."
            )

        if isinstance(
            exception,
            DatabaseQueryError,
        ):
            return (
                "The validated query could not be "
                "executed by the database."
            )

        if isinstance(
            exception,
            ResultNormalizationError,
        ):
            return str(exception)

        return (
            "An unexpected error occurred while executing "
            "the validated query."
        )


def get_query_executor() -> QueryExecutor:
    """
    Return a QueryExecutor using the initialized shared registry.

    Keeping construction behind a function avoids creating additional
    database engines or registries.
    """
    return QueryExecutor(
        registry=database_registry,
        default_database_name="northwind",
        max_rows=settings.MAX_QUERY_ROWS,
        query_timeout_seconds=(
            settings.QUERY_TIMEOUT
        ),
    )