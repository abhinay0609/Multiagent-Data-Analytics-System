"""Deterministic analytics building blocks."""

from analytics.anomaly_detection import detect_anomalies
from analytics.comparison_analysis import (
    compare_groups,
    compare_periods,
    compare_values,
)
from analytics.insight_generator import generate_insights
from analytics.root_cause_analysis import analyze_contributions
from analytics.trend_analysis import analyze_trend

__all__ = [
    "analyze_contributions",
    "analyze_trend",
    "compare_groups",
    "compare_periods",
    "compare_values",
    "detect_anomalies",
    "generate_insights",
]