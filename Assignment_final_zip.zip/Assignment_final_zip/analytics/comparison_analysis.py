"""Deterministic comparisons across periods, products, or other segments."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from schemas.analysis_schema import ComparisonResult


def compare_values(
    metric_name: str,
    baseline_label: str,
    baseline_value: float,
    target_label: str,
    target_value: float,
) -> ComparisonResult:
    """Compare two measured values and calculate absolute and relative change."""
    baseline = _finite_number(baseline_value, "baseline_value")
    target = _finite_number(target_value, "target_value")
    change = target - baseline
    percentage = change / baseline * 100.0 if baseline != 0 else None
    direction = (
        "increased" if change > 0 else
        "decreased" if change < 0 else
        "was unchanged"
    )
    return ComparisonResult(
        name=metric_name,
        baseline_label=baseline_label,
        target_label=target_label,
        baseline_value=baseline,
        target_value=target,
        absolute_change=change,
        percentage_change=percentage,
        interpretation=(
            f"{metric_name} {direction} from the baseline to the target."
        ),
    )


def compare_groups(
    frame: pd.DataFrame,
    metric_column: str,
    group_column: str,
    baseline: Any,
    target: Any,
) -> ComparisonResult | None:
    """Compare summed metric values for any two dimension labels.

    The grouping column can represent a period, product, customer segment, or
    another categorical dimension. Return ``None`` when either group has no
    valid numeric observations.
    """
    if metric_column not in frame.columns or group_column not in frame.columns:
        raise ValueError("metric_column and group_column must exist in the data.")
    if baseline is None or target is None:
        raise ValueError("Both baseline and target labels are required.")

    values = pd.to_numeric(frame[metric_column], errors="coerce")
    valid = np.isfinite(values.to_numpy(dtype=float, na_value=np.nan))
    data = pd.DataFrame(
        {
            "group": frame[group_column],
            "value": values,
        },
        index=frame.index,
    ).loc[valid]
    data = data.dropna(subset=["group", "value"])
    if data.empty:
        return None

    grouped = data.groupby("group", dropna=True)["value"].sum()
    baseline_key = _matching_key(grouped.index, baseline)
    target_key = _matching_key(grouped.index, target)
    if baseline_key is None or target_key is None:
        return None
    result = compare_values(
        metric_column,
        str(baseline),
        float(grouped.loc[baseline_key]),
        str(target),
        float(grouped.loc[target_key]),
    )
    result.source_columns = [group_column, metric_column]
    return result


def compare_periods(
    frame: pd.DataFrame,
    metric_column: str,
    period_column: str,
    baseline_period: Any,
    target_period: Any,
) -> ComparisonResult | None:
    """Compare summed metric values for two explicitly selected periods."""
    return compare_groups(
        frame,
        metric_column,
        period_column,
        baseline_period,
        target_period,
    )


def _matching_key(index: pd.Index, candidate: Any) -> Any | None:
    if candidate in index:
        return candidate
    candidate_text = str(candidate).casefold()
    for key in index:
        if str(key).casefold() == candidate_text:
            return key
    return None


def _finite_number(value: float, name: str) -> float:
    result = float(value)
    if not np.isfinite(result):
        raise ValueError(f"{name} must be finite.")
    return result