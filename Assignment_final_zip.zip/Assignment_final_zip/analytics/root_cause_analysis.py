"""Evidence-based segment contribution analysis without causal claims."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd

from schemas.analysis_schema import ContributionResult


def analyze_contributions(
    frame: pd.DataFrame,
    metric_column: str,
    dimensions: Sequence[str],
    *,
    period_column: str | None = None,
    baseline: object | None = None,
    target: object | None = None,
    top_n: int = 5,
) -> list[ContributionResult]:
    """Rank observed segment contributions, optionally across two periods.

    Multiple dimensions produce progressively deeper groupings, such as
    category followed by category/product. When periods are provided, each
    group's contribution is its share of the overall change. Otherwise,
    results describe group share of the returned metric total.
    """
    if metric_column not in frame.columns:
        raise ValueError("metric_column must exist in the data.")
    if isinstance(dimensions, (str, bytes)) or not dimensions:
        raise ValueError("dimensions must contain at least one column.")
    if any(dimension not in frame.columns for dimension in dimensions):
        raise ValueError("Every contribution dimension must exist in the data.")
    if (baseline is None) != (target is None):
        raise ValueError("baseline and target must be supplied together.")
    if baseline is not None and period_column is None:
        raise ValueError(
            "period_column is required when comparing baseline and target."
        )
    if period_column is not None and period_column not in frame.columns:
        raise ValueError("period_column must exist in the data.")
    if (
        isinstance(top_n, bool)
        or not isinstance(top_n, int)
        or top_n < 1
    ):
        raise ValueError("top_n must be a positive integer.")

    values = pd.to_numeric(frame[metric_column], errors="coerce")
    valid = np.isfinite(values.to_numpy(dtype=float, na_value=np.nan))
    data = frame.loc[valid, list(dimensions)].copy()
    data[metric_column] = values.loc[valid].astype(float)
    if period_column is not None:
        data[period_column] = frame.loc[valid, period_column]
    data = data.dropna(subset=list(dimensions) + [metric_column])

    results: list[ContributionResult] = []
    for depth in range(1, len(dimensions) + 1):
        group_columns = list(dimensions[:depth])
        dimension_label = " > ".join(group_columns)
        if baseline is not None and period_column is not None:
            baseline_values = _grouped_values(
                data, group_columns, metric_column, period_column, baseline
            )
            target_values = _grouped_values(
                data, group_columns, metric_column, period_column, target
            )
            keys = baseline_values.index.union(target_values.index)
            baseline_total = float(baseline_values.sum())
            target_total = float(target_values.sum())
            overall_change = target_total - baseline_total
            ranked = []
            for key in keys:
                before = float(baseline_values.get(key, 0.0))
                after = float(target_values.get(key, 0.0))
                change = after - before
                contribution = (
                    change / overall_change * 100.0
                    if overall_change != 0
                    else None
                )
                ranked.append((key, before, after, change, contribution))
            ranked.sort(key=lambda item: abs(item[3]), reverse=True)
            for key, before, after, change, contribution in ranked[:top_n]:
                results.append(
                    ContributionResult(
                        dimension=dimension_label,
                        segment=_format_key(key),
                        baseline_value=before,
                        target_value=after,
                        absolute_change=change,
                        contribution_percentage=contribution,
                        source_columns=(
                            group_columns + [metric_column, period_column]
                        ),
                        evidence=(
                            "Segment change calculated from returned baseline "
                            "and target rows; contribution is descriptive, not "
                            "causal."
                        ),
                    )
                )
        else:
            grouped = data.groupby(group_columns, dropna=True)[metric_column].sum()
            total = float(grouped.sum())
            ranked_values = grouped.sort_values(
                key=lambda series: series.abs(),
                ascending=False,
            ).head(top_n)
            for key, value in ranked_values.items():
                numeric_value = float(value)
                share = numeric_value / total * 100.0 if total != 0 else None
                results.append(
                    ContributionResult(
                        dimension=dimension_label,
                        segment=_format_key(key),
                        target_value=numeric_value,
                        share_percentage=share,
                        source_columns=group_columns + [metric_column],
                        evidence=(
                            "Group total calculated from returned rows; this "
                            "is descriptive, not causal evidence."
                        ),
                    )
                )
    return results


def _grouped_values(
    data: pd.DataFrame,
    dimensions: list[str],
    metric_column: str,
    period_column: str,
    period: object,
) -> pd.Series:
    selected = data.loc[data[period_column].astype(str) == str(period)]
    return selected.groupby(dimensions, dropna=True)[metric_column].sum()


def _format_key(key: object) -> str:
    if isinstance(key, tuple):
        return " > ".join(str(item) for item in key)
    return str(key)