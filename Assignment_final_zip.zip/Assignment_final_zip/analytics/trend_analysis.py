"""Deterministic time-series trend and growth calculations."""

from __future__ import annotations

import numpy as np
import pandas as pd

from schemas.analysis_schema import TrendDirection, TrendResult


def analyze_trend(
    frame: pd.DataFrame,
    time_column: str,
    metric_column: str,
    *,
    granularity: str = "month",
    rolling_window: int = 3,
) -> TrendResult | None:
    """Aggregate and summarize a time series with growth and rolling averages.

    Monthly and quarterly growth series are calculated regardless of the
    requested display granularity. The rolling average follows that
    granularity and uses up to ``rolling_window`` current and prior periods.
    """
    if time_column not in frame.columns or metric_column not in frame.columns:
        raise ValueError("time_column and metric_column must exist in the data.")
    if (
        isinstance(rolling_window, bool)
        or not isinstance(rolling_window, int)
        or rolling_window < 1
    ):
        raise ValueError("rolling_window must be a positive integer.")

    normalized_granularity = granularity.casefold()
    period_rule = _period_rule(normalized_granularity)
    output_granularity = (
        "month"
        if normalized_granularity in {"auto", "none"}
        else normalized_granularity
    )
    time_values = pd.to_datetime(frame[time_column], errors="coerce", utc=True)
    metric_values = pd.to_numeric(frame[metric_column], errors="coerce")
    valid = (
        time_values.notna()
        & metric_values.notna()
        & np.isfinite(metric_values.to_numpy(dtype=float, na_value=np.nan))
    )
    data = pd.DataFrame(
        {"time": time_values[valid].dt.tz_convert(None), "value": metric_values[valid]}
    )
    if data.empty:
        return None

    monthly = _aggregate_periods(data, "M")
    quarterly = _aggregate_periods(data, "Q")
    selected = _aggregate_periods(data, period_rule)
    if len(selected) < 2:
        return None

    values = selected.to_numpy(dtype=float)
    differences = np.diff(values)
    if np.all(np.isclose(differences, 0.0)):
        direction = TrendDirection.STABLE
    elif np.any(differences > 0) and np.any(differences < 0):
        direction = TrendDirection.VOLATILE
    elif values[-1] > values[0]:
        direction = TrendDirection.INCREASING
    else:
        direction = TrendDirection.DECREASING

    change = float(values[-1] - values[0])
    percentage = float(change / values[0] * 100.0) if values[0] != 0 else None
    rolling = (
        pd.Series(values)
        .rolling(window=rolling_window, min_periods=1)
        .mean()
        .to_list()
    )
    direction_text = {
        TrendDirection.INCREASING: "increased",
        TrendDirection.DECREASING: "decreased",
        TrendDirection.STABLE: "remained stable",
        TrendDirection.VOLATILE: "varied across the observed periods",
    }[direction]
    periods = [str(period) for period in selected.index]
    return TrendResult(
        metric_name=metric_column,
        direction=direction,
        start_value=float(values[0]),
        end_value=float(values[-1]),
        absolute_change=change,
        percentage_change=percentage,
        period_count=len(selected),
        interpretation=(
            f"{metric_column} {direction_text} across the observed "
            f"{output_granularity} periods."
        ),
        granularity=output_granularity,
        periods=periods,
        values=values.tolist(),
        period_growth_percentages=_growth_rates(selected),
        month_over_month_growth=_growth_rates(monthly),
        quarter_over_quarter_growth=_growth_rates(quarterly),
        rolling_average=[float(value) for value in rolling],
        rolling_window=rolling_window,
        source_columns=[time_column, metric_column],
    )


def _aggregate_periods(data: pd.DataFrame, frequency: str) -> pd.Series:
    periods = data["time"].dt.to_period(frequency)
    return data.groupby(periods, sort=True)["value"].sum()


def _growth_rates(values: pd.Series) -> list[float | None]:
    result: list[float | None] = [None]
    for offset in range(1, len(values)):
        previous = float(values.iloc[offset - 1])
        current = float(values.iloc[offset])
        prior_period = values.index[offset - 1]
        current_period = values.index[offset]
        if current_period.ordinal - prior_period.ordinal != 1:
            result.append(None)
            continue
        result.append(
            float((current - previous) / previous * 100.0)
            if previous != 0
            else None
        )
    return result


def _period_rule(granularity: str) -> str:
    normalized = granularity.casefold()
    rules = {
        "auto": "M",
        "none": "M",
        "day": "D",
        "week": "W",
        "month": "M",
        "quarter": "Q",
        "year": "Y",
    }
    try:
        return rules[normalized]
    except KeyError as exc:
        raise ValueError(
            "granularity must be auto, day, week, month, quarter, or year."
        ) from exc