# """Streamlit frontend for the Multi-Agent Data Analytics API."""
# from __future__ import annotations

# import os
# import requests
# import streamlit as st
# import pandas as pd

# st.set_page_config(page_title="Multi-Agent Analytics", page_icon="📊", layout="wide")

# DEFAULT_API = os.getenv("ANALYTICS_API_URL", "http://127.0.0.1:8000").rstrip("/")
# ANALYTICS_REQUEST_TIMEOUT_SECONDS = int(
#     os.getenv("ANALYTICS_REQUEST_TIMEOUT_SECONDS", "900")
# )
# if ANALYTICS_REQUEST_TIMEOUT_SECONDS < 1:
#     raise ValueError("ANALYTICS_REQUEST_TIMEOUT_SECONDS must be at least 1.")

# if "api_url" not in st.session_state:
#     st.session_state.api_url = DEFAULT_API
# if "token" not in st.session_state:
#     st.session_state.token = None
# if "username" not in st.session_state:
#     st.session_state.username = None
# if "history" not in st.session_state:
#     st.session_state.history = []


# def api_request(
#     method: str,
#     path: str,
#     *,
#     timeout: int | tuple[int, int] = 180,
#     **kwargs,
# ):
#     headers = kwargs.pop("headers", {})
#     if st.session_state.token:
#         headers["Authorization"] = f"Bearer {st.session_state.token}"
#     return requests.request(
#         method, f"{st.session_state.api_url}{path}",
#         headers=headers, timeout=timeout, **kwargs
#     )


# def login_panel():
#     st.title("📊 Multi-Agent Data Analytics")
#     st.caption("Northwind business analytics · LangGraph workflow")
#     with st.sidebar:
#         st.subheader("Backend")
#         st.session_state.api_url = st.text_input("API base URL", st.session_state.api_url).rstrip("/")
#         try:
#             health = requests.get(f"{st.session_state.api_url}/health", timeout=5)
#             st.success("API connected" if health.ok else "API unavailable")
#         except requests.RequestException:
#             st.error("Cannot reach FastAPI. Start it with `python run_api.py`.")
#     with st.form("login_form"):
#         username = st.text_input("Username")
#         password = st.text_input("Password", type="password")
#         submitted = st.form_submit_button("Sign in", use_container_width=True)
#     if submitted:
#         try:
#             response = api_request("POST", "/api/auth/login",
#                                    json={"username": username, "password": password})
#             if response.ok:
#                 payload = response.json()
#                 st.session_state.token = payload.get("access_token")
#                 st.session_state.username = username
#                 st.rerun()
#             else:
#                 st.error("Login failed. Check credentials and account status.")
#         except requests.RequestException as exc:
#             st.error(f"API request failed: {exc}")


# def main_app():
#     with st.sidebar:
#         st.success(f"Signed in as {st.session_state.username}")
#         database = st.selectbox("Database", ["northwind"])
#         retries = st.slider("Maximum SQL retries", 0, 5, 2)
#         if st.button("Sign out"):
#             for key in ("token", "username", "history"):
#                 st.session_state.pop(key, None)
#             st.rerun()
#         st.divider()
#         st.caption("Each submitted question runs as an independent request.")

#     st.title("Business Analytics Workspace")
#     st.write("Ask a business question in natural language. The backend handles intent, planning, SQL safety, execution, analysis and reporting.")
#     examples = [
#         "Show the top 5 customers by total sales.",
#         "Which five customers generated the lowest total sales?",
#         "Which products generated the highest total sales?",
#         "What is the average sales value per order?",
#         "Which countries have the highest number of customers?",
#         "Show total sales by country.",
#     ]
#     with st.expander("Example questions"):
#         for item in examples:
#             st.markdown(f"- {item}")

#     question = st.text_area("Business question", height=100,
#                             placeholder="e.g. Show total sales by country")
#     run = st.button("Run analysis", type="primary", disabled=not question.strip())
#     if run:
#         with st.spinner("Running multi-agent workflow..."):
#             try:
#                 response = api_request(
#                     "POST", "/api/analytics/query",
#                     json={"question": question, "database_name": database,
#                           "max_retries": retries},
#                     timeout=(5, ANALYTICS_REQUEST_TIMEOUT_SECONDS),
#                 )
#                 if response.ok:
#                     result = response.json()
#                     st.session_state.history.insert(0, {
#                         "question": question, "result": result
#                     })
#                     st.session_state.history = st.session_state.history[:10]
#                 else:
#                     try:
#                         detail = response.json().get("detail", {})
#                     except ValueError:
#                         detail = response.text
#                     st.error(f"Request failed ({response.status_code})")
#                     st.json(detail)
#             except requests.RequestException as exc:
#                 st.error(f"Backend communication error: {exc}")

#     if st.session_state.history:
#         latest = st.session_state.history[0]["result"]
#         st.divider()
#         st.subheader("Latest result")
#         c1, c2, c3, c4 = st.columns(4)
#         c1.metric("Status", latest.get("status", "—"))
#         c2.metric("Rows", latest.get("row_count", 0))
#         c3.metric("SQL executed", "Yes" if latest.get("query_executed") else "No")
#         c4.metric("Grounded", str(latest.get("grounded", "—")))
#         if latest.get("final_answer"):
#             st.markdown(latest["final_answer"])
#         report = latest.get("report") or {}
#         if report:
#             st.subheader(report.get("title", "Analytical report"))
#             summary = report.get("executive_summary")
#             if summary:
#                 st.write(summary if isinstance(summary, str) else summary)
#             findings = report.get("key_findings", [])
#             if findings:
#                 st.markdown("#### Key findings")
#                 for finding in findings:
#                     if isinstance(finding, dict):
#                         st.markdown(f"- **{finding.get('title', 'Finding')}**: {finding.get('description', finding.get('statement', ''))}")
#                     else:
#                         st.markdown(f"- {finding}")
#             recommendations = report.get("recommendations", [])
#             if recommendations:
#                 st.markdown("#### Recommendations")
#                 for item in recommendations:
#                     st.markdown(f"- {item.get('recommendation', item) if isinstance(item, dict) else item}")
#             charts = latest.get("chart_specifications", [])
#             if charts:
#                 st.markdown("#### Visualization specifications")
#                 st.json(charts)
#             with st.expander("Full validated report"):
#                 st.json(report)
#         with st.expander("Request diagnostics"):
#             st.write("Request ID:", latest.get("request_id"))
#             st.write("Retry count:", latest.get("retry_count"))
#             st.json(latest.get("errors", []))
#         with st.expander("Recent requests"):
#             for item in st.session_state.history:
#                 st.write(item["question"])
#                 st.caption(f"Request ID: {item['result'].get('request_id')} · {item['result'].get('status')}")


# if not st.session_state.token:
#     login_panel()
# else:
#     main_app()


"""
Streamlit frontend for the Multi-Agent Data Analytics API.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

import pandas as pd
import requests
import streamlit as st
from loguru import logger

from reporting.visualization_manager import (
    VisualizationError,
    create_figure,
)


st.set_page_config(
    page_title="Multi-Agent Analytics",
    page_icon="📊",
    layout="wide",
)


DEFAULT_API = os.getenv(
    "ANALYTICS_API_URL",
    "http://127.0.0.1:8000",
).rstrip("/")

ANALYTICS_CONNECT_TIMEOUT_SECONDS = int(
    os.getenv(
        "ANALYTICS_CONNECT_TIMEOUT_SECONDS",
        "10",
    )
)

ANALYTICS_REQUEST_TIMEOUT_SECONDS = int(
    os.getenv(
        "ANALYTICS_REQUEST_TIMEOUT_SECONDS",
        "900",
    )
)

if ANALYTICS_CONNECT_TIMEOUT_SECONDS < 1:
    raise ValueError(
        "ANALYTICS_CONNECT_TIMEOUT_SECONDS "
        "must be at least 1."
    )

if ANALYTICS_REQUEST_TIMEOUT_SECONDS < 1:
    raise ValueError(
        "ANALYTICS_REQUEST_TIMEOUT_SECONDS "
        "must be at least 1."
    )


def _initialize_session_state() -> None:
    """Initialize all Streamlit session values."""
    defaults = {
        "api_url": DEFAULT_API,
        "token": None,
        "username": None,
        "history": [],
    }

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


_initialize_session_state()


def api_request(
    method: str,
    path: str,
    *,
    timeout: int | tuple[int, int] | None = None,
    **kwargs: Any,
) -> requests.Response:
    """Send an authenticated request to FastAPI."""
    headers = dict(
        kwargs.pop(
            "headers",
            {},
        )
    )

    if st.session_state.token:
        headers["Authorization"] = (
            f"Bearer "
            f"{st.session_state.token}"
        )

    resolved_timeout = (
        timeout
        if timeout is not None
        else (
            ANALYTICS_CONNECT_TIMEOUT_SECONDS,
            ANALYTICS_REQUEST_TIMEOUT_SECONDS,
        )
    )

    return requests.request(
        method=method,
        url=(
            f"{st.session_state.api_url}"
            f"{path}"
        ),
        headers=headers,
        timeout=resolved_timeout,
        **kwargs,
    )


def login_panel() -> None:
    """Render authentication and API connectivity controls."""
    st.title(
        "📊 Multi-Agent Data Analytics"
    )

    st.caption(
        "Northwind business analytics · "
        "LangGraph workflow"
    )

    with st.sidebar:
        st.subheader("Backend")

        st.session_state.api_url = (
            st.text_input(
                "API base URL",
                st.session_state.api_url,
            )
            .strip()
            .rstrip("/")
        )

        if st.session_state.api_url:
            try:
                health = requests.get(
                    (
                        f"{st.session_state.api_url}"
                        f"/health"
                    ),
                    timeout=5,
                )

                if health.ok:
                    st.success(
                        "API connected"
                    )
                else:
                    st.error(
                        "API returned an unhealthy status."
                    )

            except requests.RequestException:
                st.error(
                    "Cannot reach FastAPI. "
                    "Start it with: python run_api.py"
                )
        else:
            st.warning(
                "Enter the FastAPI base URL."
            )

    with st.form("login_form"):
        username = st.text_input(
            "Username"
        )

        password = st.text_input(
            "Password",
            type="password",
        )

        submitted = st.form_submit_button(
            "Sign in",
            use_container_width=True,
        )

    if not submitted:
        return

    if not st.session_state.api_url:
        st.error(
            "Configure the API base URL first."
        )
        return

    try:
        response = api_request(
            "POST",
            "/api/auth/login",
            json={
                "username": username,
                "password": password,
            },
            timeout=(
                ANALYTICS_CONNECT_TIMEOUT_SECONDS,
                30,
            ),
        )

        if response.ok:
            payload = response.json()

            access_token = payload.get(
                "access_token"
            )

            if not access_token:
                st.error(
                    "Login succeeded but no "
                    "access token was returned."
                )
                return

            st.session_state.token = (
                access_token
            )

            st.session_state.username = (
                username.strip()
            )

            st.session_state.history = []

            st.rerun()

        else:
            st.error(
                "Login failed. Check credentials "
                "and account status."
            )

    except requests.RequestException as exc:
        st.error(
            f"API request failed: {exc}"
        )


def main_app() -> None:
    """Render the authenticated analytics workspace."""
    with st.sidebar:
        st.success(
            f"Signed in as "
            f"{st.session_state.username}"
        )

        database = st.selectbox(
            "Database",
            ["northwind"],
        )

        retries = st.slider(
            "Maximum SQL retries",
            min_value=0,
            max_value=5,
            value=2,
        )

        if st.button("Sign out"):
            _clear_authenticated_state()
            st.rerun()

        st.divider()

        st.caption(
            "Each submitted question runs "
            "as an independent request."
        )

    st.title(
        "Business Analytics Workspace"
    )

    st.write(
        "Ask a business question in natural "
        "language. The backend handles intent, "
        "planning, SQL safety, execution, "
        "analysis and reporting."
    )

    examples = [
        "How many customers are there?",
        "How many products are there?",
        "Show the top 5 customers by total sales.",
        "Show total sales by country.",
        "Which countries have the highest number of customers?",
        "Which products generated the highest total sales?",
        "What is the monthly sales revenue?",
        (
            "Which five products generated the "
            "lowest total sales?"
        ),
        "Which categories are growing fastest over time?",
    ]

    with st.expander("Example questions"):
        for item in examples:
            st.markdown(f"- {item}")

    question = st.text_area(
        "Business question",
        height=100,
        placeholder=(
            "e.g. Show total sales by country"
        ),
    )

    run_analysis = st.button(
        "Run analysis",
        type="primary",
        disabled=not question.strip(),
    )

    if run_analysis:
        _run_analysis(
            question=question.strip(),
            database=database,
            retries=retries,
        )

    if st.session_state.history:
        latest_entry = (
            st.session_state.history[0]
        )

        _render_latest_result(
            question=latest_entry[
                "question"
            ],
            result=latest_entry[
                "result"
            ],
        )

    _render_recent_requests()


def _run_analysis(
    *,
    question: str,
    database: str,
    retries: int,
) -> None:
    """Submit one independent analytics request."""
    with st.spinner(
        "Running multi-agent workflow..."
    ):
        try:
            response = api_request(
                "POST",
                "/api/analytics/query",
                json={
                    "question": question,
                    "database_name": database,
                    "max_retries": retries,
                },
                timeout=(
                    ANALYTICS_CONNECT_TIMEOUT_SECONDS,
                    ANALYTICS_REQUEST_TIMEOUT_SECONDS,
                ),
            )

            if response.ok:
                result = response.json()

                st.session_state.history.insert(
                    0,
                    {
                        "question": question,
                        "result": result,
                    },
                )

                st.session_state.history = (
                    st.session_state.history[:10]
                )

                return

            try:
                payload = response.json()
                detail = payload.get(
                    "detail",
                    payload,
                )

            except ValueError:
                detail = response.text

            st.error(
                f"Request failed "
                f"({response.status_code})"
            )

            if isinstance(
                detail,
                (dict, list),
            ):
                st.json(detail)
            else:
                st.write(detail)

        except requests.Timeout:
            st.error(
                "The analytics request exceeded "
                f"{ANALYTICS_REQUEST_TIMEOUT_SECONDS} "
                "seconds. Check the FastAPI terminal "
                "to identify the slow agent."
            )

        except requests.ConnectionError:
            st.error(
                "Cannot connect to the FastAPI "
                "backend. Confirm that python "
                "run_api.py is running."
            )

        except requests.RequestException as exc:
            st.error(
                f"Backend communication error: "
                f"{exc}"
            )


def _render_latest_result(
    *,
    question: str,
    result: dict[str, Any],
) -> None:
    """Render the newest analytics response."""
    st.divider()

    st.subheader("Latest result")

    st.caption(
        f"Question: {question}"
    )

    status_column, rows_column, sql_column, grounded_column = (
        st.columns(4)
    )

    status_column.metric(
        "Status",
        result.get(
            "status",
            "—",
        ),
    )

    rows_column.metric(
        "Rows",
        result.get(
            "row_count",
            0,
        ),
    )

    sql_column.metric(
        "SQL executed",
        (
            "Yes"
            if result.get(
                "query_executed"
            )
            else "No"
        ),
    )

    grounded_column.metric(
        "Grounded",
        str(
            result.get(
                "grounded",
                "—",
            )
        ),
    )

    final_answer = result.get(
        "final_answer"
    )

    if final_answer and not result.get("report"):
        st.markdown(final_answer)

    total_ms = result.get("total_execution_time_ms")
    if total_ms is not None:
        st.metric("Workflow stage time (sum)", f"{float(total_ms):,.1f} ms")

    sql_used = result.get("sql_used")
    if sql_used:
        with st.expander("SQL query used", expanded=True):
            st.code(sql_used, language="sql")

    stage_timings = result.get("stage_timings") or []
    if stage_timings:
        st.subheader("Agent execution timings")
        timing_rows = [
            {
                "Stage": item.get("stage", "unknown"),
                "Duration (ms)": item.get("duration_ms", 0),
                "Status": item.get("status", "completed"),
            }
            for item in stage_timings if isinstance(item, Mapping)
        ]
        if timing_rows:
            st.dataframe(pd.DataFrame(timing_rows), use_container_width=True, hide_index=True)

    _render_visualizations(result)

    _render_result_table(result)

    _render_report(result)

    _render_diagnostics(result)


def _render_visualizations(
    result: dict[str, Any],
) -> None:
    """Build and display Plotly figures."""
    chart_specifications = (
        result.get(
            "chart_specifications",
            [],
        )
        or []
    )

    visualization_data = (
        result.get(
            "visualization_data",
            [],
        )
        or []
    )

    if not chart_specifications:
        st.info(
            "No visualization was generated "
            "for this analysis."
        )
        return

    if not visualization_data:
        st.warning(
            "A visualization specification was "
            "returned, but visualization data "
            "is empty."
        )
        return

    st.subheader("Visualizations")

    request_id = str(
        result.get(
            "request_id",
            "unknown",
        )
    )

    rendered_count = 0

    for index, chart in enumerate(
        chart_specifications
    ):
        if not isinstance(
            chart,
            Mapping,
        ):
            st.warning(
                f"Chart {index + 1} has an "
                f"invalid specification."
            )
            continue

        chart_id = str(
            chart.get(
                "chart_id",
                f"chart_{index}",
            )
        )

        chart_type = str(
            chart.get(
                "chart_type",
                "unknown",
            )
        )

        try:
            figure = create_figure(
                chart,
                data=visualization_data,
            )

            if figure is None:
                continue

            st.plotly_chart(
                figure,
                use_container_width=True,
                key=(
                    f"chart_{request_id}_"
                    f"{chart_id}_{index}"
                ),
            )

            rationale = chart.get(
                "rationale"
            )

            if rationale:
                st.caption(
                    f"Why this chart: "
                    f"{rationale}"
                )

            rendered_count += 1

            logger.info(
                "[request_id={}] [STREAMLIT] "
                "chart_id={} type={} rows={} "
                "rendered=true",
                request_id,
                chart_id,
                chart_type,
                len(visualization_data),
            )

        except VisualizationError as exc:
            st.warning(
                f"Chart '{chart_id}' could not "
                f"be rendered: {exc}"
            )

            logger.warning(
                "[request_id={}] [STREAMLIT] "
                "chart_id={} type={} rows={} "
                "rendered=false reason={}",
                request_id,
                chart_id,
                chart_type,
                len(visualization_data),
                exc,
            )

    if rendered_count == 0:
        st.warning(
            "No chart could be rendered from "
            "the returned specifications."
        )


def _render_result_table(
    result: dict[str, Any],
) -> None:
    """Display visualization/query records as a proper table."""
    records = (
        result.get(
            "visualization_data",
            [],
        )
        or []
    )

    if not records:
        return

    valid_records = [
        dict(record)
        for record in records
        if isinstance(record, Mapping)
    ]

    if not valid_records:
        return

    st.subheader(
        "Returned query results"
    )

    data_frame = pd.DataFrame.from_records(
        valid_records
    )

    numeric_columns = (
        data_frame.select_dtypes(
            include="number"
        ).columns
    )

    column_configuration = {
        column: st.column_config.NumberColumn(
            _display_name(
                str(column)
            ),
            format="%.2f",
        )
        for column in numeric_columns
    }

    st.dataframe(
        data_frame,
        use_container_width=True,
        hide_index=True,
        column_config=column_configuration,
    )


def _render_report(
    result: dict[str, Any],
) -> None:
    """Render the validated analytical report."""
    report = (
        result.get("report")
        or {}
    )

    if not report:
        return

    st.subheader(
        report.get(
            "report_title",
            report.get(
                "title",
                "Analytical report",
            ),
        )
    )

    summary = report.get(
        "executive_summary"
    )

    if summary:
        st.write(summary)

    findings = report.get(
        "key_findings",
        [],
    )

    if findings:
        st.markdown(
            "#### Key findings"
        )

        for finding in findings[:5]:
            if isinstance(
                finding,
                Mapping,
            ):
                title = finding.get(
                    "title",
                    "Finding",
                )

                description = finding.get(
                    "description",
                    finding.get(
                        "statement",
                        "",
                    ),
                )

                st.markdown(
                    f"- **{title}**: "
                    f"{description}"
                )
            else:
                st.markdown(
                    f"- {finding}"
                )
        if len(findings) > 5:
            st.caption(
                f"Showing 5 of {len(findings)} findings."
            )

    recommendations = report.get(
        "recommendations",
        [],
    )

    if recommendations:
        st.markdown(
            "#### Recommendations"
        )

        for item in recommendations[:3]:
            if isinstance(
                item,
                Mapping,
            ):
                recommendation = item.get(
                    "recommendation",
                    item.get(
                        "title",
                        str(item),
                    ),
                )
            else:
                recommendation = item

            st.markdown(
                f"- {recommendation}"
            )

    limitations = report.get(
        "limitations",
        [],
    )

    if limitations:
        st.markdown(
            "#### Limitations"
        )

        for limitation in limitations:
            st.markdown(
                f"- {limitation}"
            )


def _render_diagnostics(
    result: dict[str, Any],
) -> None:
    """Render raw response diagnostics in collapsed sections."""
    chart_specifications = (
        result.get(
            "chart_specifications",
            [],
        )
        or []
    )

    report = (
        result.get("report")
        or {}
    )

    with st.expander(
        "Visualization specifications"
    ):
        st.json(
            chart_specifications
        )

    with st.expander(
        "Full validated report"
    ):
        st.json(report)

    with st.expander(
        "Request diagnostics"
    ):
        st.write(
            "Request ID:",
            result.get(
                "request_id"
            ),
        )

        st.write(
            "Retry count:",
            result.get(
                "retry_count",
                0,
            ),
        )

        st.write(
            "Execution error:",
            result.get(
                "execution_error"
            ),
        )

        st.json(
            result.get(
                "errors",
                [],
            )
        )


def _render_recent_requests() -> None:
    """Render recent request metadata."""
    if not st.session_state.history:
        return

    with st.expander("Recent requests"):
        for item in (
            st.session_state.history
        ):
            result = item.get(
                "result",
                {},
            )

            st.write(
                item.get(
                    "question",
                    "Unknown question",
                )
            )

            st.caption(
                "Request ID: "
                f"{result.get('request_id')} · "
                f"{result.get('status')}"
            )


def _clear_authenticated_state() -> None:
    """Clear authentication and request-specific frontend state."""
    for key in (
        "token",
        "username",
        "history",
    ):
        st.session_state.pop(
            key,
            None,
        )


def _display_name(
    value: str,
) -> str:
    """Convert a database column into a display label."""
    return (
        value.replace("_", " ")
        .strip()
        .title()
    )


if not st.session_state.token:
    login_panel()
else:
    main_app()