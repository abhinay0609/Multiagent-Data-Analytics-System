"""Internal identity and explicit role-permission definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

from schemas.user_schema import (
    Permission,
    UserIdentity,
    UserRole,
    UserStatus,
)


@dataclass(frozen=True)
class RoleDefinition:
    """Capabilities assigned to one application role."""

    permissions: frozenset[Permission]
    allowed_databases: frozenset[str]


ROLE_DEFINITIONS: Mapping[UserRole, RoleDefinition] = MappingProxyType(
    {
        UserRole.ADMINISTRATOR: RoleDefinition(
            permissions=frozenset(
                {
                    Permission.NORTHWIND_READ,
                    Permission.ANALYTICS_EXECUTE,
                    Permission.SCHEMA_READ,
                    Permission.REPORTS_READ,
                    Permission.TRACES_READ,
                }
            ),
            allowed_databases=frozenset({"northwind"}),
        ),
        UserRole.BUSINESS_MANAGER: RoleDefinition(
            permissions=frozenset(
                {
                    Permission.NORTHWIND_READ,
                    Permission.ANALYTICS_EXECUTE,
                    Permission.SCHEMA_READ,
                    Permission.REPORTS_READ,
                }
            ),
            allowed_databases=frozenset({"northwind"}),
        ),
        UserRole.EMPLOYEE: RoleDefinition(
            permissions=frozenset(),
            allowed_databases=frozenset(),
        ),
    }
)


@dataclass(frozen=True)
class InternalUser:
    """Server-side account record; its password hash is never serialized."""

    user_id: str
    username: str
    display_name: str
    password_hash: str = field(repr=False)
    role: UserRole
    permissions: frozenset[Permission]
    status: UserStatus
    allowed_databases: frozenset[str]

    def to_identity(self) -> UserIdentity:
        """Create a safe identity without the password hash."""
        return UserIdentity(
            user_id=self.user_id,
            username=self.username,
            display_name=self.display_name,
            role=self.role,
            permissions=sorted(
                self.permissions,
                key=lambda permission: permission.value,
            ),
            status=self.status,
            allowed_databases=sorted(self.allowed_databases),
        )


def role_definition(role: UserRole) -> RoleDefinition:
    """Return policy for a supported role."""
    if not isinstance(role, UserRole):
        raise TypeError("role must be a UserRole value.")
    return ROLE_DEFINITIONS[role]