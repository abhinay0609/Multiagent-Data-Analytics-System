"""Retrieve and format reports produced by the analytics workflow."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from pydantic import ValidationError

from schemas.report_schema import ReportResult
from services.analytics_service import AnalyticsServiceResult


class ReportServiceError(RuntimeError):
    """Base error for report retrieval and formatting."""


class ReportUnavailableError(ReportServiceError):
    """Raised when an analytics result does not contain a report."""


class ReportService:
    """Extract validated report objects and render concise text summaries."""

    def get_report(
        self,
        analytics_result: (
            AnalyticsServiceResult
            | ReportResult
            | Mapping[str, Any]
        ),
    ) -> ReportResult:
        """Retrieve the report payload from a service or workflow result."""
        if isinstance(analytics_result, ReportResult):
            report = analytics_result.model_copy(deep=True)
            report.generated_sql = None
            for chart in report.charts:
                chart.data = []
            return report
        if isinstance(analytics_result, AnalyticsServiceResult):
            report_values = analytics_result.report
        elif isinstance(analytics_result, Mapping):
            report_values = analytics_result.get(
                "report",
                analytics_result.get("report_result"),
            )
        else:
            raise TypeError(
                "analytics_result must be a report or mapping."
            )

        if not isinstance(report_values, Mapping) or not report_values:
            raise ReportUnavailableError(
                "No report is available for this analytics result."
            )
        sanitized_values = dict(report_values)
        sanitized_values.pop("generated_sql", None)
        chart_values = sanitized_values.get("charts", [])
        if isinstance(chart_values, list):
            sanitized_values["charts"] = [
                {
                    **chart,
                    "data": [],
                }
                if isinstance(chart, Mapping)
                else chart
                for chart in chart_values
            ]
        try:
            return ReportResult.model_validate(sanitized_values)
        except ValidationError as exc:
            raise ReportServiceError(
                "The report result does not match the report schema."
            ) from exc

    def format_report(
        self,
        analytics_result: (
            AnalyticsServiceResult
            | ReportResult
            | Mapping[str, Any]
        ),
    ) -> str:
        """Return the approved final answer or format a validated report."""
        if isinstance(analytics_result, AnalyticsServiceResult):
            if analytics_result.final_answer:
                return analytics_result.final_answer
            return _format(self.get_report(analytics_result))

        if isinstance(analytics_result, Mapping):
            try:
                service_result = AnalyticsServiceResult.model_validate(
                    analytics_result
                )
            except ValidationError:
                service_result = None
            if service_result is not None and service_result.final_answer:
                return service_result.final_answer

            final_answer = analytics_result.get("final_answer")
            guardrail = analytics_result.get(
                "output_guardrail_result",
                {},
            )
            if (
                isinstance(final_answer, str)
                and final_answer.strip()
                and isinstance(guardrail, Mapping)
                and guardrail.get("approved") is True
            ):
                return final_answer
        return _format(self.get_report(analytics_result))


def _format(report: ReportResult) -> str:
    sections = [
        report.report_title,
        report.executive_summary,
    ]
    if report.key_findings:
        sections.extend(
            [
                "Key findings:",
                *[
                    f"- {finding.title}: {finding.description}"
                    for finding in report.key_findings
                ],
            ]
        )
    if report.recommendations:
        sections.extend(
            [
                "Recommendations:",
                *[
                    f"- {item.title}: {item.recommendation}"
                    for item in report.recommendations
                ],
            ]
        )
    for label, values in (
        ("Limitations", report.limitations),
        ("Assumptions", report.assumptions),
        ("Warnings", report.warnings),
    ):
        if values:
            sections.extend(
                [f"{label}:", *[f"- {value}" for value in values]]
            )
    return "\n\n".join(sections)


report_service = ReportService()