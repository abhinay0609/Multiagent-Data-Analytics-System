# services/llm_service.py

import json
import logging
from typing import Any, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_ollama import ChatOllama

from config.settings import settings


logger = logging.getLogger(__name__)
_JSON_MAX_OUTPUT_TOKENS = 2048


class LLMService:
    """
    Central service for communicating with the locally running Ollama model.

    Responsibilities:
    - Initialize the configured Ollama model
    - Generate text responses
    - Generate structured JSON responses
    - Provide a simple connection test
    """

    def __init__(
        self,
        model_name: Optional[str] = None,
        base_url: Optional[str] = None,
        temperature: float = 0.1,
    ) -> None:
        self.model_name = model_name or settings.OLLAMA_MODEL
        self.base_url = base_url or settings.OLLAMA_BASE_URL
        self.temperature = temperature

        self._client = ChatOllama(
            model=self.model_name,
            base_url=self.base_url,
            temperature=self.temperature,
            num_predict=_JSON_MAX_OUTPUT_TOKENS,
        )

        logger.info(
            "LLMService initialized with model=%s and base_url=%s",
            self.model_name,
            self.base_url,
        )

    @property
    def client(self) -> ChatOllama:
        """Return the configured ChatOllama client."""
        return self._client

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
    ) -> str:
        """
        Generate a text response from Ollama.

        Args:
            prompt: User instruction or question.
            system_prompt: Optional behavior or role instruction.

        Returns:
            Generated response as a cleaned string.
        """
        if not prompt or not prompt.strip():
            raise ValueError("Prompt cannot be empty.")

        messages = self._build_messages(prompt, system_prompt)

        try:
            response = self._client.invoke(messages)
            content = response.content

            if isinstance(content, str):
                return content.strip()

            return str(content).strip()

        except Exception as exc:
            logger.exception(
                "Ollama generation failed using model %s",
                self.model_name,
            )
            raise RuntimeError(
                "Unable to generate an Ollama response. "
                f"Confirm that Ollama is running at {self.base_url} "
                f"and that model '{self.model_name}' is installed."
            ) from exc

    def generate_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        output_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Generate JSON using JSON-Schema constraints when a schema is supplied.

        Unconstrained JSON calls still use Ollama JSON mode.
        """
        if not prompt or not prompt.strip():
            raise ValueError("Prompt cannot be empty.")
        if output_schema is not None and not isinstance(output_schema, dict):
            raise TypeError("output_schema must be a JSON Schema object.")

        json_instruction = (
            "\n\nReturn only valid JSON. "
            "Do not include Markdown, code fences, or explanatory text."
        )
        messages = self._build_messages(
            prompt.strip() + json_instruction,
            system_prompt,
        )

        if output_schema is not None:
            response = self._client.with_structured_output(
                output_schema,
                method="json_schema",
                include_raw=True,
            ).invoke(messages)
            if not isinstance(response, dict):
                raise ValueError(
                    "Ollama returned an invalid structured response."
                )
            parsing_error = response.get("parsing_error")
            if parsing_error is not None:
                raise ValueError(
                    "Ollama returned a response that did not match "
                    "the requested JSON schema."
                ) from parsing_error
            parsed_response = response.get("parsed")
            if not isinstance(parsed_response, dict):
                raise ValueError(
                    "Ollama did not return a JSON object matching "
                    "the requested schema."
                )
            return parsed_response

        response = self._client.bind(
            format="json",
            options={
                "temperature": self.temperature,
                "num_predict": _JSON_MAX_OUTPUT_TOKENS,
            },
        ).invoke(messages)
        content = response.content
        response_text = (
            content.strip()
            if isinstance(content, str)
            else str(content).strip()
        )
        cleaned_response = self._remove_code_fences(response_text)

        try:
            parsed_response = json.loads(
                cleaned_response,
                object_pairs_hook=_reject_duplicate_json_keys,
            )
        except json.JSONDecodeError as exc:
            logger.warning(
                "Ollama returned invalid JSON at line %s, column %s.",
                exc.lineno,
                exc.colno,
            )
            raise ValueError(
                "Ollama returned an invalid JSON response."
            ) from exc
        except _DuplicateJSONKeyError as exc:
            logger.warning("Ollama returned duplicate JSON object keys.")
            raise ValueError(
                "Ollama returned a JSON object with duplicate keys."
            ) from exc

        if not isinstance(parsed_response, dict):
            raise ValueError(
                "Expected a JSON object, but Ollama returned another JSON type."
            )

        return parsed_response

    def health_check(self) -> dict[str, Any]:
        """
        Check whether the configured Ollama model responds successfully.
        """
        try:
            response = self.generate(
                prompt="Reply with exactly: OK",
                system_prompt=(
                    "You are a health-check service. "
                    "Follow the user's output instruction exactly."
                ),
            )

            return {
                "status": "healthy",
                "provider": "ollama",
                "model": self.model_name,
                "base_url": self.base_url,
                "response": response,
            }

        except Exception as exc:
            return {
                "status": "unhealthy",
                "provider": "ollama",
                "model": self.model_name,
                "base_url": self.base_url,
                "error": str(exc),
            }

    @staticmethod
    def _remove_code_fences(response: str) -> str:
        """Remove common JSON Markdown fences."""
        cleaned = response.strip()

        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        elif cleaned.startswith("```"):
            cleaned = cleaned[3:]

        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]

        return cleaned.strip()

    @staticmethod
    def _build_messages(
        prompt: str,
        system_prompt: Optional[str],
    ) -> list[SystemMessage | HumanMessage]:
        """Create chat messages from validated prompt text."""
        messages: list[SystemMessage | HumanMessage] = []
        if system_prompt and system_prompt.strip():
            messages.append(SystemMessage(content=system_prompt.strip()))
        messages.append(HumanMessage(content=prompt.strip()))
        return messages


class _DuplicateJSONKeyError(ValueError):
    """Raised when a JSON object repeats one of its keys."""


def _reject_duplicate_json_keys(
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateJSONKeyError(key)
        result[key] = value
    return result


# Shared service instance for agents and application modules.
llm_service = LLMService()