"""Authorization-checked schema access for application and agent callers."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Protocol

from auth.authentication import authentication_service
from auth.authorization import authorization_service
from schemas.user_schema import AuthorizationResult, Permission, UserIdentity


class SchemaServiceError(RuntimeError):
    """Base error for safe schema service operations."""


class SchemaAuthenticationError(SchemaServiceError):
    """Raised when a username cannot be resolved to an active identity."""


class SchemaAccessDeniedError(SchemaServiceError):
    """Raised when the identity lacks schema access."""


class SchemaDatabaseUnavailableError(SchemaServiceError):
    """Raised when the requested logical database is not registered."""


class UserLookup(Protocol):
    def get_user_by_username(self, username: str) -> UserIdentity | None: ...


class SchemaAuthorizer(Protocol):
    def authorize(
        self,
        user: UserIdentity,
        required_permission: Permission | str,
        database_name: str | None = None,
    ) -> AuthorizationResult: ...


class RegistryLookup(Protocol):
    def contains(self, name: str) -> bool: ...


class SchemaManagerProvider(Protocol):
    def get_database_schema(
        self,
        database_name: str | None = None,
    ) -> dict[str, Any]: ...

    def list_tables(
        self,
        database_name: str | None = None,
    ) -> list[str]: ...

    def get_table_schema(
        self,
        table_name: str,
        database_name: str | None = None,
    ) -> dict[str, Any]: ...

    def build_schema_context(
        self,
        database_name: str | None = None,
        **kwargs: Any,
    ) -> str: ...


class SchemaService:
    """Expose registered schema metadata only after backend authorization."""

    def __init__(
        self,
        *,
        registry: RegistryLookup | None = None,
        schema_manager: SchemaManagerProvider | None = None,
        authentication: UserLookup | None = None,
        authorization: SchemaAuthorizer | None = None,
    ) -> None:
        if registry is None and schema_manager is None:
            from database.database_registry import (
                initialize_database_registry,
            )
            from database.schema_manager import SchemaManager

            registry = initialize_database_registry()
            schema_manager = SchemaManager(registry)
        elif registry is None or schema_manager is None:
            raise ValueError(
                "registry and schema_manager must be supplied together."
            )

        self._registry = registry
        self._schema_manager = schema_manager
        self._authentication = (
            authentication
            if authentication is not None
            else authentication_service
        )
        self._authorization = (
            authorization
            if authorization is not None
            else authorization_service
        )

    def get_schema(
        self,
        username: str,
        database_name: str = "northwind",
    ) -> dict[str, Any]:
        """Return full schema metadata for a permitted registered database."""
        self._authorize(username, database_name)
        schema = self._schema_manager.get_database_schema(
            database_name=database_name,
        )
        return deepcopy(schema)

    def list_tables(
        self,
        username: str,
        database_name: str = "northwind",
    ) -> list[str]:
        """List table names for a permitted registered database."""
        self._authorize(username, database_name)
        return list(
            self._schema_manager.list_tables(
                database_name=database_name,
            )
        )

    def get_table_schema(
        self,
        username: str,
        table_name: str,
        database_name: str = "northwind",
    ) -> dict[str, Any]:
        """Return one table's columns, keys, indexes, and relationships."""
        self._authorize(username, database_name)
        return deepcopy(
            self._schema_manager.get_table_schema(
                table_name=table_name,
                database_name=database_name,
            )
        )

    def build_schema_context(
        self,
        username: str,
        database_name: str = "northwind",
        *,
        table_names: list[str] | None = None,
        max_tables: int = 25,
        max_characters: int = 12000,
    ) -> str:
        """Build compact schema context for an authorized agent request."""
        self._authorize(username, database_name)
        return self._schema_manager.build_schema_context(
            database_name=database_name,
            table_names=table_names,
            max_tables=max_tables,
            max_characters=max_characters,
        )

    def _authorize(
        self,
        username: str,
        database_name: str,
    ) -> UserIdentity:
        if not isinstance(username, str) or not username.strip():
            raise ValueError("username must be a non-empty string.")
        if not isinstance(database_name, str) or not database_name.strip():
            raise ValueError("database_name must be a non-empty string.")

        identity = self._authentication.get_user_by_username(username)
        if identity is None:
            raise SchemaAuthenticationError(
                "No active account exists for the supplied username."
            )

        decision = self._authorization.authorize(
            identity,
            Permission.SCHEMA_READ,
            database_name,
        )
        if not decision.allowed:
            raise SchemaAccessDeniedError(decision.reason)
        if not self._registry.contains(database_name):
            raise SchemaDatabaseUnavailableError(
                f"Database '{database_name}' is not registered."
            )
        return identity