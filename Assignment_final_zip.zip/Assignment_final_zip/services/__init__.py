"""Application services for schema, analytics, and report access."""

from importlib import import_module
from typing import Any


_EXPORTS = {
    "AnalyticsAuthenticationError": "analytics_service",
    "AnalyticsService": "analytics_service",
    "AnalyticsServiceError": "analytics_service",
    "AnalyticsServiceResult": "analytics_service",
    "ReportService": "report_service",
    "ReportServiceError": "report_service",
    "ReportUnavailableError": "report_service",
    "SchemaAccessDeniedError": "schema_service",
    "SchemaAuthenticationError": "schema_service",
    "SchemaDatabaseUnavailableError": "schema_service",
    "SchemaService": "schema_service",
    "SchemaServiceError": "schema_service",
}

__all__ = [
    "AnalyticsAuthenticationError",
    "AnalyticsService",
    "AnalyticsServiceError",
    "AnalyticsServiceResult",
    "ReportService",
    "ReportServiceError",
    "ReportUnavailableError",
    "SchemaAccessDeniedError",
    "SchemaAuthenticationError",
    "SchemaDatabaseUnavailableError",
    "SchemaService",
    "SchemaServiceError",
]


def __getattr__(name: str) -> Any:
    """Load service exports on demand to avoid graph import cycles."""
    module_name = _EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module 'services' has no attribute {name!r}")
    module = import_module(f"services.{module_name}")
    return getattr(module, name)