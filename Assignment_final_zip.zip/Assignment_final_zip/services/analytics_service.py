"""Service entry point for authenticated analytics workflow requests."""

from __future__ import annotations

from threading import RLock
from typing import Any, Mapping, Protocol

from pydantic import BaseModel, ConfigDict, Field
from loguru import logger
from config.logging_config import request_logger

from auth.authentication import (
    AuthenticationService,
    authentication_service,
)
from auth.authorization import AuthorizationService, authorization_service
from graph.nodes import create_default_dependencies
from graph.state import AnalyticsState, create_initial_state, validate_state
from graph.workflow import build_workflow


class AnalyticsServiceError(RuntimeError):
    """Base error for analytics service operations."""


class AnalyticsAuthenticationError(AnalyticsServiceError):
    """Raised when the username does not resolve to an active user."""


class WorkflowInvoker(Protocol):
    def invoke(
        self,
        input: Any,
        config: Any = None,
        **kwargs: Any,
    ) -> Any: ...


class AnalyticsServiceResult(BaseModel):
    """Public result without internal SQL or workflow state."""

    model_config = ConfigDict(extra="forbid")

    request_id: str
    status: str
    database_name: str
    final_answer: str | None = None
    report: dict[str, Any] | None = None
    chart_specifications: list[dict[str, Any]]
    visualization_data: list[dict[str, Any]]
    errors: list[dict[str, Any]]
    retry_count: int
    requires_human_approval: bool
    human_approved: bool | None = None
    query_executed: bool = False
    row_count: int = 0
    result_rows: int = 0
    execution_error: str | None = None
    sufficient_data: bool | None = None
    grounded: bool | None = None
    sql_used: str | None = None
    stage_timings: list[dict[str, Any]] = Field(default_factory=list)
    total_execution_time_ms: float = 0.0


class AnalyticsService:
    """Resolve the user and invoke the complete analytics StateGraph."""

    def __init__(
        self,
        workflow: WorkflowInvoker | None = None,
        *,
        authentication: AuthenticationService | None = None,
        authorization: AuthorizationService | None = None,
        workflow_database_name: str = "northwind",
    ) -> None:
        self._authentication = (
            authentication
            if authentication is not None
            else authentication_service
        )
        self._authorization = (
            authorization
            if authorization is not None
            else authorization_service
        )
        self._fixed_workflow = workflow
        self._fixed_database_name = _normalize_database_name(
            workflow_database_name
        )
        self._workflows: dict[str, WorkflowInvoker] = {}
        self._lock = RLock()
        if workflow is not None:
            self._workflows[self._fixed_database_name] = workflow

    def analyze(
        self,
        user_question: str,
        username: str,
        database_name: str = "northwind",
        *,
        conversation_id: str | None = None,
        max_retries: int = 2,
    ) -> AnalyticsServiceResult:
        """Run analytics for a username resolved by the backend auth service.

        Callers should supply the username from their authenticated request
        context rather than accepting an untrusted client-selected identity.
        """
        if not isinstance(username, str) or not username.strip():
            raise ValueError("username must be a non-empty string.")
        selected_database = _normalize_database_name(database_name)
        identity = self._authentication.get_user_by_username(username)
        if identity is None:
            raise AnalyticsAuthenticationError(
                "No active account exists for the supplied username."
            )

        initial_state = create_initial_state(
            user_query=user_question,
            database_name=selected_database,
            user_id=identity.user_id,
            conversation_id=conversation_id,
            max_retries=max_retries,
        )
        request_id = initial_state["request_id"]
        thread_id = request_id  # independent request = independent LangGraph thread
        log = request_logger(request_id, "request")
        log.info(
            "request_started user={} database={} thread_id={} question={!r}",
            username, selected_database, thread_id, user_question[:500],
        )
        log.info(
            "fresh_state intent={} selected_tables={} generated_sql_present={} query_results={} final_answer_present={}",
            initial_state.get("intent"), initial_state.get("selected_tables"),
            bool(initial_state.get("generated_sql")), 0,
            bool(initial_state.get("final_answer")),
        )
        workflow = self._workflow_for(selected_database)
        result = workflow.invoke(
            initial_state,
            config={"configurable": {"thread_id": thread_id}},
        )
        if not isinstance(result, Mapping):
            raise AnalyticsServiceError(
                "The workflow returned an invalid state object."
            )

        state: AnalyticsState = dict(result)
        validate_state(state)
        public_result = self._public_result(state)
        log.info(
            "request_completed status={} query_executed={} row_count={} grounded={} retries={} errors={} warnings={}",
            public_result.status, public_result.query_executed,
            public_result.row_count, public_result.grounded,
            public_result.retry_count, len(public_result.errors),
            len(state.get("warnings", [])),
        )
        return public_result

    def _workflow_for(self, database_name: str) -> WorkflowInvoker:
        if (
            self._fixed_workflow is not None
            and database_name != self._fixed_database_name
        ):
            raise ValueError(
                "The injected workflow is configured for database "
                f"'{self._fixed_database_name}', not '{database_name}'."
            )

        with self._lock:
            workflow = self._workflows.get(database_name)
            if workflow is None:
                dependencies = create_default_dependencies(
                    database_name,
                    authentication=self._authentication,
                    authorization=self._authorization,
                )
                workflow = build_workflow(dependencies)
                self._workflows[database_name] = workflow
            return workflow

    @staticmethod
    def _public_result(state: AnalyticsState) -> AnalyticsServiceResult:
        guardrail = state.get("output_guardrail_result", {})
        execution = state.get("execution_result", {})
        execution = execution if isinstance(execution, Mapping) else {}
        execution_metadata = execution.get("metadata", {})
        execution_metadata = (
            execution_metadata
            if isinstance(execution_metadata, Mapping)
            else {}
        )
        execution_records = execution.get("records", [])
        execution_records = (
            execution_records if isinstance(execution_records, list) else []
        )
        analysis = state.get("analysis_result", {})
        analysis = analysis if isinstance(analysis, Mapping) else {}
        analysis_sufficiency = analysis.get("sufficient_data")
        if not isinstance(analysis_sufficiency, bool):
            analysis_sufficiency = None

        output_approved = (
            isinstance(guardrail, Mapping)
            and guardrail.get("approved") is True
        )
        approval_satisfied = (
            not state.get("requires_human_approval", False)
            or state.get("human_approved") is True
        )
        can_publish = output_approved and approval_satisfied

        report = state.get("report_result") or None
        if not can_publish:
            report = None
        if report is not None:
            report = dict(report)
            report.pop("generated_sql", None)
            for chart in report.get("charts", []):
                if isinstance(chart, dict):
                    chart.pop("data", None)

        public_errors = []
        for error in state.get("errors", []):
            if isinstance(error, Mapping):
                public_errors.append(
                    {
                        "category": error.get("category", "internal"),
                        "message": error.get(
                            "message",
                            "The workflow encountered an error.",
                        ),
                        "recoverable": bool(error.get("recoverable", False)),
                    }
                )

        if (
            state.get("current_agent") == "output_guardrail"
            and public_errors
            and isinstance(guardrail, Mapping)
        ):
            issue_codes = sorted(
                {
                    issue.partition(":")[0].strip()
                    for issue in guardrail.get("issues", [])
                    if isinstance(issue, str) and ":" in issue
                }
            )
            if issue_codes:
                public_errors[-1]["diagnostic_codes"] = issue_codes

        grounding = state.get("output_guardrail_result", {}).get(
            "grounded"
        )
        report_grounding = (
            report.get("grounded")
            if isinstance(report, Mapping)
            else None
        )
        if isinstance(grounding, bool) and isinstance(report_grounding, bool):
            grounding = grounding and report_grounding
        if not isinstance(grounding, bool) and report is not None:
            grounding = (
                report_grounding
                if isinstance(report_grounding, bool)
                else None
            )
        if not isinstance(grounding, bool):
            grounding = None
        row_count = execution_metadata.get("row_count")
        if (
            isinstance(row_count, bool)
            or not isinstance(row_count, int)
            or row_count < 0
        ):
            row_count = len(execution_records)
        execution_error = (
            "Database query execution failed."
            if (
                execution and execution.get("success") is False
            )
            or (
                not execution
                and any(
                    isinstance(error, Mapping)
                    and error.get("category") == "sql_execution"
                    for error in state.get("errors", [])
                )
            )
            else None
        )

        return AnalyticsServiceResult(
            request_id=state["request_id"],
            status=state["status"],
            database_name=state["database_name"],
            final_answer=(
                state.get("final_answer") if output_approved else None
            ),
            report=report,
            chart_specifications=[
                dict(item)
                for item in state.get("chart_specifications", [])
                if can_publish and isinstance(item, Mapping)
            ],
            visualization_data=[
                dict(item)
                for item in state.get("visualization_data", [])
                if (
                    can_publish
                    and state.get("chart_specifications")
                    and isinstance(item, Mapping)
                )
            ],
            errors=public_errors,
            retry_count=state.get("retry_count", 0),
            requires_human_approval=state.get(
                "requires_human_approval",
                False,
            ),
            human_approved=state.get("human_approved"),
            query_executed=bool(execution) or execution_error is not None,
            row_count=row_count,
            result_rows=len(execution_records),
            execution_error=execution_error,
            sufficient_data=analysis_sufficiency,
            grounded=grounding,
            sql_used=state.get("validated_sql") or state.get("generated_sql"),
            stage_timings=list(state.get("stage_timings", [])),
            total_execution_time_ms=round(sum(
                float(item.get("duration_ms", 0))
                for item in state.get("stage_timings", [])
                if isinstance(item, Mapping)
            ), 3),
        )


def _normalize_database_name(name: str) -> str:
    if not isinstance(name, str) or not name.strip():
        raise ValueError("database_name must be a non-empty string.")
    return name.strip().casefold()


analytics_service = AnalyticsService()