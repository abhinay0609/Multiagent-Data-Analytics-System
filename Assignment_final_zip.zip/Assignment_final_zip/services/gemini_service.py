"""Google Gemini client for schema-constrained narrative generation."""

from __future__ import annotations

import json
import logging
from functools import lru_cache
from typing import Any

from google import genai
from google.genai import types

from config.settings import settings


logger = logging.getLogger(__name__)


class GeminiService:
    """Generate text and JSON responses using the Gemini Developer API."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model_name: str | None = None,
        temperature: float | None = None,
    ) -> None:
        self._api_key = (
            settings.GEMINI_API_KEY if api_key is None else api_key
        )
        if not self._api_key:
            raise ValueError("GEMINI_API_KEY is not configured.")

        self.model_name = model_name or settings.GEMINI_MODEL
        self.temperature = (
            settings.GEMINI_TEMPERATURE
            if temperature is None
            else temperature
        )
        self._client: genai.Client | None = None

    def generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
    ) -> str:
        """Generate a text response from Gemini."""
        self._validate_prompt(prompt)
        try:
            response = self._client_or_create().models.generate_content(
                model=self.model_name,
                contents=prompt.strip(),
                config=types.GenerateContentConfig(
                    system_instruction=(
                        system_prompt.strip()
                        if system_prompt and system_prompt.strip()
                        else None
                    ),
                    temperature=self.temperature,
                ),
            )
        except Exception as exc:
            logger.exception(
                "Gemini text generation failed using model %s.",
                self.model_name,
            )
            raise RuntimeError("Gemini text generation failed.") from exc

        if not response.text:
            raise ValueError("Gemini returned an empty text response.")
        return response.text.strip()

    def generate_json(
        self,
        prompt: str,
        system_prompt: str | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Generate a JSON object, constrained by a supplied JSON Schema."""
        self._validate_prompt(prompt)
        if output_schema is not None and not isinstance(output_schema, dict):
            raise TypeError("output_schema must be a JSON Schema object.")

        config_values: dict[str, Any] = {
            "system_instruction": (
                system_prompt.strip()
                if system_prompt and system_prompt.strip()
                else None
            ),
            "temperature": self.temperature,
            "response_mime_type": "application/json",
        }
        if output_schema is not None:
            config_values["response_json_schema"] = output_schema

        try:
            response = self._client_or_create().models.generate_content(
                model=self.model_name,
                contents=prompt.strip(),
                config=types.GenerateContentConfig(**config_values),
            )
        except Exception as exc:
            logger.exception(
                "Gemini JSON generation failed using model %s.",
                self.model_name,
            )
            raise RuntimeError("Gemini JSON generation failed.") from exc

        if not response.text:
            raise ValueError("Gemini returned an empty JSON response.")

        try:
            parsed_response = json.loads(
                response.text,
                object_pairs_hook=_reject_duplicate_json_keys,
            )
        except (json.JSONDecodeError, _DuplicateJSONKeyError) as exc:
            logger.warning("Gemini returned invalid or duplicate-key JSON.")
            raise ValueError("Gemini returned invalid JSON.") from exc

        if not isinstance(parsed_response, dict):
            raise ValueError("Gemini must return a JSON object.")
        return parsed_response

    def _client_or_create(self) -> genai.Client:
        if self._client is None:
            self._client = genai.Client(
                api_key=self._api_key,
                http_options=types.HttpOptions(
                    timeout=settings.GEMINI_TIMEOUT_SECONDS * 1000,
                ),
            )
        return self._client

    @staticmethod
    def _validate_prompt(prompt: str) -> None:
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Prompt cannot be empty.")


class _DuplicateJSONKeyError(ValueError):
    """Raised when a JSON object repeats one of its keys."""


def _reject_duplicate_json_keys(
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateJSONKeyError(key)
        result[key] = value
    return result


@lru_cache(maxsize=1)
def get_gemini_service() -> GeminiService:
    """Return the lazily initialized shared Gemini service."""
    return GeminiService()
