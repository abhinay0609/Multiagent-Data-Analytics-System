"""Login and access-token endpoints."""

from fastapi import APIRouter, Depends, HTTPException, status

from app.dependencies import AppDependencies, get_app_dependencies
from auth.authentication import InvalidCredentialsError
from schemas.user_schema import LoginRequest, TokenResponse


router = APIRouter(prefix="/api/auth", tags=["authentication"])


@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Authenticate and issue a bearer token",
)
def login(
    request: LoginRequest,
    dependencies: AppDependencies = Depends(get_app_dependencies),
) -> TokenResponse:
    try:
        return dependencies.authentication.login(
            request.username,
            request.password.get_secret_value(),
        )
    except InvalidCredentialsError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc