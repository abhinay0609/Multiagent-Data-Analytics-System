"""Authenticated analytics execution endpoint."""

from __future__ import annotations

from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
)
from fastapi.security import (
    HTTPAuthorizationCredentials,
    HTTPBearer,
)
from pydantic import BaseModel, ConfigDict, Field

from app.dependencies import (
    AppDependencies,
    authorize_user,
    get_app_dependencies,
)
from auth.jwt_handler import InvalidAccessTokenError
from schemas.user_schema import Permission, UserIdentity
from services.analytics_service import AnalyticsServiceResult
from services.analytics_service import AnalyticsServiceError


router = APIRouter(prefix="/api/analytics", tags=["analytics"])
_bearer_scheme = HTTPBearer(auto_error=False)


class AnalyticsQueryRequest(BaseModel):
    """Validated request body for an analytics query."""

    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=1, max_length=5000)
    database_name: str = Field(default="northwind", min_length=1, max_length=100)
    max_retries: int = Field(default=2, ge=0, le=5)


def get_current_user(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None,
        Depends(_bearer_scheme),
    ],
    dependencies: Annotated[
        AppDependencies,
        Depends(get_app_dependencies),
    ],
) -> UserIdentity:
    """Resolve the current user from a verified bearer token."""
    if credentials is None or credentials.scheme.casefold() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="A valid bearer token is required.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    try:
        return dependencies.authentication.authenticate_token(
            credentials.credentials
        )
    except InvalidAccessTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Access token is invalid or expired.",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


@router.post(
    "/query",
    response_model=AnalyticsServiceResult,
    summary="Run an authorized analytics request",
)
def run_analytics_query(
    request: AnalyticsQueryRequest,
    user: Annotated[UserIdentity, Depends(get_current_user)],
    dependencies: Annotated[
        AppDependencies,
        Depends(get_app_dependencies),
    ],
) -> AnalyticsServiceResult:
    if not authorize_user(
        user,
        dependencies,
        Permission.ANALYTICS_EXECUTE.value,
        request.database_name,
    ) or not authorize_user(
        user,
        dependencies,
        Permission.NORTHWIND_READ.value,
        request.database_name,
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to run analytics on this database.",
        )

    try:
        result = dependencies.analytics.analyze(
            user_question=request.question,
            username=user.username,
            database_name=request.database_name,
            max_retries=request.max_retries,
        )
    except AnalyticsServiceError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="The analytics workflow could not complete the request.",
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    if result.status == "failed":
        # Keep the failure actionable for API clients instead of returning
        # only a generic message. The workflow's safe response contains no
        # unvalidated SQL or database internals.
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={
                "message": "The analytics workflow could not complete the request.",
                "final_answer": result.final_answer,
                "errors": result.errors,
                "request_id": result.request_id,
                "retry_count": result.retry_count,
            },
        )

    dependencies.report_store.save(user.user_id, result)
    return result