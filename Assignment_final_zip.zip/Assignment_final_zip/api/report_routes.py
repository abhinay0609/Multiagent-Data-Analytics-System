"""Owner-scoped report retrieval endpoints."""

from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict

from api.analytics_routes import get_current_user
from app.dependencies import (
    AppDependencies,
    authorize_user,
    get_app_dependencies,
)
from schemas.report_schema import ReportResult
from schemas.user_schema import Permission, UserIdentity


router = APIRouter(prefix="/api/reports", tags=["reports"])


class ReportResponse(BaseModel):
    """Safe report payload returned by the API."""

    model_config = ConfigDict(extra="forbid")

    request_id: str
    database_name: str
    status: str
    report: ReportResult
    chart_specifications: list[dict[str, Any]]
    visualization_data: list[dict[str, Any]]


@router.get(
    "/{request_id}",
    response_model=ReportResponse,
    summary="Retrieve a report from this user's analytics request",
)
def get_report(
    request_id: str,
    user: Annotated[UserIdentity, Depends(get_current_user)],
    dependencies: Annotated[
        AppDependencies,
        Depends(get_app_dependencies),
    ],
) -> ReportResponse:
    result = dependencies.report_store.get_for_user(request_id, user)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found.",
        )
    if not authorize_user(
        user,
        dependencies,
        Permission.REPORTS_READ.value,
        result.database_name,
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to access this report.",
        )

    report = dependencies.reports.get_report(result)
    return ReportResponse(
        request_id=result.request_id,
        database_name=result.database_name,
        status=result.status,
        report=report,
        chart_specifications=result.chart_specifications,
        visualization_data=result.visualization_data,
    )