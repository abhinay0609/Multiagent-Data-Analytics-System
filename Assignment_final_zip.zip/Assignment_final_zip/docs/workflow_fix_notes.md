# Workflow query-routing fixes

## Root cause

The November 23 analytics log shows that distinct requests reached SQL
generation with fresh state, but the model returned the same valid
top-customer sales query for a product count and a monthly revenue trend.
Because the query passed syntax, schema, and read-only checks, validation
could not detect that it answered the wrong question. The prompt already
identified the current question and intent as authoritative, so prompt-only
guidance was not a reliable safeguard.

## Changes

- Preserved deterministic scalar COUNT semantics for customer and product
  questions, including the requested entity and no-grouping behavior.
- Normalized monthly revenue trend requests into a summed monthly metric and
  added anomaly analysis when unusual months are requested.
- Generate common scalar COUNT and monthly revenue queries directly from the
  validated intent and registered schema. Unsupported or incomplete schema
  fails explicitly; generated candidates still pass the existing SQL
  validation and authorization gates.
- Added explicit ascending/descending customer/product sales ranking
  normalization and extraction of word-form limits such as "five".
- Added `DATA_QUERY` intent normalization for product/supplier projections.
- Added an explicit `IS NULL` intent filter for customers who never placed an
  order; SQL prompt guidance requires an anti-join (`NOT EXISTS` or
  `LEFT JOIN ... IS NULL`).
- Expanded planning and SQL prompts to preserve these semantics.
- Added a deterministic evidence-based summary finding when a successful
  query has no ranking/trend/comparison finding (including scalar metrics and
  descriptive retrievals).
- Added a conservative review recommendation when no more specific
  recommendation can be derived from verified findings.
- Added a table-style report visualization for descriptive `DATA_QUERY`
  results when the reporting model does not supply a chart.
- Added regression tests for entity-specific scalar counts and monthly trend
  SQL, as well as the existing normalization cases.

## Expected normalized intent

| Question | Intent | Important semantics |
|---|---|---|
| How many customers are there? | aggregation | COUNT, scalar customer_count, no grouping |
| How many products are there? | aggregation | COUNT, scalar product_count, no grouping |
| Show the monthly revenue trend and highlight unusual months | trend_analysis | Monthly sales sum, trend and anomaly analysis |
| Which five customers generated the lowest total sales? | ranking | customer, SUM net sales, ASC, limit 5 |
| Show product names with supplier names. | data_query | product_name + supplier_name projection |
| Which customers have never placed an order? | data_query | customer projection, salesorder.orderId IS NULL anti-join |

## Validation

The focused normalization, SQL generation and graph tests pass. Generated
COUNT and monthly trend queries were also checked against the registered
Northwind SQL validator. No live end-to-end LLM/API request was run.

```powershell
.\venv\Scripts\python.exe -m pytest -q tests\test_intent_normalization.py tests\test_sql_agent_intent_queries.py tests\test_agents.py tests\test_graph.py
```
