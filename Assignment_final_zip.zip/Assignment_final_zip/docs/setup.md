## Run the API

The API exposes interactive OpenAPI documentation at
`http://127.0.0.1:8000/docs`.

The default authentication store is in-memory. For a first local API account,
set bootstrap credentials in the current PowerShell session before starting
the server. The password must satisfy the account password policy.

```powershell
$env:API_BOOTSTRAP_ADMIN_USERNAME = "admin.user"
$env:API_BOOTSTRAP_ADMIN_PASSWORD = "<strong-local-password>"
python run_api.py
```

Do not commit bootstrap credentials. In deployments with an approved user
store, load accounts through trusted startup code instead. Public signup is
not enabled.

Run the API tests from the project directory:

```powershell
python -m tests.test_api
```

Check liveness and dependency health with:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
Invoke-RestMethod http://127.0.0.1:8000/health/database
Invoke-RestMethod http://127.0.0.1:8000/health/llm
```