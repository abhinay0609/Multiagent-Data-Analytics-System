# MCP V2 execution strategy

## Runtime topology

Run three local processes from the project root:

1. `python -m mcp_integration.server.database_server` — one MCP server, loopback port 8001.
2. `python run_api.py` — FastAPI + LangGraph backend.
3. `python -m streamlit run streamlit_app.py` — UI.

Set `MCP_ENABLED=true` only after the MCP server responds. The client reads
`mcp_integration/registry/registry_config.yaml`, initializes an MCP session,
and calls `get_schema_context` for the SQL-generation context. The established
SchemaService still performs authorization and the existing QueryExecutor
still executes only SQLValidationResult objects after SQLGlot validation.

## Request sequence

1. FastAPI authenticates JWT and enforces analytics/database permissions.
2. Input guardrail and Intent Agent classify the request.
3. Planning Agent determines the required tables and operations.
4. Schema retrieval obtains structured metadata through the existing authorized
   SchemaService. With MCP enabled, the compact SQL schema context is fetched
   from the single MCP server using the MCP Client.
5. SQL Agent uses deterministic templates for supported intents. Otherwise it
   prefers Gemini when `GEMINI_API_KEY` is set and falls back to Ollama if the
   Gemini request fails.
6. SQL Validation enforces read-only SQL, allowed tables/columns, single
   statement and row limits.
7. QueryExecutor rechecks user/database authorization and executes the
   validated query using the approved registry connection.
8. Analysis Agent performs deterministic calculations and asks Gemini for
   narrative interpretation when configured (Ollama fallback).
9. Grounding Validator checks entities, metrics, columns and causal claims.
   Numeric formatting/derived values are not blocked solely because the exact
   formatted number is absent from raw rows; derived values must still be
   calculated from the executed dataset by deterministic analysis.
10. Reporting Agent produces executive summary, findings, trends, chart
    specifications and actionable recommendations. Output guardrails still
    reject secrets, prompt leakage, stack traces and destructive guidance.

## Observability

Every LangGraph node logs a start/end record with request ID. The end record
includes node duration in milliseconds. The API result includes `sql_used`,
`stage_timings` and `total_execution_time_ms`; Streamlit displays these in the
latest-result panel. The total is the sum of timed LangGraph node execution,
not complete wall-clock latency (it excludes some API/network/UI overhead).

## Security boundary

The MCP server binds to `127.0.0.1` by default. Do not expose it publicly as-is.
The server includes a read-only SQL tool for controlled MCP inspection and
integration testing, but the current LangGraph production query path continues
to execute through the existing per-user authorization + SQL validation +
QueryExecutor boundary. Do not switch query execution to the MCP tool until
signed/verified user identity and equivalent per-user RBAC are propagated to
the server. Use a dedicated MySQL account with SELECT-only grants.

## Live acceptance tests

Run the project test suite, then test these questions in Streamlit:

- How many customers are there?
- Show the top 5 customers by total sales.
- Which five customers generated the lowest total sales?
- Show total sales by country.
- Show the monthly revenue trend and highlight unusual months.
- Which product categories contribute the most to total sales?

For monthly trends, verify the returned result has a date/month dimension,
chronological ordering and enough periods for anomaly detection. For the query
`Show net revenue for orders shipped to Germany`, first inspect `salesorder`
for a shipping destination column. The supplied source ZIP/tests do not
establish that such a column exists; do not replace it with customer country.
If absent, add the correct business field or treat the request as unsupported.
