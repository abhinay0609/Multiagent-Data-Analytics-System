# Implementation and validation notes

## What repository inspection established

- `create_initial_state()` creates a new UUID `request_id` and initializes
  intent, selected tables, schema context, SQL, query results and final answer
  for every service call.
- `AnalyticsService` caches compiled workflows by database name, but the
  workflow is compiled without a LangGraph checkpointer. The previous
  implementation therefore did not demonstrate persisted checkpoint-state
  reuse. A request-specific `thread_id` is now also passed in the invocation
  config as a defensive isolation boundary.
- `ReportStore` already keys reports by `result.request_id` and checks the
  owner. This behavior is preserved.
- `RankingRequirement.sort_direction` previously defaulted to DESCENDING.
  That can turn a missing/ignored "lowest" instruction into a plausible but
  incorrect result. Deterministic question normalization now overrides the
  common ranking vocabulary and sets an explicit direction.
- The SQL Agent previously received the plan and schema but not the exact
  current question or complete validated intent. It now receives both, and
  the SQL prompt explicitly treats them as request-specific sources of truth.
- The Streamlit package files in the input archive were empty placeholders and
  `run_streamlit.py` was empty. A working API-backed login/query/report UI has
  been added.
- Loguru node logging existed but was sparse. Request/stage-bound rotating
  logging and safe state transition summaries have been added.

## Important limitation

The archive does not include a live Northwind database or running Ollama/Gemini
services. Consequently, no honest claim can be made that all six end-to-end
questions now produce verified SQL/results. The first incorrect stage for a
particular live request must be established from the newly added request-ID
logs. The intent normalization regression tests are included, but this
execution environment did not have the project's pinned dependencies
installed, so pytest collection stopped at missing `sqlglot` and `jose`.
`compileall` did pass.

## Run locally

```powershell
python -m pip install -r requirements.txt
python -m compileall .
python -m pytest -q
python run_api.py
# second terminal
python -m streamlit run streamlit_app.py
```

Use the same `request_id` to correlate all log lines for one request. Compare
the `intent_agent` before/after, `planning_agent`, `schema_retrieval`,
`sql_agent`, `sql_validation`, `query_executor`, `analysis_agent`,
`grounding_validator`, `reporting_agent`, and `output_guardrail` records.
