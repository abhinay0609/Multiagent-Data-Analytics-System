"""Shared application dependencies and process-local report storage."""

from __future__ import annotations

from dataclasses import dataclass, field
from threading import RLock
from typing import Any, Protocol

from fastapi import Request

from auth.authentication import (
    AuthenticationService,
    authentication_service,
)
from auth.authorization import (
    AuthorizationService,
    authorization_service,
)
from schemas.user_schema import UserIdentity
from services.analytics_service import (
    AnalyticsService,
    AnalyticsServiceResult,
    analytics_service,
)
from services.llm_service import llm_service
from services.report_service import ReportService, report_service


class ReportStore:
    """Keep approved report results available for the current API process."""

    def __init__(self) -> None:
        self._reports: dict[str, tuple[str, AnalyticsServiceResult]] = {}
        self._lock = RLock()

    def save(
        self,
        owner_id: str,
        result: AnalyticsServiceResult,
    ) -> None:
        if not isinstance(owner_id, str) or not owner_id.strip():
            raise ValueError("owner_id must be a non-empty string.")
        if not isinstance(result, AnalyticsServiceResult):
            raise TypeError(
                "result must be an AnalyticsServiceResult instance."
            )
        if result.report is None:
            return

        with self._lock:
            self._reports[result.request_id] = (owner_id, result)

    def get_for_user(
        self,
        request_id: str,
        user: UserIdentity,
    ) -> AnalyticsServiceResult | None:
        with self._lock:
            stored = self._reports.get(request_id)
        if stored is None or stored[0] != user.user_id:
            return None
        return stored[1]


class RegistryHealthProvider(Protocol):
    def health_check_all(self) -> dict[str, dict[str, Any]]: ...

    def dispose(self) -> None: ...


class LLMHealthProvider(Protocol):
    model_name: str

    def health_check(self) -> dict[str, Any]: ...


@dataclass
class AppDependencies:
    """Injectable application services shared by FastAPI routes."""

    authentication: AuthenticationService
    authorization: AuthorizationService
    analytics: AnalyticsService
    reports: ReportService
    llm: LLMHealthProvider
    registry: RegistryHealthProvider | None = None
    report_store: ReportStore = field(default_factory=ReportStore)


def create_app_dependencies(
    *,
    authentication: AuthenticationService | None = None,
    authorization: AuthorizationService | None = None,
    analytics: AnalyticsService | None = None,
    reports: ReportService | None = None,
    llm: LLMHealthProvider | None = None,
    registry: RegistryHealthProvider | None = None,
) -> AppDependencies:
    """Build the default dependency bundle with optional test overrides."""
    selected_authentication = (
        authentication
        if authentication is not None
        else authentication_service
    )
    selected_authorization = (
        authorization
        if authorization is not None
        else authorization_service
    )
    selected_analytics = analytics
    if selected_analytics is None:
        selected_analytics = (
            analytics_service
            if selected_authentication is authentication_service
            and selected_authorization is authorization_service
            else AnalyticsService(
                authentication=selected_authentication,
                authorization=selected_authorization,
            )
        )

    return AppDependencies(
        authentication=selected_authentication,
        authorization=selected_authorization,
        analytics=selected_analytics,
        reports=reports if reports is not None else report_service,
        llm=llm if llm is not None else llm_service,
        registry=registry,
    )


def get_app_dependencies(request: Request) -> AppDependencies:
    """Retrieve the dependency bundle installed on the current app."""
    dependencies = getattr(request.app.state, "dependencies", None)
    if not isinstance(dependencies, AppDependencies):
        raise RuntimeError("Application dependencies are not initialized.")
    return dependencies


def authorize_user(
    user: UserIdentity,
    dependencies: AppDependencies,
    permission: str,
    database_name: str | None = None,
) -> bool:
    """Use backend RBAC to authorize a protected API operation."""
    decision = dependencies.authorization.authorize(
        user,
        permission,
        database_name,
    )
    return decision.allowed