"""Application initialization and health-check helpers."""

from __future__ import annotations

from typing import Any

from loguru import logger

from app.dependencies import AppDependencies, RegistryHealthProvider
from config.settings import settings
from database.database_registry import initialize_database_registry
from schemas.user_schema import UserRole


def initialize_application(
    dependencies: AppDependencies,
) -> RegistryHealthProvider:
    """Initialize the approved database registry for the API process."""
    provision_bootstrap_admin(
        dependencies,
        username=settings.API_BOOTSTRAP_ADMIN_USERNAME,
        password=settings.API_BOOTSTRAP_ADMIN_PASSWORD,
        display_name=settings.API_BOOTSTRAP_ADMIN_DISPLAY_NAME,
    )
    if dependencies.registry is None:
        dependencies.registry = initialize_database_registry()
        logger.info("Database registry initialized for the API.")
    return dependencies.registry


def provision_bootstrap_admin(
    dependencies: AppDependencies,
    *,
    username: str,
    password: str,
    display_name: str,
) -> None:
    """Provision an optional initial admin without a public signup route."""
    if not username and not password:
        return
    if not username or not password:
        raise ValueError(
            "Both API_BOOTSTRAP_ADMIN_USERNAME and "
            "API_BOOTSTRAP_ADMIN_PASSWORD must be configured together."
        )

    existing_user = dependencies.authentication.get_user_by_username(
        username
    )
    if existing_user is not None:
        if existing_user.role != UserRole.ADMINISTRATOR:
            raise ValueError(
                "The configured bootstrap account already exists "
                "without the administrator role."
            )
        return

    dependencies.authentication.register_user(
        username=username,
        password=password,
        role=UserRole.ADMINISTRATOR,
        display_name=display_name or username,
    )
    logger.info("Bootstrap administrator provisioned.")


def check_database_health(
    registry: RegistryHealthProvider,
) -> dict[str, Any]:
    """Return sanitized health status for registered databases."""
    databases = registry.health_check_all()
    summarized = {
        name: details.get("status", "unhealthy")
        for name, details in databases.items()
    }
    healthy = bool(summarized) and all(
        status == "healthy"
        for status in summarized.values()
    )
    return {
        "status": "healthy" if healthy else "unhealthy",
        "databases": summarized,
    }


def check_llm_health(llm: Any) -> dict[str, Any]:
    """Check Ollama while omitting its URL, response text, and raw errors."""
    result = llm.health_check()
    healthy = result.get("status") == "healthy"
    return {
        "status": "healthy" if healthy else "unhealthy",
        "provider": result.get("provider", "ollama"),
        "model": result.get("model", getattr(llm, "model_name", None)),
    }