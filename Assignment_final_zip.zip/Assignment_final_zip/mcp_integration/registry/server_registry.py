"""Small YAML-backed registry for the single analytics MCP server."""
from pathlib import Path

import yaml

CONFIG = Path(__file__).with_name("registry_config.yaml")

def get_server(name: str = "northwind_analytics") -> dict:
    data = yaml.safe_load(CONFIG.read_text(encoding="utf-8")) or {}
    server = (data.get("servers") or {}).get(name)
    if not server or not server.get("enabled", False):
        raise RuntimeError(f"MCP server '{name}' is missing or disabled")
    return server
