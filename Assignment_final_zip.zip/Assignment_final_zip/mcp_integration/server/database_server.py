"""Northwind Analytics MCP server.

Run with: python -m mcp_integration.server.database_server
The server is intentionally bound to loopback by default. Put it behind
an authenticated private gateway before exposing it to a network.
"""
from __future__ import annotations
import os
from mcp.server.fastmcp import FastMCP
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import URL
import sqlglot
from sqlglot import exp
from config.settings import settings

mcp = FastMCP("Northwind Analytics MCP Server", host=os.getenv("MCP_HOST", "127.0.0.1"), port=int(os.getenv("MCP_PORT", "8001")))


def _engine():
    return create_engine(settings.MYSQL_CONNECTION_URL, pool_pre_ping=True, pool_recycle=1800)

@mcp.tool()
def list_databases() -> list[str]:
    """Return the configured database name only (no server-wide enumeration)."""
    return [settings.DB_NAME]

@mcp.tool()
def get_database_schema() -> dict:
    """Return table names and column metadata for the configured database."""
    inspector = inspect(_engine())
    tables = {}
    relationships = []
    for table in inspector.get_table_names():
        foreign_keys = inspector.get_foreign_keys(table)
        tables[table] = {
            "columns": [
                {"name": c["name"], "type": str(c["type"]), "nullable": bool(c.get("nullable", True))}
                for c in inspector.get_columns(table)
            ],
            "foreign_keys": foreign_keys,
        }
        for fk in foreign_keys:
            relationships.append({
                "constraint_name": fk.get("name"),
                "source_table": table,
                "source_columns": fk.get("constrained_columns", []),
                "target_table": fk.get("referred_table"),
                "target_columns": fk.get("referred_columns", []),
            })
    return {
        "registry_name": "northwind", "physical_database_name": settings.DB_NAME,
        "backend": "mysql", "driver": settings.DB_DRIVER, "read_only": True,
        "table_count": len(tables), "tables": tables,
        "table_names": sorted(tables), "relationships": relationships,
        "relationship_count": len(relationships),
    }

@mcp.tool()
def get_schema_context(max_tables: int = 25, max_characters: int = 12000) -> str:
    """Return compact schema context formatted for text-to-SQL planning."""
    if not 1 <= max_tables <= 50 or not 100 <= max_characters <= 30000:
        raise ValueError("Schema context limits are outside the allowed range")
    from database.schema_manager import SchemaManager
    manager = SchemaManager()
    return manager.build_schema_context(
        database_name="northwind", max_tables=max_tables,
        max_characters=max_characters,
    )


@mcp.tool()
def get_table_schema(table_name: str) -> dict:
    """Return columns and foreign keys for one table in the configured database."""
    if not table_name.replace("_", "").isalnum():
        raise ValueError("Invalid table name")
    inspector = inspect(_engine())
    if table_name not in inspector.get_table_names():
        raise ValueError("Unknown table")
    return {
        "table": table_name,
        "columns": [
            {"name": c["name"], "type": str(c["type"]), "nullable": bool(c.get("nullable", True))}
            for c in inspector.get_columns(table_name)
        ],
        "foreign_keys": inspector.get_foreign_keys(table_name),
    }

@mcp.tool()
def get_table_relationships() -> list[dict]:
    """Return foreign-key relationships for the configured database."""
    inspector = inspect(_engine())
    relations = []
    for table in inspector.get_table_names():
        for fk in inspector.get_foreign_keys(table):
            relations.append({"table": table, **fk})
    return relations

@mcp.tool()
def get_table_sample(table_name: str, limit: int = 5) -> list[dict]:
    """Return up to five sample rows; never accepts arbitrary identifiers or SQL."""
    if not table_name.replace("_", "").isalnum() or not 1 <= limit <= 5:
        raise ValueError("Invalid table name or sample limit")
    inspector = inspect(_engine())
    if table_name not in inspector.get_table_names():
        raise ValueError("Unknown table")
    with _engine().connect() as conn:
        rows = conn.execute(text(f"SELECT * FROM `{table_name}` LIMIT :n"), {"n": limit}).mappings().all()
        return [dict(row) for row in rows]

@mcp.tool()
def execute_readonly_query(sql: str, limit: int = 1000) -> dict:
    """Execute one read-only SELECT/CTE query; use a SELECT-only DB account in production."""
    if not 1 <= limit <= min(settings.MAX_QUERY_ROWS, 1000):
        raise ValueError("Requested row limit is outside the allowed range")
    parsed = sqlglot.parse(sql, read="mysql")
    if len(parsed) != 1 or parsed[0] is None:
        raise ValueError("Exactly one SQL statement is required")
    tree = parsed[0]
    if not isinstance(tree, (exp.Select, exp.Union)):
        raise ValueError("Only SELECT queries are permitted")
    forbidden = (exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create, exp.Alter, exp.Command)
    if any(tree.find(x) is not None for x in forbidden):
        raise ValueError("Read-only query validation failed")
    # Apply a hard result cap. This server is private; API RBAC must be checked before calls.
    capped = tree.limit(limit)
    with _engine().connect() as conn:
        result = conn.execute(text(capped.sql(dialect="mysql")))
        rows = [dict(r) for r in result.mappings().all()]
    return {"columns": list(rows[0].keys()) if rows else [], "row_count": len(rows), "records": rows}

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
