"""Synchronous convenience client for the configured MCP server."""
from __future__ import annotations
import asyncio
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from mcp_integration.registry.server_registry import get_server

async def _call(tool_name: str, arguments: dict | None = None):
    cfg = get_server()
    async with streamablehttp_client(cfg["url"]) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, arguments or {})
            if result.isError:
                raise RuntimeError(f"MCP tool failed: {tool_name}")
            if getattr(result, "structuredContent", None) is not None:
                structured = result.structuredContent
                if isinstance(structured, dict) and "result" in structured:
                    return structured["result"]
                return structured
            output = []
            for item in result.content:
                if getattr(item, "text", None):
                    output.append(item.text)
            if len(output) == 1:
                return output[0]
            return output

def call_tool(tool_name: str, arguments: dict | None = None):
    """Call a discovered MCP tool from synchronous LangGraph services."""
    return asyncio.run(_call(tool_name, arguments))

async def discover_tools() -> list[dict]:
    cfg = get_server()
    async with streamablehttp_client(cfg["url"]) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.list_tools()
            return [{"name": t.name, "description": t.description} for t in result.tools]
