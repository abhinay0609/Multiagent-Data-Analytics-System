"""
Bounded SQL retry and correction management.

The retry handler decides whether the SQL Agent may regenerate a query
after deterministic validation fails.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from schemas.sql_schema import (
    SQLIssueSeverity,
    SQLValidationResult,
    SQLValidationStatus,
)


class RetryDecision(str, Enum):
    """Possible SQL retry decisions."""

    NOT_REQUIRED = "not_required"
    RETRY_ALLOWED = "retry_allowed"
    RETRY_EXHAUSTED = "retry_exhausted"
    TERMINAL_SECURITY_FAILURE = "terminal_security_failure"
    TERMINAL_VALIDATION_FAILURE = "terminal_validation_failure"


@dataclass(frozen=True)
class RetryOutcome:
    """Result of bounded SQL retry evaluation."""

    decision: RetryDecision
    should_retry: bool
    current_retry_count: int
    next_retry_count: int
    max_retries: int
    reason: str
    correction_feedback: Optional[str] = None
    terminal: bool = False

    def to_state_update(self) -> dict[str, object]:
        """Convert the outcome into a LangGraph state update."""
        update: dict[str, object] = {
            "retry_count": self.next_retry_count,
            "sql_validation_errors": (
                [self.reason]
                if self.reason
                else []
            ),
        }

        if self.should_retry:
            update.update(
                {
                    "status": "sql_generation",
                    "next_node": "sql_agent",
                    "sql_is_safe": False,
                }
            )

        elif self.decision == RetryDecision.NOT_REQUIRED:
            update.update(
                {
                    "status": "sql_execution",
                    "next_node": "query_executor",
                    "sql_is_safe": True,
                }
            )

        else:
            update.update(
                {
                    "status": "failed",
                    "next_node": "response_agent",
                    "sql_is_safe": False,
                }
            )

        return update


class SQLRetryHandler:
    """Control bounded SQL correction retries."""

    TERMINAL_SECURITY_CODES: frozenset[str] = frozenset(
        {
            "MULTIPLE_STATEMENTS",
            "NON_READ_ONLY_STATEMENT",
            "BLOCKED_AST_NODE",
            "BLOCKED_FUNCTION",
            "BLOCKED_SQL_PATTERN",
            "BLOCKED_STATEMENT_KEYWORD",
            "RESTRICTED_SCHEMA",
            "SQL_COMMENTS_NOT_ALLOWED",
        }
    )

    RETRYABLE_CODES: frozenset[str] = frozenset(
        {
            "SQL_PARSE_ERROR",
            "EMPTY_EXPRESSION",
            "UNKNOWN_TABLE",
            "UNKNOWN_COLUMN",
            "INVALID_QUALIFIED_COLUMN",
            "UNKNOWN_TABLE_ALIAS",
            "AMBIGUOUS_COLUMN",
        }
    )

    def __init__(
        self,
        max_retries: int = 2,
    ) -> None:
        if not isinstance(max_retries, int):
            raise TypeError(
                "max_retries must be an integer."
            )

        if max_retries < 0:
            raise ValueError(
                "max_retries cannot be negative."
            )

        if max_retries > 5:
            raise ValueError(
                "max_retries cannot exceed 5."
            )

        self._max_retries = max_retries

    @property
    def max_retries(self) -> int:
        """Return the configured retry limit."""
        return self._max_retries

    def evaluate(
        self,
        validation_result: SQLValidationResult,
        current_retry_count: int,
        max_retries: Optional[int] = None,
    ) -> RetryOutcome:
        """Determine whether another SQL generation attempt is allowed."""
        if not isinstance(
            validation_result,
            SQLValidationResult,
        ):
            raise TypeError(
                "validation_result must be an "
                "SQLValidationResult instance."
            )

        if not isinstance(current_retry_count, int):
            raise TypeError(
                "current_retry_count must be an integer."
            )

        if current_retry_count < 0:
            raise ValueError(
                "current_retry_count cannot be negative."
            )

        retry_limit = (
            self._max_retries
            if max_retries is None
            else max_retries
        )

        if not isinstance(retry_limit, int):
            raise TypeError(
                "max_retries must be an integer."
            )

        if retry_limit < 0:
            raise ValueError(
                "max_retries cannot be negative."
            )

        if (
            validation_result.status
            == SQLValidationStatus.VALID.value
        ):
            return RetryOutcome(
                decision=RetryDecision.NOT_REQUIRED,
                should_retry=False,
                current_retry_count=current_retry_count,
                next_retry_count=current_retry_count,
                max_retries=retry_limit,
                reason="SQL validation succeeded.",
                correction_feedback=None,
                terminal=False,
            )

        issue_codes = {
            issue.code
            for issue in validation_result.issues
        }

        has_critical_issue = any(
            issue.severity
            == SQLIssueSeverity.CRITICAL.value
            for issue in validation_result.issues
        )

        has_terminal_security_issue = bool(
            issue_codes
            & self.TERMINAL_SECURITY_CODES
        )

        if (
            has_critical_issue
            or has_terminal_security_issue
        ):
            return RetryOutcome(
                decision=(
                    RetryDecision
                    .TERMINAL_SECURITY_FAILURE
                ),
                should_retry=False,
                current_retry_count=current_retry_count,
                next_retry_count=current_retry_count,
                max_retries=retry_limit,
                reason=(
                    "SQL validation detected a terminal "
                    "security violation."
                ),
                correction_feedback=(
                    validation_result.correction_feedback
                ),
                terminal=True,
            )

        if current_retry_count >= retry_limit:
            return RetryOutcome(
                decision=RetryDecision.RETRY_EXHAUSTED,
                should_retry=False,
                current_retry_count=current_retry_count,
                next_retry_count=current_retry_count,
                max_retries=retry_limit,
                reason=(
                    f"SQL correction retry limit of "
                    f"{retry_limit} has been reached."
                ),
                correction_feedback=(
                    validation_result.correction_feedback
                ),
                terminal=True,
            )

        retryable = (
            validation_result.retry_recommended
            or bool(
                issue_codes & self.RETRYABLE_CODES
            )
        )

        if retryable:
            next_retry_count = current_retry_count + 1

            return RetryOutcome(
                decision=RetryDecision.RETRY_ALLOWED,
                should_retry=True,
                current_retry_count=current_retry_count,
                next_retry_count=next_retry_count,
                max_retries=retry_limit,
                reason=(
                    f"SQL correction retry "
                    f"{next_retry_count} of "
                    f"{retry_limit} is allowed."
                ),
                correction_feedback=(
                    validation_result.correction_feedback
                ),
                terminal=False,
            )

        return RetryOutcome(
            decision=(
                RetryDecision
                .TERMINAL_VALIDATION_FAILURE
            ),
            should_retry=False,
            current_retry_count=current_retry_count,
            next_retry_count=current_retry_count,
            max_retries=retry_limit,
            reason=(
                "SQL validation failed and the issue is not "
                "eligible for automatic correction."
            ),
            correction_feedback=(
                validation_result.correction_feedback
            ),
            terminal=True,
        )

    def build_agent_feedback(
        self,
        validation_result: SQLValidationResult,
        retry_outcome: RetryOutcome,
    ) -> str:
        """Build bounded correction instructions for the SQL Agent."""
        if not retry_outcome.should_retry:
            raise ValueError(
                "Correction feedback is available only when "
                "a retry is allowed."
            )

        validation_feedback = (
            validation_result.correction_feedback
            or "Correct the SQL validation issues."
        )

        return "\n".join(
            [
                "Previous SQL attempt failed validation.",
                (
                    f"Retry attempt: "
                    f"{retry_outcome.next_retry_count} "
                    f"of {retry_outcome.max_retries}"
                ),
                "",
                validation_feedback,
                "",
                "Correction requirements:",
                "- Return exactly one SQL statement.",
                "- Use MySQL syntax.",
                "- Use SELECT or WITH...SELECT only.",
                "- Use only approved Northwind tables.",
                "- Use only columns present in the schema.",
                "- Do not include Markdown code fences.",
                "- Do not include comments or explanation.",
            ]
        )


sql_retry_handler = SQLRetryHandler(
    max_retries=2
)