"""
SQL security policy and allowlist management.

This module defines what SQL is permitted. It does not parse, validate,
or execute queries.

Allowed database tables are discovered dynamically through SchemaManager.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from config.settings import settings
from database.schema_manager import SchemaManager, schema_manager


# =========================================================
# Static SQL security policy
# =========================================================

ALLOWED_LOGICAL_DATABASES: frozenset[str] = frozenset(
    {
        "northwind",
    }
)

ALLOWED_PHYSICAL_DATABASES: frozenset[str] = frozenset(
    {
        settings.DB_NAME.casefold(),
    }
)

RESTRICTED_SCHEMAS: frozenset[str] = frozenset(
    {
        "mysql",
        "information_schema",
        "performance_schema",
        "sys",
    }
)

ALLOWED_STATEMENT_TYPES: frozenset[str] = frozenset(
    {
        "select",
        "with",
    }
)

BLOCKED_STATEMENT_TYPES: frozenset[str] = frozenset(
    {
        "insert",
        "update",
        "delete",
        "drop",
        "alter",
        "create",
        "truncate",
        "replace",
        "merge",
        "grant",
        "revoke",
        "call",
        "execute",
        "use",
        "set",
        "show",
        "describe",
        "explain",
        "lock",
        "unlock",
        "commit",
        "rollback",
        "start transaction",
    }
)

BLOCKED_FUNCTIONS: frozenset[str] = frozenset(
    {
        "sleep",
        "benchmark",
        "load_file",
        "get_lock",
        "release_lock",
        "is_free_lock",
        "is_used_lock",
        "master_pos_wait",
        "source_pos_wait",
        "sys_exec",
        "sys_eval",
    }
)

BLOCKED_KEYWORD_PATTERNS: tuple[str, ...] = (
    "into outfile",
    "into dumpfile",
    "load data",
    "load xml",
    "for update",
    "lock in share mode",
    "procedure analyse",
)

MAX_QUERY_ROWS: int = settings.MAX_QUERY_ROWS


# =========================================================
# Policy model
# =========================================================


@dataclass(frozen=True)
class SQLSecurityPolicy:
    """Resolved SQL security policy for one registered database."""

    logical_database_name: str
    physical_database_name: str

    allowed_tables: frozenset[str]
    restricted_schemas: frozenset[str]
    allowed_statement_types: frozenset[str]
    blocked_statement_types: frozenset[str]
    blocked_functions: frozenset[str]
    blocked_keyword_patterns: tuple[str, ...]

    max_query_rows: int

    allow_comments: bool = False
    allow_cross_database_queries: bool = False
    require_row_limit: bool = True

    def is_table_allowed(self, table_name: str) -> bool:
        """Return True if a table is approved."""
        normalized_name = _normalize_identifier(
            table_name
        )

        return normalized_name in self.allowed_tables

    def is_schema_allowed(
        self,
        schema_name: Optional[str],
    ) -> bool:
        """
        Return True if a schema qualifier is permitted.

        Queries without a schema qualifier are permitted because the
        ConnectionManager already targets the approved database.
        """
        if schema_name is None:
            return True

        normalized_name = _normalize_identifier(
            schema_name
        )

        if normalized_name in self.restricted_schemas:
            return False

        if self.allow_cross_database_queries:
            return True

        return normalized_name == self.physical_database_name

    def is_function_blocked(
        self,
        function_name: str,
    ) -> bool:
        """Return True if a SQL function is blocked."""
        normalized_name = _normalize_identifier(
            function_name
        )

        return normalized_name in self.blocked_functions


# =========================================================
# Policy factory
# =========================================================


def build_security_policy(
    database_name: str = "northwind",
    manager: Optional[SchemaManager] = None,
    max_query_rows: Optional[int] = None,
) -> SQLSecurityPolicy:
    """
    Build a security policy using the current registered schema.

    Args:
        database_name:
            Logical name registered in DatabaseRegistry.

        manager:
            Optional SchemaManager. The shared manager is used by default.

        max_query_rows:
            Optional stricter row limit. The value cannot exceed the
            application MAX_QUERY_ROWS configuration.
    """
    clean_database_name = _normalize_required_name(
        database_name,
        "database_name",
    )

    if clean_database_name not in ALLOWED_LOGICAL_DATABASES:
        raise ValueError(
            f"Database '{clean_database_name}' is not approved. "
            f"Allowed databases: "
            f"{sorted(ALLOWED_LOGICAL_DATABASES)}"
        )

    active_manager = manager or schema_manager

    if not isinstance(active_manager, SchemaManager):
        raise TypeError(
            "manager must be a SchemaManager instance."
        )

    registration = active_manager.registry.get_registration(
        clean_database_name
    )

    physical_database_name = (
        registration.database_name.casefold()
    )

    if (
        physical_database_name
        not in ALLOWED_PHYSICAL_DATABASES
    ):
        raise ValueError(
            f"Physical database "
            f"'{registration.database_name}' is not approved."
        )

    tables = active_manager.list_tables(
        clean_database_name
    )

    allowed_tables = frozenset(
        table.casefold()
        for table in tables
    )

    resolved_row_limit = (
        MAX_QUERY_ROWS
        if max_query_rows is None
        else max_query_rows
    )

    if not isinstance(resolved_row_limit, int):
        raise TypeError(
            "max_query_rows must be an integer."
        )

    if resolved_row_limit < 1:
        raise ValueError(
            "max_query_rows must be at least 1."
        )

    resolved_row_limit = min(
        resolved_row_limit,
        MAX_QUERY_ROWS,
    )

    return SQLSecurityPolicy(
        logical_database_name=clean_database_name,
        physical_database_name=physical_database_name,
        allowed_tables=allowed_tables,
        restricted_schemas=RESTRICTED_SCHEMAS,
        allowed_statement_types=ALLOWED_STATEMENT_TYPES,
        blocked_statement_types=BLOCKED_STATEMENT_TYPES,
        blocked_functions=BLOCKED_FUNCTIONS,
        blocked_keyword_patterns=BLOCKED_KEYWORD_PATTERNS,
        max_query_rows=resolved_row_limit,
    )


# =========================================================
# Helpers
# =========================================================


def _normalize_required_name(
    value: str,
    label: str,
) -> str:
    """Validate and normalize a required name."""
    if not isinstance(value, str):
        raise TypeError(
            f"{label} must be a string."
        )

    clean_value = value.strip().casefold()

    if not clean_value:
        raise ValueError(
            f"{label} cannot be empty."
        )

    return clean_value


def _normalize_identifier(value: str) -> str:
    """Normalize a SQL identifier for policy comparison."""
    return (
        value.strip()
        .strip("`")
        .strip('"')
        .casefold()
    )