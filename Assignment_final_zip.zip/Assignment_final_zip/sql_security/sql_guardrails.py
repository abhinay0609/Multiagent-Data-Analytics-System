"""
Deterministic SQL guardrails.

This module detects dangerous SQL constructs using:
- Raw-text checks for MySQL-specific patterns
- SQLGlot Abstract Syntax Tree inspection
- Approved database and table policy

Guardrails do not execute SQL.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from sqlglot import exp

from schemas.sql_schema import (
    SQLIssueSeverity,
    SQLValidationIssue,
)
from sql_security.allowlist import SQLSecurityPolicy


# =========================================================
# Guardrail result
# =========================================================


@dataclass
class GuardrailResult:
    """Result of SQL security guardrail checks."""

    safe: bool
    issues: list[SQLValidationIssue] = field(
        default_factory=list
    )
    detected_functions: list[str] = field(
        default_factory=list
    )
    detected_schemas: list[str] = field(
        default_factory=list
    )

    @property
    def has_critical_issue(self) -> bool:
        """Return True if a critical issue was detected."""
        return any(
            issue.severity
            == SQLIssueSeverity.CRITICAL.value
            for issue in self.issues
        )


# =========================================================
# SQL guardrails
# =========================================================


class SQLGuardrails:
    """Apply deterministic security checks to SQL."""

    def __init__(
        self,
        policy: SQLSecurityPolicy,
    ) -> None:
        if not isinstance(policy, SQLSecurityPolicy):
            raise TypeError(
                "policy must be an SQLSecurityPolicy instance."
            )

        self._policy = policy

    @property
    def policy(self) -> SQLSecurityPolicy:
        """Return the active SQL security policy."""
        return self._policy

    def inspect(
        self,
        sql: str,
        expression: Optional[exp.Expression] = None,
        statement_count: int = 1,
    ) -> GuardrailResult:
        """
        Inspect SQL for prohibited constructs.

        Args:
            sql:
                Original SQL string.

            expression:
                Parsed SQLGlot expression, when parsing succeeded.

            statement_count:
                Number of statements returned by SQLGlot.
        """
        clean_sql = self._validate_sql(sql)

        issues: list[SQLValidationIssue] = []
        detected_functions: set[str] = set()
        detected_schemas: set[str] = set()

        if statement_count != 1:
            issues.append(
                self._issue(
                    code="MULTIPLE_STATEMENTS",
                    message=(
                        "Exactly one SQL statement is allowed."
                    ),
                    severity=SQLIssueSeverity.CRITICAL,
                    suggestion=(
                        "Return one read-only SELECT query only."
                    ),
                )
            )

        issues.extend(
            self._inspect_raw_text(clean_sql)
        )

        if expression is not None:
            ast_issues, functions, schemas = (
                self._inspect_ast(expression)
            )

            issues.extend(ast_issues)
            detected_functions.update(functions)
            detected_schemas.update(schemas)

        issues = self._deduplicate_issues(issues)

        return GuardrailResult(
            safe=not any(
                issue.severity
                in {
                    SQLIssueSeverity.ERROR.value,
                    SQLIssueSeverity.CRITICAL.value,
                }
                for issue in issues
            ),
            issues=issues,
            detected_functions=sorted(
                detected_functions
            ),
            detected_schemas=sorted(
                detected_schemas
            ),
        )

    # =====================================================
    # Raw SQL checks
    # =====================================================

    def _inspect_raw_text(
        self,
        sql: str,
    ) -> list[SQLValidationIssue]:
        """Inspect MySQL-specific patterns in SQL text."""
        issues: list[SQLValidationIssue] = []

        stripped_sql = self._remove_string_literals(sql)
        normalized_sql = re.sub(
            r"\s+",
            " ",
            stripped_sql,
        ).strip().casefold()

        if not self._policy.allow_comments:
            if self._contains_comment(sql):
                issues.append(
                    self._issue(
                        code="SQL_COMMENTS_NOT_ALLOWED",
                        message=(
                            "SQL comments are not allowed in "
                            "generated queries."
                        ),
                        severity=SQLIssueSeverity.ERROR,
                        suggestion=(
                            "Remove all line and block comments."
                        ),
                    )
                )

        for pattern in self._policy.blocked_keyword_patterns:
            pattern_expression = (
                r"\b"
                + re.escape(pattern).replace(
                    r"\ ",
                    r"\s+",
                )
                + r"\b"
            )

            if re.search(
                pattern_expression,
                normalized_sql,
                flags=re.IGNORECASE,
            ):
                issues.append(
                    self._issue(
                        code="BLOCKED_SQL_PATTERN",
                        message=(
                            f"Blocked SQL pattern detected: "
                            f"'{pattern}'."
                        ),
                        severity=SQLIssueSeverity.CRITICAL,
                        suggestion=(
                            "Generate a standard read-only SELECT "
                            "query without file, lock, or procedure "
                            "operations."
                        ),
                    )
                )

        for statement_type in (
            self._policy.blocked_statement_types
        ):
            keyword_pattern = (
                r"\b"
                + re.escape(statement_type).replace(
                    r"\ ",
                    r"\s+",
                )
                + r"\b"
            )

            if re.search(
                keyword_pattern,
                normalized_sql,
                flags=re.IGNORECASE,
            ):
                issues.append(
                    self._issue(
                        code="BLOCKED_STATEMENT_KEYWORD",
                        message=(
                            f"Blocked SQL operation detected: "
                            f"'{statement_type}'."
                        ),
                        severity=SQLIssueSeverity.CRITICAL,
                        suggestion=(
                            "ery only."
                        ),
                    )
                )

        return issues

    # =====================================================
    # SQLGlot AST checks
    # =====================================================

    def _inspect_ast(
        self,
        expression: exp.Expression,
    ) -> tuple[
        list[SQLValidationIssue],
        set[str],
        set[str],
    ]:
        """Inspect parsed SQLGlot expression nodes."""
        issues: list[SQLValidationIssue] = []
        detected_functions: set[str] = set()
        detected_schemas: set[str] = set()

        blocked_node_names = {
            "Insert",
            "Update",
            "Delete",
            "Drop",
            "Alter",
            "Create",
            "Command",
            "Merge",
            "TruncateTable",
            "Grant",
            "Revoke",
            "Use",
            "Set",
            "Transaction",
            "Commit",
            "Rollback",
            "Lock",
            "Unlock",
            "Execute",
        }

        for node in expression.walk():
            node_name = node.__class__.__name__

            if node_name in blocked_node_names:
                issues.append(
                    self._issue(
                        code="BLOCKED_AST_NODE",
                        message=(
                            f"Blocked SQL operation detected: "
                            f"'{node_name}'."
                        ),
                        severity=SQLIssueSeverity.CRITICAL,
                        suggestion=(
                            "Use a read-only SELECT query."
                        ),
                    )
                )

        for table in expression.find_all(exp.Table):
            schema_name = self._extract_schema_name(table)

            if schema_name:
                normalized_schema = (
                    self._normalize_identifier(
                        schema_name
                    )
                )

                detected_schemas.add(normalized_schema)

                if not self._policy.is_schema_allowed(
                    normalized_schema
                ):
                    issues.append(
                        self._issue(
                            code="RESTRICTED_SCHEMA",
                            message=(
                                f"Schema '{schema_name}' is not "
                                f"approved for analytics queries."
                            ),
                            severity=SQLIssueSeverity.CRITICAL,
                            location=table.sql(
                                dialect="mysql"
                            ),
                            suggestion=(
                                f"Use only the approved database "
                                f"'{self._policy.physical_database_name}'."
                            ),
                        )
                    )

        for function in expression.find_all(exp.Func):
            function_name = self._function_name(
                function
            )

            if not function_name:
                continue

            normalized_function = (
                self._normalize_identifier(
                    function_name
                )
            )

            detected_functions.add(
                normalized_function
            )

            if self._policy.is_function_blocked(
                normalized_function
            ):
                issues.append(
                    self._issue(
                        code="BLOCKED_FUNCTION",
                        message=(
                            f"Function '{function_name}' is blocked."
                        ),
                        severity=SQLIssueSeverity.CRITICAL,
                        location=function.sql(
                            dialect="mysql"
                        ),
                        suggestion=(
                            "Remove the blocked function and use "
                            "normal analytical SQL functions."
                        ),
                    )
                )

        return (
            issues,
            detected_functions,
            detected_schemas,
        )

    # =====================================================
    # Helpers
    # =====================================================

    @staticmethod
    def _extract_schema_name(
        table: exp.Table,
    ) -> Optional[str]:
        """Extract database/schema qualifier from a table."""
        catalog = table.catalog
        database = table.db

        if catalog:
            return catalog

        if database:
            return database

        return None

    @staticmethod
    def _function_name(
        function: exp.Func,
    ) -> str:
        """Return a normalized function name."""
        if isinstance(function, exp.Anonymous):
            return function.name

        try:
            name = function.sql_name()
        except Exception:
            name = function.__class__.__name__

        return str(name or "").strip()

    @staticmethod
    def _contains_comment(sql: str) -> bool:
        """Return True if SQL contains line or block comments."""
        without_strings = (
            SQLGuardrails._remove_string_literals(sql)
        )

        return bool(
            re.search(
                r"(--[^\r\n]*|#[^\r\n]*|/\*.*?\*/)",
                without_strings,
                flags=re.DOTALL,
            )
        )

    @staticmethod
    def _remove_string_literals(sql: str) -> str:
        """
        Replace quoted SQL literals before keyword inspection.

        This avoids treating text such as 'drop in revenue' as a DROP
        operation.
        """
        result: list[str] = []
        index = 0
        length = len(sql)

        while index < length:
            character = sql[index]

            if character not in {"'", '"'}:
                result.append(character)
                index += 1
                continue

            quote = character
            result.append(" ")
            index += 1

            while index < length:
                current = sql[index]

                if current == "\\":
                    index += 2
                    continue

                if current == quote:
                    if (
                        index + 1 < length
                        and sql[index + 1] == quote
                    ):
                        index += 2
                        continue

                    index += 1
                    break

                index += 1

        return "".join(result)

    @staticmethod
    def _validate_sql(sql: str) -> str:
        """Validate SQL input."""
        if not isinstance(sql, str):
            raise TypeError(
                "sql must be a string."
            )

        clean_sql = sql.strip()

        if not clean_sql:
            raise ValueError(
                "sql cannot be empty."
            )

        return clean_sql

    @staticmethod
    def _normalize_identifier(value: str) -> str:
        """Normalize a SQL identifier."""
        return (
            value.strip()
            .strip("`")
            .strip('"')
            .casefold()
        )

    @staticmethod
    def _issue(
        code: str,
        message: str,
        severity: SQLIssueSeverity,
        location: Optional[str] = None,
        suggestion: Optional[str] = None,
    ) -> SQLValidationIssue:
        """Build one structured validation issue."""
        return SQLValidationIssue(
            code=code,
            message=message,
            severity=severity,
            location=location,
            suggestion=suggestion,
        )

    @staticmethod
    def _deduplicate_issues(
        issues: list[SQLValidationIssue],
    ) -> list[SQLValidationIssue]:
        """Remove duplicate issue code/message combinations."""
        seen: set[tuple[str, str]] = set()
        unique_issues: list[SQLValidationIssue] = []

        for issue in issues:
            key = (
                issue.code,
                issue.message,
            )

            if key not in seen:
                seen.add(key)
                unique_issues.append(issue)

        return unique_issues