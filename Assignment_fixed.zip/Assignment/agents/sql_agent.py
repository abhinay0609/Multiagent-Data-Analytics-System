"""Generate SQL candidates without accessing database connections."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError

from agents._common import AgentLLM, call_text, get_default_llm, render_prompt
from schemas.plan_schema import AnalysisPlan, TaskType
from schemas.sql_schema import (
    SQLGenerationResult,
    SQLStatementType,
)


class SQLAgent:
    """Generate a MySQL candidate query and extract its declared metadata."""

    def __init__(self, llm: AgentLLM | None = None) -> None:
        self._llm = llm if llm is not None else get_default_llm()

    def run(
        self,
        plan: AnalysisPlan | Mapping[str, Any],
        schema_context: Mapping[str, Any] | str,
        *,
        previous_validation_errors: Sequence[str] = (),
        task_id: str | None = None,
        max_result_rows: int | None = None,
        user_question: str | None = None,
        intent_result: Mapping[str, Any] | None = None,
    ) -> SQLGenerationResult:
        """Generate one SQL query; validation and execution stay external."""
        analysis_plan = AnalysisPlan.model_validate(plan)
        if not analysis_plan.controls.read_only_required:
            raise ValueError("SQL Agent requires a read-only execution plan.")
        if not isinstance(schema_context, (Mapping, str)):
            raise TypeError("schema_context must be a mapping or string.")
        if not schema_context or (
            isinstance(schema_context, str) and not schema_context.strip()
        ):
            raise ValueError("schema_context cannot be empty.")
        if isinstance(previous_validation_errors, (str, bytes)):
            raise TypeError("previous_validation_errors must be a sequence.")
        if any(
            not isinstance(error, str) or not error.strip()
            for error in previous_validation_errors
        ):
            raise ValueError(
                "Validation feedback must contain non-empty strings."
            )
        if len(previous_validation_errors) > 5:
            raise ValueError("SQL correction attempts cannot exceed five.")

        sql_tasks = [
            task
            for task in analysis_plan.tasks
            if task.task_type == TaskType.SQL_GENERATION
        ]
        if task_id is not None:
            sql_tasks = [
                task for task in sql_tasks if task.task_id == task_id
            ]
        if len(sql_tasks) != 1:
            raise ValueError(
                "The plan must identify exactly one matching SQL-generation "
                "task."
            )
        task = sql_tasks[0]

        row_limit = (
            analysis_plan.controls.max_result_rows
            if max_result_rows is None
            else max_result_rows
        )
        if (
            isinstance(row_limit, bool)
            or not isinstance(row_limit, int)
            or not 1 <= row_limit <= analysis_plan.controls.max_result_rows
        ):
            raise ValueError(
                "max_result_rows must be within the plan's result-row limit."
            )

        intent_context = {
            "objective": analysis_plan.objective,
            "required_tables": task.required_tables,
            "required_columns": task.required_columns,
            "data_requirements": (
                analysis_plan.data_requirements.model_dump(mode="json")
            ),
        }
        prompt = render_prompt(
            "sql_prompt.txt",
            {
                "LOGICAL_DATABASE_NAME": (
                    analysis_plan.data_requirements.database_name
                ),
                "USER_QUESTION": user_question or analysis_plan.objective,
                "INTENT_RESULT": (
                    dict(intent_result) if intent_result is not None
                    else intent_context
                ),
                "PLAN_TASK": task.model_dump(mode="json"),
                "SCHEMA_CONTEXT": schema_context,
                "MAX_RESULT_ROWS": row_limit,
                "FILTER_VALUES": [],
                "PREVIOUS_VALIDATION_ERRORS": list(
                    previous_validation_errors
                ),
            },
        )
        sql_query = _strip_sql_code_fence(call_text(self._llm, prompt))
        if not sql_query:
            raise ValueError(
                "SQL Agent returned no query; generation must stop."
            )

        statement, statement_type, tables, columns, expected = (
            _extract_query_metadata(sql_query)
        )
        retry_attempt = len(previous_validation_errors)
        explanation = (
            "Candidate query generated for the planned task: "
            f"{task.description}"
        )
        return SQLGenerationResult(
            database_name=analysis_plan.data_requirements.database_name,
            sql_query=statement.sql(dialect="mysql"),
            statement_type=statement_type,
            referenced_tables=tables,
            referenced_columns=columns,
            expected_columns=expected,
            explanation=explanation,
            is_read_only=True,
            retry_attempt=retry_attempt,
            confidence=0.0,
        )


def _extract_query_metadata(
    sql_query: str,
) -> tuple[
    exp.Expression,
    SQLStatementType,
    list[str],
    dict[str, list[str]],
    list[str],
]:
    try:
        statements = [
            statement
            for statement in sqlglot.parse(sql_query, read="mysql")
            if statement is not None
        ]
    except ParseError as exc:
        raise ValueError("SQL Agent returned unparsable MySQL.") from exc

    if len(statements) != 1:
        raise ValueError("SQL Agent must return exactly one SQL statement.")

    statement = statements[0]
    if not isinstance(statement, (exp.Select, exp.Union, exp.Intersect, exp.Except)):
        raise ValueError(
            "SQL Agent output must be a SELECT or read-only query."
        )

    statement_type = (
        SQLStatementType.WITH
        if any(statement.find_all(exp.With))
        else SQLStatementType.SELECT
    )
    cte_names = {
        cte.alias_or_name.casefold()
        for cte in statement.find_all(exp.CTE)
    }

    table_aliases: dict[str, str] = {}
    referenced_tables: list[str] = []
    for table in statement.find_all(exp.Table):
        table_name = table.name
        if not table_name or table_name.casefold() in cte_names:
            continue
        table_aliases[table.alias_or_name.casefold()] = table_name
        if table_name not in referenced_tables:
            referenced_tables.append(table_name)

    referenced_columns: dict[str, list[str]] = {
        table_name: []
        for table_name in referenced_tables
    }
    for column in statement.find_all(exp.Column):
        if not column.name or column.name == "*":
            continue
        table_name = table_aliases.get(column.table.casefold())
        if table_name is None and not column.table and len(referenced_tables) == 1:
            table_name = referenced_tables[0]
        if table_name is not None:
            names = referenced_columns[table_name]
            if column.name not in names:
                names.append(column.name)

    projections = (
        statement.expressions
        if isinstance(statement, exp.Select)
        else []
    )
    expected_columns = list(
        dict.fromkeys(
            projection.alias_or_name
            for projection in projections
            if projection.alias_or_name
            and projection.alias_or_name != "*"
        )
    )
    return (
        statement,
        statement_type,
        referenced_tables,
        referenced_columns,
        expected_columns,
    )


def _strip_sql_code_fence(sql_query: str) -> str:
    """Remove a single enclosing Markdown fence without accepting prose."""
    match = re.fullmatch(
        r"\s*```(?:sql)?\s*(.*?)\s*```\s*",
        sql_query,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return match.group(1).strip() if match is not None else sql_query.strip()