"""Understand and structure a business analytics request."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Mapping, Sequence

from guardrails import (
    InputGuardrail,
    InputGuardrailResult,
    RequestCategory,
    input_guardrail,
)
from schemas.intent_schema import (
    ComparisonRequirement,
    ComparisonType,
    IntentResult,
    QueryIntent,
)
from schemas.user_schema import UserRole

from agents._common import (
    AgentLLM,
    call_model_json,
    get_default_llm,
    render_prompt,
)


class AgentRequestBlockedError(ValueError):
    """Raised when deterministic input policy blocks agent processing."""

    def __init__(self, result: InputGuardrailResult) -> None:
        self.guardrail_result = result
        super().__init__(result.reason)


class IntentAgent:
    """Convert an approved natural-language question into a typed intent."""

    def __init__(
        self,
        llm: AgentLLM | None = None,
        input_guardrail_instance: InputGuardrail | None = None,
    ) -> None:
        self._llm = llm if llm is not None else get_default_llm()
        self._input_guardrail = (
            input_guardrail_instance
            if input_guardrail_instance is not None
            else input_guardrail
        )

    def run(
        self,
        user_question: str,
        user_role: UserRole | str,
        available_databases: Sequence[Mapping[str, Any] | Any],
        *,
        database_name: str = "northwind",
        conversation_context: str = "",
        defer_human_approval: bool = False,
    ) -> IntentResult:
        """Classify a user request after deterministic input guardrails."""
        if not isinstance(user_question, str):
            raise TypeError("user_question must be a string.")
        if not isinstance(database_name, str) or not database_name.strip():
            raise ValueError("database_name must be a non-empty string.")
        if not isinstance(defer_human_approval, bool):
            raise TypeError("defer_human_approval must be a boolean.")
        role_name = _role_name(user_role)
        database_descriptions = _public_database_descriptions(
            available_databases
        )
        if not database_descriptions:
            raise ValueError("At least one available database is required.")

        guardrail = self._input_guardrail.validate(
            user_question,
            database_name=database_name,
        )
        if not guardrail.accepted or (
            guardrail.requires_human_approval
            and not defer_human_approval
        ):
            raise AgentRequestBlockedError(guardrail)

        clean_question = guardrail.normalized_input
        if clean_question is None:
            raise ValueError("Input guardrail returned no normalized request.")

        if guardrail.requires_clarification:
            comparison = ComparisonRequirement()
            intent = QueryIntent.UNKNOWN
            if guardrail.category == RequestCategory.CLARIFICATION_REQUIRED:
                intent = QueryIntent.COMPARISON
                comparison = ComparisonRequirement(
                    required=True,
                    comparison_type=ComparisonType.PERIOD_OVER_PERIOD,
                )
            return IntentResult(
                original_question=clean_question,
                normalized_question=clean_question,
                intent=intent,
                comparison=comparison,
                requires_clarification=True,
                clarification_question=(
                    guardrail.clarification_question
                    or "Please clarify the request."
                ),
                missing_information=[guardrail.reason],
                confidence=1.0,
            )

        prompt = render_prompt(
            "intent_prompt.txt",
            {
                "USER_QUESTION": clean_question,
                "USER_ROLE": role_name,
                "SCOPE_DECISION": _scope_context(guardrail),
                "AVAILABLE_DATABASES": database_descriptions,
                "SCHEMA_CONTEXT": {},
                "CONVERSATION_CONTEXT": conversation_context,
            },
        )
        result = call_model_json(self._llm, prompt, IntentResult)
        if result.original_question != clean_question:
            raise ValueError(
                "Intent Agent changed the original user question."
            )
        result = normalize_intent_from_question(result, clean_question)
        return result


def _role_name(user_role: UserRole | str) -> str:
    if isinstance(user_role, UserRole):
        return user_role.value
    if isinstance(user_role, str):
        try:
            return UserRole(user_role).value
        except ValueError as exc:
            raise ValueError(f"Unsupported user role: {user_role!r}.") from exc
    raise TypeError("user_role must be a UserRole or role string.")


def _public_database_descriptions(
    databases: Sequence[Mapping[str, Any] | Any],
) -> list[dict[str, Any]]:
    if isinstance(databases, (str, bytes)):
        raise TypeError("available_databases must be a sequence.")

    public_fields = {
        "name",
        "database_name",
        "backend",
        "driver",
        "host",
        "port",
        "description",
        "read_only",
        "is_default",
    }
    results: list[dict[str, Any]] = []
    for database in databases:
        if isinstance(database, Mapping):
            values = database
        elif is_dataclass(database) and not isinstance(database, type):
            values = asdict(database)
        else:
            raise TypeError(
                "Each database description must be a mapping or dataclass."
            )
        results.append(
            {
                key: value
                for key, value in values.items()
                if key in public_fields
            }
        )
    return results


def _scope_context(result: InputGuardrailResult) -> dict[str, Any]:
    scope_result = result.scope_result
    return {
        "accepted": result.accepted,
        "category": (
            result.category.value
            if result.category is not None
            else None
        ),
        "reason": result.reason,
        "requires_clarification": result.requires_clarification,
        "requires_human_approval": result.requires_human_approval,
        "scope_supported": (
            scope_result.supported if scope_result is not None else None
        ),
    }


def normalize_intent_from_question(result: IntentResult, question: str) -> IntentResult:
    """Apply deterministic, conservative normalization for common analytics language.

    This prevents an LLM omission or a few-shot example from silently turning
    a bottom-N/product/count/scalar question into customer-sales ranking.
    """
    import re
    from schemas.intent_schema import (
        AggregationType, AnalysisType, DimensionDefinition,
        MetricDefinition, RankingRequirement, SortDirection,
    )

    text = re.sub(r"\\s+", " ", question.casefold()).strip()
    updates: dict[str, Any] = {}
    ranking_words = re.search(
        r"\\b(top|bottom|highest|lowest|most|least|largest|smallest|greatest|fewest|minimum|maximum)\\b",
        text,
    )
    ascending = bool(re.search(
        r"\\b(lowest|bottom|least|smallest|minimum|fewest)\\b", text
    ))
    descending = bool(re.search(
        r"\\b(highest|top|most|largest|greatest|maximum)\\b", text
    ))

    # Explicit subject takes precedence over whatever entity the model guessed.
    dimension = None
    if re.search(r"\\bproducts?\\b", text):
        dimension = "product"
    elif re.search(r"\\bcustomers?\\b", text):
        dimension = "customer"
    elif re.search(r"\\bcountr(?:y|ies)\\b", text):
        dimension = "country"
    elif re.search(r"\\bemployees?\\b", text):
        dimension = "employee"

    if dimension and re.search(r"\\b(by|per|each|across|among|which|show|find)\\b", text):
        updates["dimensions"] = [DimensionDefinition(name=dimension)]

    if re.search(r"\\b(average|mean)\\b", text) and re.search(r"\\b(per|each)\\s+order\\b", text):
        updates["intent"] = QueryIntent.AGGREGATION
        updates["metrics"] = [MetricDefinition(
            name="average_sales_per_order",
            aggregation=AggregationType.AVERAGE,
            alias="average_sales_per_order",
        )]
        updates["dimensions"] = []
        updates["ranking"] = RankingRequirement(required=False)
        updates["analysis_types"] = [AnalysisType.AGGREGATION]
    elif re.search(r"\\b(count|number of|how many)\\b", text) or re.search(r"\\b(highest number|lowest number|most customers|fewest customers)\\b", text):
        metric_name = "customer_count" if "customer" in text else "count"
        updates["metrics"] = [MetricDefinition(
            name=metric_name,
            aggregation=AggregationType.COUNT,
            alias=metric_name,
        )]
        if dimension == "country" or re.search(r"\\bcountr(?:y|ies)\\b", text):
            updates["dimensions"] = [DimensionDefinition(name="country")]
        if ranking_words:
            updates["intent"] = QueryIntent.RANKING
            updates["ranking"] = RankingRequirement(
                required=True,
                limit=(_extract_limit(text) or result.ranking.limit or 5),
                sort_direction=(
                    SortDirection.ASCENDING if ascending
                    else SortDirection.DESCENDING
                ),
                rank_by=metric_name,
            )
            updates["analysis_types"] = [AnalysisType.RANKING]
        else:
            updates["intent"] = QueryIntent.AGGREGATION
            updates["ranking"] = RankingRequirement(required=False)
    elif ranking_words and dimension and re.search(r"\\b(sales|revenue|value)\\b", text):
        metric_name = "total_sales"
        updates["intent"] = QueryIntent.RANKING
        updates["metrics"] = [MetricDefinition(
            name=metric_name, aggregation=AggregationType.SUM, alias=metric_name
        )]
        updates["ranking"] = RankingRequirement(
            required=True,
            limit=(_extract_limit(text) or result.ranking.limit or 5),
            sort_direction=(
                SortDirection.ASCENDING if ascending
                else SortDirection.DESCENDING
            ),
            rank_by=metric_name,
        )
        updates["analysis_types"] = [AnalysisType.RANKING]

    if updates:
        result = result.model_copy(update=updates)
    return result


def _extract_limit(question: str) -> int | None:
    import re
    match = re.search(r"\\b(?:top|bottom|highest|lowest)\\s+(\\d+)\\b", question)
    if match:
        return max(1, min(int(match.group(1)), 1000))
    words = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
             "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
    match = re.search(r"\\b(?:top|bottom|highest|lowest)\\s+(" + "|".join(words) + r")\\b", question)
    return words[match.group(1)] if match else None
