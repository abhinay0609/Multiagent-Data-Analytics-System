"""Streamlit frontend for the Multi-Agent Data Analytics API."""
from __future__ import annotations

import os
import requests
import streamlit as st
import pandas as pd

st.set_page_config(page_title="Multi-Agent Analytics", page_icon="📊", layout="wide")

DEFAULT_API = os.getenv("ANALYTICS_API_URL", "http://127.0.0.1:8000").rstrip("/")
if "api_url" not in st.session_state:
    st.session_state.api_url = DEFAULT_API
if "token" not in st.session_state:
    st.session_state.token = None
if "username" not in st.session_state:
    st.session_state.username = None
if "history" not in st.session_state:
    st.session_state.history = []


def api_request(method: str, path: str, **kwargs):
    headers = kwargs.pop("headers", {})
    if st.session_state.token:
        headers["Authorization"] = f"Bearer {st.session_state.token}"
    return requests.request(
        method, f"{st.session_state.api_url}{path}",
        headers=headers, timeout=180, **kwargs
    )


def login_panel():
    st.title("📊 Multi-Agent Data Analytics")
    st.caption("Northwind business analytics · LangGraph workflow")
    with st.sidebar:
        st.subheader("Backend")
        st.session_state.api_url = st.text_input("API base URL", st.session_state.api_url).rstrip("/")
        try:
            health = requests.get(f"{st.session_state.api_url}/health", timeout=5)
            st.success("API connected" if health.ok else "API unavailable")
        except requests.RequestException:
            st.error("Cannot reach FastAPI. Start it with `python run_api.py`.")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Sign in", use_container_width=True)
    if submitted:
        try:
            response = api_request("POST", "/api/auth/login",
                                   json={"username": username, "password": password})
            if response.ok:
                payload = response.json()
                st.session_state.token = payload.get("access_token")
                st.session_state.username = username
                st.rerun()
            else:
                st.error("Login failed. Check credentials and account status.")
        except requests.RequestException as exc:
            st.error(f"API request failed: {exc}")


def main_app():
    with st.sidebar:
        st.success(f"Signed in as {st.session_state.username}")
        database = st.selectbox("Database", ["northwind"])
        retries = st.slider("Maximum SQL retries", 0, 5, 2)
        if st.button("Sign out"):
            for key in ("token", "username", "history"):
                st.session_state.pop(key, None)
            st.rerun()
        st.divider()
        st.caption("Each submitted question runs as an independent request.")

    st.title("Business Analytics Workspace")
    st.write("Ask a business question in natural language. The backend handles intent, planning, SQL safety, execution, analysis and reporting.")
    examples = [
        "Show the top 5 customers by total sales.",
        "Which five customers generated the lowest total sales?",
        "Which products generated the highest total sales?",
        "What is the average sales value per order?",
        "Which countries have the highest number of customers?",
        "Show total sales by country.",
    ]
    with st.expander("Example questions"):
        for item in examples:
            st.markdown(f"- {item}")

    question = st.text_area("Business question", height=100,
                            placeholder="e.g. Show total sales by country")
    run = st.button("Run analysis", type="primary", disabled=not question.strip())
    if run:
        with st.spinner("Running multi-agent workflow..."):
            try:
                response = api_request(
                    "POST", "/api/analytics/query",
                    json={"question": question, "database_name": database,
                          "max_retries": retries},
                )
                if response.ok:
                    result = response.json()
                    st.session_state.history.insert(0, {
                        "question": question, "result": result
                    })
                    st.session_state.history = st.session_state.history[:10]
                else:
                    try:
                        detail = response.json().get("detail", {})
                    except ValueError:
                        detail = response.text
                    st.error(f"Request failed ({response.status_code})")
                    st.json(detail)
            except requests.RequestException as exc:
                st.error(f"Backend communication error: {exc}")

    if st.session_state.history:
        latest = st.session_state.history[0]["result"]
        st.divider()
        st.subheader("Latest result")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Status", latest.get("status", "—"))
        c2.metric("Rows", latest.get("row_count", 0))
        c3.metric("SQL executed", "Yes" if latest.get("query_executed") else "No")
        c4.metric("Grounded", str(latest.get("grounded", "—")))
        if latest.get("final_answer"):
            st.markdown(latest["final_answer"])
        report = latest.get("report") or {}
        if report:
            st.subheader(report.get("title", "Analytical report"))
            summary = report.get("executive_summary")
            if summary:
                st.write(summary if isinstance(summary, str) else summary)
            findings = report.get("key_findings", [])
            if findings:
                st.markdown("#### Key findings")
                for finding in findings:
                    if isinstance(finding, dict):
                        st.markdown(f"- **{finding.get('title', 'Finding')}**: {finding.get('description', finding.get('statement', ''))}")
                    else:
                        st.markdown(f"- {finding}")
            recommendations = report.get("recommendations", [])
            if recommendations:
                st.markdown("#### Recommendations")
                for item in recommendations:
                    st.markdown(f"- {item.get('recommendation', item) if isinstance(item, dict) else item}")
            charts = latest.get("chart_specifications", [])
            if charts:
                st.markdown("#### Visualization specifications")
                st.json(charts)
            with st.expander("Full validated report"):
                st.json(report)
        with st.expander("Request diagnostics"):
            st.write("Request ID:", latest.get("request_id"))
            st.write("Retry count:", latest.get("retry_count"))
            st.json(latest.get("errors", []))
        with st.expander("Recent requests"):
            for item in st.session_state.history:
                st.write(item["question"])
                st.caption(f"Request ID: {item['result'].get('request_id')} · {item['result'].get('status')}")


if not st.session_state.token:
    login_panel()
else:
    main_app()
