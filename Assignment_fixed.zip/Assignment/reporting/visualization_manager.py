"""Build Plotly figures from chart specifications at the render boundary."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from schemas.report_schema import ChartSpecification, ChartType


_LAYOUT_OPTIONS = {
    "barmode",
    "height",
    "hovermode",
    "legend",
    "margin",
    "showlegend",
    "template",
    "width",
    "xaxis_title",
    "yaxis_title",
}


def create_figure(
    chart: ChartSpecification | Mapping[str, Any],
    *,
    data: list[dict[str, Any]] | None = None,
) -> go.Figure | None:
    """Create a Plotly figure from a serializable chart specification.

    This function is intended for a UI or reporting boundary. Callers should
    keep the ChartSpecification, not the returned Figure, in workflow state.
    """
    values = (
        chart.model_dump(mode="json")
        if isinstance(chart, ChartSpecification)
        else dict(chart)
    )
    if data is not None:
        values["data"] = data
    specification = ChartSpecification.model_validate(values)
    chart_type = ChartType(specification.chart_type)
    if chart_type == ChartType.NONE:
        return None

    data = pd.DataFrame.from_records(specification.data)
    if data.empty:
        raise ValueError("Chart data is required to create a Plotly figure.")
    axis_columns = [
        column
        for column in (
            specification.x_column,
            specification.color_column,
            *specification.y_columns,
        )
        if column is not None
    ]
    missing_columns = [column for column in axis_columns if column not in data]
    if missing_columns:
        raise ValueError(
            "Chart references missing data columns: "
            + ", ".join(missing_columns)
        )

    if chart_type == ChartType.TABLE:
        figure = _table_figure(data, specification.title)
    elif chart_type == ChartType.KPI:
        figure = _kpi_figure(data, specification)
    elif chart_type == ChartType.BAR:
        _require_axes(specification)
        figure = px.bar(
            data,
            x=specification.x_column,
            y=specification.y_columns,
            color=specification.color_column,
            orientation=specification.orientation[:1],
            title=specification.title,
        )
    elif chart_type == ChartType.LINE:
        _require_axes(specification)
        figure = px.line(
            data,
            x=specification.x_column,
            y=specification.y_columns,
            color=specification.color_column,
            title=specification.title,
        )
    elif chart_type == ChartType.SCATTER:
        _require_axes(specification)
        figure = px.scatter(
            data,
            x=specification.x_column,
            y=specification.y_columns[0],
            color=specification.color_column,
            title=specification.title,
        )
    elif chart_type == ChartType.BOX:
        _require_axes(specification)
        figure = px.box(
            data,
            x=specification.x_column,
            y=specification.y_columns,
            color=specification.color_column,
            title=specification.title,
        )
    elif chart_type == ChartType.PIE:
        if not specification.x_column or not specification.y_columns:
            raise ValueError("Pie charts require x_column and one y_column.")
        figure = px.pie(
            data,
            names=specification.x_column,
            values=specification.y_columns[0],
            title=specification.title,
        )
    elif chart_type == ChartType.HISTOGRAM:
        value_column = (
            specification.x_column
            or (specification.y_columns[0] if specification.y_columns else None)
        )
        if value_column is None:
            raise ValueError("Histograms require an x_column or y_column.")
        figure = px.histogram(data, x=value_column, title=specification.title)
    elif chart_type == ChartType.HEATMAP:
        if not specification.x_column or not specification.y_columns:
            raise ValueError(
                "Heatmaps require a row-label x_column and numeric y_columns."
            )
        matrix = data[specification.y_columns].apply(
            pd.to_numeric,
            errors="coerce",
        )
        if matrix.isna().any().any():
            raise ValueError("Heatmap value columns must contain numeric data.")
        values = matrix.to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise ValueError("Heatmap values must be finite.")
        figure = go.Figure(
            data=go.Heatmap(
                x=specification.y_columns,
                y=data[specification.x_column].astype(str),
                z=values,
            )
        )
    else:
        raise ValueError(f"Unsupported chart type: {chart_type.value}.")

    options = specification.options
    unsupported = set(options) - _LAYOUT_OPTIONS
    if unsupported:
        raise ValueError(
            "Unsupported Plotly layout options: "
            + ", ".join(sorted(unsupported))
        )
    figure.update_layout(title=specification.title, **options)
    return figure


def _require_axes(specification: ChartSpecification) -> None:
    if not specification.x_column or not specification.y_columns:
        raise ValueError("This chart type requires x_column and y_columns.")


def _table_figure(data: pd.DataFrame, title: str) -> go.Figure:
    return go.Figure(
        data=[
            go.Table(
                header={"values": [str(column) for column in data.columns]},
                cells={
                    "values": [
                        data[column].astype(str).tolist()
                        for column in data.columns
                    ]
                },
            )
        ],
        layout={"title": title},
    )


def _kpi_figure(
    data: pd.DataFrame,
    specification: ChartSpecification,
) -> go.Figure:
    value_column = (
        specification.y_columns[0]
        if specification.y_columns
        else specification.x_column
    )
    if value_column is None or value_column not in data:
        raise ValueError("KPI charts require a numeric value column.")
    values = pd.to_numeric(data[value_column], errors="coerce").dropna()
    if values.empty:
        raise ValueError("KPI value column contains no numeric values.")
    aggregation = (specification.aggregation or "first").casefold()
    aggregations = {
        "first": lambda series: float(series.iloc[0]),
        "sum": lambda series: float(series.sum()),
        "average": lambda series: float(series.mean()),
        "min": lambda series: float(series.min()),
        "max": lambda series: float(series.max()),
    }
    if aggregation not in aggregations:
        raise ValueError(
            "KPI aggregation must be first, sum, average, min, or max."
        )
    value = aggregations[aggregation](values)
    if not np.isfinite(value):
        raise ValueError("KPI value must be finite.")
    return go.Figure(
        data=[
            go.Indicator(
                mode="number",
                value=value,
                title={"text": specification.title},
            )
        ]
    )