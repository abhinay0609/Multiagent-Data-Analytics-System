"""Generate cautious recommendations linked to deterministic findings."""

from __future__ import annotations

from schemas.analysis_schema import (
    AnalysisResult,
    FindingType,
    TrendDirection,
)
from schemas.report_schema import (
    BusinessRecommendation,
    RecommendationPriority,
    RecommendationTimeframe,
)


def generate_recommendations(
    analysis: AnalysisResult,
) -> list[BusinessRecommendation]:
    """Recommend evidence review, never unsupported actions or causal claims."""
    if not analysis.sufficient_data:
        return []

    findings_by_type: dict[str, set[str]] = {}
    for finding in analysis.findings:
        findings_by_type.setdefault(
            str(getattr(finding.finding_type, "value", finding.finding_type)),
            set(),
        ).add(finding.title)

    recommendations: list[BusinessRecommendation] = []
    for trend in analysis.trends:
        if (
            trend.direction != TrendDirection.DECREASING
            or f"{trend.metric_name} trend"
            not in findings_by_type.get(FindingType.TREND.value, set())
        ):
            continue
        title = f"Review the declining {trend.metric_name} trend"
        recommendations.append(
            BusinessRecommendation(
                title=title,
                recommendation=(
                    "Review the observed decline and validate relevant "
                    "business factors before taking corrective action."
                ),
                rationale=trend.interpretation,
                priority=RecommendationPriority.MEDIUM,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[f"{trend.metric_name} trend"],
            )
        )

    for comparison in analysis.comparisons:
        finding_title = f"{comparison.name} comparison"
        if (
            comparison.absolute_change >= 0
            or finding_title
            not in findings_by_type.get(FindingType.COMPARISON.value, set())
        ):
            continue
        recommendations.append(
            BusinessRecommendation(
                title=f"Review the {comparison.name} decrease",
                recommendation=(
                    f"Review the observed change from "
                    f"{comparison.baseline_label} to {comparison.target_label} "
                    "before deciding on further action."
                ),
                rationale=comparison.interpretation,
                priority=RecommendationPriority.MEDIUM,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding_title],
            )
        )

    for anomaly in analysis.anomalies:
        finding_title = f"Unusual {anomaly.metric_name} value"
        if finding_title not in findings_by_type.get(FindingType.ANOMALY.value, set()):
            continue
        recommendations.append(
            BusinessRecommendation(
                title=f"Verify the unusual {anomaly.metric_name} observation",
                recommendation=(
                    f"Review the returned {anomaly.metric_name} value for "
                    f"{anomaly.entity} and confirm its source before acting."
                ),
                rationale=anomaly.evidence,
                priority=RecommendationPriority.MEDIUM,
                timeframe=RecommendationTimeframe.IMMEDIATE,
                supporting_findings=[finding_title],
            )
        )
        break

    for finding in analysis.findings:
        if finding.finding_type != FindingType.CONTRIBUTION:
            continue
        segment = finding.title.partition(
            "Observed contribution from "
        )[2] or finding.title
        recommendations.append(
            BusinessRecommendation(
                title="Review the largest observed segment contribution",
                recommendation=(
                    f"Review the observed contribution from {segment} "
                    "before deciding on further action."
                ),
                rationale=finding.description,
                priority=RecommendationPriority.LOW,
                timeframe=RecommendationTimeframe.SHORT_TERM,
                supporting_findings=[finding.title],
            )
        )
        break

    return recommendations[:3]