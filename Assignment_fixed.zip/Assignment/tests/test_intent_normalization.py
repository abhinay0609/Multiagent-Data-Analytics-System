from agents.intent_agent import normalize_intent_from_question
from schemas.intent_schema import (
    AggregationType, IntentResult, QueryIntent, SortDirection
)


def base(question):
    return IntentResult(
        original_question=question,
        normalized_question=question,
        intent=QueryIntent.UNKNOWN,
        confidence=0.8,
    )


def test_lowest_customers_is_ascending_customer_sales_ranking():
    result = normalize_intent_from_question(
        base("Which five customers generated the lowest total sales?"),
        "Which five customers generated the lowest total sales?",
    )
    assert result.intent == QueryIntent.RANKING
    assert result.ranking.required is True
    assert result.ranking.sort_direction == SortDirection.ASCENDING
    assert result.ranking.limit == 5
    assert result.dimensions[0].name == "customer"
    assert result.metrics[0].name == "total_sales"


def test_products_are_not_customers():
    question = "Which products generated the highest total sales?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.RANKING
    assert result.dimensions[0].name == "product"
    assert result.ranking.sort_direction == SortDirection.DESCENDING


def test_average_sales_per_order_is_scalar_aggregation():
    question = "What is the average sales value per order?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.AGGREGATION
    assert result.ranking.required is False
    assert result.dimensions == []
    assert result.metrics[0].name == "average_sales_per_order"
    assert result.metrics[0].aggregation == AggregationType.AVERAGE


def test_customer_count_by_country_is_count_ranking():
    question = "Which countries have the highest number of customers?"
    result = normalize_intent_from_question(base(question), question)
    assert result.intent == QueryIntent.RANKING
    assert result.dimensions[0].name == "country"
    assert result.metrics[0].name == "customer_count"
    assert result.metrics[0].aggregation == AggregationType.COUNT
    assert result.ranking.sort_direction == SortDirection.DESCENDING
