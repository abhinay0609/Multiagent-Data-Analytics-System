"""Offline tests for deterministic LangGraph workflow routing.

Run from the project root with:

    python -m tests.test_graph
"""

from __future__ import annotations

from typing import Any, Mapping

from agents.analysis_agent import AnalysisAgent
from agents.reporting_agent import ReportingAgent
from auth.authorization import AuthorizationService
from graph.nodes import WorkflowDependencies
from graph.router import route_after_sql_validation
from graph.state import create_initial_state, validate_state
from graph.workflow import build_workflow
from guardrails import GroundingValidator, InputGuardrail, OutputGuardrail
from schemas.analysis_schema import AnalysisResult
from schemas.intent_schema import IntentResult, MetricDefinition, QueryIntent
from schemas.plan_schema import (
    AnalysisPlan,
    AnalyticalTask,
    DataRequirement,
    ExecutionControls,
    TaskType,
    AgentType,
)
from schemas.report_schema import ReportResult
from schemas.sql_schema import (
    QueryExecutionMetadata,
    QueryExecutionResult,
    SQLGenerationResult,
    SQLIssueSeverity,
    SQLStatementType,
    SQLValidationIssue,
    SQLValidationResult,
    SQLValidationStatus,
)
from schemas.user_schema import Permission, UserIdentity, UserRole
from services.schema_service import SchemaService
from sql_security.retry_handler import SQLRetryHandler


class FakeAuthentication:
    def __init__(self, identity: UserIdentity) -> None:
        self.identity = identity
        self.lookups = 0

    def get_user_by_id(self, user_id: str) -> UserIdentity | None:
        self.lookups += 1
        return self.identity if user_id == self.identity.user_id else None

    def get_user_by_username(self, username: str) -> UserIdentity | None:
        return (
            self.identity
            if username.casefold() == self.identity.username.casefold()
            else None
        )


class FakeRegistry:
    def contains(self, name: str) -> bool:
        return name == "northwind"

    def list_databases(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "northwind",
                "database_name": "northwind_db",
                "backend": "mysql",
                "driver": "pymysql",
                "description": "Northwind business data",
                "read_only": True,
                "is_default": True,
            }
        ]


class FakeSchemaManager:
    def get_database_schema(
        self,
        database_name: str | None = None,
    ) -> dict[str, Any]:
        return {
            "registry_name": database_name or "northwind",
            "physical_database_name": "northwind_db",
            "backend": "mysql",
            "table_names": ["salesorder"],
            "tables": {
                "salesorder": {
                    "columns": [
                        {"name": "sales", "type": "DECIMAL"},
                    ]
                }
            },
            "relationships": [],
        }

    def build_schema_context(
        self,
        database_name: str | None = None,
        **kwargs: Any,
    ) -> str:
        return "Database: northwind_db\nTABLE salesorder\n- sales: DECIMAL"


class FakeIntentAgent:
    def run(self, question: str, user_role: Any, databases: Any, **kwargs: Any):
        if "table" in question.casefold() or "schema" in question.casefold():
            return IntentResult(
                original_question=question,
                normalized_question=question,
                intent=QueryIntent.SCHEMA_QUESTION,
                confidence=1.0,
            )
        return IntentResult(
            original_question=question,
            normalized_question=question,
            intent=QueryIntent.DATA_QUERY,
            metrics=[MetricDefinition(name="sales")],
            confidence=0.9,
        )


class FakePlanningAgent:
    def run(self, intent: Any, permission_context: Any, databases: Any,
            database_name: str, **kwargs: Any) -> AnalysisPlan:
        policy = kwargs.get("execution_policy", {})
        return AnalysisPlan(
            objective="Summarize sales.",
            strategy_summary="Read sales from the registered data source.",
            data_requirements=DataRequirement(
                database_name=database_name,
                required_tables=["salesorder"],
                required_metrics=["sales"],
            ),
            tasks=[
                AnalyticalTask(
                    task_id="sales-query",
                    sequence=1,
                    task_type=TaskType.SQL_GENERATION,
                    assigned_agent=AgentType.SQL_AGENT,
                    title="Read sales",
                    description="Read sales from salesorder.",
                    required_tables=["salesorder"],
                    expected_output="One read-only query.",
                )
            ],
            controls=ExecutionControls(
                max_sql_retries=policy.get("max_sql_retries", 2),
                max_result_rows=policy.get("max_result_rows", 100),
                query_timeout_seconds=policy.get(
                    "query_timeout_seconds",
                    30,
                ),
                read_only_required=True,
                human_approval_required=policy.get(
                    "human_approval_required",
                    False,
                ),
                approval_reason=policy.get("approval_reason"),
            ),
            confidence=0.9,
        )


class FakeSQLAgent:
    def __init__(self) -> None:
        self.calls = 0

    def run(self, plan: Any, schema_context: str, **kwargs: Any):
        self.calls += 1
        return SQLGenerationResult(
            query_id=f"query-{self.calls}",
            database_name="northwind",
            sql_query="SELECT sales FROM salesorder",
            statement_type=SQLStatementType.SELECT,
            referenced_tables=["salesorder"],
            referenced_columns={"salesorder": ["sales"]},
            expected_columns=["sales"],
            explanation="Read sales.",
            retry_attempt=max(0, self.calls - 1),
            confidence=0.8,
        )


class FakeSQLValidator:
    def __init__(self, *, invalid_once: bool = False, terminal: bool = False):
        self.invalid_once = invalid_once
        self.terminal = terminal
        self.calls = 0

    def validate(self, sql: str, query_id: str | None = None):
        self.calls += 1
        if self.terminal:
            return SQLValidationResult(
                query_id=query_id or "query",
                status=SQLValidationStatus.INVALID,
                original_sql=sql,
                statement_type=SQLStatementType.SELECT,
                syntax_valid=True,
                schema_valid=False,
                security_valid=False,
                read_only=False,
                issues=[
                    SQLValidationIssue(
                        code="NON_READ_ONLY_STATEMENT",
                        message="Unsafe statement.",
                        severity=SQLIssueSeverity.CRITICAL,
                    )
                ],
                retry_recommended=False,
            )
        if self.invalid_once and self.calls == 1:
            return SQLValidationResult(
                query_id=query_id or "query",
                status=SQLValidationStatus.INVALID,
                original_sql=sql,
                statement_type=SQLStatementType.SELECT,
                syntax_valid=True,
                schema_valid=False,
                security_valid=True,
                read_only=True,
                issues=[
                    SQLValidationIssue(
                        code="UNKNOWN_COLUMN",
                        message="Unknown column sales.",
                        severity=SQLIssueSeverity.ERROR,
                    )
                ],
                retry_recommended=True,
                correction_feedback="Use a known result column.",
            )
        return SQLValidationResult(
            query_id=query_id or "query",
            status=SQLValidationStatus.VALID,
            original_sql=sql,
            normalized_sql=sql,
            executable_sql=sql,
            statement_type=SQLStatementType.SELECT,
            syntax_valid=True,
            schema_valid=True,
            security_valid=True,
            read_only=True,
            referenced_tables=["salesorder"],
            referenced_columns={"salesorder": ["sales"]},
        )


class FakeQueryExecutor:
    def __init__(
        self,
        *,
        fail_once: bool = False,
        retryable_failure: bool = True,
        records: list[dict[str, Any]] | None = None,
    ) -> None:
        self.fail_once = fail_once
        self.retryable_failure = retryable_failure
        self.records = records
        self.calls = 0

    def execute(
        self,
        validation_result: SQLValidationResult,
        user: UserIdentity,
        database_name: str | None = None,
        parameters: Mapping[str, Any] | None = None,
        max_rows: int | None = None,
    ) -> QueryExecutionResult:
        self.calls += 1
        if self.fail_once and self.calls == 1:
            return QueryExecutionResult(
                success=False,
                metadata=QueryExecutionMetadata(
                    query_id=validation_result.query_id,
                    database_name=database_name or "northwind",
                ),
                error_message="Temporary connection failure.",
                retryable=self.retryable_failure,
            )
        rows = self.records if self.records is not None else [{"sales": 12.0}]
        return QueryExecutionResult(
            success=True,
            metadata=QueryExecutionMetadata(
                query_id=validation_result.query_id,
                database_name=database_name or "northwind",
                row_count=len(rows),
                columns=list(rows[0].keys()) if rows else ["sales"],
            ),
            records=rows,
        )


class FakeAnalysisAgent:
    def __init__(
        self,
        analysis_summary: str = "Sales results were analyzed.",
        sufficient_data: bool = True,
    ) -> None:
        self.analysis_summary = analysis_summary
        self.sufficient_data = sufficient_data

    def run(self, execution: Any, intent: Any, plan: Any, **kwargs: Any):
        return AnalysisResult(
            analysis_summary=self.analysis_summary,
            analyzed_row_count=1,
            source_columns=["sales"],
            limitations=(
                []
                if self.sufficient_data
                else ["There is insufficient data for analysis."]
            ),
            sufficient_data=self.sufficient_data,
            confidence=0.9,
        )


class FailingLLM:
    def generate_json(
        self,
        prompt: str,
        system_prompt: str | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        raise RuntimeError("Ollama is unavailable.")


class FakeReportingAgent:
    def run(self, intent: Any, execution: Any, analysis: Any,
            grounding: Any, chart_recommendations: Any = (), **kwargs: Any):
        return ReportResult(
            report_title="Sales report",
            executive_summary="Sales results were reviewed.",
            grounded=True,
            confidence=0.9,
        )


class FakeAuthorizationService(AuthorizationService):
    def __init__(self) -> None:
        super().__init__()
        self.calls = 0

    def authorize(self, *args: Any, **kwargs: Any):
        self.calls += 1
        return super().authorize(*args, **kwargs)


def _identity(role: UserRole = UserRole.BUSINESS_MANAGER) -> UserIdentity:
    permissions = {
        UserRole.ADMINISTRATOR: [
            Permission.NORTHWIND_READ,
            Permission.SCHEMA_READ,
            Permission.REPORTS_READ,
            Permission.TRACES_READ,
        ],
        UserRole.BUSINESS_MANAGER: [
            Permission.NORTHWIND_READ,
            Permission.SCHEMA_READ,
            Permission.REPORTS_READ,
        ],
        UserRole.EMPLOYEE: [],
    }[role]
    return UserIdentity(
        user_id="test-user",
        username="business.manager" if role != UserRole.EMPLOYEE else "employee",
        display_name="Test User",
        role=role,
        permissions=permissions,
        allowed_databases=(
            ["northwind"] if role != UserRole.EMPLOYEE else []
        ),
    )


def _build(
    *,
    role: UserRole = UserRole.BUSINESS_MANAGER,
    validator: FakeSQLValidator | None = None,
    executor: FakeQueryExecutor | None = None,
    sql_agent: FakeSQLAgent | None = None,
    analysis_agent: FakeAnalysisAgent | None = None,
    reporting_agent: Any | None = None,
):
    identity = _identity(role)
    auth = FakeAuthentication(identity)
    sql_component = sql_agent or FakeSQLAgent()
    executor_component = executor or FakeQueryExecutor()
    validator_component = validator or FakeSQLValidator()
    authorization = FakeAuthorizationService()
    dependencies = WorkflowDependencies(
        authentication=auth,  # type: ignore[arg-type]
        authorization=authorization,
        registry=FakeRegistry(),  # type: ignore[arg-type]
        schema_manager=FakeSchemaManager(),  # type: ignore[arg-type]
        sql_validator=validator_component,  # type: ignore[arg-type]
        query_executor=executor_component,  # type: ignore[arg-type]
        intent_agent=FakeIntentAgent(),
        planning_agent=FakePlanningAgent(),
        sql_agent=sql_component,
        analysis_agent=analysis_agent or FakeAnalysisAgent(),
        reporting_agent=reporting_agent or FakeReportingAgent(),
        input_guardrail=InputGuardrail(),
        grounding_validator=GroundingValidator(),
        output_guardrail=OutputGuardrail(),
        retry_handler=SQLRetryHandler(max_retries=2),
        schema_service=SchemaService(
            registry=FakeRegistry(),  # type: ignore[arg-type]
            schema_manager=FakeSchemaManager(),  # type: ignore[arg-type]
            authentication=auth,  # type: ignore[arg-type]
            authorization=authorization,
        ),
    )
    return (
        build_workflow(dependencies),
        auth,
        validator_component,
        executor_component,
        sql_component,
    )


def _state(question: str, *, user_id: str = "test-user"):
    return create_initial_state(
        question,
        user_id=user_id,
        max_retries=2,
    )


def main() -> None:
    print("=" * 60)
    print("Testing LangGraph Workflow")
    print("=" * 60)

    graph, _, _, executor, _ = _build()
    success = graph.invoke(_state("Show sales by customer."))
    assert success["status"] == "completed", success
    assert success["execution_result"]["success"] is True

    five_customer_rows = [
        {
            "customer": f"Customer {chr(64 + index)}",
            "sales": 600.0 - index * 100,
        }
        for index in range(1, 6)
    ]
    fallback_graph, _, _, _, _ = _build(
        executor=FakeQueryExecutor(records=five_customer_rows),
        analysis_agent=AnalysisAgent(llm=FailingLLM()),  # type: ignore[arg-type]
        reporting_agent=ReportingAgent(
            llm=FailingLLM(),  # type: ignore[arg-type]
        ),
    )
    fallback_result = fallback_graph.invoke(
        _state("Show the top five customers by total sales.")
    )
    assert fallback_result["status"] == "completed", fallback_result
    assert fallback_result["execution_result"]["metadata"]["row_count"] == 5
    assert fallback_result["response_metadata"]["result_rows"] == 5
    assert "Returned query results:" in fallback_result["final_answer"]
    for row in five_customer_rows:
        assert row["customer"] in fallback_result["final_answer"]
        assert str(row["sales"]) in fallback_result["final_answer"]
    assert executor.calls == 1
    assert success["final_answer"].startswith("Sales report")
    assert success["output_guardrail_result"]["approved"] is True
    assert validate_state(success) is True

    graph, _, _, _, _ = _build(
        analysis_agent=FakeAnalysisAgent(
            analysis_summary="Sales increased by 77."
        ),
    )
    ungrounded_analysis = graph.invoke(
        _state("Show sales by customer.")
    )
    assert ungrounded_analysis["grounding_result"]["grounded"] is False
    assert ungrounded_analysis["analysis_result"]["sufficient_data"] is True
    assert ungrounded_analysis["status"] == "completed"
    assert ungrounded_analysis["output_guardrail_result"]["approved"] is True

    customer_rows = [
        {"customer_name": f"Customer {index}", "total_sales": 100 - index}
        for index in range(5)
    ]
    graph, _, _, _, _ = _build(
        executor=FakeQueryExecutor(records=customer_rows),
        analysis_agent=FakeAnalysisAgent(
            analysis_summary="Sales increased by 999."
        ),
        reporting_agent=ReportingAgent(llm=object()),  # type: ignore[arg-type]
    )
    transition_states = list(
        graph.stream(
            _state("Show the top five customers by total sales."),
            stream_mode="values",
        )
    )
    grounded_failure = transition_states[-1]
    assert grounded_failure["execution_result"]["success"] is True
    assert grounded_failure["execution_result"]["records"] == customer_rows
    assert grounded_failure["execution_result"]["metadata"]["row_count"] == 5
    assert grounded_failure["grounding_result"]["grounded"] is False
    assert grounded_failure["analysis_result"]["sufficient_data"] is True
    assert grounded_failure["report_result"]["grounded"] is False
    assert grounded_failure["report_result"]["key_findings"] == []
    assert "returned 5 rows" in grounded_failure["final_answer"]
    assert "execution failed" not in grounded_failure["final_answer"].casefold()
    assert "no rows" not in grounded_failure["final_answer"].casefold()
    assert grounded_failure["response_metadata"]["query_executed"] is True
    assert grounded_failure["response_metadata"]["row_count"] == 5
    assert grounded_failure["response_metadata"]["result_rows"] == 5
    assert grounded_failure["response_metadata"]["execution_error"] is False
    assert grounded_failure["response_metadata"]["grounded"] is False
    assert grounded_failure["status"] == "completed"

    graph, _, _, _, _ = _build(
        executor=FakeQueryExecutor(records=[]),
        analysis_agent=FakeAnalysisAgent(
            analysis_summary=(
                "There is insufficient data because the query returned "
                "zero rows."
            ),
            sufficient_data=False,
        ),
        reporting_agent=ReportingAgent(llm=object()),  # type: ignore[arg-type]
    )
    zero_rows = graph.invoke(
        _state("Show sales by customer.")
    )
    assert zero_rows["execution_result"]["success"] is True
    assert zero_rows["execution_result"]["metadata"]["row_count"] == 0
    assert zero_rows["response_metadata"]["query_executed"] is True
    assert zero_rows["response_metadata"]["execution_error"] is False
    assert zero_rows["response_metadata"]["sufficient_data"] is False
    assert "returned zero rows" in zero_rows["final_answer"].casefold()
    assert "execution failed" not in zero_rows["final_answer"].casefold()

    preserved_result = None
    for snapshot in transition_states:
        current_result = snapshot["execution_result"]
        if (
            preserved_result is None
            and current_result.get("success") is True
        ):
            preserved_result = current_result
        if preserved_result is not None:
            assert current_result == preserved_result
            assert len(current_result["records"]) == 5
            assert current_result["metadata"]["row_count"] == 5
        assert "query_results" not in snapshot
        assert "execution_succeeded" not in snapshot
    assert preserved_result is not None

    graph, _, validator, executor, sql_agent = _build(
        validator=FakeSQLValidator(invalid_once=True),
    )
    retried = graph.invoke(_state("Show sales by customer."))
    assert retried["status"] == "completed", retried
    assert validator.calls == 2
    assert sql_agent.calls == 2
    assert retried["retry_count"] == 1
    assert executor.calls == 1

    graph, _, _, executor, sql_agent = _build(
        validator=FakeSQLValidator(terminal=True),
    )
    rejected = graph.invoke(_state("Show sales by customer."))
    assert rejected["status"] == "failed"
    assert executor.calls == 0
    assert sql_agent.calls == 1
    assert "was not executed" in rejected["final_answer"]

    graph, auth, _, executor, _ = _build()
    clarification = graph.invoke(_state("Compare sales."))
    assert clarification["status"] == "requires_clarification"
    assert "compare" in clarification["final_answer"].casefold()
    assert auth.lookups == 0
    assert executor.calls == 0

    graph, _, _, executor, _ = _build(role=UserRole.EMPLOYEE)
    denied = graph.invoke(_state("Show sales by customer."))
    assert denied["status"] == "failed"
    assert executor.calls == 0

    graph, _, _, executor, _ = _build(
        executor=FakeQueryExecutor(fail_once=True),
    )
    execution_retry = graph.invoke(_state("Show sales by customer."))
    assert execution_retry["status"] == "completed", execution_retry
    assert execution_retry["retry_count"] == 1
    assert executor.calls == 2

    graph, _, _, executor, sql_agent = _build(
        executor=FakeQueryExecutor(
            fail_once=True,
            retryable_failure=False,
        ),
    )
    permanent_failure = graph.invoke(_state("Show sales by customer."))
    assert permanent_failure["status"] == "failed"
    assert permanent_failure["retry_count"] == 0
    assert permanent_failure["execution_result"]["success"] is False
    assert permanent_failure["response_metadata"]["query_executed"] is True
    assert permanent_failure["response_metadata"]["execution_error"] is True
    assert executor.calls == 1
    assert sql_agent.calls == 1

    graph, _, _, executor, _ = _build()
    pending = graph.invoke(_state("Export all customer records."))
    assert pending["status"] == "requires_approval", pending
    assert pending["requires_human_approval"] is True
    assert executor.calls == 0
    pending["human_approved"] = True
    approved = graph.invoke(pending)
    assert approved["status"] == "completed", approved
    assert executor.calls == 1

    graph, _, _, executor, _ = _build()
    schema_answer = graph.invoke(_state("List the database tables."))
    assert schema_answer["status"] == "completed", schema_answer
    assert "salesorder" in schema_answer["final_answer"]
    assert executor.calls == 0

    print("Success, bounded retries, terminal SQL rejection, clarification,")
    print("authorization, human approval, and schema routes passed.")


if __name__ == "__main__":
    main()

def test_sql_validation_router_allows_last_retry_approved_by_handler() -> None:
    """The router must not reject a retry already approved by SQLRetryHandler."""
    state = {
        "status": "sql_generation",
        "next_node": "sql_agent",
        "retry_count": 2,
        "max_retries": 2,
        "terminal_error": False,
        "sql_validation_result": {"status": "requires_correction"},
    }
    assert route_after_sql_validation(state) == "sql_agent"


def test_sql_validation_router_stops_after_retry_exhaustion() -> None:
    state = {
        "status": "failed",
        "next_node": "reporting_agent",
        "retry_count": 2,
        "max_retries": 2,
        "terminal_error": True,
        "sql_validation_result": {"status": "invalid"},
    }
    assert route_after_sql_validation(state) == "reporting_agent"
